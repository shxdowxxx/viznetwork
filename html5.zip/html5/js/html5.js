(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib._1000WebGames = function() {
	this.initialize(img._1000WebGames);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,594,63);


(lib._1000Games = function() {
	this.initialize(img._1000Games);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,144,13);


(lib._1000bulta = function() {
	this.initialize(img._1000bulta);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,18,24);


(lib.acceleratePedal = function() {
	this.initialize(img.acceleratePedal);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,214,290);


(lib.ach1 = function() {
	this.initialize(img.ach1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,128,128);


(lib.ach10 = function() {
	this.initialize(img.ach10);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,128,128);


(lib.ach11 = function() {
	this.initialize(img.ach11);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,128,128);


(lib.ach12 = function() {
	this.initialize(img.ach12);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,128,128);


(lib.ach2 = function() {
	this.initialize(img.ach2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,128,128);


(lib.ach3 = function() {
	this.initialize(img.ach3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,128,128);


(lib.ach4 = function() {
	this.initialize(img.ach4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,128,128);


(lib.ach5 = function() {
	this.initialize(img.ach5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,128,128);


(lib.ach6 = function() {
	this.initialize(img.ach6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,128,128);


(lib.ach7 = function() {
	this.initialize(img.ach7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,128,128);


(lib.ach8 = function() {
	this.initialize(img.ach8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,128,128);


(lib.ach9 = function() {
	this.initialize(img.ach9);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,128,128);


(lib.button = function() {
	this.initialize(img.button);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,65,65);


(lib.check = function() {
	this.initialize(img.check);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,100,84);


(lib.clock = function() {
	this.initialize(img.clock);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,30,34);


(lib.drag = function() {
	this.initialize(img.drag);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,128,128);


(lib.explosion = function() {
	this.initialize(img.explosion);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,320,252);


(lib.icon1 = function() {
	this.initialize(img.icon1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon10 = function() {
	this.initialize(img.icon10);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon11 = function() {
	this.initialize(img.icon11);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon12 = function() {
	this.initialize(img.icon12);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon13 = function() {
	this.initialize(img.icon13);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon14 = function() {
	this.initialize(img.icon14);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon15 = function() {
	this.initialize(img.icon15);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon16 = function() {
	this.initialize(img.icon16);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon17 = function() {
	this.initialize(img.icon17);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon18 = function() {
	this.initialize(img.icon18);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon19 = function() {
	this.initialize(img.icon19);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon2 = function() {
	this.initialize(img.icon2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon20 = function() {
	this.initialize(img.icon20);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon3 = function() {
	this.initialize(img.icon3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon4 = function() {
	this.initialize(img.icon4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon5 = function() {
	this.initialize(img.icon5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon6 = function() {
	this.initialize(img.icon6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon7 = function() {
	this.initialize(img.icon7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon8 = function() {
	this.initialize(img.icon8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.icon9 = function() {
	this.initialize(img.icon9);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,340,170);


(lib.mouse = function() {
	this.initialize(img.mouse);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,53);


(lib.sakums = function() {
	this.initialize(img.sakums);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2020,980);


(lib.settings = function() {
	this.initialize(img.settings);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,128,113);


(lib.smoke = function() {
	this.initialize(img.smoke);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,64,64);


(lib.smoke2 = function() {
	this.initialize(img.smoke2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,64,64);


(lib.smoke3 = function() {
	this.initialize(img.smoke3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,64,64);


(lib.star0 = function() {
	this.initialize(img.star0);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,256,80);


(lib.star1 = function() {
	this.initialize(img.star1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,256,80);


(lib.star2 = function() {
	this.initialize(img.star2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,256,80);


(lib.star3 = function() {
	this.initialize(img.star3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,256,80);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.ts = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD440").s().p("AjvBGQAWgyAugZQAugaBEgDICugJQAUgBAMgHQANgGAGgOQAGgOgHgFQgIgFgUABIkpAPIBzhhIDXgLQAqgCAaAHQAbAGANAOQAMANAAAVQABAVgMAZQgKAXgRATQgRAUgXAOQgXAOgdAIQgeAJgjACIivAJQgTABgNAHQgMAFgGAOIgMAbIFjgSIhyBhImIATg");
	this.shape.setTransform(518.976,32.8265);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AjvBGQAWgyAugZQAugaBEgDICugJQAUgBAMgHQANgGAGgOQAGgOgHgFQgIgFgUABIkpAPIBzhhIDXgLQAqgCAaAHQAbAGANAOQAMANAAAVQABAVgMAZQgKAXgRATQgRAUgXAOQgXAOgdAIQgeAJgjACIivAJQgTABgNAHQgMAFgGAOIgMAbIFjgSIhyBhImIATg");
	this.shape_1.setTransform(520.726,34.5765);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer_5
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFCC33").s().p("EgkEABLMBIegDLIgVAYMhIeADpg");
	this.shape_2.setTransform(237,60.45);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ah0iTIFzgSIhkBVIjPAKIgRAlID+gMIhZBJIjEAKIgTAqIEQgNIhjBUIk0AQg");
	this.shape_3.setTransform(461.775,22.65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ai4CbQgfgLgQgUQgQgUgCgdQgCgdAPgiQAPghAbgdQAcgeAjgVQAjgWAogNQAogNApgCIDhgLIhkBVIigAIQgUABgUAHQgUAGgRALQgRAKgNAPQgOAOgHAQQgIARABANQABAOAJAKQAIAJAPAEQAPAFAUgBIDggLIhjBUIihAIIgNAAQghAAgZgIg");
	this.shape_4.setTransform(421.5182,24.2917);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("ABAh/QAQgOAUgMQAUgLAYgBQAXgBAKAJQALAJADAOIBMESIl0ATIBfhUIBQgEIAegCIAaAAIgGgUIgGgYIgVhPIjyDXIh1AFg");
	this.shape_5.setTransform(361.575,27.62);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ai+ADIEUgMQAXgCARgKQARgLAHgQQAIgRgJgJQgIgJgXACIkUANIBmhVIDJgKQAlgCAZAIQAaAHANAOQAOAPABAVQABAVgMAaQgLAbgUAWQgUAUgbARQgbAPgiAKQggAKgmACIinAIIgjBRIhjAFg");
	this.shape_6.setTransform(315.854,30.1039);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ai3BUIDygMQASgBALgGQAKgGAGgMQAEgMgFgFQgGgFgSABIiuAJQgfABgTgFQgUgGgKgKQgKgMAAgPQABgQAIgUQAKgWAQgTQAQgTAWgNQAXgOAdgIQAdgIAkgCIEXgOIhkBVIjeALQgSABgKAFQgKAFgGAMQgFANAGAEQAGAFARgBICugJQA8gDAVAUQAWATgUArQgKAYgRAUQgPATgXAOQgYAPgdAIQgcAIglACIkqAPg");
	this.shape_7.setTransform(270.05,32.125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ah/iSIBkgGIggBJIgNAdIgNAaIAhgVIAwghIB+hRICQgHIijBgIglAXIgcAQIgYANIgSAKIAWAVIAiAlIBXBhIiVAHIg8hNIgZggIgMgTIgJAXIgKAXIgoBaIhjAFg");
	this.shape_8.setTransform(208,35.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ai4CbQgfgLgQgUQgQgUgCgdQgCgdAPgiQAPghAbgdQAcgeAjgVQAjgWAogNQAogNApgCIDhgLIhkBVIigAIQgUABgUAHQgUAGgRALQgRAKgNAPQgOAOgHAQQgIARABANQABAOAJAKQAIAJAPAEQAPAFAUgBIDggLIhjBUIihAIIgNAAQghAAgZgIg");
	this.shape_9.setTransform(166.7182,36.8917);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AizCgQglgGgUgRQgTgRgBgaQgBgaAQgjIBOixIBjgEIhOCwQgIARgBAMQAAALAKAHQAKAHAXACQAXABAmgBQAdgCAUgEQAUgEAPgIQAPgJAKgMQAKgLAIgRIBOiwIBkgFIhOCwQg/CPjIAKIgdAAQgnAAgcgFg");
	this.shape_10.setTransform(119.4971,39.4329);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AjFAEIEXgNQAXgBAUgKQAUgLAHgQQAIgTgKgIQgKgIgaABIkXAOIBlhVIDNgLQAcgBAbAEQAbADATALQASAMAGAVQAGAVgPAiQgIASgNARQgNAQgRANQgQAOgTAKQgUAJgWAFQAGAGAGAJIAPAZIAhA6IiGAGIgjhPIiXAHIglBTIhjAFg");
	this.shape_11.setTransform(67.2107,42.4389);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhRhEIiXAIIBlhVIFsgSIhlBVIhyAGIhmDnIhjAFg");
	this.shape_12.setTransform(28.075,43.95);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#333333").s().p("EgkDABLMBIcgDLIgUAYMhIeADpg");
	this.shape_13.setTransform(237.75,61.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]}).wait(1));

	// Layer_3
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("Ah0iTIFzgTIhkBWIjPAKIgRAmID+gNIhZBKIjEAJIgTArIEQgOIhjBUIk0APg");
	this.shape_14.setTransform(462.825,24.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("Ai4CbQgfgLgQgUQgQgUgCgdQgCgdAPgiQAPghAbgdQAcgeAjgVQAjgWAogNQAogNApgCIDhgLIhkBVIigAIQgUABgUAHQgUAGgRALQgRAKgNAPQgOAOgHAQQgIARABANQABAOAJAKQAIAJAPAEQAPAFAUgBIDggLIhjBUIihAIIgNAAQghAAgZgIg");
	this.shape_15.setTransform(422.5682,26.0417);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("ABAh/QAQgOAUgMQAUgLAYgBQAXgBAKAJQALAJADAOIBMESIl0ATIBfhUIBQgEIAegCIAaAAIgGgUIgGgYIgVhPIjyDXIh1AFg");
	this.shape_16.setTransform(362.625,29.37);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#333333").s().p("Ai+ADIEUgMQAXgCARgKQARgLAHgQQAIgRgJgJQgIgJgXACIkUANIBmhVIDJgKQAlgCAZAIQAaAHANAOQAOAPABAVQABAVgMAaQgLAbgUAWQgUAUgbARQgbAPgiAKQggAKgmACIinAIIgjBRIhjAFg");
	this.shape_17.setTransform(316.904,31.8539);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("Ai3BUIDygMQASgBAKgGQALgGAFgMQAGgMgGgFQgGgFgSABIiuAJQgfABgUgFQgTgGgKgKQgKgMAAgPQAAgQAJgUQAKgWAQgTQAQgTAWgNQAWgOAegIQAdgIAjgCIEXgOIhjBVIjfALQgQABgLAFQgLAFgFAMQgFANAGAEQAGAFARgBICugJQA8gDAVAUQAVATgSArQgLAYgQAUQgRATgWAOQgYAPgcAIQgdAIglACIkrAPg");
	this.shape_18.setTransform(271.1,33.875);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("Ah/iTIBkgEIggBJIgNAcIgNAbIAggXIAyggIB9hRICQgHIijBhIglAVIgdARIgWANIgTAKIAWAVIAiAkIBYBiIiWAIIg9hPIgXgeIgNgUIgJAXIgKAXIgnBaIhkAFg");
	this.shape_19.setTransform(209.05,36.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#333333").s().p("Ai4CbQgfgLgQgUQgQgUgCgdQgCgdAPgiQAPghAbgdQAcgeAjgVQAjgWAogNQAogNApgCIDhgLIhkBVIigAIQgUABgUAHQgUAGgRALQgRAKgNAPQgOAOgHAQQgIARABANQABAOAJAKQAIAJAPAEQAPAFAUgBIDggLIhjBUIihAIIgNAAQghAAgZgIg");
	this.shape_20.setTransform(167.7682,38.6417);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#333333").s().p("AizCgQglgGgUgRQgTgRgBgaQgBgaAQgjIBOixIBjgEIhOCwQgIARgBAMQAAALAKAHQAKAHAXACQAXABAmgBQAdgCAUgEQAUgEAPgIQAPgJAKgMQAKgLAIgRIBOiwIBkgFIhOCwQg/CPjIAKIgdAAQgnAAgcgFg");
	this.shape_21.setTransform(120.5471,41.1829);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#333333").s().p("AjFAEIEXgNQAXgBAUgKQAUgLAHgQQAIgTgKgIQgKgIgaABIkXAOIBlhVIDNgLQAcgBAbAEQAbADATALQASAMAGAVQAGAVgPAiQgIASgNARQgNAQgRANQgQAOgTAKQgUAJgWAFQAGAGAGAJIAPAZIAhA6IiGAGIgjhPIiXAHIglBTIhjAFg");
	this.shape_22.setTransform(68.2607,44.1889);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AhRhDIiXAHIBlhVIFsgSIhlBVIhyAFIhmDoIhjAFg");
	this.shape_23.setTransform(29.125,45.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ts, new cjs.Rectangle(-13.6,-9.1,579.7,86.1), null);


(lib.timeWindow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.timetext = new cjs.Text("3 : 00", "14px 'Arial'", "#EBEBEB");
	this.timetext.name = "timetext";
	this.timetext.lineHeight = 18;
	this.timetext.parent = this;
	this.timetext.setTransform(26.75,5.8);

	this.instance = new lib.clock();
	this.instance.parent = this;
	this.instance.setTransform(5,4,0.4666,0.4632);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.timetext}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.timeWindow, new cjs.Rectangle(5,3.8,59.099999999999994,19.599999999999998), null);


(lib.stars = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1));

	// Layer_1
	this.instance = new lib.star0();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.2734,0.2733);

	this.instance_1 = new lib.star1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.2734,0.2733);

	this.instance_2 = new lib.star2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0,0,0.2734,0.2733);

	this.instance_3 = new lib.star3();
	this.instance_3.parent = this;
	this.instance_3.setTransform(0,0,0.2734,0.2733);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,70,21.9);


(lib.smokesymbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.smoke3();
	this.instance.parent = this;
	this.instance.setTransform(-32,-32);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32,-32,64,64);


(lib.smokesymbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.smoke2();
	this.instance.parent = this;
	this.instance.setTransform(-32,-32);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32,-32,64,64);


(lib.smokesymbol = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.smoke();
	this.instance.parent = this;
	this.instance.setTransform(-32,-32);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32,-32,64,64);


(lib.settingButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.settings();
	this.instance.parent = this;
	this.instance.setTransform(7,2,0.2111,0.2108);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").ss(1,1,1,3,true).p("ADGifIAAEeIAAAhImLAAIAAghIAAkeg");
	this.shape.setTransform(19.8,16);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#474747").ss(0.2,1,1).p("AivAAIFfAA");
	this.shape_1.setTransform(19.975,28.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("ACxCQIleAAIgYAAIAAkfIGLAAIAAEfg");
	this.shape_2.setTransform(19.8,14.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2E2E2E").s().p("AjFARIAAggIAYAAIFeAAIAVAAIAAAgg");
	this.shape_3.setTransform(19.8,30.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.settingButton, new cjs.Rectangle(-1,-1,41.6,34), null);


(lib.selectbackground = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AhKCVQgoAAAAgoIAAhnQAAgnAoAAICWAAQAnAAAAAnIAABnQAAAognAAgAgQAeQgGAGAAAJQAAAKAGAGIAFAFIAAAZQAAAFAEADQADADAEAAQAFAAADgDQADgDAAgFIAAgZIAFgFQAHgGAAgJQAAgKgHgGQgHgGgJAAQgJAAgHAGgAAtgsIAAgXQgBgUgMgNIgBAAQgNgNgSAAQgSAAgNANQgMANgCASIAAACIAAAXIgiAAIAAgXIAAgCIAAgBQACgfAVgXQAXgYAhAAQAhAAAXAYQAWAXABAfIAAABIAAACIAAAXg");
	this.shape.setTransform(57.4,26.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#666666").ss(0.2,1,1).p("Ao+AAIR9AA");
	this.shape_1.setTransform(57.5,57.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("Ao+BHIAAiMIR9AAIAACMg");
	this.shape_2.setTransform(57.5,64.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// Layer 1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("Ao+EgIAAo/IR9AAIAAI/g");
	this.shape_3.setTransform(57.5,28.675);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	// Layer_4
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#262626").s().p("Ao+FiIAArDIR9AAIAALDg");
	this.shape_4.setTransform(59.25,38.175);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

}).prototype = getMCSymbolPrototype(lib.selectbackground, new cjs.Rectangle(-1,-0.1,117.8,73.69999999999999), null);


(lib.ramitisselect = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(0.2,1,1).p("Ao+llIR9AAIAALLIx9AAg");
	this.shape.setTransform(57.5,35.775);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ramitisselect, new cjs.Rectangle(-1,-1,117,73.6), null);


(lib.mobilebuttons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.menuscore = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		menuscoresrc = this;
		menuscoresrc.stop();
		
		var menuscore = 0;
		for (i = 0; i < levelScores.length; i++) {
		    menuscore += levelScores[i];
			}
		menuscoresrc.scoreTxt.text = menuscore;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 3
	this.scoreTxt = new cjs.Text("10000", "bold 13px 'Arial'", "#E4E4E4");
	this.scoreTxt.name = "scoreTxt";
	this.scoreTxt.lineHeight = 15;
	this.scoreTxt.lineWidth = 40;
	this.scoreTxt.parent = this;
	this.scoreTxt.setTransform(30.6,5.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E4E4E4").s().p("AAAAsIg0AjIASg8IgygnIA/gBIAVg7IAVA8IBAADIgzAkIARA+g");
	this.shape.setTransform(16.5,10.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.scoreTxt}]}).wait(2));

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#999999").ss(0.2,1,1).p("Al5hvIBCDfIKxAA");
	this.shape_1.setTransform(37.8,11.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#424242").s().p("Ak3BwIhCjfILzAAIAADfg");
	this.shape_2.setTransform(37.8,11.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,77.6,24.4);


(lib.lgames = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._1000Games, null, new cjs.Matrix2D(1,0,0,1,-3.2,-6.5)).s().p("AggBBIAAiBIBAAAIAACBg");
	this.shape.setTransform(-68.75,0.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img._1000Games, null, new cjs.Matrix2D(1,0,0,1,-10.9,-6.5)).s().p("AhsBBIAAiBIDZAAIAACBg");
	this.shape_1.setTransform(-61.1,0.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(img._1000Games, null, new cjs.Matrix2D(1,0,0,1,-18.5,-6.5)).s().p("Ai4BBIAAiBIFxAAIAACBg");
	this.shape_2.setTransform(-53.475,0.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.bf(img._1000Games, null, new cjs.Matrix2D(1,0,0,1,-26.2,-6.5)).s().p("AkFBBIAAiBIILAAIAACBg");
	this.shape_3.setTransform(-45.825,0.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.bf(img._1000Games, null, new cjs.Matrix2D(1,0,0,1,-33.8,-6.5)).s().p("AlRBBIAAiBIKjAAIAACBg");
	this.shape_4.setTransform(-38.2,0.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.bf(img._1000Games, null, new cjs.Matrix2D(1,0,0,1,-41.4,-6.5)).s().p("AmeBBIAAiBIM8AAIAACBg");
	this.shape_5.setTransform(-30.55,0.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.bf(img._1000Games, null, new cjs.Matrix2D(1,0,0,1,-49.1,-6.5)).s().p("AnqBBIAAiBIPVAAIAACBg");
	this.shape_6.setTransform(-22.925,0.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.bf(img._1000Games, null, new cjs.Matrix2D(1,0,0,1,-56.7,-6.5)).s().p("Ao2BBIAAiBIRtAAIAACBg");
	this.shape_7.setTransform(-15.275,0.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.bf(img._1000Games, null, new cjs.Matrix2D(1,0,0,1,-64.3,-6.5)).s().p("AqDBBIAAiBIUHAAIAACBg");
	this.shape_8.setTransform(-7.65,0.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.bf(img._1000Games, null, new cjs.Matrix2D(1,0,0,1,-72,-6.5)).s().p("ArPBBIAAiBIWfAAIAACBg");
	this.shape_9.setTransform(0,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-72,-6,144,13);


(lib.levelload = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgRAdIAAg5IAIAAIAAAyIAbAAIAAAHg");
	this.shape.setTransform(1.425,-2.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgUAdIAAg5IAoAAIAAAHIghAAIAAASIAfAAIAAAGIgfAAIAAATIAiAAIAAAHg");
	this.shape_1.setTransform(-3.525,-2.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgDAdIgWg5IAIAAIAPApIACAJIADgJIAQgpIAHAAIgWA5g");
	this.shape_2.setTransform(-9,-2.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgUAdIAAg5IAoAAIAAAHIghAAIAAASIAfAAIAAAGIgfAAIAAATIAiAAIAAAHg");
	this.shape_3.setTransform(-14.225,-2.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgRAdIAAg5IAIAAIAAAyIAbAAIAAAHg");
	this.shape_4.setTransform(-19.075,-2.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgMAaQgGgEgEgHQgDgHAAgIQAAgHADgHQAEgIAGgDQAHgDAHgBQAGAAAFACQAFACADAEQADAEACAGIgHABIgDgHQgCgCgEgBQgDgCgFAAQgEAAgEACQgEABgCACQgCADgBADQgDAGAAAFQAAAHADAGQADAFAFACQAFACAEABQAFgBAFgBQAFgCACgDIAAgKIgRAAIAAgGIAYAAIAAAVQgFAEgGACQgGACgGABQgIAAgHgEg");
	this.shape_5.setTransform(-26.775,-2.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAPAdIgdgsIAAAsIgHAAIAAg5IAHAAIAeAsIAAgsIAHAAIAAA5g");
	this.shape_6.setTransform(-32.8,-2.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgDAdIAAg5IAHAAIAAA5g");
	this.shape_7.setTransform(-36.725,-2.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgXAdIAAg5IAUAAIAJABQAFABAEADQAEAEADAGQACAGAAAHQAAAGgCAFQgBAFgDAEIgFAFIgHADIgIABgAgPAWIAMAAIAIgBIAFgDQADgDABgEQACgFAAgGQAAgIgDgFQgDgFgEgCIgJgBIgMAAg");
	this.shape_8.setTransform(-40.675,-2.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgRAdIAAg5IAIAAIAAAyIAbAAIAAAHg");
	this.shape_9.setTransform(-45.725,-2.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgDAdIAAg5IAHAAIAAA5g");
	this.shape_10.setTransform(-49.175,-2.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgMAaQgGgCgCgGQgBgFAAgJIAAggIAHAAIAAAgQAAAHACAEQABAEADABQADACAFAAQAIAAADgDQAEgEAAgLIAAggIAIAAIAAAgQAAAJgCAFQgCAFgFADQgGADgIAAQgHAAgFgDg");
	this.shape_11.setTransform(-53.2,-2.875);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgUAdIAAg5IAUAAQAGAAAEACQAFACABAEQADADAAAEQAAAEgCADQgCADgEACQAFABADADQADAEAAAFQAAAEgCAEQgCADgDACIgGADIgJABgAgNAWIANAAIAGAAIADgCQABAAAAAAQABgBAAAAQABgBAAAAQAAgBABAAQAAgBAAAAQAAgBABAAQAAgBAAgBQAAAAAAgBQAAgDgCgCQgCgDgDgBIgHgBIgNAAgAgNgDIAMAAIAHgBQADgBABgCQACgCAAgDQAAgDgCgCQgBgCgDgBIgIgBIgLAAg");
	this.shape_12.setTransform(-58.7,-2.925);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_13.setTransform(6.85,-0.45);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_14.setTransform(6.85,-0.45);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_15.setTransform(6.85,-0.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.shape_13,p:{x:6.85}}]},19).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.shape_14,p:{x:6.85}},{t:this.shape_13,p:{x:9.05}}]},20).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.shape_15},{t:this.shape_14,p:{x:9.05}},{t:this.shape_13,p:{x:11.25}}]},20).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.shape_15},{t:this.shape_14,p:{x:9.05}},{t:this.shape_13,p:{x:11.25}}]},20).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63.4,-9.2,77.9,12.899999999999999);


(lib.ievads = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.sakums();
	this.instance.parent = this;
	this.instance.setTransform(0,-410,0.4763,0.4763);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8EC4F2").s().p("EhLKBHqMAAAiPTMCWVAAAMAAACPTg");
	this.shape.setTransform(481.075,-865.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ievads, new cjs.Rectangle(0,-1324.1,962.2,1380.8999999999999), null);


(lib.fons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#303030").s().p("Egx/AcIMAAAg4PMBj/AAAMAAAA4Pg");
	this.shape.setTransform(320,180);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.fons, new cjs.Rectangle(0,0,640,360), null);


(lib.explosionsymbol = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.explosion();
	this.instance.parent = this;
	this.instance.setTransform(-160,-90);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.explosionsymbol, new cjs.Rectangle(-160,-90,320,252), null);


(lib.closeoptions2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,1,1).p("AAAAAIiUCRAAAAAICVCRACViQIiVCQAiUiQICUCQ");
	this.shape.setTransform(17.025,18.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(66,66,66,0.02)").s().p("AjvEFIAAoJIHfAAIAAIJg");
	this.shape_1.setTransform(18.5716,16.3939,1.7208,1.4012);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.closeoptions2, new cjs.Rectangle(-22.7,-20.1,82.6,73.1), null);


(lib.closeoptions = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,1,1).p("AiUiQICUCQIiUCRACViQIiVCQICVCR");
	this.shape.setTransform(17.025,18.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(66,66,66,0.02)").s().p("AjvEFIAAoJIHfAAIAAIJg");
	this.shape_1.setTransform(18.55,16.375);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.closeoptions, new cjs.Rectangle(-5.4,-9.7,48,52.2), null);


(lib.buttonbackground = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#474747").ss(0.2,1,1).p("Au3AAIdvAA");
	this.shape.setTransform(97.6,28.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#999999").ss(1,1,1,3,true).p("AvNifIebAAIAAEeIAAAhI+bAAIAAghg");
	this.shape_1.setTransform(97.425,16);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2E2E2E").s().p("AvNARIAAggIAYAAIdvAAIAUAAIAAAgg");
	this.shape_2.setTransform(97.425,30.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AO6CQI9vAAIgYAAIAAkfIebAAIAAEfg");
	this.shape_3.setTransform(97.425,14.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.buttonbackground, new cjs.Rectangle(-1,-1,196.9,34), null);


(lib.bultapreloader = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._1000bulta();
	this.instance.parent = this;
	this.instance.setTransform(-9,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.bultapreloader, new cjs.Rectangle(-9,-12,18,24), null);


(lib.black = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B2B2B").s().p("EhBJAk0MAAAhJnMCCTAAAMAAABJng");
	this.shape.setTransform(420.7624,230.9035,1.0204,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.black, new cjs.Rectangle(-4.7,-4.6,851,471.1), null);


(lib.achievementramis = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(1,1,1,3,true).p("AgqgqIBVAAIAABVIhVAAg");
	this.shape.setTransform(179.925,32.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#CCCCCC").ss(0.2,1,1).p("AvDjHIeHAAIAAGPI+HAAg");
	this.shape_1.setTransform(96.35,19.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AvDDIIAAmPIeGAAIAAGPg");
	this.shape_2.setTransform(96.35,19.975);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// Layer_4
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#262626").s().p("AvDDJIAAmRIeHAAIAAGRg");
	this.shape_3.setTransform(98.1,21.825);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.achievementramis, new cjs.Rectangle(-1,-1,195.5,43), null);


(lib.achievement_unlocked = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(13));

	// Layer_2
	this.instance = new lib.check();
	this.instance.parent = this;
	this.instance.setTransform(187,-1,0.1602,0.161);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(12));

	// Layer_1
	this.instance_1 = new lib.ach1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(174,-3,0.164,0.164);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33FF99").s().p("AgPAvIADgOIAMAAIgCAOgAgIAXIAHgxIADgUIAOAAIgEAVIgNAwg");
	this.shape.setTransform(163.6,9.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#33FF99").s().p("AgcAoQgGgHAAgNQAAgNAEgJQAGgKAHgFQAHgFAIAAQAMAAAGAMIAIgkIAMAAIgUBcIgLAAIADgKQgKALgLAAQgJAAgGgHgAgIgLQgEACgEAEQgCAFgDAGQgCAGAAAGIABALQACAEADACQAEADAEAAQAIAAAFgIQAIgLAAgQQAAgHgDgEQgFgFgFAAQgEAAgDACg");
	this.shape_1.setTransform(158.25,9.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#33FF99").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_2.setTransform(150.525,10.375);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#33FF99").s().p("AAKAvIgNgjIgOAMIgEAXIgMAAIAUhdIALAAIgMA5IAhgfIAPAAIgdAYIARArg");
	this.shape_3.setTransform(144.075,9.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#33FF99").s().p("AgWAcQgHgHAAgNQABgKAEgKQAEgLAIgGQAIgFAKAAQAKAAAHAGQAGAGAAAKIgLABQAAgGgEgEQgEgEgFAAQgGAAgFAFQgFAEgDAJQgDAIAAAIQAAAJADAEQAEAEAGAAQAEAAAGgEQAFgEADgJIAMABQgFANgIAGQgIAGgJAAQgLAAgHgHg");
	this.shape_4.setTransform(137.45,10.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#33FF99").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_5.setTransform(130.325,10.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#33FF99").s().p("AgPAvIAThdIAMAAIgTBdg");
	this.shape_6.setTransform(125.5,9.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#33FF99").s().p("AAKAjIAJgqIABgJQAAgEgBgCQgDgCgFAAQgIAAgGAHQgHAFgDAPIgGAgIgMAAIAOhDIAKAAIgCAMQAHgHAEgEQAHgDAFAAQAJABAFAEQAEAEAAAIIgCALIgIApg");
	this.shape_7.setTransform(120,10.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#33FF99").s().p("AgaAeQgFgEAAgHIACgPIAIglIAMAAIgJAqIgCAIQAAAEADACQACACAFAAQAEAAAFgCQAEgDADgEQADgEACgFIAEgMIAGgcIALAAIgOBCIgKAAIACgMQgLANgNAAQgIABgEgFg");
	this.shape_8.setTransform(113.125,10.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#33FF99").s().p("AgNAsQgDgEAAgDIABgLIAIgmIgJAAIACgJIAJAAIAEgRIAMgHIgFAYIALAAIgCAJIgLAAIgHAkIgBAIIABAEIADABIAGgBIgBAKIgHABQgHAAgEgDg");
	this.shape_9.setTransform(104.375,9.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#33FF99").s().p("AALAjIAJgqIAAgJQABgEgCgCQgDgCgFAAQgIAAgGAHQgHAFgDAPIgHAgIgLAAIAOhDIALAAIgDAMQAHgHAEgEQAGgDAGAAQAJABAFAEQAEAEAAAIIgCALIgIApg");
	this.shape_10.setTransform(98.3,10.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#33FF99").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_11.setTransform(91.175,10.375);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#33FF99").s().p("AAcAjIAKgsIABgIQAAgDgCgCQgCgCgEAAQgFAAgGADQgEADgDAFQgDAGgDAJIgHAhIgKAAIAKgtIAAgGQAAgEgBgCQgDgCgDAAQgFAAgGADQgEADgEAGQgEAFgBAJIgHAhIgLAAIANhDIAMAAIgDALQAHgHAFgDQAFgDAGAAQAFABAFADQAEADABAGQAFgGAGgEQAGgDAGAAQAIAAAEAFQAFAEAAAHIgCAKIgJArg");
	this.shape_12.setTransform(82.05,10.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#33FF99").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_13.setTransform(73.075,10.375);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#33FF99").s().p("AgTAiIgLhDIALAAIAGAkIACAUIAIgQIAWgoIAMAAIglBDg");
	this.shape_14.setTransform(66.95,10.375);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#33FF99").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_15.setTransform(59.325,10.375);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#33FF99").s().p("AgPAvIAPhDIAKAAIgNBDgAABggIADgOIAMAAIgDAOg");
	this.shape_16.setTransform(54.6,9.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#33FF99").s().p("AALAvIAIgqIACgJQAAgEgCgCQgDgCgEAAQgHAAgFAEQgEACgEAGQgDAFgCANIgHAdIgLAAIAThdIALAAIgGAkQAGgGAEgDQAGgDAFAAQAJABAFAEQAEAEAAAIIgCALIgIApg");
	this.shape_17.setTransform(49.05,9.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#33FF99").s().p("AgWAcQgHgHABgNQAAgKADgKQAFgLAIgGQAJgFAJAAQAKAAAHAGQAGAGAAAKIgLABQAAgGgEgEQgEgEgFAAQgGAAgFAFQgGAEgCAJQgDAIAAAIQAAAJADAEQAFAEAFAAQAFAAAFgEQAFgEADgJIAMABQgFANgIAGQgIAGgJAAQgLAAgHgHg");
	this.shape_18.setTransform(42.6,10.375);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#33FF99").s().p("AgZAeQgFgGAAgIQAAgGACgEQADgFAEgBIALgEIANgBQALgBAEgCIACgHQAAgEgDgDQgEgDgHAAQgHAAgEADQgFAEgCAGIgLgBQADgLAIgFQAIgFAKAAQAMAAAIAGQAFAEABAHIgCANIgEAQIgCANIABAJIgLAAIgBgJQgGAGgGACQgEACgHAAQgJAAgGgFgAAMABIgJABIgNACQgEACgDADQgCADAAADQAAAFADADQAEADAGAAQAFAAAFgDQAFgDAEgFQADgFABgKIgFABg");
	this.shape_19.setTransform(35.35,10.375);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#33FF99").s().p("AAAAiIgBgnIgBgOIgGAPIgSAmIgMAAIgHhDIAMAAIADAfIABAQIAAAHIADgKIAFgJIAQgjIALAAIACAhIABAVIALgXIAOgfIALAAIggBDg");
	this.shape_20.setTransform(24.2,10.375);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#33FF99").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_21.setTransform(15.175,10.375);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#33FF99").s().p("AAOAvIgWg1IgJgaIgEAXIgMA4IgMAAIAThdIAMAAIAPAjIALAaIAGARIAFgYIALg2IAMAAIgUBdg");
	this.shape_22.setTransform(7.25,9.1);

	this.instance_2 = new lib.ach2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(174,-3,0.164,0.164);

	this.instance_3 = new lib.ach3();
	this.instance_3.parent = this;
	this.instance_3.setTransform(174,-3,0.164,0.164);

	this.instance_4 = new lib.ach4();
	this.instance_4.parent = this;
	this.instance_4.setTransform(174,-3,0.164,0.164);

	this.instance_5 = new lib.ach5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(174,-3,0.164,0.164);

	this.instance_6 = new lib.ach6();
	this.instance_6.parent = this;
	this.instance_6.setTransform(174,-3,0.164,0.164);

	this.instance_7 = new lib.ach7();
	this.instance_7.parent = this;
	this.instance_7.setTransform(174,-3,0.164,0.164);

	this.instance_8 = new lib.ach8();
	this.instance_8.parent = this;
	this.instance_8.setTransform(174,-3,0.164,0.164);

	this.instance_9 = new lib.ach9();
	this.instance_9.parent = this;
	this.instance_9.setTransform(174,-3,0.164,0.164);

	this.instance_10 = new lib.ach10();
	this.instance_10.parent = this;
	this.instance_10.setTransform(174,-3,0.164,0.164);

	this.instance_11 = new lib.ach11();
	this.instance_11.parent = this;
	this.instance_11.setTransform(174,-3,0.164,0.164);

	this.instance_12 = new lib.ach12();
	this.instance_12.parent = this;
	this.instance_12.setTransform(174,-3,0.164,0.164);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_1}]},1).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_2}]},1).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_3}]},1).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_4}]},1).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_5}]},1).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_6}]},1).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_7}]},1).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_8}]},1).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_9}]},1).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_10}]},1).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_11}]},1).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_12}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-3,203,21.5);


(lib.achievement_lock = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("Ag6B0QgfAAAAgeIAAhSQAAgeAfAAIB1AAQAfAAAAAeIAABSQAAAegfAAgAgMAYQgFAEAAAHQAAAIAFAFIAEADIAAAUQAAAEADADQACABADAAQAEAAACgBQADgDAAgEIAAgUIADgDQAGgFAAgHQAAgIgGgEQgGgFgGgBQgHABgFAFgAAjgiIAAgTQgBgPgKgJIAAAAQgKgMgOAAQgOAAgKAMQgJAJgCAOIAAABIAAATIgaAAIAAgTIAAgBIAAgBQABgYAQgSQATgTAZAAQAaAAASATQARASABAYIAAABIAAABIAAATg");
	this.shape.setTransform(20,19.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	// Layer_6
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#CCCCCC").ss(0.1,1,1).p("AititIFbAAIAAFbIlbAAg");
	this.shape_1.setTransform(20.025,20.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AitCuIAAlbIFbAAIAAFbg");
	this.shape_2.setTransform(20.025,20.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1.6,1.6,36.9,36.9);


(lib._1000WebGames_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib._1000WebGames();
	this.instance.parent = this;
	this.instance.setTransform(-297,-31.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib._1000WebGames_1, new cjs.Rectangle(-297,-31.5,594,63), null);


(lib.tryagainbutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E3E3E3").s().p("AASAvIgkg8IAAA8IgSAAIAAhcIASAAIAlA8IAAg8IASAAIAABcg");
	this.shape.setTransform(90.6,16.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E3E3E3").s().p("AgIAvIAAhcIARAAIAABcg");
	this.shape_1.setTransform(84.175,16.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E3E3E3").s().p("AAaAvIgIgVIgkAAIgIAVIgUAAIAkhcIATAAIAmBcgAgMAKIAYAAIgMgig");
	this.shape_2.setTransform(77.625,16.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E3E3E3").s().p("AgVAqQgKgGgGgMQgFgLAAgNQAAgOAGgLQAGgMAMgFQAIgFANAAQARAAAKAHQAJAHAEANIgTAEQgCgHgFgEQgGgEgIAAQgLAAgHAHQgIAJAAAPQAAAPAIAJQAHAIAKAAQAHAAAFgCQAHgDAEgDIAAgMIgWAAIAAgPIApAAIAAAkQgGAHgLAEQgLAEgMAAQgNAAgMgGg");
	this.shape_3.setTransform(67.8,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E3E3E3").s().p("AAaAvIgIgVIgkAAIgIAVIgUAAIAkhcIATAAIAmBcgAgMAKIAYAAIgMgig");
	this.shape_4.setTransform(58.125,16.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E3E3E3").s().p("AgIAvIAAgnIgjg1IAXAAIAUAlIAVglIAXAAIgjA1IAAAng");
	this.shape_5.setTransform(46.3,16.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E3E3E3").s().p("AATAvIgNgUIgJgPQgDgCgDgBIgJgBIgEAAIAAAnIgTAAIAAhcIAoAAQAOAAAHACQAGADAEAGQAEAHAAAHQAAALgGAHQgGAFgMACQAGAEAEAEIALAQIALASgAgWgGIAOAAQAMAAAEgBQADgBACgEQACgCAAgEQAAgFgCgDQgDgDgFgBIgMAAIgPAAg");
	this.shape_6.setTransform(38.175,16.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E3E3E3").s().p("AgIAvIAAhNIgcAAIAAgPIBJAAIAAAPIgcAAIAABNg");
	this.shape_7.setTransform(29.075,16.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.instance = new lib.buttonbackground();
	this.instance.parent = this;
	this.instance.setTransform(60.15,16,0.6159,1,0,0,0,97.5,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tryagainbutton, new cjs.Rectangle(0.1,0,120,32), null);


(lib.dums = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_33 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(33).call(this.frame_33).wait(1));

	// Layer 1
	this.instance = new lib.smokesymbol("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.0469,0.0469);
	this.instance.alpha = 0.1992;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({scaleX:0.4219,scaleY:0.4219,alpha:0.7891},8).to({scaleX:1.3906,scaleY:1.3906,alpha:0},24).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-44.4,-44.4,89,89);


(lib.selectlevelbutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape.setTransform(101.925,16.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_1.setTransform(93.475,16.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("AgJAvIghhcIAUAAIAXBDIAWhDIAUAAIghBcg");
	this.shape_2.setTransform(84.675,16.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_3.setTransform(76.175,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape_4.setTransform(68.025,16.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("AgIAvIAAhNIgcAAIAAgPIBJAAIAAAPIgcAAIAABNg");
	this.shape_5.setTransform(56.175,16.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCCCC").s().p("AgbAkQgMgNgBgWQABgWAMgNQALgNATAAQARAAALAKQAGAGADALIgSAFQgCgIgFgEQgGgEgGAAQgKAAgHAHQgGAIAAAQQAAARAGAHQAHAIAJAAQAHAAAGgEQAFgGACgKIASAGQgDAQgKAGQgKAIgPAAQgSAAgLgMg");
	this.shape_6.setTransform(47.45,16.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCCCC").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_7.setTransform(38.625,16.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CCCCCC").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape_8.setTransform(30.475,16.425);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CCCCCC").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_9.setTransform(22.025,16.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CCCCCC").s().p("AgZAoQgKgIgCgQIASgCQACAKAFAEQAFAFAIgBQAJAAAEgDQAFgEAAgFQAAgEgCgCQgCgDgEgBIgPgFQgPgDgGgFQgIgHAAgLQAAgIADgFQAFgHAHgDQAIgDAKAAQARAAAJAHQAJAIAAANIgTABQgBgHgDgEQgEgDgIAAQgIABgFADQgCACAAADQAAAEACACQAEADANADQANADAHAEQAGAEAEAEQAEAHAAAJQAAAHgFAIQgEAGgIAEQgIADgMAAQgRAAgJgIg");
	this.shape_10.setTransform(13.15,16.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.instance = new lib.buttonbackground();
	this.instance.parent = this;
	this.instance.setTransform(57.6,16,0.6723,1,0,0,0,96.8,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.selectlevelbutton, new cjs.Rectangle(-7.5,0,131,32), null);


(lib.select20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("20", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 21;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon20();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("19", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 21;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon19();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("18", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 21;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon18();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("17", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 21;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon17();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("16", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 21;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon16();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("15", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 21;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon15();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("14", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 21;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon14();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("13", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 21;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon13();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("12", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 21;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("11", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 21;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon11();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("10", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 21;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon10();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("9", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 10;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon9();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("8", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 10;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon8();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("7", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 10;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon7();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("6", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 10;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon6();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("5", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 10;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon5();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("4", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 10;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("3", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 10;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.text = new cjs.Text("2", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 10;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3382,0.3384);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.select1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_3
	this.text = new cjs.Text("1", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 20;
	this.text.lineWidth = 10;
	this.text.parent = this;
	this.text.setTransform(3.05,2.8);

	this.instance = new lib.ramitisselect();
	this.instance.parent = this;
	this.instance.setTransform(57.5,35.8,1,1,0,0,0,57.5,35.8);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(94.6,67.8,0.4857,0.48,0,0,0,35.3,18);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.stars},{t:this.instance},{t:this.text}]}).to({state:[{t:this.stars},{t:this.text},{t:this.instance}]},1).wait(1));

	// Layer 1
	this.instance_1 = new lib.icon1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.3383,0.3383);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({scaleY:0.3386},0).wait(1));

	// Layer 2
	this.instance_2 = new lib.selectbackground();
	this.instance_2.parent = this;
	this.instance_2.setTransform(57.5,32.4,1,1,0,0,0,57.5,32.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,116.89999999999999,73.69999999999999);


(lib.playagainbutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E3E3E3").s().p("AASAvIgkg8IAAA8IgSAAIAAhcIASAAIAlA8IAAg8IASAAIAABcg");
	this.shape.setTransform(95.1,16.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E3E3E3").s().p("AgIAvIAAhcIARAAIAABcg");
	this.shape_1.setTransform(88.675,16.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E3E3E3").s().p("AAaAvIgIgVIgkAAIgIAVIgUAAIAkhcIATAAIAmBcgAgMAKIAYAAIgMgig");
	this.shape_2.setTransform(82.125,16.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E3E3E3").s().p("AgVAqQgKgGgGgMQgFgLgBgNQABgOAGgLQAGgMAMgFQAIgFANAAQARAAAKAHQAJAHAEANIgTAEQgCgHgFgEQgGgEgIAAQgLAAgHAHQgIAJAAAPQAAAPAIAJQAHAIAKAAQAHAAAFgCQAHgDAEgDIAAgMIgWAAIAAgPIApAAIAAAkQgGAHgLAEQgLAEgMAAQgNAAgMgGg");
	this.shape_3.setTransform(72.3,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E3E3E3").s().p("AAaAvIgIgVIgkAAIgIAVIgUAAIAkhcIATAAIAmBcgAgMAKIAYAAIgMgig");
	this.shape_4.setTransform(62.625,16.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E3E3E3").s().p("AgIAvIAAgnIgjg1IAXAAIAUAlIAVglIAXAAIgjA1IAAAng");
	this.shape_5.setTransform(50.8,16.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E3E3E3").s().p("AAaAvIgIgVIgkAAIgIAVIgUAAIAkhcIATAAIAmBcgAgMAKIAYAAIgMgig");
	this.shape_6.setTransform(42.925,16.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E3E3E3").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape_7.setTransform(34.575,16.425);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E3E3E3").s().p("AgjAvIAAhcIAeAAQARAAAFABQAIACAFAHQAGAHgBALQAAAJgCAFQgEAGgEACQgFAEgFABQgGABgMAAIgNAAIAAAkgAgQgEIAKAAQALABAEgCQADgCADgCQACgEAAgDQAAgGgDgDQgDgDgFgBIgNgBIgJAAg");
	this.shape_8.setTransform(26.15,16.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.instance = new lib.buttonbackground();
	this.instance.parent = this;
	this.instance.setTransform(60.05,16,0.6158,1,0,0,0,97.5,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.playagainbutton, new cjs.Rectangle(0,0,120,32), null);


(lib.openoptions = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.instance = new lib.settingButton();
	this.instance.parent = this;
	this.instance.setTransform(59.3,305.95,1,1,0,0,0,58,15.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.openoptions, new cjs.Rectangle(1.3,290.3,39.6,32), null);


(lib.playButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape.setTransform(89.525,16.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("AAbAvIAAhJIgSBJIgRAAIgShJIAABJIgSAAIAAhcIAcAAIAQA+IARg+IAcAAIAABcg");
	this.shape_1.setTransform(79.6,16.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("AAaAvIgIgVIgkAAIgIAVIgUAAIAkhcIATAAIAmBcgAgMAKIAYAAIgMgig");
	this.shape_2.setTransform(69.475,16.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AgUAqQgMgGgFgMQgGgLAAgNQAAgOAHgLQAGgMALgFQAKgFAMAAQARAAAKAHQAKAHADANIgTAEQgCgHgGgEQgFgEgIAAQgLAAgIAHQgHAJAAAPQAAAPAHAJQAIAIALAAQAFAAAHgCQAFgDAFgDIAAgMIgWAAIAAgPIAoAAIAAAkQgFAHgMAEQgLAEgLAAQgNAAgLgGg");
	this.shape_3.setTransform(59.65,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AATAvIgThFIgSBFIgUAAIgWhcIATAAIAOA/IARg/IAWAAIAQBAIAOhAIATAAIgWBcg");
	this.shape_4.setTransform(45,16.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_5.setTransform(34.675,16.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCCCC").s().p("AASAvIglg8IAAA8IgRAAIAAhcIASAAIAlA8IAAg8IASAAIAABcg");
	this.shape_6.setTransform(25.45,16.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 3
	this.instance = new lib.buttonbackground();
	this.instance.parent = this;
	this.instance.setTransform(57.6,16,0.6723,1,0,0,0,96.8,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.playButton, new cjs.Rectangle(-7.5,0,131,32), null);


(lib.moregamesbutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D9D9D9").s().p("AgZAoQgKgIgCgQIASgCQACAKAFAEQAFAFAIgBQAJAAAEgDQAFgEAAgFQAAgEgCgCQgCgDgEgBIgPgFQgPgDgGgFQgIgHAAgLQAAgIADgFQAFgHAHgDQAIgDAKAAQARAAAJAHQAJAIAAANIgTABQgBgHgDgEQgEgDgIAAQgIABgFADQgCACAAADQAAAEACACQAEADAMADQAOADAHAEQAGAEAEAEQAEAHAAAJQAAAHgFAIQgEAGgIAEQgIADgMAAQgRAAgJgIg");
	this.shape.setTransform(100.45,16.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D9D9D9").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_1.setTransform(92.025,16.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D9D9D9").s().p("AAcAvIAAhJIgTBJIgRAAIgShJIAABJIgSAAIAAhcIAdAAIAPA+IARg+IAcAAIAABcg");
	this.shape_2.setTransform(82.1,16.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D9D9D9").s().p("AAaAvIgIgVIgkAAIgIAVIgUAAIAkhcIATAAIAmBcgAgMAKIAYAAIgMgig");
	this.shape_3.setTransform(71.975,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D9D9D9").s().p("AgUAqQgLgGgGgMQgFgLgBgNQABgOAGgLQAGgMAMgFQAJgFAMAAQARAAAKAHQAKAHADANIgTAEQgCgHgFgEQgGgEgIAAQgLAAgIAHQgHAJAAAPQAAAPAHAJQAIAIAKAAQAHAAAGgCQAFgDAFgDIAAgMIgWAAIAAgPIApAAIAAAkQgGAHgMAEQgLAEgLAAQgOAAgKgGg");
	this.shape_4.setTransform(62.15,16.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D9D9D9").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_5.setTransform(49.425,16.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D9D9D9").s().p("AATAvIgNgUIgJgPQgDgCgDgBIgJgBIgEAAIAAAnIgTAAIAAhcIAoAAQAOAAAHACQAGADAEAGQAEAHAAAHQAAALgGAHQgGAFgMACQAGAEAEAEIALAQIALASgAgWgGIAOAAQAMAAAEgBQADgBACgEQACgCAAgEQAAgFgCgDQgDgDgFgBIgMAAIgPAAg");
	this.shape_6.setTransform(40.675,16.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D9D9D9").s().p("AggAkQgMgNAAgWQAAgNAEgLQADgGAGgGQAFgFAHgDQAJgEAKAAQAUAAANANQAMANAAAVQAAAXgMANQgMAMgVAAQgUAAgMgMgAgSgXQgHAIAAAPQAAAPAIAJQAHAIAKAAQALAAAIgIQAHgIAAgQQAAgQgHgHQgHgIgMAAQgLAAgHAIg");
	this.shape_7.setTransform(30.525,16.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D9D9D9").s().p("AAcAvIAAhJIgTBJIgRAAIgShJIAABJIgSAAIAAhcIAdAAIAPA+IARg+IAcAAIAABcg");
	this.shape_8.setTransform(20,16.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.instance = new lib.buttonbackground();
	this.instance.parent = this;
	this.instance.setTransform(60,16,0.6159,1,0,0,0,97.4,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.moregamesbutton, new cjs.Rectangle(0,0,120,32), null);


(lib.morefinishbutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E3E3E3").s().p("AgaAoQgJgIgCgQIASgCQACAKAFAEQAFAFAIgBQAJAAAFgDQAEgEAAgFQAAgEgCgCQgCgDgFgBIgNgFQgQgDgGgFQgJgHAAgLQAAgIAFgFQADgHAIgDQAIgDAKAAQARAAAJAHQAJAIAAANIgTABQgBgHgEgEQgDgDgIAAQgIABgEADQgEACAAADQAAAEAEACQADADANADQAOADAGAEQAHAEADAEQAEAHAAAJQAAAHgEAIQgFAGgIAEQgJADgMAAQgQAAgKgIg");
	this.shape.setTransform(100.95,16.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E3E3E3").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_1.setTransform(92.525,16.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E3E3E3").s().p("AAbAvIAAhJIgSBJIgRAAIgThJIAABJIgRAAIAAhcIAcAAIAQA+IARg+IAcAAIAABcg");
	this.shape_2.setTransform(82.6,16.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E3E3E3").s().p("AAaAvIgIgVIgkAAIgIAVIgUAAIAkhcIATAAIAmBcgAgMAKIAYAAIgMgig");
	this.shape_3.setTransform(72.475,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E3E3E3").s().p("AgVAqQgLgGgFgMQgGgLABgNQAAgOAGgLQAGgMALgFQAJgFANAAQASAAAJAHQAJAHADANIgSAEQgCgHgGgEQgFgEgIAAQgLAAgHAHQgIAJAAAPQAAAPAIAJQAHAIALAAQAFAAAGgCQAHgDAEgDIAAgMIgWAAIAAgPIAoAAIAAAkQgFAHgLAEQgMAEgLAAQgOAAgLgGg");
	this.shape_4.setTransform(62.65,16.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E3E3E3").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_5.setTransform(49.925,16.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E3E3E3").s().p("AATAvIgNgUIgJgPQgDgCgDgBIgJgBIgEAAIAAAnIgTAAIAAhcIAoAAQAOAAAHACQAGADAEAGQAEAHAAAHQAAALgGAHQgGAFgMACQAGAEAEAEIALAQIALASgAgWgGIAOAAQAMAAAEgBQADgBACgEQACgCAAgEQAAgFgCgDQgDgDgFgBIgMAAIgPAAg");
	this.shape_6.setTransform(41.175,16.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E3E3E3").s().p("AggAkQgMgNAAgWQAAgNAEgLQADgGAGgGQAFgFAHgDQAJgEAKAAQAUAAANANQAMANAAAVQAAAXgMANQgMAMgVAAQgUAAgMgMgAgSgXQgHAIAAAPQAAAPAIAJQAHAIAKAAQALAAAIgIQAHgIAAgQQAAgQgHgHQgHgIgMAAQgLAAgHAIg");
	this.shape_7.setTransform(31.025,16.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E3E3E3").s().p("AAbAvIAAhJIgSBJIgRAAIgThJIAABJIgRAAIAAhcIAcAAIAQA+IARg+IAcAAIAABcg");
	this.shape_8.setTransform(20.5,16.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.instance = new lib.buttonbackground();
	this.instance.parent = this;
	this.instance.setTransform(60.05,16,0.6158,1,0,0,0,97.5,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.morefinishbutton, new cjs.Rectangle(0,0,120,32), null);


(lib.mainmenubutton2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D9D9D9").s().p("AgSAsQgHgDgEgFQgEgFgBgFQgCgIAAgQIAAgwIATAAIAAAxQAAAMABAEQABAFAEAEQAEADAIAAQAHAAAEgDQAEgDACgFIAAgQIAAgyIATAAIAAAwQAAAQgBAHQgCAHgEAFQgEAFgHADQgHACgLAAQgMAAgHgDg");
	this.shape.setTransform(91.55,16.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D9D9D9").s().p("AASAvIglg8IAAA8IgRAAIAAhcIASAAIAlA8IAAg8IASAAIAABcg");
	this.shape_1.setTransform(82.15,16.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D9D9D9").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_2.setTransform(73.325,16.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D9D9D9").s().p("AAcAvIAAhJIgTBJIgRAAIgShJIAABJIgSAAIAAhcIAcAAIAQA+IARg+IAcAAIAABcg");
	this.shape_3.setTransform(63.4,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D9D9D9").s().p("AASAvIgkg8IAAA8IgSAAIAAhcIASAAIAlA8IAAg8IASAAIAABcg");
	this.shape_4.setTransform(49.65,16.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D9D9D9").s().p("AgIAvIAAhcIARAAIAABcg");
	this.shape_5.setTransform(43.225,16.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D9D9D9").s().p("AAaAvIgIgVIgkAAIgIAVIgUAAIAkhcIATAAIAmBcgAgMAKIAYAAIgMgig");
	this.shape_6.setTransform(36.675,16.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D9D9D9").s().p("AAcAvIAAhJIgTBJIgRAAIgThJIAABJIgRAAIAAhcIAdAAIAPA+IARg+IAcAAIAABcg");
	this.shape_7.setTransform(26.55,16.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.instance = new lib.buttonbackground();
	this.instance.parent = this;
	this.instance.setTransform(60.15,16,0.6159,1,0,0,0,97.5,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainmenubutton2, new cjs.Rectangle(0.1,0,120,32), null);


(lib.mainmenubutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D9D9D9").s().p("AgSAsQgHgDgEgFQgEgFgCgFQgBgIAAgQIAAgwIASAAIAAAxQAAAMABAEQABAFAFAEQAFADAGAAQAIAAAFgDQADgDABgFIABgQIAAgyIATAAIAAAwQAAAQgCAHQgBAHgEAFQgEAFgHADQgHACgLAAQgNAAgGgDg");
	this.shape.setTransform(127.05,16.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D9D9D9").s().p("AASAvIgkg8IAAA8IgSAAIAAhcIATAAIAlA8IAAg8IARAAIAABcg");
	this.shape_1.setTransform(117.65,16.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D9D9D9").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_2.setTransform(108.825,16.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D9D9D9").s().p("AAbAvIAAhJIgSBJIgRAAIgThJIAABJIgRAAIAAhcIAdAAIAPA+IARg+IAcAAIAABcg");
	this.shape_3.setTransform(98.9,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D9D9D9").s().p("AASAvIglg8IAAA8IgRAAIAAhcIATAAIAlA8IAAg8IARAAIAABcg");
	this.shape_4.setTransform(85.15,16.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D9D9D9").s().p("AgIAvIAAhcIARAAIAABcg");
	this.shape_5.setTransform(78.725,16.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D9D9D9").s().p("AAaAvIgIgVIgkAAIgIAVIgUAAIAkhcIATAAIAmBcgAgMAKIAYAAIgMgig");
	this.shape_6.setTransform(72.175,16.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D9D9D9").s().p("AAbAvIAAhJIgSBJIgRAAIgShJIAABJIgSAAIAAhcIAcAAIAQA+IARg+IAcAAIAABcg");
	this.shape_7.setTransform(62.05,16.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.instance = new lib.buttonbackground();
	this.instance.parent = this;
	this.instance.setTransform(97.4,16,1,1,0,0,0,97.4,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainmenubutton, new cjs.Rectangle(0,0,194.9,32), null);


(lib.levelcompletefinal2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.achText = new lib.achievement_unlocked();
	this.achText.name = "achText";
	this.achText.parent = this;
	this.achText.setTransform(53.55,83.2,1,1,0,0,0,88.5,9.2);

	this.againButton = new lib.playagainbutton();
	this.againButton.name = "againButton";
	this.againButton.parent = this;
	this.againButton.setTransform(62.95,153.5,1,1,0,0,0,97.5,16);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(295.35,61.65,1.1429,1.1429,0,0,0,35.1,17.6);

	this.moreButton = new lib.moregamesbutton();
	this.moreButton.name = "moreButton";
	this.moreButton.parent = this;
	this.moreButton.setTransform(190.5,153.6,1,1,0,0,0,97.8,16.1);

	this.text = new cjs.Text("All levels completed !", "italic 13px 'Arial'", "#D9D9D9");
	this.text.lineHeight = 17;
	this.text.lineWidth = 169;
	this.text.parent = this;
	this.text.setTransform(113,103.8);

	this.text_1 = new cjs.Text("CONGRATULATIONS !", "italic 13px 'Arial'", "#00CC66");
	this.text_1.lineHeight = 17;
	this.text_1.lineWidth = 162;
	this.text_1.parent = this;
	this.text_1.setTransform(-32.95,103.3);

	this.levelscoretxt = new cjs.Text("0", "italic 13px 'Arial'", "#D9D9D9");
	this.levelscoretxt.name = "levelscoretxt";
	this.levelscoretxt.lineHeight = 17;
	this.levelscoretxt.lineWidth = 62;
	this.levelscoretxt.parent = this;
	this.levelscoretxt.setTransform(43.05,60);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D9D9D9").s().p("AgMAiIACgNIAMAAIgCANgAgBgUIABgNIAOAAIgDANg");
	this.shape.setTransform(36.25,66.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_1.setTransform(30.675,66.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D9D9D9").s().p("AgYAjIAOhDIAKAAIgDAOQAEgIAGgDQAEgFAGAAQADAAAFADIgFALQgDgCgDAAQgGAAgHAGQgFAHgDAQIgHAcg");
	this.shape_2.setTransform(25.5,66.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D9D9D9").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_3.setTransform(19.125,66.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D9D9D9").s().p("AgWAcQgGgHgBgNQAAgKAFgKQAEgLAIgGQAJgFAJAAQAKAAAHAGQAHAGAAAKIgMABQAAgGgEgEQgDgEgGAAQgGAAgFAFQgGAEgCAJQgDAIAAAIQAAAJAEAEQAEAEAFAAQAFAAAFgEQAFgEADgJIALABQgEANgIAGQgIAGgJAAQgLAAgHgHg");
	this.shape_4.setTransform(12.5,66.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D9D9D9").s().p("AgVAdQgIgFAAgNIAMgBQAAAFABADQACAEAEACQAEACAFAAQAHAAAEgDQAEgDAAgEQAAgDgDgCQgCgDgJgEIgLgFQgEgCgCgEQgCgDAAgFQAAgIAGgFQAGgGALAAQAMAAAHAGQAHAGAAAJIgLABQgBgGgEgEQgEgDgHAAQgFAAgDACQgEADAAADQAAAEADACQACACAHADQANAGAEACQAFAFAAAIQAAAFgDAFQgDAEgGADQgHADgHAAQgMAAgIgGg");
	this.shape_5.setTransform(5.8235,66.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D9D9D9").s().p("AgPAvIAThcIAMAAIgTBcg");
	this.shape_6.setTransform(-2.3,65.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_7.setTransform(-7.675,66.375);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D9D9D9").s().p("AgTAiIgLhDIALAAIAGAkIACAUIAJgQIAVgoIAMAAIgmBDg");
	this.shape_8.setTransform(-13.8,66.375);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_9.setTransform(-21.425,66.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D9D9D9").s().p("AgfAvIAUhcIAMAAIgQBRIAuAAIgBALg");
	this.shape_10.setTransform(-28.8,65.1);

	this.totalscoretxt = new cjs.Text("0", "italic 13px 'Arial'", "#D9D9D9");
	this.totalscoretxt.name = "totalscoretxt";
	this.totalscoretxt.lineHeight = 17;
	this.totalscoretxt.lineWidth = 62;
	this.totalscoretxt.parent = this;
	this.totalscoretxt.setTransform(43.05,44);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFCC66").s().p("AgIAvIAAgSIARAAIAAASgAgEAWIgFgtIAAgXIATAAIAAAXIgFAtg");
	this.shape_11.setTransform(84.425,17.55);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFCC66").s().p("AgiAvIAAhdIBEAAIAAAQIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_12.setTransform(74.525,17.55);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFCC66").s().p("AgIAvIAAhNIgcAAIAAgQIBJAAIAAAQIgcAAIAABNg");
	this.shape_13.setTransform(66.075,17.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFCC66").s().p("AgiAvIAAhdIBEAAIAAAQIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_14.setTransform(57.925,17.55);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFCC66").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape_15.setTransform(49.775,17.575);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFCC66").s().p("AgjAvIAAhdIAeAAQARAAAFACQAIACAFAHQAGAHAAALQAAAJgDAFQgDAGgFACQgFAEgFABQgGABgNABIgMAAIAAAjgAgQgDIAKAAQALgBAEgBQADgBADgEQACgDAAgDQAAgGgEgDQgDgDgEgBIgNgBIgJAAg");
	this.shape_16.setTransform(41.35,17.55);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFCC66").s().p("AAbAvIAAhJIgSBJIgRAAIgThJIAABJIgRAAIAAhdIAdAAIAPA/IARg/IAcAAIAABdg");
	this.shape_17.setTransform(31.4,17.55);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFCC66").s().p("AggAjQgMgMAAgWQAAgNAEgKQADgIAGgFQAFgFAHgDQAJgEAKAAQAUAAANANQAMAMAAAWQAAAWgMANQgMANgVAAQgUAAgMgNgAgSgXQgHAIAAAPQAAAPAIAJQAHAIAKAAQALAAAIgIQAHgIAAgQQAAgPgHgIQgHgIgMAAQgLAAgHAIg");
	this.shape_18.setTransform(20.975,17.55);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFCC66").s().p("AgcAjQgMgMABgWQgBgWAMgNQANgNASAAQASAAAKAKQAHAGADALIgTAFQgCgIgFgEQgGgEgGAAQgKAAgGAIQgHAHAAAQQAAARAHAHQAFAIAKAAQAIAAAFgEQAFgGADgJIASAFQgEAPgKAIQgKAHgPAAQgRAAgNgNg");
	this.shape_19.setTransform(11.15,17.55);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFCC66").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape_20.setTransform(-0.775,17.575);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFCC66").s().p("AgiAvIAAhdIBEAAIAAAQIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_21.setTransform(-9.225,17.55);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFCC66").s().p("AgJAvIghhdIAUAAIAXBEIAWhEIAUAAIghBdg");
	this.shape_22.setTransform(-18.025,17.55);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFCC66").s().p("AgiAvIAAhdIBEAAIAAAQIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_23.setTransform(-26.525,17.55);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFCC66").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape_24.setTransform(-34.675,17.575);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#D9D9D9").s().p("AgNAiIADgNIAMAAIgCANgAgBgUIACgNIAMAAIgCANg");
	this.shape_25.setTransform(34.05,50.375);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_26.setTransform(28.475,50.375);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#D9D9D9").s().p("AgYAiIAOhCIAKAAIgDAOQAFgIAEgDQAFgEAFAAQAEAAAFACIgEAKQgEgBgDAAQgGgBgGAIQgGAGgEAQIgFAbg");
	this.shape_27.setTransform(23.3,50.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#D9D9D9").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_28.setTransform(16.925,50.375);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#D9D9D9").s().p("AgWAcQgHgHABgNQAAgKADgKQAFgLAIgGQAJgFAJAAQALAAAGAGQAGAGAAAKIgLABQAAgGgDgEQgFgEgFAAQgGAAgFAFQgGAEgCAJQgDAIAAAIQAAAJADAEQAEAEAGAAQAFAAAFgEQAFgEADgJIAMABQgFANgIAGQgIAGgJAAQgLAAgHgHg");
	this.shape_29.setTransform(10.3,50.375);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#D9D9D9").s().p("AgVAdQgIgFAAgNIAMgBQAAAFABADQACAEAEACQAEACAFAAQAHAAAEgDQAEgDAAgEQAAgDgDgCQgCgDgJgEIgLgFQgEgCgCgEQgCgDAAgFQAAgIAGgFQAGgGALAAQAMAAAHAGQAHAGAAAJIgLABQgBgGgEgEQgEgDgHAAQgFAAgDACQgEADAAADQAAAEADACQACACAHADQANAGAEACQAFAFAAAIQAAAFgDAFQgDAEgGADQgHADgHAAQgMAAgIgGg");
	this.shape_30.setTransform(3.6235,50.375);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#D9D9D9").s().p("AgOAuIAShbIALAAIgSBbg");
	this.shape_31.setTransform(-4.5,49.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#D9D9D9").s().p("AgZAeQgFgGgBgIQABgGADgEQACgFAEgBIALgEIANgBQALgBAEgCIACgHQAAgEgDgDQgEgDgHAAQgHAAgFADQgEAEgCAGIgMgBQAEgLAHgFQAIgFALAAQANAAAHAGQAGAEgBAHIgBANIgEAQIgBANIABAJIgMAAIgBgJQgGAGgGACQgEACgGAAQgKAAgGgFgAAMABIgKABIgMACQgEACgDADQgCADAAADQAAAFADADQAEADAGAAQAFAAAFgDQAFgDADgFQAEgFABgKIgFABg");
	this.shape_32.setTransform(-9.95,50.375);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#D9D9D9").s().p("AgNArQgDgCAAgFIABgKIAIgmIgJAAIACgJIAJAAIAEgQIAMgJIgFAZIALAAIgCAJIgLAAIgHAkIgBAJIABADIADABIAGgBIgBAJIgHABQgHAAgEgDg");
	this.shape_33.setTransform(-14.775,49.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#D9D9D9").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_34.setTransform(-20.675,50.375);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#D9D9D9").s().p("AgXAuIARhRIgfAAIADgKIBIAAIgCAKIgfAAIgQBRg");
	this.shape_35.setTransform(-27.075,49.1);

	this.nextButton = new lib.mainmenubutton2();
	this.nextButton.name = "nextButton";
	this.nextButton.parent = this;
	this.nextButton.setTransform(317.25,153.6,1,1,0,0,0,97.8,16.1);

	this.closeButton = new lib.closeoptions();
	this.closeButton.name = "closeButton";
	this.closeButton.parent = this;
	this.closeButton.setTransform(329.45,13.5,0.6667,0.6664,0,0,0,10.1,9.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.closeButton},{t:this.nextButton},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.totalscoretxt},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.levelscoretxt},{t:this.text_1},{t:this.text},{t:this.moreButton},{t:this.stars},{t:this.againButton},{t:this.achText}]}).wait(1));

	// Layer 1
	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#CCCCCC").ss(0.2,1,1).p("AFmAAIZeAAA/DAAIFfAAIfKAA");
	this.shape_36.setTransform(152.75,35.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#CCCCCC").ss(1,1,1,3,true).p("AFmumIZeAAIAAFjIAAXqMg+HAAAIAA3qIAAljIFfAAg");
	this.shape_37.setTransform(152.75,93.475);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#3B3B3B").s().p("A/CL1IAA3pIFeAAIfKAAIAALLI/KAAIAArLIAALLIfKAAIAArLIZeAAIAAXpg");
	this.shape_38.setTransform(152.75,111.225);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("AFmCxI/KAAIAAliIAAFiIleAAIAAliIFeAAIfKAAIAAFiIAAliIZeAAIAAFig");
	this.shape_39.setTransform(152.75,17.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36}]}).wait(1));

	// Layer 3
	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#262626").s().p("A/COaIAA8zMA+FAAAIAAczg");
	this.shape_40.setTransform(155.8,98.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_40).wait(1));

}).prototype = getMCSymbolPrototype(lib.levelcompletefinal2, new cjs.Rectangle(-47,-1,401.6,191.5), null);


(lib.levelcompletefinal = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_48 = function() {
		if (backgroundSound) backgroundSound.stop();
	}
	this.frame_69 = function() {
		backgroundSound = createjs.Sound.play("sakumamuzons",{interrupt: createjs.Sound.INTERRUPT_EARLY, loop:-1});
	}
	this.frame_76 = function() {
		var nextcreen = this;
		nextcreen.stop();
		nextcreen.screen.levelscoretxt.text = levelScore;
		nextcreen.screen.totalscoretxt.text = totalScore;
		
		nextcreen.screen.stars.gotoAndStop(levelStars);
		
		nextcreen.screen.closeButton.addEventListener("click", closeScreen);
		nextcreen.screen.nextButton.addEventListener("click", closeScreen);
		nextcreen.screen.againButton.addEventListener("click", closeScreen2);
		nextcreen.screen.moreButton.addEventListener("click", playMore);
		
		
		function closeScreen(event) {
			
			removeListeners();
			nextcreen.gotoAndPlay(77);
			
		}
		
		function closeScreen2(event) {
			
			removeListeners();
			nextcreen.gotoAndPlay(77);
			again = true;
			canvas.style.pointerEvents = "none";
		}
		
		function playMore()
		{	
			var gotourl;
			if(mobile) {
			gotourl = "https://m.1000webgames.com/?utm_campaign=truck_space_2&utm_medium=moregames_starplevel&utm_source=" + ref;	
			} else {
			gotourl = "https://1000webgames.com/?utm_campaign=truck_space_2&utm_medium=moregames_starplevel&utm_source=" + ref;
			}
			window.open(gotourl, "_blank");
		}
		
		function removeListeners() {
			nextcreen.screen.closeButton.removeEventListener("click", closeScreen);
			nextcreen.screen.nextButton.removeEventListener("click", closeScreen);
			nextcreen.screen.moreButton.removeEventListener("click", playMore);
			nextcreen.screen.againButton.removeEventListener("click", closeScreen2);
		}
	}
	this.frame_167 = function() {
		this.stop();
		resetgame();
		
		
		if(again) {
			again = false;
			this.parent.removeChild(this);
			startGame();
		} else {
			exportRoot.gotoAndStop(1);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(48).call(this.frame_48).wait(21).call(this.frame_69).wait(7).call(this.frame_76).wait(91).call(this.frame_167).wait(1));

	// Layer 1
	this.screen = new lib.levelcompletefinal2();
	this.screen.name = "screen";
	this.screen.parent = this;
	this.screen.setTransform(321,278.4,1,1,0,0,0,152,128.4);
	this.screen.alpha = 0;
	this.screen._off = true;

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(48).to({_off:false},0).wait(1).to({regX:154,regY:95,x:323,y:237.15,alpha:0.065},0).wait(1).to({y:229.4,alpha:0.1297},0).wait(1).to({y:221.75,alpha:0.1937},0).wait(1).to({y:214.15,alpha:0.2568},0).wait(1).to({y:206.75,alpha:0.3187},0).wait(1).to({y:199.45,alpha:0.3792},0).wait(1).to({y:192.4,alpha:0.4379},0).wait(1).to({y:185.6,alpha:0.4948},0).wait(1).to({y:179,alpha:0.5497},0).wait(1).to({y:172.7,alpha:0.6023},0).wait(1).to({y:166.65,alpha:0.6525},0).wait(1).to({y:160.95,alpha:0.7003},0).wait(1).to({y:155.55,alpha:0.7453},0).wait(1).to({y:150.45,alpha:0.7877},0).wait(1).to({y:145.7,alpha:0.8272},0).wait(1).to({y:141.35,alpha:0.8637},0).wait(1).to({y:137.3,alpha:0.8972},0).wait(1).to({y:133.65,alpha:0.9277},0).wait(1).to({y:130.4,alpha:0.955},0).wait(1).to({y:127.5,alpha:0.9791},0).wait(1).to({regX:152,regY:128.4,x:321,y:158.4,alpha:1},0).to({y:172.4},7).wait(1).to({regX:154,regY:95,x:323,y:136.3},0).wait(1).to({y:133.2},0).wait(1).to({y:130.1},0).wait(1).to({y:127.45},0).wait(1).to({y:125.65},0).wait(1).to({regX:152,regY:128.4,x:321,y:158.4},0).wait(1).to({regX:154,regY:95,x:323,y:125.15,alpha:0.9985},0).wait(1).to({y:125.7,alpha:0.994},0).wait(1).to({y:126.6,alpha:0.9865},0).wait(1).to({y:127.85,alpha:0.976},0).wait(1).to({y:129.45,alpha:0.9626},0).wait(1).to({y:131.4,alpha:0.9463},0).wait(1).to({y:133.75,alpha:0.9271},0).wait(1).to({y:136.4,alpha:0.9049},0).wait(1).to({y:139.4,alpha:0.8799},0).wait(1).to({y:142.7,alpha:0.8521},0).wait(1).to({y:146.4,alpha:0.8215},0).wait(1).to({y:150.4,alpha:0.7881},0).wait(1).to({y:154.75,alpha:0.752},0).wait(1).to({y:159.4,alpha:0.7132},0).wait(1).to({y:164.35,alpha:0.6718},0).wait(1).to({y:169.65,alpha:0.6278},0).wait(1).to({y:175.2,alpha:0.5813},0).wait(1).to({y:181.1,alpha:0.5323},0).wait(1).to({y:187.25,alpha:0.481},0).wait(1).to({y:193.7,alpha:0.4275},0).wait(1).to({y:200.35,alpha:0.3717},0).wait(1).to({y:207.3,alpha:0.3139},0).wait(1).to({y:214.45,alpha:0.2542},0).wait(1).to({y:221.85,alpha:0.1928},0).wait(1).to({y:229.4,alpha:0.1298},0).wait(1).to({y:237.1,alpha:0.0654},0).wait(1).to({regX:152,regY:128.4,x:321,y:278.4,alpha:0},0).to({_off:true},20).wait(39));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,523.6,340.5);


(lib.levelcompletebutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E3E3E3").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape.setTransform(97.125,16.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E3E3E3").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_1.setTransform(88.675,16.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E3E3E3").s().p("AgJAvIghhcIAUAAIAXBDIAWhDIAUAAIghBcg");
	this.shape_2.setTransform(79.875,16.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E3E3E3").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_3.setTransform(71.375,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E3E3E3").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape_4.setTransform(63.225,16.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E3E3E3").s().p("AgIAvIAAhNIgcAAIAAgPIBJAAIAAAPIgcAAIAABNg");
	this.shape_5.setTransform(51.375,16.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E3E3E3").s().p("AAVAvIgVghIgUAhIgWAAIAggwIgdgsIAWAAIARAeIATgeIAVAAIgdAtIAgAvg");
	this.shape_6.setTransform(43.075,16.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E3E3E3").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_7.setTransform(34.575,16.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E3E3E3").s().p("AASAvIglg8IAAA8IgRAAIAAhcIASAAIAlA8IAAg8IASAAIAABcg");
	this.shape_8.setTransform(25.35,16.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.instance = new lib.buttonbackground();
	this.instance.parent = this;
	this.instance.setTransform(60.05,16,0.6158,1,0,0,0,97.5,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.levelcompletebutton, new cjs.Rectangle(0,0,120,32), null);


(lib.levelcomplete2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.achText = new lib.achievement_unlocked();
	this.achText.name = "achText";
	this.achText.parent = this;
	this.achText.setTransform(48.05,94.2,1,1,0,0,0,88.5,9.2);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(295.35,61.65,1.1429,1.1429,0,0,0,35.1,17.6);

	this.againButton = new lib.playagainbutton();
	this.againButton.name = "againButton";
	this.againButton.parent = this;
	this.againButton.setTransform(189.95,159.5,1,1,0,0,0,97.5,16);

	this.nextButton = new lib.levelcompletebutton();
	this.nextButton.name = "nextButton";
	this.nextButton.parent = this;
	this.nextButton.setTransform(320.45,159.5,1,1,0,0,0,97.5,16);

	this.levelscoretxt = new cjs.Text("0", "italic 13px 'Arial'", "#D9D9D9");
	this.levelscoretxt.name = "levelscoretxt";
	this.levelscoretxt.lineHeight = 17;
	this.levelscoretxt.lineWidth = 62;
	this.levelscoretxt.parent = this;
	this.levelscoretxt.setTransform(37.05,64.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D9D9D9").s().p("AgNAiIADgNIAMAAIgCANgAgBgUIACgNIAMAAIgCANg");
	this.shape.setTransform(30.25,70.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_1.setTransform(24.675,70.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D9D9D9").s().p("AgYAjIAOhDIAKAAIgDAOQAFgIAFgDQAFgFAEAAQAEAAAFADIgFALQgDgCgDAAQgGAAgHAGQgFAHgEAQIgFAcg");
	this.shape_2.setTransform(19.5,70.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D9D9D9").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_3.setTransform(13.125,70.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D9D9D9").s().p("AgWAcQgHgHAAgNQABgKAEgKQAEgLAIgGQAIgFAKAAQAKAAAHAGQAGAGAAAKIgLABQAAgGgEgEQgEgEgFAAQgGAAgFAFQgFAEgDAJQgDAIAAAIQAAAJADAEQAEAEAGAAQAEAAAGgEQAFgEADgJIAMABQgFANgIAGQgIAGgJAAQgLAAgHgHg");
	this.shape_4.setTransform(6.5,70.875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D9D9D9").s().p("AgVAdQgIgFAAgNIAMgBQAAAFABADQACAEAEACQAEACAFAAQAHAAAEgDQAEgDAAgEQAAgDgDgCQgCgDgJgEIgLgFQgEgCgCgEQgCgDAAgFQAAgIAGgFQAGgGALAAQAMAAAHAGQAHAGAAAJIgLABQgBgGgEgEQgEgDgHAAQgFAAgDACQgEADAAADQAAAEADACQACACAHADQANAGAEACQAFAFAAAIQAAAFgDAFQgDAEgGADQgHADgHAAQgMAAgIgGg");
	this.shape_5.setTransform(-0.1765,70.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D9D9D9").s().p("AgOAvIAShcIALAAIgSBcg");
	this.shape_6.setTransform(-8.3,69.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_7.setTransform(-13.675,70.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D9D9D9").s().p("AgTAiIgLhDIALAAIAGAkIACAUIAIgQIAWgoIAMAAIglBDg");
	this.shape_8.setTransform(-19.8,70.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_9.setTransform(-27.425,70.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D9D9D9").s().p("AgfAvIAUhcIAMAAIgRBRIAvAAIgCALg");
	this.shape_10.setTransform(-34.8,69.6);

	this.totalscoretxt = new cjs.Text("0", "italic 13px 'Arial'", "#D9D9D9");
	this.totalscoretxt.name = "totalscoretxt";
	this.totalscoretxt.lineHeight = 17;
	this.totalscoretxt.lineWidth = 62;
	this.totalscoretxt.parent = this;
	this.totalscoretxt.setTransform(37.05,48.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFCC66").s().p("AgIAvIAAgSIARAAIAAASgAgEAXIgFguIAAgXIATAAIAAAXIgFAug");
	this.shape_11.setTransform(85.425,16.55);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFCC66").s().p("AgiAvIAAhdIBEAAIAAAQIgyAAIAAAVIAuAAIAAAPIguAAIAAAZIAzAAIAAAQg");
	this.shape_12.setTransform(75.525,16.55);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFCC66").s().p("AgIAvIAAhNIgcAAIAAgQIBJAAIAAAQIgcAAIAABNg");
	this.shape_13.setTransform(67.075,16.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFCC66").s().p("AgiAvIAAhdIBEAAIAAAQIgyAAIAAAVIAuAAIAAAPIguAAIAAAZIAzAAIAAAQg");
	this.shape_14.setTransform(58.925,16.55);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFCC66").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape_15.setTransform(50.775,16.575);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFCC66").s().p("AgjAvIAAhdIAeAAQARABAFABQAIACAFAHQAGAHgBALQAAAJgCAFQgEAFgEAEQgFADgFABQgGACgMAAIgNAAIAAAjgAgQgDIAKAAQALgBAEgBQADgCADgDQACgCAAgFQAAgFgDgDQgDgDgFgBIgNgBIgJAAg");
	this.shape_16.setTransform(42.35,16.55);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFCC66").s().p("AAcAvIAAhJIgTBJIgRAAIgThJIAABJIgRAAIAAhdIAdAAIAPA/IARg/IAcAAIAABdg");
	this.shape_17.setTransform(32.4,16.55);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFCC66").s().p("AggAjQgMgMAAgXQAAgMAEgKQADgIAGgFQAFgGAHgDQAJgDAKAAQAUAAANAMQAMANAAAWQAAAXgMAMQgMANgVAAQgUAAgMgNgAgSgXQgHAIAAAPQAAAPAIAJQAHAIAKAAQALAAAIgIQAHgIAAgQQAAgPgHgIQgHgIgMAAQgLAAgHAIg");
	this.shape_18.setTransform(21.975,16.55);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFCC66").s().p("AgcAjQgMgMAAgWQAAgXAMgNQANgMASAAQASAAAKAKQAHAGACALIgSAFQgCgIgFgEQgGgEgGAAQgKAAgGAIQgHAHAAAQQAAARAHAHQAFAIAKAAQAHAAAGgFQAFgEACgKIASAFQgDAPgKAIQgKAHgPAAQgRAAgNgNg");
	this.shape_19.setTransform(12.15,16.55);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFCC66").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape_20.setTransform(0.225,16.575);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFCC66").s().p("AgiAvIAAhdIBEAAIAAAQIgyAAIAAAVIAuAAIAAAPIguAAIAAAZIAzAAIAAAQg");
	this.shape_21.setTransform(-8.225,16.55);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFCC66").s().p("AgJAvIghhdIAUAAIAXBFIAWhFIAUAAIghBdg");
	this.shape_22.setTransform(-17.025,16.55);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFCC66").s().p("AgiAvIAAhdIBEAAIAAAQIgyAAIAAAVIAuAAIAAAPIguAAIAAAZIAzAAIAAAQg");
	this.shape_23.setTransform(-25.525,16.55);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFCC66").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape_24.setTransform(-33.675,16.575);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#D9D9D9").s().p("AgMAiIACgNIAMAAIgCANgAgBgUIABgNIAOAAIgDANg");
	this.shape_25.setTransform(28.05,54.875);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_26.setTransform(22.475,54.875);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#D9D9D9").s().p("AgYAiIAOhCIAKAAIgDAOQAEgIAFgDQAFgEAGAAQADAAAFACIgEAKQgDgBgEAAQgGgBgGAIQgGAGgDAQIgHAbg");
	this.shape_27.setTransform(17.3,54.8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#D9D9D9").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_28.setTransform(10.925,54.875);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#D9D9D9").s().p("AgWAcQgGgHAAgNQgBgKAEgKQAFgLAIgGQAJgFAJAAQALAAAGAGQAHAGAAAKIgMABQAAgGgDgEQgEgEgGAAQgGAAgFAFQgFAEgDAJQgDAIAAAIQAAAJAEAEQAEAEAFAAQAFAAAFgEQAFgEADgJIALABQgEANgIAGQgIAGgJAAQgLAAgHgHg");
	this.shape_29.setTransform(4.3,54.875);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#D9D9D9").s().p("AgVAdQgIgFAAgNIAMgBQAAAFABADQACAEAEACQAEACAFAAQAHAAAEgDQAEgDAAgEQAAgDgDgCQgCgDgJgEIgLgFQgEgCgCgEQgCgDAAgFQAAgIAGgFQAGgGALAAQAMAAAHAGQAHAGAAAJIgLABQgBgGgEgEQgEgDgHAAQgFAAgDACQgEADAAADQAAAEADACQACACAHADQANAGAEACQAFAFAAAIQAAAFgDAFQgDAEgGADQgHADgHAAQgMAAgIgGg");
	this.shape_30.setTransform(-2.3765,54.875);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#D9D9D9").s().p("AgPAuIAThbIAMAAIgTBbg");
	this.shape_31.setTransform(-10.5,53.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#D9D9D9").s().p("AgZAeQgFgGAAgIQAAgGACgEQADgFAEgBIAKgEIAOgBQALgBAEgCIACgHQAAgEgDgDQgEgDgHAAQgHAAgEADQgFAEgCAGIgLgBQADgLAIgFQAIgFAKAAQAMAAAIAGQAFAEABAHIgCANIgEAQIgCANIABAJIgLAAIgBgJQgGAGgGACQgEACgHAAQgJAAgGgFgAAMABIgJABIgOACQgDACgDADQgCADAAADQAAAFADADQAEADAGAAQAFAAAFgDQAFgDAEgFQADgFABgKIgFABg");
	this.shape_32.setTransform(-15.95,54.875);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#D9D9D9").s().p("AgNArQgDgCAAgFIABgKIAIgmIgJAAIACgJIAJAAIAEgQIAMgJIgFAZIALAAIgCAJIgLAAIgHAkIgBAJIABADIADABIAGgBIgBAJIgHABQgHAAgEgDg");
	this.shape_33.setTransform(-20.775,53.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#D9D9D9").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_34.setTransform(-26.675,54.875);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#D9D9D9").s().p("AgXAuIARhRIgfAAIADgKIBIAAIgCAKIgfAAIgQBRg");
	this.shape_35.setTransform(-33.075,53.6);

	this.moreButton = new lib.morefinishbutton();
	this.moreButton.name = "moreButton";
	this.moreButton.parent = this;
	this.moreButton.setTransform(59.45,159.5,1,1,0,0,0,97.5,16);

	this.closeButton = new lib.closeoptions();
	this.closeButton.name = "closeButton";
	this.closeButton.parent = this;
	this.closeButton.setTransform(329.95,13.25,0.6667,0.6664,0,0,0,10.1,9.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.closeButton},{t:this.moreButton},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.totalscoretxt},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.levelscoretxt},{t:this.nextButton},{t:this.againButton},{t:this.stars},{t:this.achText}]}).wait(1));

	// Layer 1
	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#CCCCCC").ss(0.2,1,1).p("A/DAAMA+HAAA");
	this.shape_36.setTransform(152.75,35.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#CCCCCC").ss(1,1,1,3,true).p("A/DumMA+HAAAIAAFjIAAXqMg+HAAAIAA3qg");
	this.shape_37.setTransform(152.75,93.475);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#3B3B3B").s().p("A/CL1IAA3pMA+GAAAIAAXpg");
	this.shape_38.setTransform(152.75,111.225);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#333333").s().p("A/CCxIAAliMA+GAAAIAAFig");
	this.shape_39.setTransform(152.75,17.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36}]}).wait(1));

	// Layer 3
	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#262626").s().p("A/COaIAA8zMA+FAAAIAAczg");
	this.shape_40.setTransform(155.8,98.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_40).wait(1));

}).prototype = getMCSymbolPrototype(lib.levelcomplete2, new cjs.Rectangle(-47,-1,401.6,191.5), null);


(lib.levelcomplete = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_48 = function() {
		if (backgroundSound) backgroundSound.stop();
		var nextcreen2 = this;
		nextcreen2.screen.stars.gotoAndStop(levelStars);
	}
	this.frame_69 = function() {
		backgroundSound = createjs.Sound.play("sakumamuzons",{interrupt: createjs.Sound.INTERRUPT_EARLY, loop:-1});
	}
	this.frame_76 = function() {
		var nextcreen = this;
		nextcreen.stop();
		nextcreen.screen.levelscoretxt.text = levelScore;
		nextcreen.screen.totalscoretxt.text = totalScore;
		
		nextcreen.screen.achText.gotoAndStop(unlockedAchievement + 1);
		
		nextcreen.screen.stars.gotoAndStop(levelStars);
		
		nextcreen.screen.closeButton.addEventListener("click", closeScreen);
		nextcreen.screen.nextButton.addEventListener("click", closeScreen);
		nextcreen.screen.againButton.addEventListener("click", closeScreen2);
		nextcreen.screen.moreButton.addEventListener("click", moreGbutton);
		
		function closeScreen(event) {
			
			removeListeners();
			nextcreen.gotoAndPlay(77);
			canvas.style.pointerEvents = "none";
		}
		
		function closeScreen2(event) {
			
			removeListeners();
			nextcreen.gotoAndPlay(77);
			again = true;
			canvas.style.pointerEvents = "none";
		}
		
		function moreGbutton()
		{
		var gotourl;
			if(mobile) {
			gotourl = "https://m.1000webgames.com/?utm_campaign=truck_space_2&utm_medium=moregames_starplevel&utm_source=" + ref;	
			} else {
			gotourl = "https://1000webgames.com/?utm_campaign=truck_space_2&utm_medium=moregames_starplevel&utm_source=" + ref;
			}
			window.open(gotourl, "_blank");	
		}
		
		function removeListeners() {
			nextcreen.screen.closeButton.removeEventListener("click", closeScreen);
			nextcreen.screen.nextButton.removeEventListener("click", closeScreen);
			nextcreen.screen.againButton.removeEventListener("click", closeScreen2);
			nextcreen.screen.moreButton.removeEventListener("click", moreGbutton);
		}
	}
	this.frame_167 = function() {
		this.stop();
		resetgame();
		
		if(again) {
			again = false;
		} else {
			Level++;
		}
		this.parent.removeChild(this);
		startGame();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(48).call(this.frame_48).wait(21).call(this.frame_69).wait(7).call(this.frame_76).wait(91).call(this.frame_167).wait(1));

	// Layer 1
	this.screen = new lib.levelcomplete2();
	this.screen.name = "screen";
	this.screen.parent = this;
	this.screen.setTransform(321,278.4,1,1,0,0,0,152,128.4);
	this.screen.alpha = 0;
	this.screen._off = true;

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(48).to({_off:false},0).wait(1).to({regX:154,regY:95,x:323,y:237.15,alpha:0.065},0).wait(1).to({y:229.4,alpha:0.1297},0).wait(1).to({y:221.75,alpha:0.1937},0).wait(1).to({y:214.15,alpha:0.2568},0).wait(1).to({y:206.75,alpha:0.3187},0).wait(1).to({y:199.45,alpha:0.3792},0).wait(1).to({y:192.4,alpha:0.4379},0).wait(1).to({y:185.6,alpha:0.4948},0).wait(1).to({y:179,alpha:0.5497},0).wait(1).to({y:172.7,alpha:0.6023},0).wait(1).to({y:166.65,alpha:0.6525},0).wait(1).to({y:160.95,alpha:0.7003},0).wait(1).to({y:155.55,alpha:0.7453},0).wait(1).to({y:150.45,alpha:0.7877},0).wait(1).to({y:145.7,alpha:0.8272},0).wait(1).to({y:141.35,alpha:0.8637},0).wait(1).to({y:137.3,alpha:0.8972},0).wait(1).to({y:133.65,alpha:0.9277},0).wait(1).to({y:130.4,alpha:0.955},0).wait(1).to({y:127.5,alpha:0.9791},0).wait(1).to({regX:152,regY:128.4,x:321,y:158.4,alpha:1},0).to({y:172.4},7).wait(1).to({regX:154,regY:95,x:323,y:136.3},0).wait(1).to({y:133.2},0).wait(1).to({y:130.1},0).wait(1).to({y:127.45},0).wait(1).to({y:125.65},0).wait(1).to({regX:152,regY:128.4,x:321,y:158.4},0).wait(1).to({regX:154,regY:95,x:323,y:125.15,alpha:0.9985},0).wait(1).to({y:125.7,alpha:0.994},0).wait(1).to({y:126.6,alpha:0.9865},0).wait(1).to({y:127.85,alpha:0.976},0).wait(1).to({y:129.45,alpha:0.9626},0).wait(1).to({y:131.4,alpha:0.9463},0).wait(1).to({y:133.75,alpha:0.9271},0).wait(1).to({y:136.4,alpha:0.9049},0).wait(1).to({y:139.4,alpha:0.8799},0).wait(1).to({y:142.7,alpha:0.8521},0).wait(1).to({y:146.4,alpha:0.8215},0).wait(1).to({y:150.4,alpha:0.7881},0).wait(1).to({y:154.75,alpha:0.752},0).wait(1).to({y:159.4,alpha:0.7132},0).wait(1).to({y:164.35,alpha:0.6718},0).wait(1).to({y:169.65,alpha:0.6278},0).wait(1).to({y:175.2,alpha:0.5813},0).wait(1).to({y:181.1,alpha:0.5323},0).wait(1).to({y:187.25,alpha:0.481},0).wait(1).to({y:193.7,alpha:0.4275},0).wait(1).to({y:200.35,alpha:0.3717},0).wait(1).to({y:207.3,alpha:0.3139},0).wait(1).to({y:214.45,alpha:0.2542},0).wait(1).to({y:221.85,alpha:0.1928},0).wait(1).to({y:229.4,alpha:0.1298},0).wait(1).to({y:237.1,alpha:0.0654},0).wait(1).to({regX:152,regY:128.4,x:321,y:278.4,alpha:0},0).to({_off:true},20).wait(39));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,523.6,340.5);


(lib.instructionsbutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D9D9D9").s().p("AgZAoQgKgIgCgQIASgCQACAKAFAEQAFAFAIgBQAJAAAEgDQAFgEAAgFQAAgEgCgCQgCgDgEgBIgPgFQgPgDgGgFQgJgHABgLQAAgIADgFQAEgHAIgDQAIgDAKAAQARAAAJAHQAJAIAAANIgTABQgBgHgDgEQgFgDgHAAQgIABgFADQgCACAAADQAAAEACACQAEADANADQANADAHAEQAHAEADAEQAEAHAAAJQAAAHgFAIQgEAGgIAEQgJADgLAAQgRAAgJgIg");
	this.shape.setTransform(138.6,16.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D9D9D9").s().p("AASAvIglg8IAAA8IgRAAIAAhcIASAAIAmA8IAAg8IARAAIAABcg");
	this.shape_1.setTransform(129.6,16.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D9D9D9").s().p("AggAkQgMgNAAgWQAAgNAEgLQADgGAGgGQAFgFAHgDQAJgEAKAAQAUAAANANQAMANAAAVQAAAXgMANQgMAMgVAAQgUAAgMgMgAgSgXQgHAIAAAPQAAAPAIAJQAHAIAKAAQALAAAIgIQAHgIAAgQQAAgQgHgHQgHgIgMAAQgLAAgHAIg");
	this.shape_2.setTransform(119.925,16.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D9D9D9").s().p("AgIAvIAAhcIARAAIAABcg");
	this.shape_3.setTransform(113.075,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D9D9D9").s().p("AgIAvIAAhNIgcAAIAAgPIBJAAIAAAPIgcAAIAABNg");
	this.shape_4.setTransform(107.275,16.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D9D9D9").s().p("AgcAkQgMgNABgWQgBgWAMgNQANgNASAAQASAAAKAKQAHAGACALIgSAFQgCgIgFgEQgGgEgGAAQgKAAgGAHQgHAIAAAQQAAARAHAHQAFAIAKAAQAHAAAGgEQAFgGACgKIASAGQgDAQgKAGQgKAIgPAAQgRAAgNgMg");
	this.shape_5.setTransform(98.55,16.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D9D9D9").s().p("AgSAsQgHgDgEgFQgEgFgCgFQgBgIAAgQIAAgwIASAAIAAAxQAAAMABAEQACAFAEAEQAFADAGAAQAJAAADgDQAFgDABgFIAAgQIAAgyIATAAIAAAwQAAAQgCAHQgBAHgEAFQgEAFgHADQgHACgLAAQgMAAgHgDg");
	this.shape_6.setTransform(89.15,16.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D9D9D9").s().p("AATAvIgNgUIgJgPQgDgCgDgBIgJgBIgEAAIAAAnIgTAAIAAhcIAoAAQAOAAAHACQAGADAEAGQAEAHAAAHQAAALgGAHQgGAFgMACQAGAEAEAEIALAQIALASgAgWgGIAOAAQAMAAAEgBQADgBACgEQACgCAAgEQAAgFgCgDQgDgDgFgBIgMAAIgPAAg");
	this.shape_7.setTransform(80.225,16.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D9D9D9").s().p("AgIAvIAAhNIgcAAIAAgPIBJAAIAAAPIgcAAIAABNg");
	this.shape_8.setTransform(71.125,16.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D9D9D9").s().p("AgZAoQgKgIgCgQIATgCQABAKAFAEQAFAFAIgBQAJAAAEgDQAFgEAAgFQAAgEgCgCQgCgDgEgBIgPgFQgPgDgGgFQgIgHAAgLQAAgIADgFQAFgHAHgDQAIgDAKAAQARAAAJAHQAJAIAAANIgSABQgCgHgDgEQgFgDgHAAQgIABgFADQgCACAAADQAAAEACACQAEADAMADQAOADAHAEQAGAEAEAEQAEAHAAAJQAAAHgFAIQgEAGgIAEQgIADgMAAQgRAAgJgIg");
	this.shape_9.setTransform(62.75,16.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D9D9D9").s().p("AASAvIgkg8IAAA8IgSAAIAAhcIATAAIAlA8IAAg8IARAAIAABcg");
	this.shape_10.setTransform(53.75,16.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D9D9D9").s().p("AgIAvIAAhcIARAAIAABcg");
	this.shape_11.setTransform(47.325,16.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.instance = new lib.buttonbackground();
	this.instance.parent = this;
	this.instance.setTransform(97.55,16,1,1,0,0,0,97.4,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.instructionsbutton, new cjs.Rectangle(0.2,0,194.8,32), null);


(lib.gmenu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.buttons = new lib.mobilebuttons();
	this.buttons.name = "buttons";
	this.buttons.parent = this;
	this.buttons.setTransform(0,-1);

	this.tWindow = new lib.timeWindow();
	this.tWindow.name = "tWindow";
	this.tWindow.parent = this;
	this.tWindow.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.tWindow},{t:this.buttons}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.gmenu, new cjs.Rectangle(7,5.8,59.099999999999994,19.599999999999998), null);


(lib.fullscreenButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D9D9D9").s().p("AASAvIgkg8IAAA8IgSAAIAAhcIATAAIAlA8IAAg8IARAAIAABcg");
	this.shape.setTransform(134.85,16.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D9D9D9").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_1.setTransform(126.025,16.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D9D9D9").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_2.setTransform(117.375,16.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D9D9D9").s().p("AATAvIgNgUIgJgPQgDgCgDgBIgJgBIgEAAIAAAnIgTAAIAAhcIAoAAQAOAAAHACQAGADAEAGQAEAHAAAHQAAALgGAHQgGAFgMACQAGAEAEAEIALAQIALASgAgWgGIAOAAQAMAAAEgBQADgBACgEQACgCAAgEQAAgFgCgDQgDgDgFgBIgMAAIgPAAg");
	this.shape_3.setTransform(108.625,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D9D9D9").s().p("AgbAkQgMgNgBgWQABgWAMgNQALgNATAAQARAAALAKQAGAGADALIgSAFQgCgIgFgEQgGgEgGAAQgKAAgHAHQgGAIAAAQQAAARAGAHQAHAIAJAAQAHAAAGgEQAFgGACgKIASAGQgDAQgKAGQgKAIgPAAQgSAAgLgMg");
	this.shape_4.setTransform(98.75,16.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D9D9D9").s().p("AgaAoQgJgIgCgQIASgCQACAKAFAEQAFAFAIgBQAJAAAFgDQAEgEAAgFQAAgEgCgCQgCgDgFgBIgNgFQgQgDgGgFQgJgHAAgLQAAgIAFgFQADgHAIgDQAIgDAKAAQARAAAJAHQAJAIAAANIgTABQgBgHgEgEQgDgDgIAAQgIABgEADQgEACAAADQAAAEAEACQADADANADQAOADAGAEQAHAEADAEQAEAHAAAJQAAAHgEAIQgFAGgIAEQgJADgMAAQgQAAgKgIg");
	this.shape_5.setTransform(89.7,16.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D9D9D9").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape_6.setTransform(78.425,16.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D9D9D9").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape_7.setTransform(70.475,16.425);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D9D9D9").s().p("AgSAsQgHgDgEgFQgEgFgCgFQgBgIAAgQIAAgwIASAAIAAAxQAAAMABAEQABAFAFAEQAFADAGAAQAIAAAFgDQADgDABgFIABgQIAAgyIATAAIAAAwQAAAQgCAHQgBAHgEAFQgEAFgHADQgHACgLAAQgNAAgGgDg");
	this.shape_8.setTransform(61.45,16.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D9D9D9").s().p("AgfAvIAAhcIA/AAIAAAPIgsAAIAAAWIAlAAIAAAPIglAAIAAAog");
	this.shape_9.setTransform(53,16.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D9D9D9").s().p("AASAvIglg8IAAA8IgRAAIAAhcIASAAIAmA8IAAg8IARAAIAABcg");
	this.shape_10.setTransform(151.1,16.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D9D9D9").s().p("AgcAkQgMgNABgWQgBgWAMgNQANgNASAAQARAAALAKQAHAGADALIgTAFQgCgIgFgEQgGgEgGAAQgKAAgGAHQgHAIAAAQQAAARAHAHQAFAIAKAAQAIAAAFgEQAFgGADgKIASAGQgFAQgJAGQgKAIgPAAQgRAAgNgMg");
	this.shape_11.setTransform(115,16.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#D9D9D9").s().p("AgZAoQgKgIgCgQIATgCQABAKAFAEQAFAFAIgBQAJAAAEgDQAFgEAAgFQAAgEgCgCQgCgDgEgBIgPgFQgPgDgGgFQgIgHAAgLQAAgIADgFQAFgHAHgDQAIgDAKAAQARAAAJAHQAJAIAAANIgSABQgCgHgEgEQgEgDgHAAQgIABgFADQgCACAAADQAAAEACACQAEADAMADQAOADAHAEQAGAEAEAEQAEAHAAAJQAAAHgFAIQgEAGgIAEQgIADgMAAQgRAAgJgIg");
	this.shape_12.setTransform(105.95,16.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#D9D9D9").s().p("AgSAsQgHgDgEgFQgEgFgBgFQgCgIAAgQIAAgwIATAAIAAAxQAAAMABAEQABAFAEAEQAEADAIAAQAHAAAEgDQAFgDABgFIAAgQIAAgyIATAAIAAAwQAAAQgBAHQgCAHgEAFQgEAFgHADQgHACgLAAQgMAAgHgDg");
	this.shape_13.setTransform(77.7,16.475);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#D9D9D9").s().p("AgfAvIAAhcIA/AAIAAAPIgsAAIAAAWIAmAAIAAAPIgmAAIAAAog");
	this.shape_14.setTransform(69.25,16.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#D9D9D9").s().p("AgIAvIAAhNIgcAAIAAgPIBJAAIAAAPIgcAAIAABNg");
	this.shape_15.setTransform(57.525,16.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#D9D9D9").s().p("AgIAvIAAhcIARAAIAABcg");
	this.shape_16.setTransform(51.775,16.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#D9D9D9").s().p("AAVAvIgVghIgUAhIgWAAIAggwIgdgsIAWAAIARAeIATgeIAVAAIgdAtIAgAvg");
	this.shape_17.setTransform(45.625,16.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#D9D9D9").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_18.setTransform(37.125,16.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7,p:{x:70.475}},{t:this.shape_6,p:{x:78.425}},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3,p:{x:108.625}},{t:this.shape_2,p:{x:117.375}},{t:this.shape_1,p:{x:126.025}},{t:this.shape}]}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_7,p:{x:86.725}},{t:this.shape_6,p:{x:94.675}},{t:this.shape_12},{t:this.shape_11},{t:this.shape_3,p:{x:124.875}},{t:this.shape_2,p:{x:133.625}},{t:this.shape_1,p:{x:142.275}},{t:this.shape_10}]},1).wait(1));

	// Layer 3
	this.instance = new lib.buttonbackground();
	this.instance.parent = this;
	this.instance.setTransform(97.55,16,1,1,0,0,0,97.4,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.2,0,194.8,32);


(lib.fadeout = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_10 = function() {
		pause = false;
		exportRoot.gmenu.visible = true;
	}
	this.frame_30 = function() {
		this.stop();
		//advancedTexture2.dispose();
		this.parent.removeChild(this);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(10).call(this.frame_10).wait(20).call(this.frame_30).wait(1));

	// Layer_2
	this.instance = new lib.levelload();
	this.instance.parent = this;
	this.instance.setTransform(341,343.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},10).wait(21));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,348.9,347.2);


(lib.explosion_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_89 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(89).call(this.frame_89).wait(1));

	// Layer_1
	this.instance = new lib.explosionsymbol();
	this.instance.parent = this;
	this.instance.setTransform(0,13.9,0.3875,0.3875,0,0,0,0,36);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0.1,scaleX:0.4245,scaleY:0.4245,rotation:1.003,x:10.95,y:15.3,alpha:0.9297},5).to({scaleX:0.825,scaleY:0.8248,rotation:11.9993,x:65.1,y:29.7,alpha:0},84).wait(1));

	// Layer_1
	this.instance_1 = new lib.explosionsymbol();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,-0.05,0.4344,0.4343);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:0.5645,scaleY:0.5645,rotation:1.0022,x:7.2,y:0,alpha:0.4297},5).to({scaleX:0.9416,scaleY:0.9413,rotation:12.0007,x:69.25,alpha:0},79).to({_off:true},1).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.8,-114.1,344,294.6);


(lib.creditsbutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D9D9D9").s().p("AgZAoQgKgIgCgQIASgCQACAKAFAEQAFAFAIgBQAJAAAEgDQAFgEAAgFQAAgEgCgCQgCgDgEgBIgOgFQgQgDgGgFQgJgHABgLQAAgIADgFQAEgHAIgDQAIgDAKAAQARAAAJAHQAJAIAAANIgTABQgBgHgDgEQgFgDgHAAQgIABgEADQgDACAAADQAAAEADACQADADANADQANADAHAEQAHAEADAEQAEAHAAAJQAAAHgFAIQgEAGgIAEQgJADgLAAQgRAAgJgIg");
	this.shape.setTransform(118.35,16.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D9D9D9").s().p("AgIAvIAAhNIgcAAIAAgPIBJAAIAAAPIgcAAIAABNg");
	this.shape_1.setTransform(110.125,16.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D9D9D9").s().p("AgIAvIAAhcIARAAIAABcg");
	this.shape_2.setTransform(104.375,16.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D9D9D9").s().p("AgmAvIAAhcIAiAAQALAAAGABQAIACAGAHQAGAGADAJQADAJAAAMQAAALgDAIQgEALgGAGQgFAFgIADQgGACgJAAgAgUAfIAPAAIAKgBQAFgBADgDQACgCACgHQACgGABgLQgBgKgCgFQgCgHgDgCQgDgEgFgBIgPgBIgJAAg");
	this.shape_3.setTransform(98,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D9D9D9").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_4.setTransform(88.975,16.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D9D9D9").s().p("AATAvIgNgUIgJgPQgDgCgDgBIgJgBIgEAAIAAAnIgTAAIAAhcIAoAAQAOAAAHACQAGADAEAGQAEAHAAAHQAAALgGAHQgGAFgMACQAGAEAEAEIALAQIALASgAgWgGIAOAAQAMAAAEgBQADgBACgEQACgCAAgEQAAgFgCgDQgDgDgFgBIgMAAIgPAAg");
	this.shape_5.setTransform(80.225,16.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D9D9D9").s().p("AgbAkQgMgNAAgWQAAgWAMgNQAMgNASAAQARAAALAKQAGAGAEALIgTAFQgCgIgFgEQgFgEgIAAQgJAAgGAHQgHAIAAAQQAAARAHAHQAFAIAKAAQAHAAAGgEQAFgGADgKIASAGQgFAQgJAGQgKAIgPAAQgRAAgMgMg");
	this.shape_6.setTransform(70.35,16.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.instance = new lib.buttonbackground();
	this.instance.parent = this;
	this.instance.setTransform(97.55,16,1,1,0,0,0,97.4,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.creditsbutton, new cjs.Rectangle(0.2,0,194.8,32), null);


(lib.bultadumi = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_160 = function() {
		this.stop();
		this.parent.removeChild(this);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(160).call(this.frame_160).wait(1));

	// Layer_1
	this.instance = new lib.smokesymbol3("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.1406,0.1406);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:1},0).to({scaleX:0.2737,scaleY:0.2737,x:0.45,alpha:0.9805},4).to({regX:0.5,scaleX:0.4376,scaleY:0.4376,x:4.8,alpha:0},29).to({_off:true},1).wait(126));

	// Layer_1
	this.instance_1 = new lib.smokesymbol2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.1406,0.1406);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({scaleX:0.2737,scaleY:0.2737,x:0.45,alpha:0.9805},4).to({regX:-0.2,scaleX:3.2656,scaleY:3.2656,x:17,alpha:0},155).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-87.1,-104.4,209.3,209);


(lib.audiobutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D9D9D9").s().p("AgIAeIAAg5IAwgjIAAB9gAgnAeIAAg5IAZAAIAAA5g");
	this.shape.setTransform(42.5,17.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B00000").s().p("AgmAmQgQgQAAgWQAAgWAQgPIAAAAIAFgFIAAAAIACgBQAOgKARAAQAWAAARAQQAPAPAAAWQAAAWgPAQIgDADIgBABQgPAMgUAAQgWABgQgRgAgnAAQAAARAMALQAMAMAPgBQALAAAJgEIgxg8QgKALAAAOgAgSgiIAxA7QAIgKABgPQAAgQgMgLQgMgLgQAAQgJgBgJAFg");
	this.shape_1.setTransform(48.95,22.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

	// Layer 2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D9D9D9").s().p("AggAkQgMgNAAgWQAAgNAEgLQADgGAGgGQAFgFAHgDQAJgEAKAAQAUAAANANQAMANAAAVQAAAXgMANQgMAMgVAAQgUAAgMgMgAgSgXQgHAIAAAPQAAAPAIAJQAHAIAKAAQALAAAIgIQAHgIAAgQQAAgQgHgHQgHgIgMAAQgLAAgHAIg");
	this.shape_2.setTransform(138.525,16.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D9D9D9").s().p("AgIAvIAAhcIARAAIAABcg");
	this.shape_3.setTransform(131.675,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D9D9D9").s().p("AgmAvIAAhcIAiAAQALAAAGABQAIACAGAHQAGAGADAJQADAJAAAMQAAALgDAIQgDALgHAGQgFAFgIADQgHACgJAAgAgUAfIAPAAIAKgBQAEgBADgDQAEgCACgHQACgGAAgLQAAgKgCgFQgCgHgEgCQgDgEgGgBIgOgBIgJAAg");
	this.shape_4.setTransform(125.3,16.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D9D9D9").s().p("AgSAsQgHgDgEgFQgEgFgCgFQgBgIAAgQIAAgwIASAAIAAAxQABAMAAAEQACAFAEAEQAFADAGAAQAJAAADgDQAFgDAAgFIABgQIAAgyIATAAIAAAwQAAAQgCAHQgBAHgEAFQgEAFgHADQgHACgLAAQgMAAgHgDg");
	this.shape_5.setTransform(115.7,16.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D9D9D9").s().p("AAaAvIgIgVIgkAAIgIAVIgUAAIAkhcIATAAIAmBcgAgMAKIAYAAIgMgig");
	this.shape_6.setTransform(106.325,16.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D9D9D9").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_7.setTransform(94.375,16.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D9D9D9").s().p("AgIAvIAAhNIgcAAIAAgPIBJAAIAAAPIgcAAIAABNg");
	this.shape_8.setTransform(85.925,16.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D9D9D9").s().p("AgSAsQgHgDgEgFQgEgFgCgFQgBgIAAgQIAAgwIASAAIAAAxQAAAMABAEQABAFAFAEQAFADAGAAQAIAAAFgDQADgDABgFIABgQIAAgyIATAAIAAAwQAAAQgCAHQgBAHgEAFQgEAFgHADQgHACgLAAQgNAAgGgDg");
	this.shape_9.setTransform(77.2,16.475);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D9D9D9").s().p("AAbAvIAAhJIgSBJIgRAAIgThJIAABJIgRAAIAAhcIAcAAIAQA+IARg+IAcAAIAABcg");
	this.shape_10.setTransform(67.1,16.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D9D9D9").s().p("AgmAvIAAhcIAiAAQALAAAGABQAIACAGAHQAGAGADAJQADAJAAAMQAAALgDAIQgDALgHAGQgFAFgIADQgHACgJAAgAgTAfIANAAIALgBQAEgBADgDQADgCADgHQABgGAAgLQAAgKgBgFQgCgHgEgCQgDgEgGgBIgOgBIgIAAg");
	this.shape_11.setTransform(140.7,16.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#D9D9D9").s().p("AAbAvIAAhJIgSBJIgRAAIgShJIAABJIgSAAIAAhcIAcAAIAQA+IARg+IAcAAIAABcg");
	this.shape_12.setTransform(99.85,16.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#D9D9D9").s().p("AgSAsQgHgDgEgFQgEgFgCgFQgBgIAAgQIAAgwIASAAIAAAxQAAAMABAEQABAFAFAEQAFADAGAAQAIAAAFgDQADgDABgFIABgQIAAgyIATAAIAAAwQAAAQgCAHQgBAHgEAFQgEAFgHADQgHACgLAAQgNAAgGgDg");
	this.shape_13.setTransform(89.7,16.475);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#D9D9D9").s().p("AgZAoQgKgIgCgQIASgCQACAKAFAEQAFAFAIgBQAJAAAEgDQAFgEAAgFQAAgEgCgCQgCgDgEgBIgPgFQgPgDgGgFQgIgHAAgLQAAgIADgFQAFgHAHgDQAIgDAKAAQARAAAJAHQAJAIAAANIgTABQgBgHgDgEQgEgDgIAAQgIABgFADQgCACAAADQAAAEACACQAEADAMADQAOADAHAEQAHAEADAEQAEAHAAAJQAAAHgFAIQgEAGgIAEQgIADgMAAQgRAAgJgIg");
	this.shape_14.setTransform(80.65,16.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#D9D9D9").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_15.setTransform(72.225,16.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#D9D9D9").s().p("AATAvIgNgUIgJgPQgDgCgDgBIgJgBIgEAAIAAAnIgTAAIAAhcIAoAAQAOAAAHACQAGADAEAGQAEAHAAAHQAAALgGAHQgGAFgMACQAGAEAEAEIALAQIALASgAgWgGIAOAAQAMAAAEgBQADgBACgEQACgCAAgEQAAgFgCgDQgDgDgFgBIgMAAIgPAAg");
	this.shape_16.setTransform(63.475,16.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#D9D9D9").s().p("AgIAeIAAg5IAwgjIAAB9gAgnAeIAAg5IAZAAIAAA5g");
	this.shape_17.setTransform(42.5,17.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9,p:{x:77.2}},{t:this.shape_8},{t:this.shape_7,p:{x:94.375}},{t:this.shape_6,p:{x:106.325}},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3,p:{x:131.675}},{t:this.shape_2,p:{x:138.525}}]}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_7,p:{x:109.775}},{t:this.shape_6,p:{x:121.725}},{t:this.shape_9,p:{x:131.1}},{t:this.shape_11},{t:this.shape_3,p:{x:147.075}},{t:this.shape_2,p:{x:153.925}}]},1).wait(1));

	// Layer 1
	this.instance = new lib.buttonbackground();
	this.instance.parent = this;
	this.instance.setTransform(97.55,16,1,1,0,0,0,97.4,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.2,0,194.8,32);


(lib.achievementsbutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgaAoQgJgIgCgQIATgCQABAKAFAEQAFAFAIgBQAJAAAFgDQAEgEAAgFQAAgEgCgCQgCgDgFgBIgNgFQgQgDgGgFQgJgHAAgLQAAgIAFgFQAEgHAHgDQAIgDAKAAQARAAAJAHQAJAIAAANIgSABQgCgHgEgEQgDgDgIAAQgIABgEADQgEACAAADQAAAEAEACQADADAMADQAPADAGAEQAHAEADAEQAEAHAAAJQAAAHgEAIQgFAGgIAEQgJADgMAAQgQAAgKgIg");
	this.shape.setTransform(104.45,16.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("AgIAvIAAhNIgcAAIAAgPIBJAAIAAAPIgcAAIAABNg");
	this.shape_1.setTransform(96.225,16.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("AASAvIgkg8IAAA8IgSAAIAAhcIATAAIAlA8IAAg8IARAAIAABcg");
	this.shape_2.setTransform(87.5,16.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_3.setTransform(78.675,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AAbAvIAAhJIgSBJIgRAAIgThJIAABJIgRAAIAAhcIAdAAIAPA+IARg+IAcAAIAABcg");
	this.shape_4.setTransform(68.75,16.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_5.setTransform(59.175,16.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCCCC").s().p("AgJAvIghhcIAUAAIAXBDIAWhDIAUAAIghBcg");
	this.shape_6.setTransform(50.375,16.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCCCC").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_7.setTransform(41.875,16.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CCCCCC").s().p("AgIAvIAAhcIARAAIAABcg");
	this.shape_8.setTransform(35.625,16.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CCCCCC").s().p("AASAvIAAgpIgjAAIAAApIgTAAIAAhcIATAAIAAAkIAjAAIAAgkIATAAIAABcg");
	this.shape_9.setTransform(29.075,16.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CCCCCC").s().p("AgbAkQgNgNAAgWQAAgWANgNQALgNATAAQARAAALAKQAGAGADALIgSAFQgCgIgFgEQgFgEgIAAQgJAAgHAHQgGAIAAAQQAAARAGAHQAHAIAJAAQAIAAAFgEQAFgGACgKIASAGQgDAQgKAGQgKAIgPAAQgSAAgLgMg");
	this.shape_10.setTransform(19.65,16.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CCCCCC").s().p("AAaAvIgIgVIgkAAIgIAVIgUAAIAkhcIATAAIAmBcgAgMAKIAYAAIgMgig");
	this.shape_11.setTransform(10.275,16.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.instance = new lib.buttonbackground();
	this.instance.parent = this;
	this.instance.setTransform(57.6,16,0.6723,1,0,0,0,96.8,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.achievementsbutton, new cjs.Rectangle(-7.5,0,131,32), null);


(lib.achievement12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgLAUQgEgGAAgOQAAgNAFgGQAEgGAGAAQAHAAAEAGQAFAGAAANQAAAOgFAGQgEAGgHAAQgGAAgFgGgAgCgPQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAIgBAMIABAMIACAFIACABIADgBIACgEIABgNIgBgLIgCgEQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgCACg");
	this.shape.setTransform(89.025,12.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("AgLAUQgEgGAAgOQAAgNAFgGQAEgGAGAAQAHAAAEAGQAFAGAAANQAAAOgFAGQgEAGgHAAQgGAAgFgGgAgCgPQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAIgBAMIABAMIACAFIACABIADgBIACgEIABgNIgBgLIgCgEQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgCACg");
	this.shape_1.setTransform(85.125,12.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("AgLAUQgEgGAAgOQAAgNAFgGQAEgGAGAAQAHAAAEAGQAFAGAAANQAAAOgFAGQgEAGgHAAQgGAAgFgGgAgCgPQgBAAAAAAQAAABAAAAQgBABAAAAQAAABAAAAIgBAMIABAMIACAFIACABIADgBIACgEIABgNIgBgLIgCgEQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgCACg");
	this.shape_2.setTransform(81.225,12.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AgLAUQgEgGAAgOQAAgNAFgGQAEgGAGAAQAHAAAEAGQAFAGAAANQAAAOgFAGQgEAGgHAAQgGAAgFgGgAgCgPQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAIgBAMIABAMIACAFIACABIADgBIACgEIABgNIgBgLIgCgEQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgCACg");
	this.shape_3.setTransform(77.325,12.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AgQAZQABgFADgEQADgFAHgHIAHgIQACgDAAgCQAAgEgCgBQAAgBAAAAQgBAAAAgBQgBAAgBAAQAAAAgBAAQgCAAgCACQgCACAAAEIgJgBQAAgIAEgEQAFgDAGAAQAIAAAEAEQAEAEAAAGQAAADgCADIgDAGIgHAGIgFAGIgBACIASAAIAAAJg");
	this.shape_4.setTransform(73.35,12.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("AgSAZIAAgxIAkAAIAAAJIgaAAIAAAKIAYAAIAAAIIgYAAIAAAOIAbAAIAAAIg");
	this.shape_5.setTransform(67.3,12.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCCCC").s().p("AAKAZIgHgLIgEgHIgDgDIgFAAIgCAAIAAAVIgKAAIAAgxIAVAAQAHAAADABQAEABADAEQABADAAAFQAAAGgCAEQgEACgGABIAFAEIAGAIIAGAKgAgLgDIAHAAIAJgBIACgCIABgDIgBgFIgEgBIgGAAIgIAAg");
	this.shape_6.setTransform(62.6,12.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCCCC").s().p("AgRATQgGgHAAgLQAAgIACgFQACgEADgCQADgEADgBQAFgCAFAAQALAAAHAHQAGAHAAALQAAAMgGAHQgHAHgLAAQgKAAgHgHgAgJgMQgEAFAAAHQAAAIAEAFQAEAEAFAAQAGAAAEgEQAEgFAAgIQAAgIgEgEQgEgEgGAAQgFAAgEAEg");
	this.shape_7.setTransform(57.125,12.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CCCCCC").s().p("AgPATQgGgHAAgLQAAgMAHgHQAGgHAKAAQAJAAAFAGQAEACACAHIgKACQgBgEgDgCQgDgDgEABQgFAAgDADQgEAFAAAIQAAAJAEAEQADAEAFAAQAEAAADgDQADgCABgFIAKADQgDAIgFAEQgFAEgIAAQgJAAgHgHg");
	this.shape_8.setTransform(51.875,12.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CCCCCC").s().p("AgOAVQgEgEgCgIIALgBQABAFACACQADACAEABQAEAAADgCQACgDAAgCIgBgDIgEgDIgHgCQgIgCgDgCQgFgEABgGQAAgEACgDQACgDAEgCQAEgCAFAAQAJAAAFAEQAEAFABAGIgKABQgBgEgCgCQgCgCgEABQgEgBgCACQgBAAAAABQAAAAgBABQAAAAAAABQAAAAAAAAIACAEQACABAGABIALAFQAEABACACQABAEAAAFQAAAEgCAEQgCADgFACQgEACgHAAQgIAAgGgFg");
	this.shape_9.setTransform(47,12.45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CCCCCC").s().p("AgGAGIADgLIAKAAIgDALg");
	this.shape_10.setTransform(133.225,25.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CCCCCC").s().p("AgNASQgFgDgCgGIAKgCQACAEACABQACACAEAAQADAAACgCQABAAAAgBQAAAAABAAQAAgBAAAAQAAAAAAgBIgBgCIgEgCQgKgDgCgCQgEgCAAgFQAAgFADgEQAGgFAJAAQAIAAAEADQAEADABAFIgKACIgDgDQgDgCgDAAIgEABQAAAAgBABQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAABAAQAAABAAAAQAAAAAAABQABAAAAAAIAGADIAKAEQAEADABAEQgBAGgFAEQgEAFgJAAQgIAAgFgEg");
	this.shape_11.setTransform(130.05,24.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_12.setTransform(126.975,23.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CCCCCC").s().p("AAFAVIAEgWIACgHQAAAAgBgBQAAAAAAgBQAAAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAgBAAQgCAAgDACQgCACgBADIgDAJIgEARIgLAAIAJgoIAKAAIgBAFIAHgFQADgBAEAAQAFAAADADQADADAAAEIgBAJIgGAWg");
	this.shape_13.setTransform(122.75,24.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CCCCCC").s().p("AgLAdIAJgpIAKAAIgIApgAgBgRIABgLIAMAAIgCALg");
	this.shape_14.setTransform(119.475,23.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CCCCCC").s().p("AgMATQgEgCgDgEQgCgFAAgEQABgLAGgHQAHgHAJAAQAJAAAFAFQAGAFAAAJQgBAJgGAHQgHAIgKAAQgFAAgFgDgAgEgKQgDACgBAFIgCAGQAAAFADACQADADADAAQAEAAADgEQAEgFABgHQgBgEgCgDQgCgCgEAAQgDAAgDACg");
	this.shape_15.setTransform(115.75,24.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CCCCCC").s().p("AgXAdIALg4IALAAIgBAEQADgDADgBQADgBADAAQAGAAAFAEQADAFAAAJQABAKgIAIQgGAGgHAAQgHAAgFgGIgEAVgAAAgSQgCACgBAFIgBAIQAAADACADQACADACAAQADAAACgCQADgCACgEIACgJQAAgEgCgDQgDgCgDAAQgDAAgDACg");
	this.shape_16.setTransform(110.6,24.825);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAHgJAKAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgCgDgEAAQgCAAgDADg");
	this.shape_17.setTransform(104,24.075);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CCCCCC").s().p("AgRAVIAJgoIAJAAIgBAIQAGgJAGAAIAGABIgFAJIgDAAQgDAAgDACQgDACgBAEQgBACgCAIIgCANg");
	this.shape_18.setTransform(100.475,24.025);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CCCCCC").s().p("AgMATQgEgCgDgEQgCgFAAgEQABgLAGgHQAHgHAJAAQAJAAAFAFQAGAFAAAJQgBAJgGAHQgHAIgKAAQgFAAgFgDgAgDgKQgDACgCAFIgCAGQABAFACACQACADAEAAQADAAAEgEQAFgFAAgHQAAgEgDgDQgDgCgDAAQgCAAgDACg");
	this.shape_19.setTransform(96.2,24.075);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CCCCCC").s().p("AgOARQgFgFAAgIQAAgGACgGQAEgGAFgDQAGgEAGAAQAHAAAEAEQAFAEAAAGIgLABQAAgDgCgCQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAAAgBAAQgDAAgCACQgDACgCAFIgBAIQAAAEABACQABAAABABQAAAAABAAQAAABABAAQAAAAABAAQACAAADgCQACgCACgEIAKACQgDAHgFAEQgFAEgGAAQgIAAgEgFg");
	this.shape_20.setTransform(91.6,24.075);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CCCCCC").s().p("AgNASQgFgDgCgGIAKgCQACAEACABQADACADAAQADAAACgCQABAAAAgBQAAAAABAAQAAgBAAAAQAAAAAAgBIgBgCIgEgCQgKgDgCgCQgEgCAAgFQAAgFADgEQAGgFAJAAQAIAAAEADQAEADABAFIgKACIgDgDQgCgCgEAAIgEABQAAAAgBABQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAABAAQAAABAAAAQAAAAAAABQABAAAAAAIAFADIALAEQAFADAAAEQgBAGgFAEQgFAFgIAAQgJAAgEgEg");
	this.shape_21.setTransform(86.95,24.075);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CCCCCC").s().p("AgPAYQgEgFAAgJQAAgJADgIQADgLAGgFQAGgFAGAAQAHAAAEAFQAEAFAAAJQAAAJgDAJQgDAKgGAFQgFAFgGAAQgHAAgFgFgAAAgQQgEAEgCAKQgCAIAAAGQAAAEABACQABABAAAAQAAABABAAQAAAAABAAQABAAAAAAQADAAACgDQADgEADgLQACgIAAgFQAAgEgCgCQAAgBgBAAQAAAAAAgBQgBAAgBAAQAAAAgBAAQgDAAgBADg");
	this.shape_22.setTransform(80.525,23.325);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CCCCCC").s().p("AgPAYQgEgFAAgJQAAgJADgIQADgLAGgFQAGgFAGAAQAHAAAEAFQAEAFAAAJQAAAJgDAJQgDAKgGAFQgFAFgGAAQgHAAgFgFgAAAgQQgEAEgCAKQgCAIAAAGQAAAEABACQABABAAAAQABABAAAAQABAAAAAAQABAAAAAAQADAAACgDQADgEADgLQACgIAAgFQAAgEgCgCQAAgBgBAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQgDAAgBADg");
	this.shape_23.setTransform(76.075,23.325);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#CCCCCC").s().p("AgPAYQgEgFAAgJQAAgJADgIQADgLAGgFQAGgFAGAAQAHAAAEAFQAEAFAAAJQAAAJgDAJQgDAKgGAFQgFAFgGAAQgHAAgFgFgAAAgQQgEAEgCAKQgCAIAAAGQAAAEABACQABABAAAAQAAABABAAQAAAAABAAQABAAAAAAQADAAACgDQADgEADgLQACgIAAgFQAAgEgCgCQAAgBgBAAQAAAAAAgBQgBAAgBAAQAAAAgBAAQgDAAgBADg");
	this.shape_24.setTransform(71.625,23.325);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#CCCCCC").s().p("AgPAYQgEgFAAgJQAAgJADgIQADgLAGgFQAGgFAGAAQAHAAAEAFQAEAFAAAJQAAAJgDAJQgDAKgGAFQgFAFgGAAQgHAAgFgFgAAAgQQgEAEgCAKQgCAIAAAGQAAAEABACQABABAAAAQABABAAAAQAAAAABAAQABAAAAAAQADAAACgDQADgEADgLQACgIAAgFQAAgEgCgCQAAgBgBAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQgDAAgBADg");
	this.shape_25.setTransform(67.175,23.325);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#CCCCCC").s().p("AgTAdIACgIIAFgHIAKgLIAHgGIAEgFIABgEQAAgDgCgCQgBgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQgDAAgBACQgCACgBAFIgLgBQABgIAFgEQAFgFAGAAQAIAAAFAFQAEAEAAAHIgBAGIgFAHIgHAHIgHAHIgCAEIATAAIgDAKg");
	this.shape_26.setTransform(62.725,23.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_27.setTransform(57.225,23.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#CCCCCC").s().p("AgNAQQgGgFAAgJQAAgHAFgHQAHgJALAAQAHAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEADACQABADAEAAQAEAAAEgGIAKACQgDAGgFADQgFADgFAAQgJAAgEgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgCgCQgCgDgDAAQgCAAgDADg");
	this.shape_28.setTransform(53.35,24.075);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#CCCCCC").s().p("AgTAYQgIgGAAgMQAAgIADgIQAFgIAHgFQAHgGAJAAQAKABAGAEQAGAEACAJIgLABQgCgEgDgDQgDgCgFAAQgEAAgGADQgEADgDAGQgCAGgBAHQABAGADAEQADAEAHAAIAGgCIAHgCIACgJIgOAAIABgIIAaAAIgGAYQgEACgHACQgGADgGAAQgKgBgGgFg");
	this.shape_29.setTransform(48.2,23.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(2));

	// Layer 2
	this.instance = new lib.achievement_lock();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	this.instance_1 = new lib.check();
	this.instance_1.parent = this;
	this.instance_1.setTransform(176,24,0.1302,0.13);

	this.instance_2 = new lib.ach12();
	this.instance_2.parent = this;
	this.instance_2.setTransform(2,2,0.2811,0.2811);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).wait(1));

	// Layer_4
	this.instance_3 = new lib.achievementramis();
	this.instance_3.parent = this;
	this.instance_3.setTransform(97.2,20.9,1,1,0,0,0,97.2,20.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,194.6,42.1);


(lib.achievement11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgLAUQgEgGAAgOQAAgNAFgGQAEgGAGAAQAHAAAEAGQAFAGAAANQAAAOgFAGQgEAGgHAAQgGAAgFgGgAgCgPQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAIgBAMIABAMIACAFIACABIADgBIACgEIABgNIgBgLIgCgEQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgCACg");
	this.shape.setTransform(89.025,12.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("AgLAUQgEgGAAgOQAAgNAFgGQAEgGAGAAQAHAAAEAGQAFAGAAANQAAAOgFAGQgEAGgHAAQgGAAgFgGgAgCgPQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAIgBAMIABAMIACAFIACABIADgBIACgEIABgNIgBgLIgCgEQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgCACg");
	this.shape_1.setTransform(85.125,12.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("AgLAUQgEgGAAgOQAAgNAFgGQAEgGAGAAQAHAAAEAGQAFAGAAANQAAAOgFAGQgEAGgHAAQgGAAgFgGgAgCgPQgBAAAAAAQAAABAAAAQgBABAAAAQAAABAAAAIgBAMIABAMIACAFIACABIADgBIACgEIABgNIgBgLIgCgEQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgCACg");
	this.shape_2.setTransform(81.225,12.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AgLAUQgEgGAAgOQAAgNAFgGQAEgGAGAAQAHAAAEAGQAFAGAAANQAAAOgFAGQgEAGgHAAQgGAAgFgGgAgCgPQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAIgBAMIABAMIACAFIACABIADgBIACgEIABgNIgBgLIgCgEQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgCACg");
	this.shape_3.setTransform(77.325,12.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AABAZIAAgjQgEAFgHACIAAgIQAEgCAEgDQAEgDACgFIAHAAIAAAxg");
	this.shape_4.setTransform(73.15,12.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("AgSAZIAAgxIAkAAIAAAJIgaAAIAAAKIAYAAIAAAIIgYAAIAAAOIAbAAIAAAIg");
	this.shape_5.setTransform(67.3,12.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCCCC").s().p("AAKAZIgHgLIgEgHIgDgDIgFAAIgCAAIAAAVIgKAAIAAgxIAVAAQAHAAADABQAEABADAEQABADAAAFQAAAGgCAEQgEACgGABIAFAEIAGAIIAGAKgAgLgDIAHAAIAJgBIACgCIABgDIgBgFIgEgBIgGAAIgIAAg");
	this.shape_6.setTransform(62.6,12.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCCCC").s().p("AgRATQgGgHAAgLQAAgIACgFQACgEADgCQADgEADgBQAFgCAFAAQALAAAHAHQAGAHAAALQAAAMgGAHQgHAHgLAAQgKAAgHgHgAgJgMQgEAFAAAHQAAAIAEAFQAEAEAFAAQAGAAAEgEQAEgFAAgIQAAgIgEgEQgEgEgGAAQgFAAgEAEg");
	this.shape_7.setTransform(57.125,12.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CCCCCC").s().p("AgPATQgGgHAAgLQAAgMAHgHQAGgHAKAAQAJAAAFAGQAEACACAHIgKACQgBgEgDgCQgDgDgEABQgFAAgDADQgEAFAAAIQAAAJAEAEQADAEAFAAQAEAAADgDQADgCABgFIAKADQgDAIgFAEQgFAEgIAAQgJAAgHgHg");
	this.shape_8.setTransform(51.875,12.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CCCCCC").s().p("AgOAVQgEgEgCgIIALgBQABAFACACQADACAEABQAEAAADgCQACgDAAgCIgBgDIgEgDIgHgCQgIgCgDgCQgFgEABgGQAAgEACgDQACgDAEgCQAEgCAFAAQAJAAAFAEQAEAFABAGIgKABQgBgEgCgCQgCgCgEABQgEgBgCACQgBAAAAABQAAAAgBABQAAAAAAABQAAAAAAAAIACAEQACABAGABIALAFQAEABACACQABAEAAAFQAAAEgCAEQgCADgFACQgEACgHAAQgIAAgGgFg");
	this.shape_9.setTransform(47,12.45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CCCCCC").s().p("AgGAGIADgLIAKAAIgDALg");
	this.shape_10.setTransform(133.225,25.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CCCCCC").s().p("AgNASQgFgDgCgGIAKgCQACAEACABQACACAEAAQADAAACgCQABAAAAgBQAAAAABAAQAAgBAAAAQAAAAAAgBIgBgCIgEgCQgKgDgCgCQgEgCAAgFQAAgFADgEQAGgFAJAAQAIAAAEADQAEADABAFIgKACIgDgDQgDgCgDAAIgEABQAAAAgBABQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAABAAQAAABAAAAQAAAAAAABQABAAAAAAIAGADIAKAEQAEADABAEQgBAGgFAEQgEAFgJAAQgIAAgFgEg");
	this.shape_11.setTransform(130.05,24.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_12.setTransform(126.975,23.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CCCCCC").s().p("AAFAVIAEgWIACgHQAAAAgBgBQAAAAAAgBQAAAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAgBAAQgCAAgDACQgCACgBADIgDAJIgEARIgLAAIAJgoIAKAAIgBAFIAHgFQADgBAEAAQAFAAADADQADADAAAEIgBAJIgGAWg");
	this.shape_13.setTransform(122.75,24.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CCCCCC").s().p("AgLAdIAJgpIAKAAIgIApgAgBgRIABgLIAMAAIgCALg");
	this.shape_14.setTransform(119.475,23.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CCCCCC").s().p("AgMATQgEgCgDgEQgCgFAAgEQABgLAGgHQAHgHAJAAQAJAAAFAFQAGAFAAAJQgBAJgGAHQgHAIgKAAQgFAAgFgDgAgEgKQgDACgBAFIgCAGQAAAFADACQADADADAAQAEAAADgEQAEgFABgHQgBgEgCgDQgCgCgEAAQgDAAgDACg");
	this.shape_15.setTransform(115.75,24.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CCCCCC").s().p("AgXAdIALg4IALAAIgBAEQADgDADgBQADgBADAAQAGAAAFAEQADAFAAAJQABAKgIAIQgGAGgHAAQgHAAgFgGIgEAVgAAAgSQgCACgBAFIgBAIQAAADACADQACADACAAQADAAACgCQADgCACgEIACgJQAAgEgCgDQgDgCgDAAQgDAAgDACg");
	this.shape_16.setTransform(110.6,24.825);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAHgJAKAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgCgDgEAAQgCAAgDADg");
	this.shape_17.setTransform(104,24.075);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CCCCCC").s().p("AgRAVIAJgoIAJAAIgBAIQAGgJAGAAIAGABIgFAJIgDAAQgDAAgDACQgDACgBAEQgBACgCAIIgCANg");
	this.shape_18.setTransform(100.475,24.025);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CCCCCC").s().p("AgMATQgEgCgDgEQgCgFAAgEQABgLAGgHQAHgHAJAAQAJAAAFAFQAGAFAAAJQgBAJgGAHQgHAIgKAAQgFAAgFgDgAgDgKQgDACgCAFIgCAGQABAFACACQACADAEAAQADAAAEgEQAFgFAAgHQAAgEgDgDQgDgCgDAAQgCAAgDACg");
	this.shape_19.setTransform(96.2,24.075);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CCCCCC").s().p("AgOARQgFgFAAgIQAAgGACgGQAEgGAFgDQAGgEAGAAQAHAAAEAEQAFAEAAAGIgLABQAAgDgCgCQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAAAgBAAQgDAAgCACQgDACgCAFIgBAIQAAAEABACQABAAABABQAAAAABAAQAAABABAAQAAAAABAAQACAAADgCQACgCACgEIAKACQgDAHgFAEQgFAEgGAAQgIAAgEgFg");
	this.shape_20.setTransform(91.6,24.075);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CCCCCC").s().p("AgNASQgFgDgCgGIAKgCQACAEACABQADACADAAQADAAACgCQABAAAAgBQAAAAABAAQAAgBAAAAQAAAAAAgBIgBgCIgEgCQgKgDgCgCQgEgCAAgFQAAgFADgEQAGgFAJAAQAIAAAEADQAEADABAFIgKACIgDgDQgCgCgEAAIgEABQAAAAgBABQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAABAAQAAABAAAAQAAAAAAABQABAAAAAAIAFADIALAEQAFADAAAEQgBAGgFAEQgFAFgIAAQgJAAgEgEg");
	this.shape_21.setTransform(86.95,24.075);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CCCCCC").s().p("AgPAYQgEgFAAgJQAAgJADgIQADgLAGgFQAGgFAGAAQAHAAAEAFQAEAFAAAJQAAAJgDAJQgDAKgGAFQgFAFgGAAQgHAAgFgFgAAAgQQgEAEgCAKQgCAIAAAGQAAAEABACQABABAAAAQAAABABAAQAAAAABAAQABAAAAAAQADAAACgDQADgEADgLQACgIAAgFQAAgEgCgCQAAgBgBAAQAAAAAAgBQgBAAgBAAQAAAAgBAAQgDAAgBADg");
	this.shape_22.setTransform(80.525,23.325);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CCCCCC").s().p("AgPAYQgEgFAAgJQAAgJADgIQADgLAGgFQAGgFAGAAQAHAAAEAFQAEAFAAAJQAAAJgDAJQgDAKgGAFQgFAFgGAAQgHAAgFgFgAAAgQQgEAEgCAKQgCAIAAAGQAAAEABACQABABAAAAQABABAAAAQABAAAAAAQABAAAAAAQADAAACgDQADgEADgLQACgIAAgFQAAgEgCgCQAAgBgBAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQgDAAgBADg");
	this.shape_23.setTransform(76.075,23.325);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#CCCCCC").s().p("AgPAYQgEgFAAgJQAAgJADgIQADgLAGgFQAGgFAGAAQAHAAAEAFQAEAFAAAJQAAAJgDAJQgDAKgGAFQgFAFgGAAQgHAAgFgFgAAAgQQgEAEgCAKQgCAIAAAGQAAAEABACQABABAAAAQAAABABAAQAAAAABAAQABAAAAAAQADAAACgDQADgEADgLQACgIAAgFQAAgEgCgCQAAgBgBAAQAAAAAAgBQgBAAgBAAQAAAAgBAAQgDAAgBADg");
	this.shape_24.setTransform(71.625,23.325);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#CCCCCC").s().p("AgPAYQgEgFAAgJQAAgJADgIQADgLAGgFQAGgFAGAAQAHAAAEAFQAEAFAAAJQAAAJgDAJQgDAKgGAFQgFAFgGAAQgHAAgFgFgAAAgQQgEAEgCAKQgCAIAAAGQAAAEABACQABABAAAAQABABAAAAQAAAAABAAQABAAAAAAQADAAACgDQADgEADgLQACgIAAgFQAAgEgCgCQAAgBgBAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQgDAAgBADg");
	this.shape_25.setTransform(67.175,23.325);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#CCCCCC").s().p("AgHAdIAIgnIgIAEIgIADIACgKQAOgGAIgJIAHAAIgMA5g");
	this.shape_26.setTransform(62.725,23.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_27.setTransform(57.225,23.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#CCCCCC").s().p("AgNAQQgGgFAAgJQAAgHAFgHQAHgJALAAQAHAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEADACQABADAEAAQAEAAAEgGIAKACQgDAGgFADQgFADgFAAQgJAAgEgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgCgCQgCgDgDAAQgCAAgDADg");
	this.shape_28.setTransform(53.35,24.075);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#CCCCCC").s().p("AgTAYQgIgGAAgMQAAgIADgIQAFgIAHgFQAHgGAJAAQAKABAGAEQAGAEACAJIgLABQgCgEgDgDQgDgCgFAAQgEAAgGADQgEADgDAGQgCAGgBAHQABAGADAEQADAEAHAAIAGgCIAHgCIACgJIgOAAIABgIIAaAAIgGAYQgEACgHACQgGADgGAAQgKgBgGgFg");
	this.shape_29.setTransform(48.2,23.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(2));

	// Layer 2
	this.instance = new lib.achievement_lock();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	this.instance_1 = new lib.check();
	this.instance_1.parent = this;
	this.instance_1.setTransform(176,24,0.1302,0.13);

	this.instance_2 = new lib.ach11();
	this.instance_2.parent = this;
	this.instance_2.setTransform(2,2,0.2811,0.2811);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).wait(1));

	// Layer_4
	this.instance_3 = new lib.achievementramis();
	this.instance_3.parent = this;
	this.instance_3.setTransform(97.2,20.9,1,1,0,0,0,97.2,20.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,194.6,42.1);


(lib.achievement10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgLAUQgEgGAAgOQAAgNAFgGQAEgGAGAAQAHAAAEAGQAFAGAAANQAAAOgFAGQgEAGgHAAQgGAAgFgGgAgCgPQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAIgBAMIABAMIACAFIACABIADgBIACgEIABgNIgBgLIgCgEQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgCACg");
	this.shape.setTransform(85.125,12.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("AgLAUQgEgGAAgOQAAgNAFgGQAEgGAGAAQAHAAAEAGQAFAGAAANQAAAOgFAGQgEAGgHAAQgGAAgFgGgAgCgPQgBAAAAAAQAAABAAAAQgBABAAAAQAAABAAAAIgBAMIABAMIACAFIACABIADgBIACgEIABgNIgBgLIgCgEQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgCACg");
	this.shape_1.setTransform(81.225,12.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("AgLAUQgEgGAAgOQAAgNAFgGQAEgGAGAAQAHAAAEAGQAFAGAAANQAAAOgFAGQgEAGgHAAQgGAAgFgGgAgCgPQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAIgBAMIABAMIACAFIACABIADgBIACgEIABgNIgBgLIgCgEQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgCACg");
	this.shape_2.setTransform(77.325,12.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AgKAVQgFgDgBgHIAJgBQABAEACACQACABACAAQADAAACgCQACgCAAgFQAAgFgCgCQgCgCgDAAQgDAAgEADIgIgBIAFgZIAZAAIAAAJIgRAAIgCAIQADgBACAAQAHAAAFAEQAEAEAAAHQAAAHgEAEQgEAHgJAAQgGAAgEgEg");
	this.shape_3.setTransform(73.5,12.525);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AgSAZIAAgxIAkAAIAAAJIgaAAIAAAKIAYAAIAAAIIgYAAIAAAOIAbAAIAAAIg");
	this.shape_4.setTransform(67.3,12.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("AAKAZIgHgLIgEgHIgDgDIgFAAIgCAAIAAAVIgKAAIAAgxIAVAAQAHAAADABQAEABADAEQABADAAAFQAAAGgCAEQgEACgGABIAFAEIAGAIIAGAKgAgLgDIAHAAIAJgBIACgCIABgDIgBgFIgEgBIgGAAIgIAAg");
	this.shape_5.setTransform(62.6,12.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCCCC").s().p("AgRATQgGgHAAgLQAAgIACgFQACgEADgCQADgEADgBQAFgCAFAAQALAAAHAHQAGAHAAALQAAAMgGAHQgHAHgLAAQgKAAgHgHgAgJgMQgEAFAAAHQAAAIAEAFQAEAEAFAAQAGAAAEgEQAEgFAAgIQAAgIgEgEQgEgEgGAAQgFAAgEAEg");
	this.shape_6.setTransform(57.125,12.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCCCC").s().p("AgPATQgGgHAAgLQAAgMAHgHQAGgHAKAAQAJAAAFAGQAEACACAHIgKACQgBgEgDgCQgDgDgEABQgFAAgDADQgEAFAAAIQAAAJAEAEQADAEAFAAQAEAAADgDQADgCABgFIAKADQgDAIgFAEQgFAEgIAAQgJAAgHgHg");
	this.shape_7.setTransform(51.875,12.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CCCCCC").s().p("AgOAVQgEgEgCgIIALgBQABAFACACQADACAEABQAEAAADgCQACgDAAgCIgBgDIgEgDIgHgCQgIgCgDgCQgFgEABgGQAAgEACgDQACgDAEgCQAEgCAFAAQAJAAAFAEQAEAFABAGIgKABQgBgEgCgCQgCgCgEABQgEgBgCACQgBAAAAABQAAAAgBABQAAAAAAABQAAAAAAAAIACAEQACABAGABIALAFQAEABACACQABAEAAAFQAAAEgCAEQgCADgFACQgEACgHAAQgIAAgGgFg");
	this.shape_8.setTransform(47,12.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CCCCCC").s().p("AgGAGIADgLIAKAAIgDALg");
	this.shape_9.setTransform(128.775,25.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CCCCCC").s().p("AgOASQgFgDgBgGIALgCQABAEACABQACACAEAAQADAAACgCQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAAAgBIgBgCIgFgCQgJgDgCgCQgEgCAAgFQAAgFAEgEQAFgFAJAAQAIAAAEADQAEADABAFIgKACIgDgDQgDgCgDAAIgEABQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQABAAAAAAIAFADIAMAEQADADAAAEQAAAGgEAEQgGAFgIAAQgJAAgFgEg");
	this.shape_10.setTransform(125.6,24.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_11.setTransform(122.525,23.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CCCCCC").s().p("AAEAVIAGgWIAAgHQAAAAAAgBQAAAAAAgBQAAAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAAAAAQgDAAgDACQgCACgCADIgDAJIgDARIgLAAIAIgoIALAAIgBAFIAGgFQAEgBAEAAQAFAAADADQADADAAAEIgCAJIgEAWg");
	this.shape_12.setTransform(118.3,24.025);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CCCCCC").s().p("AgLAdIAJgpIAKAAIgIApgAgBgRIABgLIAMAAIgCALg");
	this.shape_13.setTransform(115.025,23.275);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CCCCCC").s().p("AgLATQgFgCgDgEQgBgFAAgEQAAgLAGgHQAGgHAKAAQAJAAAFAFQAFAFABAJQAAAJgHAHQgGAIgKAAQgGAAgEgDgAgDgKQgEACgBAFIgCAGQABAFACACQACADAEAAQAEAAADgEQAFgFgBgHQAAgEgCgDQgDgCgDAAQgCAAgDACg");
	this.shape_14.setTransform(111.3,24.075);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CCCCCC").s().p("AgYAdIANg4IAKAAIAAAEQABgDADgBQAEgBADAAQAGAAAEAEQAFAFAAAJQgBAKgGAIQgHAGgIAAQgGAAgFgGIgEAVgAAAgSQgCACgCAFIgBAIQAAADADADQACADACAAQADAAADgCQACgCACgEIABgJQAAgEgCgDQgCgCgDAAQgDAAgDACg");
	this.shape_15.setTransform(106.15,24.825);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAHgJALAAQAHAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEADACQACADADAAQAEAAAEgGIAKACQgDAGgFADQgFADgFAAQgJAAgFgGgAgDgKQgDADgBAFIARAAIAAgBQAAgFgDgCQgBgDgEAAQgCAAgDADg");
	this.shape_16.setTransform(99.55,24.075);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CCCCCC").s().p("AgRAVIAJgoIAJAAIgBAIQAGgJAGAAIAGABIgFAJIgDAAQgDAAgDACQgDACgBAEQgBACgCAIIgCANg");
	this.shape_17.setTransform(96.025,24.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CCCCCC").s().p("AgLATQgFgCgCgEQgCgFAAgEQgBgLAHgHQAGgHAKAAQAJAAAGAFQAEAFAAAJQABAJgHAHQgHAIgJAAQgGAAgEgDgAgEgKQgCACgCAFIgBAGQgBAFADACQADADADAAQAEAAADgEQAEgFAAgHQABgEgDgDQgDgCgDAAQgDAAgDACg");
	this.shape_18.setTransform(91.75,24.075);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CCCCCC").s().p("AgPARQgEgFAAgIQAAgGADgGQADgGAFgDQAGgEAFAAQAIAAAEAEQAEAEABAGIgKABQgBgDgBgCQgBAAgBAAQAAgBgBAAQAAAAgBAAQAAAAgBAAQgDAAgCACQgDACgBAFIgCAIQAAAEACACQAAAAABABQAAAAABAAQAAABABAAQAAAAABAAQACAAACgCQADgCACgEIAKACQgDAHgEAEQgGAEgGAAQgIAAgFgFg");
	this.shape_19.setTransform(87.15,24.075);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CCCCCC").s().p("AgNASQgGgDgBgGIAKgCQACAEACABQACACAEAAQADAAACgCQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAAAgBIgBgCIgFgCQgJgDgCgCQgEgCAAgFQAAgFAEgEQAFgFAJAAQAIAAAEADQAEADABAFIgKACIgDgDQgDgCgDAAIgEABQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQABAAAAAAIAGADIALAEQADADAAAEQAAAGgEAEQgGAFgIAAQgJAAgEgEg");
	this.shape_20.setTransform(82.5,24.075);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CCCCCC").s().p("AgPAYQgEgFAAgJQAAgJADgIQADgLAGgFQAGgFAGAAQAHAAAEAFQAEAFAAAJQAAAJgDAJQgDAKgGAFQgFAFgGAAQgHAAgFgFgAAAgQQgEAEgCAKQgCAIAAAGQAAAEABACQABABAAAAQABABAAAAQABAAAAAAQABAAAAAAQADAAACgDQADgEADgLQACgIAAgFQAAgEgCgCQAAgBgBAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQgDAAgBADg");
	this.shape_21.setTransform(76.075,23.325);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CCCCCC").s().p("AgPAYQgEgFAAgJQAAgJADgIQADgLAGgFQAGgFAGAAQAHAAAEAFQAEAFAAAJQAAAJgDAJQgDAKgGAFQgFAFgGAAQgHAAgFgFgAAAgQQgEAEgCAKQgCAIAAAGQAAAEABACQABABAAAAQAAABABAAQAAAAABAAQABAAAAAAQADAAACgDQADgEADgLQACgIAAgFQAAgEgCgCQAAgBgBAAQAAAAAAgBQgBAAgBAAQAAAAgBAAQgDAAgBADg");
	this.shape_22.setTransform(71.625,23.325);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CCCCCC").s().p("AgPAYQgEgFAAgJQAAgJADgIQADgLAGgFQAGgFAGAAQAHAAAEAFQAEAFAAAJQAAAJgDAJQgDAKgGAFQgFAFgGAAQgHAAgFgFgAAAgQQgEAEgCAKQgCAIAAAGQAAAEABACQABABAAAAQABABAAAAQAAAAABAAQABAAAAAAQADAAACgDQADgEADgLQACgIAAgFQAAgEgCgCQAAgBgBAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQgDAAgBADg");
	this.shape_23.setTransform(67.175,23.325);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#CCCCCC").s().p("AgOAYQgFgFgBgIIAMgBIAAACQAAAEABACQACACADAAQADAAADgEQAEgEAAgHQgBgEgCgBQgCgCgCAAIgEABIgDACIgKAAIAJgdIAbAAIgBALIgTAAIgCAIIACgBIADAAQAHAAAEAEQAFAFAAAGQAAAGgEAGQgDAGgEADQgGADgFAAQgHAAgEgFg");
	this.shape_24.setTransform(62.75,23.375);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_25.setTransform(57.225,23.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#CCCCCC").s().p("AgNAQQgGgFAAgJQAAgHAFgHQAHgJALAAQAHAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEADACQABADAEAAQAEAAAEgGIAKACQgDAGgFADQgFADgFAAQgJAAgEgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgCgCQgCgDgDAAQgCAAgDADg");
	this.shape_26.setTransform(53.35,24.075);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#CCCCCC").s().p("AgTAYQgIgGAAgMQAAgIADgIQAFgIAHgFQAHgGAJAAQAKABAGAEQAGAEACAJIgLABQgCgEgDgDQgDgCgFAAQgEAAgGADQgEADgDAGQgCAGgBAHQABAGADAEQADAEAHAAIAGgCIAHgCIACgJIgOAAIABgIIAaAAIgGAYQgEACgHACQgGADgGAAQgKgBgGgFg");
	this.shape_27.setTransform(48.2,23.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(2));

	// Layer 2
	this.instance = new lib.achievement_lock();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	this.instance_1 = new lib.check();
	this.instance_1.parent = this;
	this.instance_1.setTransform(176,24,0.1302,0.13);

	this.instance_2 = new lib.ach10();
	this.instance_2.parent = this;
	this.instance_2.setTransform(2,2,0.2811,0.2811);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).wait(1));

	// Layer_4
	this.instance_3 = new lib.achievementramis();
	this.instance_3.parent = this;
	this.instance_3.setTransform(97.2,20.9,1,1,0,0,0,97.2,20.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,194.6,42.1);


(lib.achievement9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgLAUQgEgGAAgOQAAgNAFgGQAEgGAGAAQAHAAAEAGQAFAGAAANQAAAOgFAGQgEAGgHAAQgGAAgFgGgAgCgPQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAIgBAMIABAMIACAFIACABIADgBIACgEIABgNIgBgLIgCgEQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgCACg");
	this.shape.setTransform(85.125,12.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("AgLAUQgEgGAAgOQAAgNAFgGQAEgGAGAAQAHAAAEAGQAFAGAAANQAAAOgFAGQgEAGgHAAQgGAAgFgGgAgCgPQgBAAAAAAQAAABAAAAQgBABAAAAQAAABAAAAIgBAMIABAMIACAFIACABIADgBIACgEIABgNIgBgLIgCgEQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgCACg");
	this.shape_1.setTransform(81.225,12.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("AgLAUQgEgGAAgOQAAgNAFgGQAEgGAGAAQAHAAAEAGQAFAGAAANQAAAOgFAGQgEAGgHAAQgGAAgFgGgAgCgPQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAIgBAMIABAMIACAFIACABIADgBIACgEIABgNIgBgLIgCgEQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgCACg");
	this.shape_2.setTransform(77.325,12.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AABAZIAAgjQgEAFgHACIAAgIQAEgCAEgDQAEgDACgFIAHAAIAAAxg");
	this.shape_3.setTransform(73.15,12.425);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AgSAZIAAgxIAkAAIAAAJIgaAAIAAAKIAYAAIAAAIIgYAAIAAAOIAbAAIAAAIg");
	this.shape_4.setTransform(67.3,12.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("AAKAZIgHgLIgEgHIgDgDIgFAAIgCAAIAAAVIgKAAIAAgxIAVAAQAHAAADABQAEABADAEQABADAAAFQAAAGgCAEQgEACgGABIAFAEIAGAIIAGAKgAgLgDIAHAAIAJgBIACgCIABgDIgBgFIgEgBIgGAAIgIAAg");
	this.shape_5.setTransform(62.6,12.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCCCC").s().p("AgRATQgGgHAAgLQAAgIACgFQACgEADgCQADgEADgBQAFgCAFAAQALAAAHAHQAGAHAAALQAAAMgGAHQgHAHgLAAQgKAAgHgHgAgJgMQgEAFAAAHQAAAIAEAFQAEAEAFAAQAGAAAEgEQAEgFAAgIQAAgIgEgEQgEgEgGAAQgFAAgEAEg");
	this.shape_6.setTransform(57.125,12.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCCCC").s().p("AgPATQgGgHAAgLQAAgMAHgHQAGgHAKAAQAJAAAFAGQAEACACAHIgKACQgBgEgDgCQgDgDgEABQgFAAgDADQgEAFAAAIQAAAJAEAEQADAEAFAAQAEAAADgDQADgCABgFIAKADQgDAIgFAEQgFAEgIAAQgJAAgHgHg");
	this.shape_7.setTransform(51.875,12.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CCCCCC").s().p("AgOAVQgEgEgCgIIALgBQABAFACACQADACAEABQAEAAADgCQACgDAAgCIgBgDIgEgDIgHgCQgIgCgDgCQgFgEABgGQAAgEACgDQACgDAEgCQAEgCAFAAQAJAAAFAEQAEAFABAGIgKABQgBgEgCgCQgCgCgEABQgEgBgCACQgBAAAAABQAAAAgBABQAAAAAAABQAAAAAAAAIACAEQACABAGABIALAFQAEABACACQABAEAAAFQAAAEgCAEQgCADgFACQgEACgHAAQgIAAgGgFg");
	this.shape_8.setTransform(47,12.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CCCCCC").s().p("AgGAGIADgLIAKAAIgDALg");
	this.shape_9.setTransform(128.775,25.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CCCCCC").s().p("AgOASQgFgDgBgGIALgCQABAEACABQACACAEAAQADAAACgCQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAAAgBIgBgCIgFgCQgJgDgCgCQgEgCAAgFQAAgFAEgEQAFgFAJAAQAIAAAEADQAEADABAFIgKACIgDgDQgDgCgDAAIgEABQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQABAAAAAAIAFADIAMAEQADADAAAEQAAAGgEAEQgGAFgIAAQgJAAgFgEg");
	this.shape_10.setTransform(125.6,24.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_11.setTransform(122.525,23.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CCCCCC").s().p("AAEAVIAGgWIAAgHQAAAAAAgBQAAAAAAgBQAAAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAAAAAQgDAAgDACQgCACgCADIgDAJIgDARIgLAAIAIgoIALAAIgBAFIAGgFQAEgBAEAAQAFAAADADQADADAAAEIgCAJIgEAWg");
	this.shape_12.setTransform(118.3,24.025);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CCCCCC").s().p("AgLAdIAJgpIAKAAIgIApgAgBgRIABgLIAMAAIgCALg");
	this.shape_13.setTransform(115.025,23.275);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CCCCCC").s().p("AgLATQgFgCgDgEQgBgFAAgEQAAgLAGgHQAGgHAKAAQAJAAAFAFQAFAFABAJQAAAJgHAHQgGAIgKAAQgGAAgEgDgAgDgKQgEACgBAFIgCAGQABAFACACQACADAEAAQAEAAADgEQAFgFgBgHQAAgEgCgDQgDgCgDAAQgCAAgDACg");
	this.shape_14.setTransform(111.3,24.075);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CCCCCC").s().p("AgYAdIANg4IAKAAIAAAEQABgDADgBQAEgBADAAQAGAAAEAEQAFAFAAAJQgBAKgGAIQgHAGgIAAQgGAAgFgGIgEAVgAAAgSQgCACgCAFIgBAIQAAADADADQACADACAAQADAAADgCQACgCACgEIABgJQAAgEgCgDQgCgCgDAAQgDAAgDACg");
	this.shape_15.setTransform(106.15,24.825);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAHgJALAAQAHAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEADACQACADADAAQAEAAAEgGIAKACQgDAGgFADQgFADgFAAQgJAAgFgGgAgDgKQgDADgBAFIARAAIAAgBQAAgFgDgCQgBgDgEAAQgCAAgDADg");
	this.shape_16.setTransform(99.55,24.075);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CCCCCC").s().p("AgRAVIAJgoIAJAAIgBAIQAGgJAGAAIAGABIgFAJIgDAAQgDAAgDACQgDACgBAEQgBACgCAIIgCANg");
	this.shape_17.setTransform(96.025,24.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CCCCCC").s().p("AgLATQgFgCgCgEQgCgFAAgEQgBgLAHgHQAGgHAKAAQAJAAAGAFQAEAFAAAJQABAJgHAHQgHAIgJAAQgGAAgEgDgAgEgKQgCACgCAFIgBAGQgBAFADACQADADADAAQAEAAADgEQAEgFAAgHQABgEgDgDQgDgCgDAAQgDAAgDACg");
	this.shape_18.setTransform(91.75,24.075);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CCCCCC").s().p("AgPARQgEgFAAgIQAAgGADgGQADgGAFgDQAGgEAFAAQAIAAAEAEQAEAEABAGIgKABQgBgDgBgCQgBAAgBAAQAAgBgBAAQAAAAgBAAQAAAAgBAAQgDAAgCACQgDACgBAFIgCAIQAAAEACACQAAAAABABQAAAAABAAQAAABABAAQAAAAABAAQACAAACgCQADgCACgEIAKACQgDAHgEAEQgGAEgGAAQgIAAgFgFg");
	this.shape_19.setTransform(87.15,24.075);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CCCCCC").s().p("AgNASQgGgDgBgGIAKgCQACAEACABQACACAEAAQADAAACgCQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAAAgBIgBgCIgFgCQgJgDgCgCQgEgCAAgFQAAgFAEgEQAFgFAJAAQAIAAAEADQAEADABAFIgKACIgDgDQgDgCgDAAIgEABQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQABAAAAAAIAGADIALAEQADADAAAEQAAAGgEAEQgGAFgIAAQgJAAgEgEg");
	this.shape_20.setTransform(82.5,24.075);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CCCCCC").s().p("AgPAYQgEgFAAgJQAAgJADgIQADgLAGgFQAGgFAGAAQAHAAAEAFQAEAFAAAJQAAAJgDAJQgDAKgGAFQgFAFgGAAQgHAAgFgFgAAAgQQgEAEgCAKQgCAIAAAGQAAAEABACQABABAAAAQABABAAAAQABAAAAAAQABAAAAAAQADAAACgDQADgEADgLQACgIAAgFQAAgEgCgCQAAgBgBAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQgDAAgBADg");
	this.shape_21.setTransform(76.075,23.325);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CCCCCC").s().p("AgPAYQgEgFAAgJQAAgJADgIQADgLAGgFQAGgFAGAAQAHAAAEAFQAEAFAAAJQAAAJgDAJQgDAKgGAFQgFAFgGAAQgHAAgFgFgAAAgQQgEAEgCAKQgCAIAAAGQAAAEABACQABABAAAAQAAABABAAQAAAAABAAQABAAAAAAQADAAACgDQADgEADgLQACgIAAgFQAAgEgCgCQAAgBgBAAQAAAAAAgBQgBAAgBAAQAAAAgBAAQgDAAgBADg");
	this.shape_22.setTransform(71.625,23.325);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CCCCCC").s().p("AgPAYQgEgFAAgJQAAgJADgIQADgLAGgFQAGgFAGAAQAHAAAEAFQAEAFAAAJQAAAJgDAJQgDAKgGAFQgFAFgGAAQgHAAgFgFgAAAgQQgEAEgCAKQgCAIAAAGQAAAEABACQABABAAAAQABABAAAAQAAAAABAAQABAAAAAAQADAAACgDQADgEADgLQACgIAAgFQAAgEgCgCQAAgBgBAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQgDAAgBADg");
	this.shape_23.setTransform(67.175,23.325);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#CCCCCC").s().p("AgHAdIAIgnIgIAEIgIADIACgKQAOgGAIgJIAHAAIgMA5g");
	this.shape_24.setTransform(62.725,23.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_25.setTransform(57.225,23.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#CCCCCC").s().p("AgNAQQgGgFAAgJQAAgHAFgHQAHgJALAAQAHAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEADACQABADAEAAQAEAAAEgGIAKACQgDAGgFADQgFADgFAAQgJAAgEgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgCgCQgCgDgDAAQgCAAgDADg");
	this.shape_26.setTransform(53.35,24.075);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#CCCCCC").s().p("AgTAYQgIgGAAgMQAAgIADgIQAFgIAHgFQAHgGAJAAQAKABAGAEQAGAEACAJIgLABQgCgEgDgDQgDgCgFAAQgEAAgGADQgEADgDAGQgCAGgBAHQABAGADAEQADAEAHAAIAGgCIAHgCIACgJIgOAAIABgIIAaAAIgGAYQgEACgHACQgGADgGAAQgKgBgGgFg");
	this.shape_27.setTransform(48.2,23.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(2));

	// Layer 2
	this.instance = new lib.achievement_lock();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	this.instance_1 = new lib.check();
	this.instance_1.parent = this;
	this.instance_1.setTransform(176,24,0.1302,0.13);

	this.instance_2 = new lib.ach9();
	this.instance_2.parent = this;
	this.instance_2.setTransform(2,2,0.2811,0.2811);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).wait(1));

	// Layer_4
	this.instance_3 = new lib.achievementramis();
	this.instance_3.parent = this;
	this.instance_3.setTransform(97.2,20.9,1,1,0,0,0,97.2,20.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,194.6,42.1);


(lib.achievement8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgLAUQgEgGAAgOQAAgNAFgGQAEgGAGAAQAHAAAEAGQAFAGAAANQAAAOgFAGQgEAGgHAAQgGAAgFgGgAgCgPQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAIgBAMIABAMIACAFIACABIADgBIACgEIABgNIgBgLIgCgEQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgCACg");
	this.shape.setTransform(85.675,12.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("AgQAZQABgFADgEQACgFAIgHIAIgIQABgDAAgCQAAgEgBgBQgBgBAAAAQgBAAAAgBQgBAAgBAAQAAAAgBAAQgCAAgCACQgCACAAAEIgJgBQAAgIAEgEQAFgDAGAAQAHAAAFAEQAEAEAAAGQAAADgCADIgDAGIgGAGIgGAGIgBACIASAAIAAAJg");
	this.shape_1.setTransform(81.7,12.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("AAHASIgHgLIgHALIgLAAIANgSIgNgRIAMAAIAGAKIAHgKIALAAIgMARIANASg");
	this.shape_2.setTransform(77.9,13.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AgOAVQgEgEgCgIIAKgBQACAFACACQADACAEABQAEAAACgCQADgDAAgCIgBgDIgEgDIgHgCQgIgCgDgCQgFgEABgGQAAgEACgDQACgDAEgCQAEgCAFAAQAJAAAFAEQAEAFABAGIgKABQgBgEgCgCQgCgCgEABQgEgBgCACQgBAAAAABQAAAAgBABQAAAAAAABQAAAAAAAAIACAEQACABAGABIALAFQAEABACACQACAEAAAFQgBAEgCAEQgCADgFACQgEACgHAAQgJAAgFgFg");
	this.shape_3.setTransform(71.65,12.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AALAZIgHgLIgFgHIgDgDIgFAAIgDAAIAAAVIgKAAIAAgxIAWAAQAHAAAEABQADABACAEQACADABAFQgBAGgDAEQgDACgHABIAGAEIAFAIIAGAKgAgMgDIAIAAIAJgBIACgCIABgDIgBgFIgEgBIgHAAIgIAAg");
	this.shape_4.setTransform(67.05,12.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("AAOAZIgEgMIgTAAIgFAMIgKAAIATgxIAKAAIAUAxgAgGAFIAMAAIgGgSg");
	this.shape_5.setTransform(62.025,12.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCCCC").s().p("AgEAZIAAgoIgPAAIAAgJIAnAAIAAAJIgPAAIAAAog");
	this.shape_6.setTransform(57.35,12.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCCCC").s().p("AgOAVQgEgEgCgIIALgBQABAFACACQADACAEABQAEAAADgCQACgDAAgCIgBgDIgEgDIgHgCQgIgCgDgCQgFgEABgGQAAgEACgDQACgDAEgCQAEgCAFAAQAJAAAFAEQAEAFABAGIgKABQgBgEgCgCQgCgCgEABQgEgBgCACQgBAAAAABQAAAAgBABQAAAAAAABQAAAAAAAAIACAEQACABAGABIALAFQAEABACACQABAEAAAFQAAAEgCAEQgCADgFACQgEACgHAAQgIAAgGgFg");
	this.shape_7.setTransform(52.85,12.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CCCCCC").s().p("AgKAWQgFgEgBgHIAKgBQAAAEACACQABAAAAABQABAAAAAAQABAAABABQAAAAAAAAQADAAACgDQACgCAAgEQAAgDgCgCQgCgDgDAAIgDABIABgHQADAAACgBQACgCAAgDQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAgBgBAAQAAAAAAAAQgBgBgBAAQAAAAAAAAQAAAAgBAAQgBABAAAAQAAAAgBAAQAAABgBAAQgCACAAADIgJgBIADgIQACgCADgCQADgCAEAAQAHAAAEAFQADAEAAAEQAAAHgHAEQAFABACACQADADAAAFQAAAGgFAFQgFAFgHAAQgGAAgEgEg");
	this.shape_8.setTransform(46.625,12.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CCCCCC").s().p("AgGAFIADgJIAKAAIgDAJg");
	this.shape_9.setTransform(106.525,34.65);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CCCCCC").s().p("AgSAbQgFgDAAgHIAAgCIAMACIABACIACACIADABQAEAAABgCQAAAAABAAQAAgBABAAQAAgBAAAAQABgBAAAAIABgHIABgCQgFAFgGAAQgHAAgDgEQgEgFAAgHQAAgHACgGQADgGAFgEQAFgDAFAAQADAAADACQAEADABAEIACgIIALAAIgIAiIgDAMIgCAFIgEAEIgGACIgGABQgJAAgEgDgAgEgSQgDACgBAFIgBAHQAAAEACACQACADADAAQACAAADgDQACgCACgDIABgIQAAgEgCgDQgCgDgDAAQgCAAgDADg");
	this.shape_10.setTransform(103.225,33.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CCCCCC").s().p("AAFAVIAEgWIABgHQAAAAAAgBQAAAAAAAAQAAgBAAAAQgBgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAAAAAQgDAAgDACQgCACgBADIgEAJIgDARIgLAAIAJgoIAKAAIgBAFIAHgFQADgBAEAAQAFAAADADQADADAAAEIgCAJIgEAWg");
	this.shape_11.setTransform(98.25,33.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CCCCCC").s().p("AgLAdIAJgpIAKAAIgIApgAgBgRIABgLIAMAAIgCALg");
	this.shape_12.setTransform(94.975,32.325);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgQIgGAAIACgIIAFAAIACgGIAMgIIgDAOIAHAAIgCAIIgHAAIgEAQIAAAGIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEgBIgCAJIgFAAQgGABgDgDg");
	this.shape_13.setTransform(92.725,32.45);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CCCCCC").s().p("AgPASQgDgDAAgFQAAgGADgEQAEgCAKgBIAJgCIABgDQAAgBAAAAQAAgBAAAAQgBAAAAgBQAAAAAAAAQgBgBAAAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQgBAAAAAAQgBAAgBABQAAAAAAAAQAAAAAAABQgBAAAAAAQgBABAAAAQAAABgBAAQAAABAAAAIgLgBQACgFAEgEQAFgDAHAAQAIAAAEAEQAEADgBAEIAAAEIgCAKIgBALIABAGIgLAAIgBgFIgFAEIgHACQgEAAgEgEgAAEACQgIABgCACQAAAAgBABQAAAAAAAAQgBABAAABQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAAAQAAABAAAAIAFABIADgBIAEgDIACgGIAAgCIgDABg");
	this.shape_14.setTransform(88.7,33.125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CCCCCC").s().p("AgRAVIAJgoIAJAAIgBAIQAGgJAGAAIAGABIgFAJIgDAAQgDAAgDACQgDACgBAEQgBACgCAIIgCANg");
	this.shape_15.setTransform(85.325,33.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CCCCCC").s().p("AgRAVIAJgoIAJAAIgBAIQAGgJAGAAIAGABIgFAJIgDAAQgDAAgDACQgDACgBAEQgBACgCAIIgCANg");
	this.shape_16.setTransform(80.025,33.075);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CCCCCC").s().p("AgPASQgDgDgBgFQAAgGAFgEQADgCAJgBIAKgCIABgDQAAgBAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQgBAAAAAAQgBAAgBABQAAAAAAAAQAAAAgBABQAAAAAAAAQgBABAAAAQAAABgBAAQAAABAAAAIgLgBQACgFAEgEQAGgDAGAAQAIAAAEAEQADADAAAEIAAAEIgCAKIgBALIAAAGIgKAAIgBgFIgFAEIgHACQgFAAgDgEgAAEACQgHABgDACQAAAAgBABQAAAAAAAAQgBABAAABQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAAAQAAABAAAAIAFABIADgBIAEgDIACgGIAAgCIgDABg");
	this.shape_17.setTransform(75.85,33.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgQIgGAAIACgIIAFAAIACgGIAMgIIgDAOIAHAAIgCAIIgHAAIgEAQIAAAGIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEgBIgCAJIgFAAQgGABgDgDg");
	this.shape_18.setTransform(72.775,32.45);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CCCCCC").s().p("AgNASQgGgDgBgGIAKgCQACAEACABQADACADAAQADAAACgCQAAAAABAAQAAgBABAAQAAgBAAAAQAAAAAAgBIgBgCIgEgCQgKgDgCgCQgEgCAAgFQAAgFADgEQAGgFAJAAQAIAAAEADQAEADABAFIgKACIgDgDQgDgCgDAAIgEABQAAABgBAAQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQABAAAAAAIAGADIAKAEQAEADAAAEQAAAGgEAEQgFAFgJAAQgIAAgFgEg");
	this.shape_19.setTransform(68.75,33.125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CCCCCC").s().p("AgNAQQgGgFAAgJQAAgHAFgHQAGgJAMAAQAHAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQADADADAAQAEAAAEgGIAKACQgDAGgFADQgFADgFAAQgJAAgEgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgDgDgDAAQgDAAgCADg");
	this.shape_20.setTransform(62.25,33.125);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAGgJALAAQAIAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEACACQADADADAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgJAAgFgGgAgDgKQgDADgBAFIARAAIAAgBQAAgFgCgCQgDgDgDAAQgDAAgCADg");
	this.shape_21.setTransform(57.8,33.125);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CCCCCC").s().p("AgRAVIAJgoIAJAAIgBAIQAGgJAGAAIAGABIgFAJIgDAAQgDAAgDACQgDACgBAEQgBACgCAIIgCANg");
	this.shape_22.setTransform(54.275,33.075);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CCCCCC").s().p("AAEAdIAFgZIABgEQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAQgDAAgDACQgCADgCADIgDAJIgDARIgLAAIAMg5IAKAAIgDAVQACgDAEgBQADgCAEAAQAFAAADADQADADAAAFIgCAGIgEAZg");
	this.shape_23.setTransform(49.9,32.325);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgQIgGAAIACgIIAFAAIACgGIAMgIIgDAOIAHAAIgCAIIgHAAIgEAQIAAAGIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEgBIgCAJIgFAAQgGABgDgDg");
	this.shape_24.setTransform(46.575,32.45);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#CCCCCC").s().p("AAFAdIAEgZIACgEQAAgBgBAAQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAgBAAQgCAAgDACQgCADgCADIgCAJIgEARIgLAAIAMg5IAKAAIgDAVQADgDADgBQADgCAEAAQAFAAADADQADADAAAFIgBAGIgGAZg");
	this.shape_25.setTransform(148.85,23.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_26.setTransform(145.525,23.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#CCCCCC").s().p("AgLAdIAJgpIAKAAIgIApgAgBgRIABgLIAMAAIgCALg");
	this.shape_27.setTransform(142.925,23.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#CCCCCC").s().p("AAAAVIgBgaIgNAaIgKAAIgGgpIAKAAIADAbIANgbIAJAAIACAbIANgbIALAAIgVApg");
	this.shape_28.setTransform(138.875,24.075);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#CCCCCC").s().p("AgOASQgFgDgBgGIALgCQABAEACABQADACADAAQADAAACgCQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAAAgBIgBgCIgFgCQgJgDgCgCQgEgCAAgFQAAgFAEgEQAFgFAJAAQAIAAAEADQAEADABAFIgKACIgDgDQgDgCgDAAIgEABQAAAAgBABQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAABAAQAAABAAAAQAAAAAAABQABAAAAAAIAFADIAMAEQADADAAAEQABAGgGAEQgEAFgJAAQgIAAgGgEg");
	this.shape_29.setTransform(130.9,24.075);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_30.setTransform(127.875,23.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAGgJALAAQAIAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEACACQADADADAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgJAAgFgGgAgDgKQgDADgBAFIARAAIAAgBQAAgFgCgCQgDgDgDAAQgDAAgCADg");
	this.shape_31.setTransform(124.4,24.075);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#CCCCCC").s().p("AgMAVIgJgpIALAAIADASIACAJIACgFIADgEIAKgSIAMAAIgZApg");
	this.shape_32.setTransform(120.275,24.075);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAGgJALAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIARAAIAAgBQAAgFgCgCQgCgDgEAAQgDAAgCADg");
	this.shape_33.setTransform(115.5,24.075);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_34.setTransform(112.325,23.275);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#CCCCCC").s().p("AgYAcIABgJIAFABQAEAAAEgIIgIgoIAMAAIADAUIABALQACgGADgHIAKgSIAMAAIgZAsIgFAIIgEAEQgDABgEAAIgIgBg");
	this.shape_35.setTransform(106.7,24.925);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_36.setTransform(103.425,23.4);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#CCCCCC").s().p("AAEAVIAGgWIABgHQAAAAgBgBQAAAAAAgBQAAAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAgBAAQgCAAgDACQgCACgCADIgCAJIgEARIgLAAIAIgoIALAAIgBAFIAGgFQAEgBAEAAQAFAAADADQADADAAAEIgCAJIgFAWg");
	this.shape_37.setTransform(99.2,24.025);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#CCCCCC").s().p("AgNAQQgGgFAAgJQAAgHAFgHQAGgJAMAAQAHAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQADADADAAQAEAAAEgGIAKACQgDAGgFADQgFADgFAAQgJAAgEgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgDgDgDAAQgDAAgCADg");
	this.shape_38.setTransform(94.65,24.075);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#CCCCCC").s().p("AAAAVIgBgaIgNAaIgKAAIgGgpIAKAAIADAbIANgbIAJAAIACAbIANgbIALAAIgVApg");
	this.shape_39.setTransform(89.625,24.075);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_40.setTransform(85.225,23.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAGgJALAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQABgFgCgCQgCgDgEAAQgDAAgCADg");
	this.shape_41.setTransform(79.15,24.075);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_42.setTransform(75.925,23.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAHgJAKAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgCgDgEAAQgCAAgDADg");
	this.shape_43.setTransform(72.05,24.075);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_44.setTransform(68.875,23.275);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#CCCCCC").s().p("AgXAdIALg4IALAAIgBAEQADgDACgBQADgBAEAAQAHAAAEAEQADAFAAAJQAAAKgGAIQgGAGgJAAQgHAAgDgGIgFAVgAAAgSQgCACgCAFIgBAIQAAADACADQADADACAAQADAAACgCQADgCACgEIABgJQAAgEgBgDQgDgCgEAAQgDAAgCACg");
	this.shape_45.setTransform(64.9,24.825);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#CCCCCC").s().p("AAQAVIAFgYIABgFIgBgDIgDgBQgEAAgEAEQgCADgCAHIgEATIgKAAIAFgYIABgFIgBgDIgDgBIgEABIgDADIgDAFIgBAFIgEATIgLAAIAIgoIALAAIgBAFQAGgGAHAAQADAAADACQADACAAADQACgDAEgCQAEgCAFAAQAFAAACACQADADAAAEIgBAIIgFAYg");
	this.shape_46.setTransform(59.025,24.025);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#CCCCCC").s().p("AgLATQgFgCgCgEQgCgFAAgEQgBgLAHgHQAGgHAKAAQAJAAAGAFQAEAFAAAJQABAJgHAHQgGAIgKAAQgGAAgEgDgAgDgKQgEACgBAFIgBAGQgBAFADACQADADADAAQAEAAADgEQAFgFgBgHQABgEgDgDQgDgCgDAAQgCAAgDACg");
	this.shape_47.setTransform(53.15,24.075);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#CCCCCC").s().p("AgTAXQgGgGAAgMQAAgJAEgIQAEgIAHgEQAHgFAIAAQAJAAAGAGQAFAEABAJIgLABQgBgFgCgDQgEgCgEAAQgEAAgEAEQgEACgDAHQgDAGABAGQgBAGAEAEQADAEAFAAQAEgBADgDQAFgDACgFIALABQgEALgGAEQgHAFgIABQgLAAgGgHg");
	this.shape_48.setTransform(48.05,23.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(2));

	// Layer 2
	this.instance = new lib.achievement_lock();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	this.instance_1 = new lib.check();
	this.instance_1.parent = this;
	this.instance_1.setTransform(176,24,0.1302,0.13);

	this.instance_2 = new lib.ach8();
	this.instance_2.parent = this;
	this.instance_2.setTransform(2,2,0.2811,0.2811);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).wait(1));

	// Layer_4
	this.instance_3 = new lib.achievementramis();
	this.instance_3.parent = this;
	this.instance_3.setTransform(97.2,20.9,1,1,0,0,0,97.2,20.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,194.6,42.1);


(lib.achievement7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgLAUQgEgGAAgOQAAgNAFgGQAEgGAGAAQAHAAAEAGQAFAGAAANQAAAOgFAGQgEAGgHAAQgGAAgFgGgAgCgPQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAIgBAMIABAMIACAFIACABIADgBIACgEIABgNIgBgLIgCgEQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgCACg");
	this.shape.setTransform(85.675,12.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("AABAZIAAgjQgEAFgHACIAAgIQAEgCAEgDQAEgDABgFIAIAAIAAAxg");
	this.shape_1.setTransform(81.5,12.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("AAHASIgHgLIgHALIgLAAIANgSIgNgRIAMAAIAGAKIAHgKIALAAIgMARIANASg");
	this.shape_2.setTransform(77.9,13.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AgOAVQgEgEgCgIIAKgBQACAFACACQADACAEABQAEAAACgCQADgDAAgCIgBgDIgEgDIgHgCQgIgCgDgCQgFgEABgGQAAgEACgDQACgDAEgCQAEgCAFAAQAJAAAFAEQAEAFABAGIgKABQgBgEgCgCQgCgCgEABQgEgBgCACQgBAAAAABQAAAAgBABQAAAAAAABQAAAAAAAAIACAEQACABAGABIALAFQAEABACACQACAEAAAFQgBAEgCAEQgCADgFACQgEACgHAAQgJAAgFgFg");
	this.shape_3.setTransform(71.65,12.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AALAZIgHgLIgFgHIgDgDIgFAAIgDAAIAAAVIgKAAIAAgxIAWAAQAHAAAEABQADABACAEQACADABAFQgBAGgDAEQgDACgHABIAGAEIAFAIIAGAKgAgMgDIAIAAIAJgBIACgCIABgDIgBgFIgEgBIgHAAIgIAAg");
	this.shape_4.setTransform(67.05,12.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("AAOAZIgEgMIgTAAIgFAMIgKAAIATgxIAKAAIAUAxgAgGAFIAMAAIgGgSg");
	this.shape_5.setTransform(62.025,12.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCCCC").s().p("AgEAZIAAgoIgPAAIAAgJIAnAAIAAAJIgPAAIAAAog");
	this.shape_6.setTransform(57.35,12.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCCCC").s().p("AgOAVQgEgEgCgIIALgBQABAFACACQADACAEABQAEAAADgCQACgDAAgCIgBgDIgEgDIgHgCQgIgCgDgCQgFgEABgGQAAgEACgDQACgDAEgCQAEgCAFAAQAJAAAFAEQAEAFABAGIgKABQgBgEgCgCQgCgCgEABQgEgBgCACQgBAAAAABQAAAAgBABQAAAAAAABQAAAAAAAAIACAEQACABAGABIALAFQAEABACACQABAEAAAFQAAAEgCAEQgCADgFACQgEACgHAAQgIAAgGgFg");
	this.shape_7.setTransform(52.85,12.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CCCCCC").s().p("AgKAWQgFgEgBgHIAKgBQAAAEACACQABAAAAABQABAAAAAAQABAAABABQAAAAAAAAQADAAACgDQACgCAAgEQAAgDgCgCQgCgDgDAAIgDABIABgHQADAAACgBQACgCAAgDQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAgBgBAAQAAAAAAAAQgBgBgBAAQAAAAAAAAQAAAAgBAAQgBABAAAAQAAAAgBAAQAAABgBAAQgCACAAADIgJgBIADgIQACgCADgCQADgCAEAAQAHAAAEAFQADAEAAAEQAAAHgHAEQAFABACACQADADAAAFQAAAGgFAFQgFAFgHAAQgGAAgEgEg");
	this.shape_8.setTransform(46.625,12.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CCCCCC").s().p("AgGAFIADgJIAKAAIgDAJg");
	this.shape_9.setTransform(84.775,34.65);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CCCCCC").s().p("AgSAbQgFgDAAgHIAAgCIAMACIABACIACACIADABQAEAAABgCQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBABAAIABgHIABgCQgFAFgGAAQgHAAgDgEQgEgFAAgHQAAgHACgGQADgGAFgEQAFgDAFAAQADAAADACQAEADABAEIACgIIALAAIgIAiIgDAMIgCAFIgEAEIgGACIgGABQgJAAgEgDgAgEgSQgDACgBAFIgBAHQAAAEACACQACADADAAQACAAADgDQACgCACgDIABgIQAAgEgCgDQgCgDgDAAQgCAAgDADg");
	this.shape_10.setTransform(81.475,33.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CCCCCC").s().p("AAEAVIAGgWIABgHQAAAAgBgBQAAAAAAAAQAAgBAAAAQgBgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAgBAAQgCAAgDACQgCACgCADIgCAJIgEARIgLAAIAJgoIAKAAIgBAFIAHgFQADgBAEAAQAFAAADADQADADAAAEIgBAJIgGAWg");
	this.shape_11.setTransform(76.5,33.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CCCCCC").s().p("AgLAdIAJgpIAKAAIgIApgAgBgRIABgLIAMAAIgCALg");
	this.shape_12.setTransform(73.225,32.325);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgQIgGAAIACgIIAFAAIACgGIAMgIIgDAOIAHAAIgCAIIgHAAIgEAQIAAAGIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEgBIgCAJIgFAAQgGABgDgDg");
	this.shape_13.setTransform(70.975,32.45);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CCCCCC").s().p("AgPASQgDgDgBgFQAAgGAFgEQADgCAJgBIAKgCIABgDQAAgBAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQgBAAAAAAQgBAAgBABQAAAAAAAAQAAAAgBABQAAAAAAAAQgBABAAAAQAAABgBAAQAAABAAAAIgLgBQACgFAEgEQAGgDAGAAQAIAAAEAEQAEADAAAEIAAAEIgDAKIgCALIABAGIgLAAIAAgFIgFAEIgGACQgGAAgDgEgAAEACQgHABgDACQgBAAAAABQAAAAAAAAQgBABAAABQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAAAQAAABABAAIADABIAEgBIAEgDIABgGIAAgCIgCABg");
	this.shape_14.setTransform(66.95,33.125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CCCCCC").s().p("AgRAVIAJgoIAJAAIgBAIQAGgJAGAAIAGABIgFAJIgDAAQgDAAgDACQgDACgBAEQgBACgCAIIgCANg");
	this.shape_15.setTransform(63.575,33.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CCCCCC").s().p("AgRAVIAJgoIAJAAIgBAIQAGgJAGAAIAGABIgFAJIgDAAQgDAAgDACQgDACgBAEQgBACgCAIIgCANg");
	this.shape_16.setTransform(58.275,33.075);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CCCCCC").s().p("AgPASQgEgDAAgFQABgGAEgEQADgCAJgBIAKgCIABgDQAAgBAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQgBAAAAAAQgBAAgBABQAAAAAAAAQAAAAgBABQAAAAAAAAQgBABAAAAQAAABgBAAQAAABAAAAIgLgBQACgFAFgEQAEgDAHAAQAIAAAEAEQADADABAEIAAAEIgDAKIgCALIABAGIgLAAIgBgFIgEAEIgGACQgFAAgEgEgAAEACQgHABgDACQgBAAAAABQAAAAgBAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAAAQAAABABAAIADABIAEgBIADgDIACgGIAAgCIgCABg");
	this.shape_17.setTransform(54.1,33.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgQIgGAAIACgIIAFAAIACgGIAMgIIgDAOIAHAAIgCAIIgHAAIgEAQIAAAGIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEgBIgCAJIgFAAQgGABgDgDg");
	this.shape_18.setTransform(51.025,32.45);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CCCCCC").s().p("AgOASQgEgDgCgGIALgCQABAEACABQADACADAAQADAAACgCQABAAAAAAQAAgBABAAQAAgBAAAAQAAAAAAgBIgBgCIgEgCQgKgDgCgCQgEgCAAgFQAAgFADgEQAGgFAJAAQAIAAAEADQAEADABAFIgKACIgDgDQgCgCgEAAIgEABQAAABgBAAQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAABAAQAAABAAAAQAAAAAAABQABAAAAAAIAFADIALAEQAFADAAAEQAAAGgGAEQgFAFgIAAQgJAAgFgEg");
	this.shape_19.setTransform(47,33.125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CCCCCC").s().p("AgNAQQgGgFAAgJQAAgHAFgHQAGgJAMAAQAHAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQADADADAAQAEAAAEgGIAKACQgDAGgFADQgFADgFAAQgJAAgEgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgCgCQgCgDgDAAQgDAAgCADg");
	this.shape_20.setTransform(157.65,24.075);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAGgJALAAQAIAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEADACQACADADAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgJAAgFgGgAgDgKQgDADgBAFIARAAIAAgBQAAgFgCgCQgDgDgDAAQgDAAgCADg");
	this.shape_21.setTransform(153.2,24.075);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CCCCCC").s().p("AgRAVIAJgoIAJAAIgBAIQAGgJAGAAIAGABIgFAJIgDAAQgDAAgDACQgDACgBAEQgBACgCAIIgCANg");
	this.shape_22.setTransform(149.675,24.025);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CCCCCC").s().p("AAEAdIAFgZIABgEQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAQgDAAgDACQgCADgCADIgDAJIgDARIgLAAIAMg5IAKAAIgDAVQADgDADgBQADgCAEAAQAFAAADADQADADAAAFIgCAGIgEAZg");
	this.shape_23.setTransform(145.3,23.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_24.setTransform(141.975,23.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#CCCCCC").s().p("AAEAdIAGgZIABgEQAAgBgBAAQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAgBAAQgCAAgDACQgCADgCADIgCAJIgEARIgLAAIAMg5IAKAAIgDAVQACgDAEgBQADgCAEAAQAFAAADADQADADAAAFIgBAGIgGAZg");
	this.shape_25.setTransform(135.55,23.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_26.setTransform(132.225,23.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#CCCCCC").s().p("AgLAdIAJgpIAKAAIgIApgAgBgRIABgLIAMAAIgCALg");
	this.shape_27.setTransform(129.625,23.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#CCCCCC").s().p("AAAAVIgBgaIgNAaIgKAAIgGgpIAKAAIADAbIANgbIAJAAIACAbIANgbIALAAIgVApg");
	this.shape_28.setTransform(125.575,24.075);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#CCCCCC").s().p("AgNASQgGgDgBgGIAKgCQACAEACABQACACAEAAQADAAACgCQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAAAgBIgBgCIgFgCQgJgDgCgCQgEgCAAgFQAAgFAEgEQAFgFAJAAQAIAAAEADQAEADABAFIgKACIgDgDQgDgCgDAAIgEABQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQABAAAAAAIAGADIALAEQADADAAAEQAAAGgEAEQgGAFgIAAQgJAAgEgEg");
	this.shape_29.setTransform(117.6,24.075);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_30.setTransform(114.575,23.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAGgJALAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgCgDgEAAQgDAAgCADg");
	this.shape_31.setTransform(111.1,24.075);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#CCCCCC").s().p("AgMAVIgJgpIALAAIADASIACAJIACgFIADgEIAKgSIAMAAIgZApg");
	this.shape_32.setTransform(106.975,24.075);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAHgJAKAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgCgDgEAAQgCAAgDADg");
	this.shape_33.setTransform(102.2,24.075);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_34.setTransform(99.025,23.275);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#CCCCCC").s().p("AAEAVIAGgWIAAgHQAAAAAAgBQAAAAAAgBQAAAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAgBAAQgCAAgDACQgCACgCADIgDAJIgDARIgLAAIAIgoIALAAIgBAFIAGgFQAEgBAEAAQAFAAADADQADADAAAEIgCAJIgEAWg");
	this.shape_35.setTransform(93,24.025);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#CCCCCC").s().p("AgNAQQgGgFAAgJQAAgHAFgHQAHgJALAAQAHAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEADACQABADAEAAQAEAAAEgGIAKACQgDAGgFADQgFADgFAAQgJAAgEgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgCgCQgCgDgDAAQgCAAgDADg");
	this.shape_36.setTransform(88.45,24.075);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_37.setTransform(85.225,23.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAGgJALAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQABgFgCgCQgCgDgEAAQgDAAgCADg");
	this.shape_38.setTransform(79.15,24.075);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_39.setTransform(75.925,23.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAHgJAKAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgCgDgEAAQgCAAgDADg");
	this.shape_40.setTransform(72.05,24.075);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_41.setTransform(68.875,23.275);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#CCCCCC").s().p("AgXAdIALg4IALAAIgBAEQADgDACgBQADgBAEAAQAHAAAEAEQADAFAAAJQAAAKgGAIQgGAGgJAAQgHAAgDgGIgFAVgAAAgSQgCACgCAFIgBAIQAAADACADQADADACAAQADAAACgCQADgCACgEIABgJQAAgEgBgDQgDgCgEAAQgDAAgCACg");
	this.shape_42.setTransform(64.9,24.825);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#CCCCCC").s().p("AAQAVIAFgYIABgFIgBgDIgDgBQgEAAgEAEQgCADgCAHIgEATIgKAAIAFgYIABgFIgBgDIgDgBIgEABIgDADIgDAFIgBAFIgEATIgLAAIAIgoIALAAIgBAFQAGgGAHAAQADAAADACQADACAAADQACgDAEgCQAEgCAFAAQAFAAACACQADADAAAEIgBAIIgFAYg");
	this.shape_43.setTransform(59.025,24.025);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#CCCCCC").s().p("AgLATQgFgCgCgEQgCgFAAgEQgBgLAHgHQAGgHAKAAQAJAAAGAFQAEAFAAAJQABAJgHAHQgGAIgKAAQgGAAgEgDgAgDgKQgEACgBAFIgBAGQgBAFADACQADADADAAQAEAAADgEQAFgFgBgHQABgEgDgDQgDgCgDAAQgCAAgDACg");
	this.shape_44.setTransform(53.15,24.075);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#CCCCCC").s().p("AgTAXQgGgGAAgMQAAgJAEgIQAEgIAHgEQAHgFAIAAQAJAAAGAGQAFAEABAJIgLABQgBgFgCgDQgEgCgEAAQgEAAgEAEQgEACgDAHQgDAGABAGQgBAGAEAEQADAEAFAAQAEgBADgDQAFgDACgFIALABQgEALgGAEQgHAFgIABQgLAAgGgHg");
	this.shape_45.setTransform(48.05,23.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(2));

	// Layer 2
	this.instance = new lib.achievement_lock();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	this.instance_1 = new lib.check();
	this.instance_1.parent = this;
	this.instance_1.setTransform(176,24,0.1302,0.13);

	this.instance_2 = new lib.ach7();
	this.instance_2.parent = this;
	this.instance_2.setTransform(2,2,0.2811,0.2811);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).wait(1));

	// Layer_4
	this.instance_3 = new lib.achievementramis();
	this.instance_3.parent = this;
	this.instance_3.setTransform(97.2,20.9,1,1,0,0,0,97.2,20.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,194.6,42.1);


(lib.achievement6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgOAVQgEgEgCgIIAKgBQACAFACACQADACAEABQAEAAACgCQADgDAAgCIgBgDIgEgDIgHgCQgIgCgDgCQgFgEABgGQAAgEACgDQACgDAEgCQAEgCAFAAQAJAAAFAEQAEAFABAGIgKABQgBgEgCgCQgCgCgEABQgEgBgCACQgBAAAAABQAAAAgBABQAAAAAAABQAAAAAAAAIACAEQACABAGABIALAFQAEABACACQACAEAAAFQgBAEgCAEQgCADgFACQgEACgHAAQgJAAgFgFg");
	this.shape.setTransform(71.65,12.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("AALAZIgHgLIgFgHIgDgDIgFAAIgDAAIAAAVIgKAAIAAgxIAWAAQAHAAAEABQADABACAEQACADABAFQgBAGgDAEQgDACgHABIAGAEIAFAIIAGAKgAgMgDIAIAAIAJgBIACgCIABgDIgBgFIgEgBIgHAAIgIAAg");
	this.shape_1.setTransform(67.05,12.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("AAOAZIgEgMIgTAAIgFAMIgKAAIATgxIAKAAIAUAxgAgGAFIAMAAIgGgSg");
	this.shape_2.setTransform(62.025,12.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AgEAZIAAgoIgPAAIAAgJIAnAAIAAAJIgPAAIAAAog");
	this.shape_3.setTransform(57.35,12.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AgOAVQgEgEgCgIIALgBQABAFACACQADACAEABQAEAAADgCQACgDAAgCIgBgDIgEgDIgHgCQgIgCgDgCQgFgEABgGQAAgEACgDQACgDAEgCQAEgCAFAAQAJAAAFAEQAEAFABAGIgKABQgBgEgCgCQgCgCgEABQgEgBgCACQgBAAAAABQAAAAgBABQAAAAAAABQAAAAAAAAIACAEQACABAGABIALAFQAEABACACQABAEAAAFQAAAEgCAEQgCADgFACQgEACgHAAQgIAAgGgFg");
	this.shape_4.setTransform(52.85,12.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("AgKAWQgFgEgBgHIAKgBQAAAEACACQABAAAAABQABAAAAAAQABAAABABQAAAAAAAAQADAAACgDQACgCAAgEQAAgDgCgCQgCgDgDAAIgDABIABgHQADAAACgBQACgCAAgDQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAgBgBAAQAAAAAAAAQgBgBgBAAQAAAAAAAAQAAAAgBAAQgBABAAAAQAAAAgBAAQAAABgBAAQgCACAAADIgJgBIADgIQACgCADgCQADgCAEAAQAHAAAEAFQADAEAAAEQAAAHgHAEQAFABACACQADADAAAFQAAAGgFAFQgFAFgHAAQgGAAgEgEg");
	this.shape_5.setTransform(46.625,12.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCCCC").s().p("AgGAFIADgJIAKAAIgDAJg");
	this.shape_6.setTransform(67.925,34.65);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCCCC").s().p("AgSAbQgFgDAAgHIAAgCIAMACIABACIACACIADABQAEAAABgCQAAAAABAAQAAgBABAAQAAgBAAAAQAAgBABAAIABgHIABgCQgFAFgGAAQgHAAgDgEQgEgFAAgHQAAgHACgGQADgGAFgEQAFgDAFAAQADAAADACQAEADABAEIACgIIALAAIgIAiIgDAMIgCAFIgEAEIgGACIgGABQgJAAgEgDgAgEgSQgDACgBAFIgBAHQAAAEACACQACADADAAQACAAADgDQACgCACgDIABgIQAAgEgCgDQgCgDgDAAQgCAAgDADg");
	this.shape_7.setTransform(64.625,33.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CCCCCC").s().p("AAFAVIAEgWIABgHQAAAAAAgBQAAAAAAAAQAAgBAAAAQgBgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAAAAAQgDAAgDACQgCACgBADIgEAJIgDARIgLAAIAJgoIAKAAIgBAFIAHgFQADgBAEAAQAFAAADADQADADAAAEIgBAJIgFAWg");
	this.shape_8.setTransform(59.65,33.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CCCCCC").s().p("AgLAdIAJgpIAKAAIgIApgAgBgRIABgLIAMAAIgCALg");
	this.shape_9.setTransform(56.375,32.325);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgQIgGAAIACgIIAFAAIACgGIAMgIIgDAOIAHAAIgCAIIgHAAIgEAQIAAAGIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEgBIgCAJIgFAAQgGABgDgDg");
	this.shape_10.setTransform(54.125,32.45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CCCCCC").s().p("AgPASQgDgDgBgFQAAgGAEgEQAEgCAKgBIAJgCIABgDQAAgBAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQgBAAAAAAQgBAAgBABQAAAAAAAAQAAAAAAABQgBAAAAAAQgBABAAAAQAAABgBAAQAAABAAAAIgLgBQACgFAEgEQAGgDAGAAQAIAAAEAEQAEADgBAEIAAAEIgCAKIgBALIABAGIgLAAIgBgFIgFAEIgHACQgFAAgDgEgAAEACQgIABgCACQAAAAgBABQAAAAAAAAQgBABAAABQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAAAQAAABAAAAIAFABIADgBIAEgDIACgGIAAgCIgDABg");
	this.shape_11.setTransform(50.1,33.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CCCCCC").s().p("AgRAVIAJgoIAJAAIgBAIQAGgJAGAAIAGABIgFAJIgDAAQgDAAgDACQgDACgBAEQgBACgCAIIgCANg");
	this.shape_12.setTransform(46.725,33.075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CCCCCC").s().p("AgRAVIAJgoIAJAAIgBAIQAGgJAGAAIAGABIgFAJIgDAAQgDAAgDACQgDACgBAEQgBACgCAIIgCANg");
	this.shape_13.setTransform(163.425,24.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CCCCCC").s().p("AgPASQgEgDABgFQAAgGADgEQAEgCAKgBIAJgCIABgDQAAgBAAAAQAAgBAAAAQgBAAAAgBQAAAAAAAAQgBgBAAAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQgBAAAAAAQgBAAgBABQAAAAAAAAQAAAAAAABQgBAAAAAAQgBABAAAAQAAABgBAAQAAABAAAAIgLgBQACgFAEgEQAFgDAHAAQAIAAAEAEQADADAAAEIAAAEIgCAKIgBALIABAGIgLAAIgCgFIgEAEIgHACQgEAAgEgEgAAEACQgIABgCACQAAAAgBABQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAAAQAAABAAAAIAFABIADgBIADgDIADgGIAAgCIgDABg");
	this.shape_14.setTransform(159.25,24.075);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_15.setTransform(156.175,23.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CCCCCC").s().p("AgOASQgFgDgBgGIALgCQABAEACABQACACAEAAQADAAACgCQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAAAgBIgBgCIgFgCQgJgDgCgCQgEgCAAgFQAAgFAEgEQAFgFAJAAQAIAAAEADQAEADABAFIgKACIgDgDQgDgCgDAAIgEABQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQABAAAAAAIAFADIAMAEQADADAAAEQAAAGgEAEQgGAFgIAAQgJAAgFgEg");
	this.shape_16.setTransform(152.15,24.075);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAGgJALAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIARAAIAAgBQAAgFgCgCQgCgDgEAAQgDAAgCADg");
	this.shape_17.setTransform(145.65,24.075);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CCCCCC").s().p("AgNAQQgGgFAAgJQAAgHAFgHQAHgJALAAQAHAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEADACQACADADAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgJAAgEgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgCgCQgCgDgDAAQgCAAgDADg");
	this.shape_18.setTransform(141.2,24.075);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CCCCCC").s().p("AgRAVIAJgoIAJAAIgBAIQAGgJAGAAIAGABIgFAJIgDAAQgDAAgDACQgDACgBAEQgBACgCAIIgCANg");
	this.shape_19.setTransform(137.675,24.025);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CCCCCC").s().p("AAEAdIAGgZIABgEQAAgBgBAAQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAgBAAQgCAAgDACQgCADgCADIgCAJIgEARIgLAAIAMg5IAKAAIgDAVQACgDAEgBQADgCAEAAQAFAAADADQADADAAAFIgBAGIgGAZg");
	this.shape_20.setTransform(133.3,23.275);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_21.setTransform(129.975,23.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CCCCCC").s().p("AAFAdIAEgZIABgEQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAQgDAAgDACQgCADgCADIgDAJIgDARIgLAAIAMg5IAKAAIgDAVQADgDADgBQADgCAEAAQAFAAADADQADADAAAFIgBAGIgGAZg");
	this.shape_22.setTransform(123.55,23.275);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_23.setTransform(120.225,23.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#CCCCCC").s().p("AgLAdIAJgpIAKAAIgIApgAgBgRIABgLIAMAAIgCALg");
	this.shape_24.setTransform(117.625,23.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#CCCCCC").s().p("AAAAVIgBgaIgNAaIgKAAIgGgpIAKAAIADAbIANgbIAJAAIACAbIANgbIALAAIgVApg");
	this.shape_25.setTransform(113.575,24.075);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_26.setTransform(107.025,23.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAHgJAKAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgCgDgEAAQgCAAgDADg");
	this.shape_27.setTransform(103.55,24.075);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#CCCCCC").s().p("AgMAVIgJgpIALAAIADASIACAJIACgFIADgEIAKgSIAMAAIgZApg");
	this.shape_28.setTransform(99.425,24.075);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#CCCCCC").s().p("AgNAQQgGgFAAgJQAAgHAFgHQAGgJAMAAQAHAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQADADADAAQAEAAAEgGIAKACQgDAGgFADQgFADgFAAQgJAAgEgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgDgDgDAAQgDAAgCADg");
	this.shape_29.setTransform(94.65,24.075);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_30.setTransform(91.475,23.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#CCCCCC").s().p("AgPASQgDgDgBgFQAAgGAEgEQAEgCAKgBIAJgCIABgDQAAgBAAAAQAAgBAAAAQgBAAAAgBQAAAAAAAAQgBgBAAAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQgBAAAAAAQgBAAgBABQAAAAAAAAQAAAAgBABQAAAAAAAAQgBABAAAAQAAABgBAAQAAABAAAAIgLgBQACgFAEgEQAGgDAGAAQAIAAAEAEQAEADgBAEIAAAEIgCAKIgBALIAAAGIgKAAIgBgFIgFAEIgHACQgFAAgDgEgAAEACQgIABgCACQAAAAgBABQAAAAAAABQgBAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAAAQAAABAAAAIAFABIADgBIAEgDIACgGIAAgCIgDABg");
	this.shape_31.setTransform(85.65,24.075);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAGgJALAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQABgFgCgCQgCgDgEAAQgDAAgCADg");
	this.shape_32.setTransform(79.15,24.075);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_33.setTransform(75.925,23.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAHgJAKAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgCgDgEAAQgCAAgDADg");
	this.shape_34.setTransform(72.05,24.075);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_35.setTransform(68.875,23.275);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#CCCCCC").s().p("AgXAdIALg4IALAAIgBAEQADgDACgBQADgBAEAAQAHAAAEAEQADAFAAAJQAAAKgGAIQgGAGgJAAQgHAAgDgGIgFAVgAAAgSQgCACgCAFIgBAIQAAADACADQADADACAAQADAAACgCQADgCACgEIABgJQAAgEgBgDQgDgCgEAAQgDAAgCACg");
	this.shape_36.setTransform(64.9,24.825);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#CCCCCC").s().p("AAQAVIAFgYIABgFIgBgDIgDgBQgEAAgEAEQgCADgCAHIgEATIgKAAIAFgYIABgFIgBgDIgDgBIgEABIgDADIgDAFIgBAFIgEATIgLAAIAIgoIALAAIgBAFQAGgGAHAAQADAAADACQADACAAADQACgDAEgCQAEgCAFAAQAFAAACACQADADAAAEIgBAIIgFAYg");
	this.shape_37.setTransform(59.025,24.025);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#CCCCCC").s().p("AgLATQgFgCgCgEQgCgFAAgEQgBgLAHgHQAGgHAKAAQAJAAAGAFQAEAFAAAJQABAJgHAHQgGAIgKAAQgGAAgEgDgAgDgKQgEACgBAFIgBAGQgBAFADACQADADADAAQAEAAADgEQAFgFgBgHQABgEgDgDQgDgCgDAAQgCAAgDACg");
	this.shape_38.setTransform(53.15,24.075);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#CCCCCC").s().p("AgTAXQgGgGAAgMQAAgJAEgIQAEgIAHgEQAHgFAIAAQAJAAAGAGQAFAEABAJIgLABQgBgFgCgDQgEgCgEAAQgEAAgEAEQgEACgDAHQgDAGABAGQgBAGAEAEQADAEAFAAQAEgBADgDQAFgDACgFIALABQgEALgGAEQgHAFgIABQgLAAgGgHg");
	this.shape_39.setTransform(48.05,23.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(2));

	// Layer 2
	this.instance = new lib.achievement_lock();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	this.instance_1 = new lib.check();
	this.instance_1.parent = this;
	this.instance_1.setTransform(176,24,0.1302,0.13);

	this.instance_2 = new lib.ach6();
	this.instance_2.parent = this;
	this.instance_2.setTransform(2,2,0.2811,0.2811);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).wait(1));

	// Layer_4
	this.instance_3 = new lib.achievementramis();
	this.instance_3.parent = this;
	this.instance_3.setTransform(97.2,20.9,1,1,0,0,0,97.2,20.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,194.6,42.1);


(lib.achievement5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgLAUQgEgGAAgOQAAgNAFgGQAEgGAGAAQAHAAAEAGQAFAGAAANQAAAOgFAGQgEAGgHAAQgGAAgFgGgAgCgPQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAIgBAMIABAMIACAFIACABIADgBIACgEIABgNIgBgLIgCgEQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgCACg");
	this.shape.setTransform(91.375,12.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("AgQAZQABgFACgEQAEgFAHgHIAHgIQACgDAAgCQAAgEgCgBQAAgBAAAAQgBAAAAgBQgBAAgBAAQAAAAgBAAQgCAAgCACQgCACAAAEIgJgBQAAgIAEgEQAFgDAGAAQAIAAAEAEQAEAEAAAGQAAADgCADIgDAGIgHAGIgFAGIgBACIASAAIAAAJg");
	this.shape_1.setTransform(87.4,12.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("AgSAZIAAgxIAkAAIAAAJIgaAAIAAAKIAYAAIAAAIIgYAAIAAAOIAbAAIAAAIg");
	this.shape_2.setTransform(81.35,12.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AgEAZIAAgoIgPAAIAAgJIAnAAIAAAJIgPAAIAAAog");
	this.shape_3.setTransform(76.8,12.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AgSAZIAAgxIAkAAIAAAJIgaAAIAAAKIAZAAIAAAIIgZAAIAAAOIAbAAIAAAIg");
	this.shape_4.setTransform(72.4,12.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("AgRAZIAAgxIAKAAIAAAoIAZAAIAAAJg");
	this.shape_5.setTransform(68,12.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCCCC").s().p("AgSAZIAAgxIAQAAIALAAQAEACADAEQADADAAAHQAAAEgBADIgFAEIgFACIgJABIgHAAIAAATgAgIgBIAFAAIAHgBIAEgDIABgDQAAgBAAgBQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAAAgBgBQAAAAgBgBQAAAAgBAAQAAAAgBAAIgGAAIgFAAg");
	this.shape_6.setTransform(63.475,12.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCCCC").s().p("AAPAZIAAgnIgKAnIgJAAIgKgnIAAAnIgJAAIAAgxIAPAAIAIAhIAJghIAPAAIAAAxg");
	this.shape_7.setTransform(58.125,12.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CCCCCC").s().p("AgRATQgGgHAAgLQAAgIACgFQACgEADgCQADgEADgBQAFgCAFAAQALAAAHAHQAGAHAAALQAAAMgGAHQgHAHgLAAQgKAAgHgHgAgJgMQgEAFAAAHQAAAIAEAFQAEAEAFAAQAGAAAEgEQAEgFAAgIQAAgIgEgEQgEgEgGAAQgFAAgEAEg");
	this.shape_8.setTransform(52.475,12.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CCCCCC").s().p("AgPATQgGgHAAgLQAAgMAHgHQAGgHAKAAQAJAAAFAGQAEACACAHIgKACQgBgEgDgCQgDgDgEABQgFAAgDADQgEAFAAAIQAAAJAEAEQADAEAFAAQAEAAADgDQADgCABgFIAKADQgDAIgFAEQgFAEgIAAQgJAAgHgHg");
	this.shape_9.setTransform(47.225,12.45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CCCCCC").s().p("AgGAGIADgLIAKAAIgDALg");
	this.shape_10.setTransform(134.075,25.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CCCCCC").s().p("AgOASQgFgDgBgGIALgCQABAEACABQADACADAAQADAAACgCQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAAAgBIgBgCIgFgCQgJgDgCgCQgEgCAAgFQAAgFAEgEQAFgFAJAAQAIAAAEADQAEADABAFIgKACIgDgDQgDgCgDAAIgEABQAAAAgBABQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAABAAQAAABAAAAQAAAAAAABQABAAAAAAIAFADIAMAEQADADAAAEQABAGgGAEQgEAFgJAAQgIAAgGgEg");
	this.shape_11.setTransform(130.9,24.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_12.setTransform(127.875,23.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAGgJALAAQAIAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEACACQADADADAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgJAAgFgGgAgDgKQgDADgBAFIARAAIAAgBQAAgFgCgCQgDgDgDAAQgDAAgCADg");
	this.shape_13.setTransform(124.4,24.075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CCCCCC").s().p("AgMAVIgJgpIALAAIADASIACAJIACgFIADgEIAKgSIAMAAIgZApg");
	this.shape_14.setTransform(120.275,24.075);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAGgJALAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIARAAIAAgBQAAgFgCgCQgCgDgEAAQgDAAgCADg");
	this.shape_15.setTransform(115.5,24.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_16.setTransform(112.325,23.275);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CCCCCC").s().p("AgYAcIABgJIAFABQAEAAAEgIIgIgoIAMAAIADAUIABALQACgGADgHIAKgSIAMAAIgZAsIgFAIIgEAEQgDABgEAAIgIgBg");
	this.shape_17.setTransform(106.7,24.925);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_18.setTransform(103.425,23.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CCCCCC").s().p("AAEAVIAGgWIABgHQAAAAgBgBQAAAAAAgBQAAAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAgBAAQgCAAgDACQgCACgCADIgCAJIgEARIgLAAIAIgoIALAAIgBAFIAGgFQAEgBAEAAQAFAAADADQADADAAAEIgCAJIgFAWg");
	this.shape_19.setTransform(99.2,24.025);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CCCCCC").s().p("AgNAQQgGgFAAgJQAAgHAFgHQAGgJAMAAQAHAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQADADADAAQAEAAAEgGIAKACQgDAGgFADQgFADgFAAQgJAAgEgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgDgDgDAAQgDAAgCADg");
	this.shape_20.setTransform(94.65,24.075);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CCCCCC").s().p("AAAAVIgBgaIgNAaIgKAAIgGgpIAKAAIADAbIANgbIAJAAIACAbIANgbIALAAIgVApg");
	this.shape_21.setTransform(89.625,24.075);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_22.setTransform(85.225,23.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAGgJALAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQABgFgCgCQgCgDgEAAQgDAAgCADg");
	this.shape_23.setTransform(79.15,24.075);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_24.setTransform(75.925,23.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAHgJAKAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgCgDgEAAQgCAAgDADg");
	this.shape_25.setTransform(72.05,24.075);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_26.setTransform(68.875,23.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#CCCCCC").s().p("AgXAdIALg4IALAAIgBAEQADgDACgBQADgBAEAAQAHAAAEAEQADAFAAAJQAAAKgGAIQgGAGgJAAQgHAAgDgGIgFAVgAAAgSQgCACgCAFIgBAIQAAADACADQADADACAAQADAAACgCQADgCACgEIABgJQAAgEgBgDQgDgCgEAAQgDAAgCACg");
	this.shape_27.setTransform(64.9,24.825);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#CCCCCC").s().p("AAQAVIAFgYIABgFIgBgDIgDgBQgEAAgEAEQgCADgCAHIgEATIgKAAIAFgYIABgFIgBgDIgDgBIgEABIgDADIgDAFIgBAFIgEATIgLAAIAIgoIALAAIgBAFQAGgGAHAAQADAAADACQADACAAADQACgDAEgCQAEgCAFAAQAFAAACACQADADAAAEIgBAIIgFAYg");
	this.shape_28.setTransform(59.025,24.025);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#CCCCCC").s().p("AgLATQgFgCgCgEQgCgFAAgEQgBgLAHgHQAGgHAKAAQAJAAAGAFQAEAFAAAJQABAJgHAHQgGAIgKAAQgGAAgEgDgAgDgKQgEACgBAFIgBAGQgBAFADACQADADADAAQAEAAADgEQAFgFgBgHQABgEgDgDQgDgCgDAAQgCAAgDACg");
	this.shape_29.setTransform(53.15,24.075);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#CCCCCC").s().p("AgTAXQgGgGAAgMQAAgJAEgIQAEgIAHgEQAHgFAIAAQAJAAAGAGQAFAEABAJIgLABQgBgFgCgDQgEgCgEAAQgEAAgEAEQgEACgDAHQgDAGABAGQgBAGAEAEQADAEAFAAQAEgBADgDQAFgDACgFIALABQgEALgGAEQgHAFgIABQgLAAgGgHg");
	this.shape_30.setTransform(48.05,23.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(2));

	// Layer 2
	this.instance = new lib.achievement_lock();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	this.instance_1 = new lib.check();
	this.instance_1.parent = this;
	this.instance_1.setTransform(176,24,0.1302,0.13);

	this.instance_2 = new lib.ach5();
	this.instance_2.parent = this;
	this.instance_2.setTransform(2,2,0.2811,0.2811);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).wait(1));

	// Layer_4
	this.instance_3 = new lib.achievementramis();
	this.instance_3.parent = this;
	this.instance_3.setTransform(97.2,20.9,1,1,0,0,0,97.2,20.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,194.6,42.1);


(lib.achievement4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgLAVQgEgDgBgHIAKgBQAAAEACACQACABACAAQADAAACgCQACgCAAgFQAAgFgCgCQgCgCgDAAQgEAAgDADIgHgBIAEgZIAYAAIAAAJIgRAAIgBAIQADgBADAAQAGAAAEAEQAFAEAAAHQAAAHgEAEQgFAHgIAAQgGAAgFgEg");
	this.shape.setTransform(91.45,12.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("AACAZIAAgjQgFAFgHACIAAgIQAEgCAEgDQAEgDACgFIAHAAIAAAxg");
	this.shape_1.setTransform(87.2,12.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("AgSAZIAAgxIAkAAIAAAJIgaAAIAAAKIAYAAIAAAIIgYAAIAAAOIAbAAIAAAIg");
	this.shape_2.setTransform(81.35,12.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AgEAZIAAgoIgPAAIAAgJIAnAAIAAAJIgPAAIAAAog");
	this.shape_3.setTransform(76.8,12.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AgSAZIAAgxIAkAAIAAAJIgaAAIAAAKIAZAAIAAAIIgZAAIAAAOIAbAAIAAAIg");
	this.shape_4.setTransform(72.4,12.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("AgRAZIAAgxIAKAAIAAAoIAZAAIAAAJg");
	this.shape_5.setTransform(68,12.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCCCC").s().p("AgSAZIAAgxIAQAAIALAAQAEACADAEQADADAAAHQAAAEgBADIgFAEIgFACIgJABIgHAAIAAATgAgIgBIAFAAIAHgBIAEgDIABgDQAAgBAAgBQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAAAgBgBQAAAAgBgBQAAAAgBAAQAAAAgBAAIgGAAIgFAAg");
	this.shape_6.setTransform(63.475,12.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCCCC").s().p("AAPAZIAAgnIgKAnIgJAAIgKgnIAAAnIgJAAIAAgxIAPAAIAIAhIAJghIAPAAIAAAxg");
	this.shape_7.setTransform(58.125,12.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CCCCCC").s().p("AgRATQgGgHAAgLQAAgIACgFQACgEADgCQADgEADgBQAFgCAFAAQALAAAHAHQAGAHAAALQAAAMgGAHQgHAHgLAAQgKAAgHgHgAgJgMQgEAFAAAHQAAAIAEAFQAEAEAFAAQAGAAAEgEQAEgFAAgIQAAgIgEgEQgEgEgGAAQgFAAgEAEg");
	this.shape_8.setTransform(52.475,12.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CCCCCC").s().p("AgPATQgGgHAAgLQAAgMAHgHQAGgHAKAAQAJAAAFAGQAEACACAHIgKACQgBgEgDgCQgDgDgEABQgFAAgDADQgEAFAAAIQAAAJAEAEQADAEAFAAQAEAAADgDQADgCABgFIAKADQgDAIgFAEQgFAEgIAAQgJAAgHgHg");
	this.shape_9.setTransform(47.225,12.45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CCCCCC").s().p("AgGAGIADgLIAKAAIgDALg");
	this.shape_10.setTransform(132.725,25.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CCCCCC").s().p("AgOASQgFgDgBgGIALgCQABAEACABQADACADAAQADAAACgCQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAAAgBIgBgCIgFgCQgJgDgCgCQgEgCAAgFQAAgFAEgEQAFgFAJAAQAIAAAEADQAEADABAFIgKACIgDgDQgDgCgDAAIgEABQAAAAgBABQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAABAAQAAABAAAAQAAAAAAABQABAAAAAAIAFADIAMAEQADADAAAEQABAGgGAEQgEAFgJAAQgIAAgGgEg");
	this.shape_11.setTransform(129.55,24.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_12.setTransform(126.525,23.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAGgJALAAQAIAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEADACQACADADAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgJAAgFgGgAgDgKQgDADgBAFIARAAIAAgBQAAgFgCgCQgDgDgDAAQgDAAgCADg");
	this.shape_13.setTransform(123.05,24.075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CCCCCC").s().p("AgMAVIgJgpIALAAIADASIACAJIACgFIADgEIAKgSIAMAAIgZApg");
	this.shape_14.setTransform(118.925,24.075);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAGgJALAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIARAAIAAgBQAAgFgCgCQgCgDgEAAQgDAAgCADg");
	this.shape_15.setTransform(114.15,24.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_16.setTransform(110.975,23.275);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CCCCCC").s().p("AAEAVIAGgWIABgHQAAAAgBgBQAAAAAAgBQAAAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAgBAAQgCAAgDACQgCACgCADIgCAJIgEARIgLAAIAIgoIALAAIgBAFIAGgFQAEgBAEAAQAFAAADADQADADAAAEIgBAJIgGAWg");
	this.shape_17.setTransform(104.95,24.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAHgJAKAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgCgDgEAAQgCAAgDADg");
	this.shape_18.setTransform(100.4,24.075);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAHgJAKAAQAIAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEADACQACADADAAQAEAAAEgGIAKACQgDAGgFADQgFADgFAAQgJAAgFgGgAgDgKQgDADgBAFIARAAIAAgBQAAgFgDgCQgBgDgEAAQgCAAgDADg");
	this.shape_19.setTransform(95.95,24.075);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_20.setTransform(92.725,23.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CCCCCC").s().p("AgPAdIAHghIgHAAIABgIIAHAAIABgDIACgIIAEgEIAGgBIALACIgDAIIgGgBIgDABIgBADIgBADIAIAAIgBAIIgJAAIgGAhg");
	this.shape_21.setTransform(90.3,23.25);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CCCCCC").s().p("AgLAdIAJgpIAKAAIgIApgAgBgRIABgLIAMAAIgCALg");
	this.shape_22.setTransform(87.475,23.275);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CCCCCC").s().p("AgQAdIAIghIgHAAIABgIIAHAAIABgDIACgIIAEgEIAGgBIALACIgCAIIgHgBIgDABIgBADIgBADIAIAAIgBAIIgJAAIgGAhg");
	this.shape_23.setTransform(85.45,23.25);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAGgJALAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQABgFgCgCQgCgDgEAAQgDAAgCADg");
	this.shape_24.setTransform(79.15,24.075);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_25.setTransform(75.925,23.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAHgJAKAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgCgDgEAAQgCAAgDADg");
	this.shape_26.setTransform(72.05,24.075);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_27.setTransform(68.875,23.275);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#CCCCCC").s().p("AgXAdIALg4IALAAIgBAEQADgDACgBQADgBAEAAQAHAAAEAEQADAFAAAJQAAAKgGAIQgGAGgJAAQgHAAgDgGIgFAVgAAAgSQgCACgCAFIgBAIQAAADACADQADADACAAQADAAACgCQADgCACgEIABgJQAAgEgBgDQgDgCgEAAQgDAAgCACg");
	this.shape_28.setTransform(64.9,24.825);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#CCCCCC").s().p("AAQAVIAFgYIABgFIgBgDIgDgBQgEAAgEAEQgCADgCAHIgEATIgKAAIAFgYIABgFIgBgDIgDgBIgEABIgDADIgDAFIgBAFIgEATIgLAAIAIgoIALAAIgBAFQAGgGAHAAQADAAADACQADACAAADQACgDAEgCQAEgCAFAAQAFAAACACQADADAAAEIgBAIIgFAYg");
	this.shape_29.setTransform(59.025,24.025);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#CCCCCC").s().p("AgLATQgFgCgCgEQgCgFAAgEQgBgLAHgHQAGgHAKAAQAJAAAGAFQAEAFAAAJQABAJgHAHQgGAIgKAAQgGAAgEgDgAgDgKQgEACgBAFIgBAGQgBAFADACQADADADAAQAEAAADgEQAFgFgBgHQABgEgDgDQgDgCgDAAQgCAAgDACg");
	this.shape_30.setTransform(53.15,24.075);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#CCCCCC").s().p("AgTAXQgGgGAAgMQAAgJAEgIQAEgIAHgEQAHgFAIAAQAJAAAGAGQAFAEABAJIgLABQgBgFgCgDQgEgCgEAAQgEAAgEAEQgEACgDAHQgDAGABAGQgBAGAEAEQADAEAFAAQAEgBADgDQAFgDACgFIALABQgEALgGAEQgHAFgIABQgLAAgGgHg");
	this.shape_31.setTransform(48.05,23.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(2));

	// Layer 2
	this.instance = new lib.achievement_lock();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	this.instance_1 = new lib.check();
	this.instance_1.parent = this;
	this.instance_1.setTransform(176,24,0.1302,0.13);

	this.instance_2 = new lib.ach4();
	this.instance_2.parent = this;
	this.instance_2.setTransform(2,2,0.2811,0.2811);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).wait(1));

	// Layer_4
	this.instance_3 = new lib.achievementramis();
	this.instance_3.parent = this;
	this.instance_3.setTransform(97.2,20.9,1,1,0,0,0,97.2,20.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,194.6,42.1);


(lib.achievement3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgLAUQgEgGAAgOQAAgNAFgGQAEgGAGAAQAHAAAEAGQAFAGAAANQAAAOgFAGQgEAGgHAAQgGAAgFgGgAgCgPQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAIgBAMIABAMIACAFIACABIADgBIACgEIABgNIgBgLIgCgEQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAIgCACg");
	this.shape.setTransform(91.375,12.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("AACAZIAAgjQgFAFgHACIAAgIQAEgCAEgDQAEgDACgFIAHAAIAAAxg");
	this.shape_1.setTransform(87.2,12.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("AgSAZIAAgxIAkAAIAAAJIgaAAIAAAKIAYAAIAAAIIgYAAIAAAOIAbAAIAAAIg");
	this.shape_2.setTransform(81.35,12.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AgEAZIAAgoIgPAAIAAgJIAnAAIAAAJIgPAAIAAAog");
	this.shape_3.setTransform(76.8,12.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AgSAZIAAgxIAkAAIAAAJIgaAAIAAAKIAZAAIAAAIIgZAAIAAAOIAbAAIAAAIg");
	this.shape_4.setTransform(72.4,12.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("AgRAZIAAgxIAKAAIAAAoIAZAAIAAAJg");
	this.shape_5.setTransform(68,12.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCCCC").s().p("AgSAZIAAgxIAQAAIALAAQAEACADAEQADADAAAHQAAAEgBADIgFAEIgFACIgJABIgHAAIAAATgAgIgBIAFAAIAHgBIAEgDIABgDQAAgBAAgBQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAAAgBgBQAAAAgBgBQAAAAgBAAQAAAAgBAAIgGAAIgFAAg");
	this.shape_6.setTransform(63.475,12.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCCCC").s().p("AAPAZIAAgnIgKAnIgJAAIgKgnIAAAnIgJAAIAAgxIAPAAIAIAhIAJghIAPAAIAAAxg");
	this.shape_7.setTransform(58.125,12.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CCCCCC").s().p("AgRATQgGgHAAgLQAAgIACgFQACgEADgCQADgEADgBQAFgCAFAAQALAAAHAHQAGAHAAALQAAAMgGAHQgHAHgLAAQgKAAgHgHgAgJgMQgEAFAAAHQAAAIAEAFQAEAEAFAAQAGAAAEgEQAEgFAAgIQAAgIgEgEQgEgEgGAAQgFAAgEAEg");
	this.shape_8.setTransform(52.475,12.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CCCCCC").s().p("AgPATQgGgHAAgLQAAgMAHgHQAGgHAKAAQAJAAAFAGQAEACACAHIgKACQgBgEgDgCQgDgDgEABQgFAAgDADQgEAFAAAIQAAAJAEAEQADAEAFAAQAEAAADgDQADgCABgFIAKADQgDAIgFAEQgFAEgIAAQgJAAgHgHg");
	this.shape_9.setTransform(47.225,12.45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CCCCCC").s().p("AgGAGIADgLIAKAAIgDALg");
	this.shape_10.setTransform(120.775,25.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CCCCCC").s().p("AgNASQgGgDgBgGIAKgCQACAEACABQACACAEAAQADAAACgCQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAAAgBIgBgCIgFgCQgJgDgCgCQgEgCAAgFQAAgFAEgEQAFgFAJAAQAIAAAEADQAEADABAFIgKACIgDgDQgDgCgDAAIgEABQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQABAAAAAAIAGADIALAEQADADAAAEQAAAGgEAEQgGAFgIAAQgJAAgEgEg");
	this.shape_11.setTransform(117.6,24.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_12.setTransform(114.575,23.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAGgJALAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgCgDgEAAQgDAAgCADg");
	this.shape_13.setTransform(111.1,24.075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CCCCCC").s().p("AgMAVIgJgpIALAAIADASIACAJIACgFIADgEIAKgSIAMAAIgZApg");
	this.shape_14.setTransform(106.975,24.075);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAHgJAKAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgCgDgEAAQgCAAgDADg");
	this.shape_15.setTransform(102.2,24.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_16.setTransform(99.025,23.275);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CCCCCC").s().p("AAEAVIAGgWIAAgHQAAAAAAgBQAAAAAAgBQAAAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAgBAAQgCAAgDACQgCACgCADIgDAJIgDARIgLAAIAIgoIALAAIgBAFIAGgFQAEgBAEAAQAFAAADADQADADAAAEIgCAJIgEAWg");
	this.shape_17.setTransform(93,24.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CCCCCC").s().p("AgNAQQgGgFAAgJQAAgHAFgHQAHgJALAAQAHAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEADACQABADAEAAQAEAAAEgGIAKACQgDAGgFADQgFADgFAAQgJAAgEgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgCgCQgCgDgDAAQgCAAgDADg");
	this.shape_18.setTransform(88.45,24.075);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_19.setTransform(85.225,23.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAGgJALAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQABgFgCgCQgCgDgEAAQgDAAgCADg");
	this.shape_20.setTransform(79.15,24.075);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_21.setTransform(75.925,23.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAHgJAKAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgCgDgEAAQgCAAgDADg");
	this.shape_22.setTransform(72.05,24.075);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_23.setTransform(68.875,23.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#CCCCCC").s().p("AgXAdIALg4IALAAIgBAEQADgDACgBQADgBAEAAQAHAAAEAEQADAFAAAJQAAAKgGAIQgGAGgJAAQgHAAgDgGIgFAVgAAAgSQgCACgCAFIgBAIQAAADACADQADADACAAQADAAACgCQADgCACgEIABgJQAAgEgBgDQgDgCgEAAQgDAAgCACg");
	this.shape_24.setTransform(64.9,24.825);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#CCCCCC").s().p("AAQAVIAFgYIABgFIgBgDIgDgBQgEAAgEAEQgCADgCAHIgEATIgKAAIAFgYIABgFIgBgDIgDgBIgEABIgDADIgDAFIgBAFIgEATIgLAAIAIgoIALAAIgBAFQAGgGAHAAQADAAADACQADACAAADQACgDAEgCQAEgCAFAAQAFAAACACQADADAAAEIgBAIIgFAYg");
	this.shape_25.setTransform(59.025,24.025);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#CCCCCC").s().p("AgLATQgFgCgCgEQgCgFAAgEQgBgLAHgHQAGgHAKAAQAJAAAGAFQAEAFAAAJQABAJgHAHQgGAIgKAAQgGAAgEgDgAgDgKQgEACgBAFIgBAGQgBAFADACQADADADAAQAEAAADgEQAFgFgBgHQABgEgDgDQgDgCgDAAQgCAAgDACg");
	this.shape_26.setTransform(53.15,24.075);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#CCCCCC").s().p("AgTAXQgGgGAAgMQAAgJAEgIQAEgIAHgEQAHgFAIAAQAJAAAGAGQAFAEABAJIgLABQgBgFgCgDQgEgCgEAAQgEAAgEAEQgEACgDAHQgDAGABAGQgBAGAEAEQADAEAFAAQAEgBADgDQAFgDACgFIALABQgEALgGAEQgHAFgIABQgLAAgGgHg");
	this.shape_27.setTransform(48.05,23.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(2));

	// Layer 2
	this.instance = new lib.achievement_lock();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	this.instance_1 = new lib.check();
	this.instance_1.parent = this;
	this.instance_1.setTransform(176,24,0.1302,0.13);

	this.instance_2 = new lib.ach3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(2,2,0.2811,0.2811);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).wait(1));

	// Layer_4
	this.instance_3 = new lib.achievementramis();
	this.instance_3.parent = this;
	this.instance_3.setTransform(97.2,20.9,1,1,0,0,0,97.2,20.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,194.6,42.1);


(lib.achievement2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgKAVQgFgDgBgHIAJgBQABAEACACQACABACAAQADAAACgCQACgCAAgFQAAgFgCgCQgCgCgDAAQgEAAgDADIgHgBIAEgZIAZAAIAAAJIgRAAIgCAIQADgBACAAQAHAAAFAEQAEAEAAAHQAAAHgEAEQgEAHgJAAQgGAAgEgEg");
	this.shape.setTransform(87.55,12.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("AgSAZIAAgxIAkAAIAAAJIgaAAIAAAKIAYAAIAAAIIgYAAIAAAOIAbAAIAAAIg");
	this.shape_1.setTransform(81.35,12.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("AgEAZIAAgoIgPAAIAAgJIAnAAIAAAJIgPAAIAAAog");
	this.shape_2.setTransform(76.8,12.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AgSAZIAAgxIAkAAIAAAJIgaAAIAAAKIAZAAIAAAIIgZAAIAAAOIAbAAIAAAIg");
	this.shape_3.setTransform(72.4,12.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AgRAZIAAgxIAKAAIAAAoIAZAAIAAAJg");
	this.shape_4.setTransform(68,12.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("AgSAZIAAgxIAQAAIALAAQAEACADAEQADADAAAHQAAAEgBADIgFAEIgFACIgJABIgHAAIAAATgAgIgBIAFAAIAHgBIAEgDIABgDQAAgBAAgBQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAAAgBgBQAAAAgBgBQAAAAgBAAQAAAAgBAAIgGAAIgFAAg");
	this.shape_5.setTransform(63.475,12.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCCCC").s().p("AAPAZIAAgnIgKAnIgJAAIgKgnIAAAnIgJAAIAAgxIAPAAIAIAhIAJghIAPAAIAAAxg");
	this.shape_6.setTransform(58.125,12.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCCCC").s().p("AgRATQgGgHAAgLQAAgIACgFQACgEADgCQADgEADgBQAFgCAFAAQALAAAHAHQAGAHAAALQAAAMgGAHQgHAHgLAAQgKAAgHgHgAgJgMQgEAFAAAHQAAAIAEAFQAEAEAFAAQAGAAAEgEQAEgFAAgIQAAgIgEgEQgEgEgGAAQgFAAgEAEg");
	this.shape_7.setTransform(52.475,12.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CCCCCC").s().p("AgPATQgGgHAAgLQAAgMAHgHQAGgHAKAAQAJAAAFAGQAEACACAHIgKACQgBgEgDgCQgDgDgEABQgFAAgDADQgEAFAAAIQAAAJAEAEQADAEAFAAQAEAAADgDQADgCABgFIAKADQgDAIgFAEQgFAEgIAAQgJAAgHgHg");
	this.shape_8.setTransform(47.225,12.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CCCCCC").s().p("AgGAGIADgLIAKAAIgDALg");
	this.shape_9.setTransform(122.525,25.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CCCCCC").s().p("AgNASQgFgDgCgGIAKgCQACAEACABQADACADAAQADAAACgCQABAAAAgBQAAAAABAAQAAgBAAAAQAAAAAAgBIgBgCIgEgCQgKgDgCgCQgEgCAAgFQAAgFADgEQAGgFAJAAQAIAAAEADQAEADABAFIgKACIgDgDQgCgCgEAAIgEABQAAAAgBABQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAABAAQAAABAAAAQAAAAAAABQABAAAAAAIAFADIALAEQAFADAAAEQgBAGgFAEQgFAFgIAAQgJAAgEgEg");
	this.shape_10.setTransform(119.35,24.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_11.setTransform(116.325,23.275);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CCCCCC").s().p("AgNAQQgGgFAAgJQAAgHAFgHQAHgJALAAQAHAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEADACQACADADAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgJAAgEgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgCgCQgCgDgDAAQgCAAgDADg");
	this.shape_12.setTransform(112.85,24.075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CCCCCC").s().p("AgMAVIgJgpIALAAIADASIACAJIACgFIADgEIAKgSIAMAAIgZApg");
	this.shape_13.setTransform(108.725,24.075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CCCCCC").s().p("AgNAQQgGgFAAgJQAAgHAFgHQAHgJALAAQAHAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEADACQACADADAAQAEAAAEgGIAKACQgDAGgFADQgFADgFAAQgJAAgEgGgAgDgKQgDADgBAFIARAAIAAgBQgBgFgCgCQgCgDgDAAQgCAAgDADg");
	this.shape_14.setTransform(103.95,24.075);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_15.setTransform(100.775,23.275);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CCCCCC").s().p("AgNAQQgGgFAAgJQAAgHAFgHQAGgJAMAAQAHAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQADADADAAQAEAAAEgGIAKACQgDAGgFADQgFADgFAAQgJAAgEgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgCgCQgCgDgDAAQgDAAgCADg");
	this.shape_16.setTransform(95.1,24.075);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CCCCCC").s().p("AgMAVIgJgpIALAAIADASIACAJIACgFIADgEIAKgSIAMAAIgZApg");
	this.shape_17.setTransform(90.975,24.075);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CCCCCC").s().p("AgLAdIAJgpIAKAAIgIApgAgBgRIABgLIAMAAIgCALg");
	this.shape_18.setTransform(87.475,23.275);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CCCCCC").s().p("AgQAdIAIghIgHAAIABgIIAHAAIABgDIACgIIAEgEIAGgBIALACIgCAIIgHgBIgDABIgBADIgBADIAIAAIgBAIIgJAAIgGAhg");
	this.shape_19.setTransform(85.45,23.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAGgJALAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQABgFgCgCQgCgDgEAAQgDAAgCADg");
	this.shape_20.setTransform(79.15,24.075);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_21.setTransform(75.925,23.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CCCCCC").s().p("AgOAQQgFgFAAgJQAAgHAFgHQAHgJAKAAQAIAAAFAFQAEAFAAAIIgBAGIgbAAIAAACQAAAEACACQACADAEAAQAFAAADgGIAKACQgDAGgFADQgFADgFAAQgIAAgGgGgAgDgKQgDADgBAFIAQAAIAAgBQAAgFgBgCQgCgDgEAAQgCAAgDADg");
	this.shape_22.setTransform(72.05,24.075);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_23.setTransform(68.875,23.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#CCCCCC").s().p("AgXAdIALg4IALAAIgBAEQADgDACgBQADgBAEAAQAHAAAEAEQADAFAAAJQAAAKgGAIQgGAGgJAAQgHAAgDgGIgFAVgAAAgSQgCACgCAFIgBAIQAAADACADQADADACAAQADAAACgCQADgCACgEIABgJQAAgEgBgDQgDgCgEAAQgDAAgCACg");
	this.shape_24.setTransform(64.9,24.825);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#CCCCCC").s().p("AAQAVIAFgYIABgFIgBgDIgDgBQgEAAgEAEQgCADgCAHIgEATIgKAAIAFgYIABgFIgBgDIgDgBIgEABIgDADIgDAFIgBAFIgEATIgLAAIAIgoIALAAIgBAFQAGgGAHAAQADAAADACQADACAAADQACgDAEgCQAEgCAFAAQAFAAACACQADADAAAEIgBAIIgFAYg");
	this.shape_25.setTransform(59.025,24.025);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#CCCCCC").s().p("AgLATQgFgCgCgEQgCgFAAgEQgBgLAHgHQAGgHAKAAQAJAAAGAFQAEAFAAAJQABAJgHAHQgGAIgKAAQgGAAgEgDgAgDgKQgEACgBAFIgBAGQgBAFADACQADADADAAQAEAAADgEQAFgFgBgHQABgEgDgDQgDgCgDAAQgCAAgDACg");
	this.shape_26.setTransform(53.15,24.075);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#CCCCCC").s().p("AgTAXQgGgGAAgMQAAgJAEgIQAEgIAHgEQAHgFAIAAQAJAAAGAGQAFAEABAJIgLABQgBgFgCgDQgEgCgEAAQgEAAgEAEQgEACgDAHQgDAGABAGQgBAGAEAEQADAEAFAAQAEgBADgDQAFgDACgFIALABQgEALgGAEQgHAFgIABQgLAAgGgHg");
	this.shape_27.setTransform(48.05,23.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(2));

	// Layer 2
	this.instance = new lib.achievement_lock();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	this.instance_1 = new lib.check();
	this.instance_1.parent = this;
	this.instance_1.setTransform(176,24,0.1302,0.13);

	this.instance_2 = new lib.ach2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(2,2,0.2811,0.2811);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).wait(1));

	// Layer_4
	this.instance_3 = new lib.achievementramis();
	this.instance_3.parent = this;
	this.instance_3.setTransform(97.2,20.9,1,1,0,0,0,97.2,20.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,194.6,42.1);


(lib.achievement1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgGAFIADgJIAKAAIgDAJg");
	this.shape.setTransform(91.025,34.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgQIgGAAIACgIIAFAAIACgGIAMgIIgDAOIAHAAIgCAIIgHAAIgEAQIAAAGIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEgBIgCAJIgFAAQgGABgDgDg");
	this.shape_1.setTransform(89.225,32.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("AgLATQgFgCgCgEQgCgFAAgEQgBgLAHgHQAGgHAKAAQAJAAAGAFQAEAFAAAJQABAJgHAHQgGAIgKAAQgGAAgEgDgAgDgKQgEACgBAFIgBAGQgBAFADACQADADADAAQAEAAADgEQAFgFgBgHQABgEgDgDQgDgCgDAAQgCAAgDACg");
	this.shape_2.setTransform(85.1,33.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AgLAdIALg5IAMAAIgMA5g");
	this.shape_3.setTransform(81.725,32.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AgNASQgFgDgCgGIAKgCQACAEACABQACACAEAAQADAAACgCQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAAAgBIgBgCIgFgCQgJgDgCgCQgEgCAAgFQAAgFADgEQAGgFAJAAQAIAAAEADQAEADABAFIgKACIgDgDQgDgCgDAAIgEABQAAABgBAAQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQABAAAAAAIAGADIALAEQADADAAAEQAAAGgEAEQgGAFgIAAQgIAAgFgEg");
	this.shape_4.setTransform(78.1,33.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("AgSAbQgFgDAAgHIAAgCIAMACIABACIACACIADABQAEAAABgCQAAAAABAAQAAgBAAAAQABgBAAAAQABgBAAAAIABgHIABgCQgFAFgGAAQgHAAgDgEQgEgFAAgHQAAgHACgGQADgGAFgEQAFgDAFAAQADAAADACQAEADABAEIACgIIALAAIgIAiIgDAMIgCAFIgEAEIgGACIgGABQgJAAgEgDgAgEgSQgDACgBAFIgBAHQAAAEACACQACADADAAQACAAADgDQACgCACgDIABgIQAAgEgCgDQgCgDgDAAQgCAAgDADg");
	this.shape_5.setTransform(71.325,33.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCCCC").s().p("AAEAVIAGgWIABgHQAAAAgBgBQAAAAAAAAQAAgBAAAAQgBgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAgBAAQgCAAgDACQgCACgCADIgCAJIgEARIgLAAIAIgoIALAAIgBAFIAGgFQAEgBAEAAQAFAAADADQADADAAAEIgBAJIgGAWg");
	this.shape_6.setTransform(66.35,33.075);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCCCC").s().p("AgLAdIAJgpIAKAAIgIApgAgBgRIABgLIAMAAIgCALg");
	this.shape_7.setTransform(63.075,32.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CCCCCC").s().p("AAEAdIgFgTIgHAGIgDANIgLAAIAMg5IAKAAIgFAdIANgNIAPAAIgRAOIAJAbg");
	this.shape_8.setTransform(59.75,32.325);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CCCCCC").s().p("AgRAVIAJgoIAJAAIgBAIQAGgJAGAAIAGABIgFAJIgDAAQgDAAgDACQgDACgBAEQgBACgCAIIgCANg");
	this.shape_9.setTransform(56.075,33.075);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CCCCCC").s().p("AgPASQgDgDAAgFQgBgGAEgEQAEgCAKgBIAJgCIABgDQAAgBAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQgBAAAAAAQgBAAgBABQAAAAAAAAQAAAAgBABQAAAAAAAAQgBABAAAAQAAABgBAAQAAABAAAAIgLgBQACgFAEgEQAGgDAGAAQAIAAAEAEQAEADgBAEIAAAEIgCAKIgBALIAAAGIgKAAIgBgFIgFAEIgHACQgFAAgDgEgAAEACQgIABgCACQAAAAgBABQAAAAAAAAQgBABAAABQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAAAQAAABAAAAIAFABIADgBIAEgDIACgGIAAgCIgDABg");
	this.shape_10.setTransform(51.9,33.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CCCCCC").s().p("AgYAdIAMg4IALAAIAAAEQACgDACgBQADgBAEAAQAHAAADAEQAEAFABAJQgBAKgGAIQgHAGgIAAQgGAAgEgGIgFAVgAAAgSQgCACgCAFIgBAIQAAADACADQADADACAAQADAAADgCQACgCACgEIABgJQAAgEgCgDQgCgCgEAAQgCAAgDACg");
	this.shape_11.setTransform(47.1,33.875);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CCCCCC").s().p("AgTAZQgEgFgBgIQAAgKAHgHQAFgIAJAAQAIAAAEAGIAEgVIAMAAIgNA4IgKAAIABgEQgDADgCABQgDABgEAAQgHAAgDgEgAgJAAQgEAFAAAGQAAAFADACQACADADAAQAEAAABgCQADgCABgFIACgIQAAgEgDgCQgCgDgCAAQgFAAgDAFg");
	this.shape_12.setTransform(143.5,23.325);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CCCCCC").s().p("AgNAQQgGgFAAgJQAAgHAFgHQAHgJALAAQAHAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEADACQACADADAAQAEAAAEgGIAKACQgDAGgFADQgFADgFAAQgJAAgEgGgAgDgKQgDADgBAFIARAAIAAgBQgBgFgCgCQgCgDgDAAQgCAAgDADg");
	this.shape_13.setTransform(138.6,24.075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CCCCCC").s().p("AAEAdIgEgTIgIAGIgDANIgLAAIAMg5IAKAAIgFAdIAOgNIAOAAIgRAOIAJAbg");
	this.shape_14.setTransform(134.3,23.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CCCCCC").s().p("AgRAVIAJgoIAJAAIgBAIQAGgJAGAAIAGABIgFAJIgDAAQgDAAgDACQgDACgBAEQgBACgCAIIgCANg");
	this.shape_15.setTransform(130.625,24.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CCCCCC").s().p("AgPASQgEgDAAgFQAAgGAFgEQADgCAJgBIAKgCIABgDQAAgBAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQgBAAAAAAQgBAAgBABQAAAAAAAAQAAAAgBABQAAAAAAAAQgBABAAAAQAAABgBAAQAAABAAAAIgLgBQACgFAFgEQAFgDAGAAQAIAAAEAEQAEADAAAEIAAAEIgDAKIgCALIABAGIgLAAIAAgFIgFAEIgGACQgGAAgDgEgAAEACQgIABgCACQgBAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAAAQAAABABAAIADABIAEgBIAEgDIABgGIAAgCIgCABg");
	this.shape_16.setTransform(126.45,24.075);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CCCCCC").s().p("AAQAVIAFgYIABgFIgBgDIgDgBQgEAAgEAEQgCADgCAHIgEATIgKAAIAFgYIABgFIgBgDIgDgBIgEABIgDADIgDAFIgBAFIgEATIgLAAIAIgoIALAAIgBAFQAGgGAHAAQADAAADACQADACAAADQACgDAEgCQAEgCAFAAQAFAAACACQADADAAAEIgBAIIgFAYg");
	this.shape_17.setTransform(120.675,24.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CCCCCC").s().p("AgMATQgEgCgDgEQgCgFAAgEQABgLAGgHQAHgHAJAAQAJAAAFAFQAGAFAAAJQgBAJgGAHQgHAIgKAAQgFAAgFgDgAgEgKQgDACgBAFIgCAGQAAAFADACQADADADAAQAEAAADgEQAEgFABgHQgBgEgCgDQgCgCgEAAQgDAAgDACg");
	this.shape_18.setTransform(112.6,24.075);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_19.setTransform(109.175,23.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CCCCCC").s().p("AAEAVIAGgWIABgHQAAAAgBgBQAAAAAAgBQAAAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBAAgBAAQgCAAgDACQgCACgCADIgCAJIgEARIgLAAIAIgoIALAAIgBAFIAGgFQAEgBAEAAQAFAAADADQADADAAAEIgBAJIgGAWg");
	this.shape_20.setTransform(104.95,24.025);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CCCCCC").s().p("AgLAdIAJgpIAKAAIgIApgAgBgRIABgLIAMAAIgCALg");
	this.shape_21.setTransform(101.675,23.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CCCCCC").s().p("AAEAdIgEgTIgIAGIgDANIgLAAIAMg5IAKAAIgFAdIAOgNIAOAAIgQAOIAJAbg");
	this.shape_22.setTransform(96.15,23.275);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CCCCCC").s().p("AgOARQgFgFAAgIQAAgGACgGQAEgGAFgDQAGgEAGAAQAHAAAEAEQAFAEAAAGIgLABQAAgDgCgCQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAAAgBAAQgDAAgCACQgDACgCAFIgBAIQAAAEABACQABAAABABQAAAAABAAQAAABABAAQAAAAABAAQACAAADgCQACgCACgEIAKACQgDAHgFAEQgFAEgGAAQgIAAgEgFg");
	this.shape_23.setTransform(91.6,24.075);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#CCCCCC").s().p("AgSASQgDgDAAgFIABgIIAGgWIAKAAIgEAXIgCAGQAAAAABABQAAAAAAABQAAAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQABAAAAAAQAAAAABAAIADAAIACgCIADgDIACgEIABgEIAFgUIALAAIgJAoIgKAAIABgFQgGAGgIAAQgFAAgDgDg");
	this.shape_24.setTransform(86.95,24.125);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#CCCCCC").s().p("AgRAVIAJgoIAJAAIgBAIQAGgJAGAAIAGABIgFAJIgDAAQgDAAgDACQgDACgBAEQgBACgCAIIgCANg");
	this.shape_25.setTransform(83.125,24.025);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_26.setTransform(80.325,23.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#CCCCCC").s().p("AgNAQQgGgFAAgJQAAgHAFgHQAHgJALAAQAHAAAEAFQAFAFAAAIIgBAGIgbAAIAAACQAAAEADACQACADADAAQAEAAAEgGIAKACQgDAGgFADQgFADgFAAQgJAAgEgGgAgDgKQgDADgBAFIARAAIAAgBQgBgFgCgCQgCgDgDAAQgCAAgDADg");
	this.shape_27.setTransform(74.25,24.075);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#CCCCCC").s().p("AAFAdIAEgZIABgEQAAgBAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAQgDAAgDACQgCADgCADIgDAJIgDARIgLAAIAMg5IAKAAIgDAVQADgDADgBQADgCAEAAQAFAAADADQADADAAAFIgCAGIgEAZg");
	this.shape_28.setTransform(69.45,23.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#CCCCCC").s().p("AgJAaQgCgCAAgEIABgJIAEgPIgGAAIACgJIAFAAIACgHIAMgIIgDAPIAHAAIgCAJIgHAAIgEAQIAAAFIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAAAAAIAEAAIgCAIIgFABQgGAAgDgDg");
	this.shape_29.setTransform(66.125,23.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#CCCCCC").s().p("AAEAdIgFgTIgHAGIgDANIgLAAIAMg5IAKAAIgFAdIANgNIAPAAIgRAOIAJAbg");
	this.shape_30.setTransform(60.2,23.275);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#CCCCCC").s().p("AgRAVIAJgoIAJAAIgBAIQAGgJAGAAIAGABIgFAJIgDAAQgDAAgDACQgDACgBAEQgBACgCAIIgCANg");
	this.shape_31.setTransform(56.525,24.025);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#CCCCCC").s().p("AgPASQgDgDgBgFQAAgGAEgEQAEgCAKgBIAJgCIABgDQAAgBAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQgBAAAAAAQgBAAgBABQAAAAAAAAQAAAAAAABQgBAAAAAAQgBABAAAAQAAABgBAAQAAABAAAAIgLgBQACgFAEgEQAGgDAGAAQAIAAAEAEQAEADgBAEIAAAEIgCAKIgBALIABAGIgLAAIgBgFIgFAEIgHACQgFAAgDgEgAAEACQgIABgCACQAAAAgBABQAAAAAAABQgBAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAAAQAAABAAAAIAFABIADgBIAEgDIACgGIAAgCIgDABg");
	this.shape_32.setTransform(52.35,24.075);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#CCCCCC").s().p("AgZAdIALg5IAXAAQAGAAAEACQAEABACAEQACADAAAFQgBAEgBAEQgCAEgCACIgFAEIgIACIgJAAIgIAAIgFAWgAgHgCIADAAQAJAAADgBQAEgBABgCQACgDAAgDIgBgEIgDgBIgHgBIgIAAg");
	this.shape_33.setTransform(47.65,23.275);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#CCCCCC").s().p("AAKAZIgNgYIgIAJIAAAPIgLAAIAAgxIALAAIAAAWIATgWIAOAAIgTATIAUAeg");
	this.shape_34.setTransform(104.375,12.45);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#CCCCCC").s().p("AgPATQgGgHAAgLQAAgMAHgHQAGgHAKAAQAJAAAFAGQAEACACAHIgKACQgBgEgDgCQgDgDgEABQgFAAgDADQgEAFAAAIQAAAJAEAEQADAEAFAAQAEAAADgDQADgCABgFIAKADQgDAIgFAEQgFAEgIAAQgJAAgHgHg");
	this.shape_35.setTransform(99.075,12.45);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#CCCCCC").s().p("AgJAXQgEgBgCgCQgDgDAAgDIgBgNIAAgZIAKAAIAAAaIABAIQAAADACACQADACADgBQAEABADgCQACgCAAgCIABgJIAAgaIAKAAIAAAYIgBAOQgBADgCADQgCACgEACQgEACgGgBQgGAAgDgCg");
	this.shape_36.setTransform(94,12.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#CCCCCC").s().p("AALAZIgIgLIgEgHIgDgDIgFAAIgDAAIAAAVIgKAAIAAgxIAWAAQAHAAAEABQADABACAEQADADAAAFQAAAGgEAEQgDACgHABIAGAEIAFAIIAGAKgAgMgDIAIAAIAIgBIADgCIABgDIgBgFIgEgBIgHAAIgIAAg");
	this.shape_37.setTransform(89.2,12.45);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#CCCCCC").s().p("AgEAZIAAgoIgPAAIAAgJIAnAAIAAAJIgPAAIAAAog");
	this.shape_38.setTransform(84.3,12.45);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#CCCCCC").s().p("AgSAZIAAgxIAkAAIAAAJIgaAAIAAAKIAYAAIAAAIIgYAAIAAAOIAbAAIAAAIg");
	this.shape_39.setTransform(77.95,12.45);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#CCCCCC").s().p("AAKAZIAAgWIgTAAIAAAWIgKAAIAAgxIAKAAIAAATIATAAIAAgTIAKAAIAAAxg");
	this.shape_40.setTransform(73,12.45);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#CCCCCC").s().p("AgEAZIAAgoIgPAAIAAgJIAnAAIAAAJIgPAAIAAAog");
	this.shape_41.setTransform(68.35,12.45);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#CCCCCC").s().p("AAKAZIgNgYIgIAJIAAAPIgLAAIAAgxIALAAIAAAWIATgWIAOAAIgTATIAUAeg");
	this.shape_42.setTransform(61.975,12.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#CCCCCC").s().p("AALAZIgIgLIgEgHIgDgDIgFAAIgDAAIAAAVIgKAAIAAgxIAWAAQAHAAAEABQADABADAEQACADAAAFQAAAGgEAEQgDACgHABIAGAEIAGAIIAFAKgAgMgDIAIAAIAIgBIADgCIABgDIgBgFIgEgBIgHAAIgIAAg");
	this.shape_43.setTransform(56.9,12.45);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#CCCCCC").s().p("AAOAZIgEgMIgTAAIgFAMIgKAAIATgxIAKAAIAUAxgAgGAFIAMAAIgGgSg");
	this.shape_44.setTransform(51.875,12.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#CCCCCC").s().p("AgSAZIAAgxIAQAAIALAAQAEACADAEQADADAAAHQAAAEgBADIgFAEIgFACIgJABIgHAAIAAATgAgIgBIAFAAIAHgBIAEgDIABgDQAAgBAAgBQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAAAgBgBQAAAAAAgBQgBAAgBAAQAAAAgBAAIgGAAIgFAAg");
	this.shape_45.setTransform(47.125,12.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(2));

	// Layer 2
	this.instance = new lib.achievement_lock();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	this.instance_1 = new lib.check();
	this.instance_1.parent = this;
	this.instance_1.setTransform(176,24,0.1302,0.13);

	this.instance_2 = new lib.ach1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(2,2,0.2811,0.2811);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).wait(1));

	// Layer_4
	this.instance_3 = new lib.achievementramis();
	this.instance_3.parent = this;
	this.instance_3.setTransform(97.2,20.9,1,1,0,0,0,97.2,20.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,194.6,42.1);


(lib.achbutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D9D9D9").s().p("AgaAoQgJgIgCgQIATgCQABAKAFAEQAFAFAIgBQAJAAAFgDQAEgEAAgFQAAgEgCgCQgCgDgFgBIgNgFQgQgDgGgFQgJgHAAgLQAAgIAFgFQADgHAIgDQAIgDAKAAQARAAAJAHQAJAIAAANIgTABQgBgHgEgEQgDgDgIAAQgIABgEADQgEACAAADQAAAEAEACQADADANADQAOADAGAEQAHAEADAEQAEAHAAAJQAAAHgEAIQgFAGgIAEQgJADgMAAQgQAAgKgIg");
	this.shape.setTransform(141.45,16.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D9D9D9").s().p("AgIAvIAAhNIgcAAIAAgPIBJAAIAAAPIgcAAIAABNg");
	this.shape_1.setTransform(133.225,16.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D9D9D9").s().p("AASAvIgkg8IAAA8IgSAAIAAhcIATAAIAkA8IAAg8IASAAIAABcg");
	this.shape_2.setTransform(124.5,16.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D9D9D9").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_3.setTransform(115.675,16.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D9D9D9").s().p("AAcAvIAAhJIgTBJIgRAAIgThJIAABJIgRAAIAAhcIAdAAIAPA+IARg+IAcAAIAABcg");
	this.shape_4.setTransform(105.75,16.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D9D9D9").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_5.setTransform(96.175,16.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D9D9D9").s().p("AgJAvIghhcIAUAAIAXBDIAWhDIAUAAIghBcg");
	this.shape_6.setTransform(87.375,16.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D9D9D9").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_7.setTransform(78.875,16.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D9D9D9").s().p("AgIAvIAAhcIARAAIAABcg");
	this.shape_8.setTransform(72.625,16.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D9D9D9").s().p("AASAvIAAgpIgjAAIAAApIgTAAIAAhcIATAAIAAAkIAjAAIAAgkIATAAIAABcg");
	this.shape_9.setTransform(66.075,16.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D9D9D9").s().p("AgbAkQgNgNAAgWQAAgWANgNQALgNATAAQARAAALAKQAGAGADALIgSAFQgCgIgFgEQgFgEgIAAQgJAAgHAHQgGAIAAAQQAAARAGAHQAHAIAJAAQAIAAAFgEQAFgGACgKIASAGQgDAQgKAGQgKAIgPAAQgSAAgLgMg");
	this.shape_10.setTransform(56.65,16.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D9D9D9").s().p("AAaAvIgIgVIgkAAIgIAVIgUAAIAkhcIATAAIAmBcgAgMAKIAYAAIgMgig");
	this.shape_11.setTransform(47.275,16.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.instance = new lib.buttonbackground();
	this.instance.parent = this;
	this.instance.setTransform(97.55,16,1,1,0,0,0,97.4,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.achbutton, new cjs.Rectangle(0.2,0,194.8,32), null);


(lib.webgamespreloader = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		loadscreen = this;
		var rotateto = 0;
		dumibultai = true;
		var lastFrame = 0;
		updatepreloader = setInterval(playpreloader, 30);
		
		
		function playpreloader() {
		
			if(dumibultai && lastFrame != loadscreen.currentFrame) {
				
				lastFrame = loadscreen.currentFrame;
				rotateto += 30;
		var dumi = new lib.bultadumi();	
		dumi.x = loadscreen.bulta.x;	
		dumi.y = loadscreen.bulta.y;
		dumi.rotation = rotateto;		
		loadscreen.fons.addChild(dumi);
			}
		}
		
		loadscreen.addEventListener("click", merePreloader);
		
		function merePreloader()
		{
			var gotourl;
				if(mobile) {
			gotourl = "https://m.1000webgames.com/?utm_campaign=truck_space_2&utm_medium=preloader&utm_source=" + ref;	
			} else {
			gotourl = "https://1000webgames.com/?utm_campaign=truck_space_2&utm_medium=preloader&utm_source=" + ref;
			}
			window.open(gotourl, "_blank");
		}
	}
	this.frame_162 = function() {
		dumibultai = false;
	}
	this.frame_494 = function() {
		this.stop();
		clearInterval(updatepreloader);
		loadscreen.removeAllEventListeners();
		exportRoot.gotoAndStop(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(162).call(this.frame_162).wait(332).call(this.frame_494).wait(1));

	// actions
	this.instance = new lib.fons();
	this.instance.parent = this;
	this.instance.setTransform(320,180,1,1,0,0,0,320,180);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(446).to({_off:false},0).to({alpha:1},22).wait(27));

	// 1000
	this.lgames = new lib.lgames();
	this.lgames.name = "lgames";
	this.lgames.parent = this;
	this.lgames.setTransform(332.5,189.55);
	this.lgames._off = true;

	this.timeline.addTween(cjs.Tween.get(this.lgames).wait(162).to({_off:false},0).wait(333));

	// bulta
	this.bulta = new lib.bultapreloader();
	this.bulta.name = "bulta";
	this.bulta.parent = this;
	this.bulta.setTransform(694.55,394.35,0.3695,0.3701,0,-118.9268,-119.0714);

	this.timeline.addTween(cjs.Tween.get(this.bulta).wait(14).to({scaleX:0.1015,scaleY:0.1012,skewX:-119.1595,skewY:-118.8221,x:669.2,y:343.7},0).to({regX:-0.1,regY:0.1,scaleX:1.3496,scaleY:1.3471,rotation:-176.7019,skewX:0,skewY:0,guide:{path:[669.2,343.7,655.9,317.7,645.1,297.7,634.9,278.6,627,265.1,617.7,249.2,611.6,240.8,587,207,540.5,147.5,494.1,87.9,456.2,65.8,418.4,43.7,373.4,28.9,338,17.3,299.5,14.8], orient:'auto'}},67).wait(1).to({regX:0,regY:0,scaleX:1.3453,scaleY:1.3429,rotation:-178.0028,x:291.8693,y:14.348},0).wait(1).to({scaleX:1.341,scaleY:1.3386,rotation:-179.2853,x:284.4805,y:14.1274},0).wait(1).to({scaleX:1.3367,scaleY:1.3343,rotation:-180.4509,x:277.1189,y:14.0687},0).wait(1).to({scaleX:1.3323,scaleY:1.33,rotation:-180.957,x:269.9423,y:14.1082},0).wait(1).to({scaleX:1.3281,scaleY:1.3257,rotation:-181.4144,x:263.6395,y:14.1953},0).wait(1).to({scaleX:1.3237,scaleY:1.3214,rotation:-181.8943,x:257.1954,y:14.3365},0).wait(1).to({scaleX:1.3194,scaleY:1.3172,rotation:-182.3877,x:250.7453,y:14.5322},0).wait(1).to({scaleX:1.3151,scaleY:1.3129,rotation:-182.8965,x:244.2716,y:14.7847},0).wait(1).to({scaleX:1.3108,scaleY:1.3086,rotation:-183.4214,x:237.7761,y:15.0962},0).wait(1).to({scaleX:1.3065,scaleY:1.3044,rotation:-183.9631,x:231.2586,y:15.469},0).wait(1).to({scaleX:1.3022,scaleY:1.3,rotation:-184.5224,x:224.7189,y:15.9056},0).wait(1).to({scaleX:1.2979,scaleY:1.2958,rotation:-185.1003,x:218.157,y:16.4085},0).wait(1).to({scaleX:1.2936,scaleY:1.2915,rotation:-185.6974,x:211.5729,y:16.9806},0).wait(1).to({scaleX:1.2892,scaleY:1.2872,rotation:-186.315,x:204.9667,y:17.6246},0).wait(1).to({scaleX:1.2849,scaleY:1.2829,rotation:-186.9539,x:198.3385,y:18.3437},0).wait(1).to({scaleX:1.2806,scaleY:1.2787,rotation:-187.6152,x:191.6887,y:19.141},0).wait(1).to({scaleX:1.2763,scaleY:1.2744,rotation:-188.3,x:185.0175,y:20.0199},0).wait(1).to({scaleX:1.272,scaleY:1.2701,rotation:-189.0097,x:178.3238,y:20.9842},0).wait(1).to({scaleX:1.2677,scaleY:1.2658,rotation:-189.7455,x:171.6093,y:22.0375},0).wait(1).to({scaleX:1.2634,scaleY:1.2615,rotation:-190.5085,x:164.8757,y:23.1837},0).wait(1).to({scaleX:1.2591,scaleY:1.2573,rotation:-191.3,x:158.1239,y:24.4268},0).wait(1).to({scaleX:1.2548,scaleY:1.253,rotation:-192.1215,x:151.3549,y:25.7714},0).wait(1).to({scaleX:1.2505,scaleY:1.2487,rotation:-192.9744,x:144.5703,y:27.2218},0).wait(1).to({scaleX:1.2462,scaleY:1.2444,rotation:-193.8602,x:137.7717,y:28.7828},0).wait(1).to({scaleX:1.2418,scaleY:1.2402,rotation:-194.7808,x:130.9589,y:30.46},0).wait(1).to({scaleX:1.2375,scaleY:1.2359,rotation:-195.7373,x:124.1368,y:32.2579},0).wait(1).to({scaleX:1.2332,scaleY:1.2316,rotation:-196.7315,x:117.3071,y:34.1821},0).wait(1).to({scaleX:1.2289,scaleY:1.2273,rotation:-197.765,x:110.473,y:36.2382},0).wait(1).to({scaleX:1.2246,scaleY:1.2231,rotation:-198.8392,x:103.638,y:38.4318},0).wait(1).to({scaleX:1.2203,scaleY:1.2188,rotation:-199.9558,x:96.8061,y:40.7688},0).wait(1).to({scaleX:1.216,scaleY:1.2145,rotation:-201.1526,x:89.9839,y:43.2558},0).wait(1).to({scaleX:1.2117,scaleY:1.2102,rotation:-202.2679,x:84.0359,y:45.5609},0).wait(1).to({scaleX:1.2074,scaleY:1.206,rotation:-203.1984,x:79.543,y:47.395},0).wait(1).to({scaleX:1.2031,scaleY:1.2017,rotation:-204.3348,x:74.5512,y:49.5381},0).wait(1).to({scaleX:1.1988,scaleY:1.1974,rotation:-205.5511,x:69.7418,y:51.7206},0).wait(1).to({scaleX:1.1945,scaleY:1.1931,rotation:-206.9226,x:64.8892,y:54.056},0).wait(1).to({scaleX:1.1902,scaleY:1.1888,rotation:-208.4578,x:60.0726,y:56.5262},0).wait(1).to({scaleX:1.1859,scaleY:1.1846,rotation:-210.1988,x:55.2752,y:59.1621},0).wait(1).to({scaleX:1.1816,scaleY:1.1803,rotation:-212.1892,x:50.5131,y:61.9841},0).wait(1).to({scaleX:1.1772,scaleY:1.176,rotation:-214.4943,x:45.7885,y:65.0284},0).wait(1).to({scaleX:1.1729,scaleY:1.1717,rotation:-217.1903,x:41.1305,y:68.3259},0).wait(1).to({scaleX:1.1686,scaleY:1.1674,rotation:-220.3839,x:36.5667,y:71.9224},0).wait(1).to({scaleX:1.1643,scaleY:1.1632,rotation:-224.2179,x:32.1389,y:75.8748},0).wait(1).to({scaleX:1.16,scaleY:1.1589,rotation:-228.883,x:27.9078,y:80.2568},0).wait(1).to({scaleX:1.1557,scaleY:1.1546,rotation:-234.6166,x:23.9706,y:85.1548},0).wait(1).to({scaleX:1.1514,scaleY:1.1503,rotation:-241.6601,x:20.4824,y:90.6526},0).wait(1).to({scaleX:1.1471,scaleY:1.1461,rotation:-250.1592,x:17.6617,y:96.8153},0).wait(1).to({scaleX:1.1428,scaleY:1.1418,rotation:-259.9206,x:15.7855,y:103.6232},0).wait(1).to({scaleX:1.1385,scaleY:1.1375,rotation:-270.1826,x:15.1088,y:110.8868},0).wait(1).to({scaleX:1.1342,scaleY:1.1332,rotation:-278.5133,x:15.6031,y:118.1349},0).wait(1).to({scaleX:1.1298,scaleY:1.1289,rotation:-287.2471,x:17.2167,y:125.4538},0).wait(1).to({scaleX:1.1255,scaleY:1.1246,rotation:-295.9433,x:20.0266,y:132.704},0).wait(1).to({scaleX:1.1212,scaleY:1.1204,rotation:-303.8933,x:23.9207,y:139.5822},0).wait(1).to({scaleX:1.1169,scaleY:1.1161,rotation:-310.6766,x:28.6295,y:145.8631},0).wait(1).to({scaleX:1.1126,scaleY:1.1118,rotation:-316.2023,x:33.8487,y:151.4622},0).wait(1).to({scaleX:1.1083,scaleY:1.1075,rotation:-321.2515,x:39.362,y:156.3941},0).wait(1).to({scaleX:1.104,scaleY:1.1032,rotation:-326.4972,x:45.9439,y:161.2939},0).wait(1).to({scaleX:1.0996,scaleY:1.0989,rotation:-331.343,x:53.0012,y:165.6406},0).wait(1).to({scaleX:1.0953,scaleY:1.0946,rotation:-335.6728,x:60.3217,y:169.3798},0).wait(1).to({scaleX:1.091,scaleY:1.0903,rotation:-339.4832,x:67.7711,y:172.5426},0).wait(1).to({scaleX:1.0867,scaleY:1.0861,rotation:-342.813,x:75.2508,y:175.1845},0).wait(1).to({scaleX:1.0824,scaleY:1.0818,rotation:-345.7215,x:82.7011,y:177.3704},0).wait(1).to({scaleX:1.0781,scaleY:1.0775,rotation:-348.2702,x:90.0869,y:179.1625},0).wait(1).to({scaleX:1.0737,scaleY:1.0732,rotation:-349.7762,x:97.3469,y:180.6441},0).wait(1).to({scaleX:1.0694,scaleY:1.0689,rotation:-350.922,x:104.948,y:182.0317},0).wait(1).to({scaleX:1.0651,scaleY:1.0646,rotation:-352.0313,x:112.6769,y:183.2868},0).wait(1).to({scaleX:1.0608,scaleY:1.0603,rotation:-353.0836,x:120.3718,y:184.3889},0).wait(1).to({scaleX:1.0564,scaleY:1.056,rotation:-354.0815,x:128.021,y:185.346},0).wait(1).to({scaleX:1.0521,scaleY:1.0517,rotation:-355.0286,x:135.6207,y:186.167},0).wait(1).to({scaleX:1.0478,scaleY:1.0474,rotation:-355.9285,x:143.1722,y:186.8607},0).wait(1).to({scaleX:1.0434,scaleY:1.0431,rotation:-356.7845,x:150.6749,y:187.435},0).wait(1).to({scaleX:1.0391,scaleY:1.0388,rotation:-357.5997,x:158.129,y:187.8971},0).wait(1).to({scaleX:1.0348,scaleY:1.0345,rotation:-358.3662,x:165.6687,y:188.2586},0).wait(1).to({scaleX:1.0304,scaleY:1.0302,rotation:-358.9229,x:176.0257,y:188.6362},0).wait(1).to({scaleX:1.0261,scaleY:1.0259,rotation:-359.3082,x:188.7201,y:188.9993},0).wait(1).to({scaleX:1.0218,scaleY:1.0216,rotation:-359.5327,x:200.0528,y:189.2664},0).wait(1).to({scaleX:1.0174,scaleY:1.0173,rotation:-359.677,x:209.7285,y:189.465},0).wait(1).to({scaleX:1.0131,scaleY:1.013,rotation:-359.7831,x:218.4563,y:189.6262},0).wait(1).to({scaleX:1.0087,scaleY:1.0087,rotation:-359.8679,x:226.6697,y:189.765},0).wait(1).to({scaleX:1.0044,scaleY:1.0043,rotation:-359.9389,x:234.5541,y:189.8884},0).wait(1).to({scaleX:1,scaleY:1,rotation:-360,x:242.05,y:190.05},0).wait(333));

	// Layer 7
	this.wgames = new lib._1000WebGames_1();
	this.wgames.name = "wgames";
	this.wgames.parent = this;
	this.wgames.setTransform(320,137,0.1587,0.1587);
	this.wgames.alpha = 0;
	this.wgames._off = true;

	this.timeline.addTween(cjs.Tween.get(this.wgames).wait(34).to({_off:false},0).to({regY:-0.7,scaleX:0.9276,scaleY:0.927,x:318.75,y:134.65,alpha:1},116).wait(345));

	// objekti
	this.instance_1 = new lib.bultadumi();
	this.instance_1.parent = this;
	this.instance_1.setTransform(308,189,2,2);

	this.instance_2 = new lib.explosion_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(268,199.6,1,1,0,0,0,0,15.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},161).to({state:[{t:this.instance_2},{t:this.instance_1}]},333).wait(1));

	// fons
	this.fons = new lib.fons();
	this.fons.name = "fons";
	this.fons.parent = this;
	this.fons.setTransform(320,180,1,1,0,0,0,320,180);

	this.timeline.addTween(cjs.Tween.get(this.fons).wait(495));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-2.2,700.1,401.59999999999997);


(lib.tryagain2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D9D9D9").s().p("AgHAGIADgLIAMAAIgDALg");
	this.shape.setTransform(133.575,75.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D9D9D9").s().p("AgcAoQgHgHAAgNQABgNAEgJQAFgKAIgFQAHgFAIAAQAMAAAGAMIAIgkIALAAIgTBcIgLAAIACgKQgJALgKAAQgKAAgGgHgAgJgLQgDACgDAEQgDAFgDAGQgCAGAAAGIABALQABAEAEACQADADAFAAQAIAAAFgIQAJgLAAgQQAAgHgFgEQgEgFgFAAQgEAAgEACg");
	this.shape_1.setTransform(129.05,71.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D9D9D9").s().p("AgYAeQgHgGAAgIQAAgGAEgEQACgFAEgBIAKgEIAOgBQALgBAFgCIABgHQAAgEgDgDQgEgDgIAAQgGAAgFADQgEAEgCAGIgMgBQAEgLAHgFQAJgFAKAAQANAAAHAGQAGAEgBAHIgBANIgEAQIgCANIACAJIgMAAIgBgJQgGAGgFACQgFACgGAAQgKAAgFgFgAAMABIgJABIgOACQgEACgCADQgCADAAADQAAAFAEADQADADAGAAQAFAAAFgDQAFgDADgFQADgFACgKIgFABg");
	this.shape_2.setTransform(121.25,72.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D9D9D9").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_3.setTransform(114.125,72.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D9D9D9").s().p("AgYAiIAOhCIAKAAIgDAOQAFgIAEgDQAGgEAEAAQAEAAAFACIgEALQgDgCgEAAQgGgBgGAIQgGAGgDAQIgGAbg");
	this.shape_4.setTransform(108.9,72.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_5.setTransform(98.875,72.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D9D9D9").s().p("AAKAuIAJgoIACgLQAAgDgDgCQgCgCgEAAQgGAAgGAEQgFADgDAFQgDAFgCAMIgGAdIgMAAIAThbIALAAIgHAjQAHgGAEgCQAGgDAGAAQAIgBAEAFQAFAFAAAGIgCANIgIAng");
	this.shape_6.setTransform(91.5,71.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D9D9D9").s().p("AgNArQgDgCAAgFIABgKIAIgmIgJAAIACgJIAJAAIAEgQIAMgJIgFAZIALAAIgCAJIgLAAIgHAkIgBAJIABADIADABIAGgBIgBAJIgHABQgHAAgEgDg");
	this.shape_7.setTransform(86.725,71.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D9D9D9").s().p("AgWAvIALg5IgKAAIACgJIAKAAIADgKIADgKQABgDADgCQAEgCAGAAIAMABIgBAKIgKgBQgEAAgCACQgBABgBAHIgCAHIANAAIgCAJIgNAAIgLA5g");
	this.shape_8.setTransform(80,71.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D9D9D9").s().p("AgWAvIALg5IgKAAIACgJIAKAAIADgKIADgKQABgDADgCQAEgCAGAAIAMABIgBAKIgKgBQgEAAgCACQgBABgBAHIgCAHIANAAIgCAJIgNAAIgLA5g");
	this.shape_9.setTransform(76.4,71.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D9D9D9").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_10.setTransform(70.025,72.875);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D9D9D9").s().p("AgWAuQgHgCgCgEQgDgFAAgEIAAgEIAMABQgBAEACACIADADQADACAFAAQAKAAAEgGQADgEACgMIACgFQgJAJgJAAQgLAAgGgHQgHgIAAgNQAAgLAFgKQAGgJAHgFQAIgFAGAAQAOAAAHAMIACgLIALAAIgNBAQgDAMgEAFQgDAHgGACQgGAEgJAAQgHAAgGgCgAgFgkIgHAHQgEAFgCAGIgCAKQABAHABADQACAFAEACQADADAEAAQAFAAAGgFQAFgEAEgGQADgJAAgIQAAgIgEgEQgGgGgGAAQgDAAgEACg");
	this.shape_11.setTransform(59.2,74.15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#D9D9D9").s().p("AALAiIAJgpIABgKQAAgDgCgCQgDgCgEAAQgJAAgGAGQgHAHgDAOIgHAfIgLAAIAOhCIALAAIgDAMQAGgHAGgDQAGgDAFAAQAJgBAFAFQAEAEAAAIIgBAMIgJAng");
	this.shape_12.setTransform(51.75,72.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#D9D9D9").s().p("AgOAuIANhCIALAAIgNBCgAABghIADgMIALAAIgCAMg");
	this.shape_13.setTransform(47.15,71.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#D9D9D9").s().p("AgTAiIgLhDIALAAIAFAkIADAUIAIgQIAWgoIAMAAIglBDg");
	this.shape_14.setTransform(42.85,72.875);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#D9D9D9").s().p("AgPAuIAPhCIAKAAIgNBCgAABghIADgMIAMAAIgEAMg");
	this.shape_15.setTransform(37.75,71.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#D9D9D9").s().p("AgYAiIAOhCIAKAAIgDAOQAEgIAFgDQAFgEAGAAQADAAAFACIgEALQgDgCgEAAQgGgBgGAIQgGAGgDAQIgHAbg");
	this.shape_16.setTransform(34.4,72.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#D9D9D9").s().p("AgcAoQgHgHABgNQAAgNAEgJQAGgKAHgFQAIgFAHAAQAMAAAGAMIAIgkIAMAAIgUBcIgLAAIACgKQgIALgMAAQgJAAgGgHgAgIgLQgEACgDAEQgDAFgDAGQgCAGAAAGIABALQACAEADACQADADAFAAQAIAAAFgIQAIgLAAgQQAAgHgDgEQgFgFgFAAQgEAAgDACg");
	this.shape_17.setTransform(28.45,71.675);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#D9D9D9").s().p("AgcAoQgGgHgBgNQAAgNAGgJQAEgKAIgFQAIgFAHAAQAMAAAGAMIAIgkIALAAIgTBcIgLAAIADgKQgKALgKAAQgKAAgGgHgAgJgLQgDACgEAEQgDAFgCAGQgCAGAAAGIABALQABAEAEACQAEADAEAAQAIAAAFgIQAJgLgBgQQAAgHgEgEQgDgFgGAAQgEAAgEACg");
	this.shape_18.setTransform(17.6,71.675);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#D9D9D9").s().p("AgOAuIANhCIALAAIgNBCgAABghIADgMIALAAIgCAMg");
	this.shape_19.setTransform(12.4,71.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#D9D9D9").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_20.setTransform(7.025,72.875);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#D9D9D9").s().p("AgTAiIgLhDIALAAIAFAkIADAUIAJgQIAVgoIAMAAIgmBDg");
	this.shape_21.setTransform(0.85,72.875);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#D9D9D9").s().p("AAdAuIgEgbIglAAIgPAbIgNAAIAzhbIAPAAIAPBbgAAIgRIgOAbIAdAAIgDgWIgDgYIgJATg");
	this.shape_22.setTransform(-8.075,71.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#D9D9D9").s().p("AgHAHIADgNIAMAAIgDANg");
	this.shape_23.setTransform(194.675,59.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#D9D9D9").s().p("AgVAdQgIgFAAgNIAMgBQAAAFABADQACAEAEACQAEACAFAAQAHAAAEgDQAEgDAAgEQAAgDgDgCQgCgDgJgEIgLgFQgEgCgCgEQgCgDAAgFQAAgIAGgFQAGgGALAAQAMAAAHAGQAHAGAAAJIgLABQgBgGgEgEQgEgDgHAAQgFAAgDACQgEADAAADQAAAEADACQACACAHADQANAGAEACQAFAFAAAIQAAAFgDAFQgDAEgGADQgHADgHAAQgMAAgIgGg");
	this.shape_24.setTransform(190.1735,56.375);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_25.setTransform(183.175,56.375);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#D9D9D9").s().p("AgPAvIAThcIALAAIgSBcg");
	this.shape_26.setTransform(178.4,55.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#D9D9D9").s().p("AgWAcQgGgHgBgNQAAgKAFgKQAEgLAIgGQAIgFAKAAQAKAAAHAGQAGAGABAKIgMABQAAgGgEgEQgDgEgGAAQgGAAgFAFQgFAEgDAJQgDAIAAAIQAAAJAEAEQADAEAGAAQAEAAAGgEQAFgEADgJIALABQgEANgIAGQgIAGgJAAQgLAAgHgHg");
	this.shape_27.setTransform(173.7,56.375);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#D9D9D9").s().p("AgZAeQgFgGgBgIQABgGADgEQACgFAEgBIALgEIANgBQALgBAFgCIABgHQAAgEgDgDQgEgDgHAAQgHAAgFADQgEAEgCAGIgMgBQAEgLAHgFQAIgFALAAQANAAAHAGQAGAEgBAHIgBANIgEAQIgBANIABAJIgMAAIgBgJQgGAGgGACQgEACgGAAQgKAAgGgFgAAMABIgKABIgMACQgEACgDADQgCADAAADQAAAFADADQAEADAGAAQAFAAAFgDQAFgDADgFQAEgFABgKIgFABg");
	this.shape_28.setTransform(166.45,56.375);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#D9D9D9").s().p("AgNAsQgDgEAAgDIABgLIAIgmIgJAAIACgJIAJAAIAEgQIAMgIIgFAYIALAAIgCAJIgLAAIgHAkIgBAIIABAEIADABIAGgBIgBAKIgHAAQgHAAgEgCg");
	this.shape_29.setTransform(161.625,55.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#D9D9D9").s().p("AgVAdQgIgFAAgNIAMgBQAAAFABADQACAEAEACQAEACAFAAQAHAAAEgDQAEgDAAgEQAAgDgDgCQgCgDgJgEIgLgFQgEgCgCgEQgCgDAAgFQAAgIAGgFQAGgGALAAQAMAAAHAGQAHAGAAAJIgLABQgBgGgEgEQgEgDgHAAQgFAAgDACQgEADAAADQAAAEADACQACACAHADQANAGAEACQAFAFAAAIQAAAFgDAFQgDAEgGADQgHADgHAAQgMAAgIgGg");
	this.shape_30.setTransform(156.1735,56.375);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#D9D9D9").s().p("AgLAsQgFgEgDgHIgCANIgKAAIAThcIALAAIgHAhQAGgFADgCQAEgCAFAAQAKAAAGAHQAHAHAAAMQgBAJgCAIQgCAHgEAFQgEAFgEADIgIAFIgIABQgGAAgFgDgAgDgIQgGAFgDAJQgDAHAAAFIAAACQABAJAEAEQAEAFAFAAQAFAAAGgEQAFgFADgJQAEgIAAgIQAAgIgFgEQgEgFgGAAQgGAAgEAFg");
	this.shape_31.setTransform(149.1,55.175);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#D9D9D9").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_32.setTransform(141.975,56.375);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#D9D9D9").s().p("AgYAjIAOhDIAKAAIgDAOQAEgIAGgDQAEgFAGAAQADABAFACIgFALQgDgCgDgBQgGABgHAGQgFAHgDARIgHAbg");
	this.shape_33.setTransform(133.15,56.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#D9D9D9").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_34.setTransform(126.775,56.375);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#D9D9D9").s().p("AgVAdQgIgFAAgNIAMgBQAAAFABADQACAEAEACQAEACAFAAQAHAAAEgDQAEgDAAgEQAAgDgDgCQgCgDgJgEIgLgFQgEgCgCgEQgCgDAAgFQAAgIAGgFQAGgGALAAQAMAAAHAGQAHAGAAAJIgLABQgBgGgEgEQgEgDgHAAQgFAAgDACQgEADAAADQAAAEADACQACACAHADQANAGAEACQAFAFAAAIQAAAFgDAFQgDAEgGADQgHADgHAAQgMAAgIgGg");
	this.shape_35.setTransform(116.3735,56.375);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_36.setTransform(109.375,56.375);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#D9D9D9").s().p("AgPAvIAThcIALAAIgSBcg");
	this.shape_37.setTransform(104.6,55.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#D9D9D9").s().p("AgWAcQgGgHgBgNQAAgKAFgKQAEgLAIgGQAIgFAKAAQAKAAAHAGQAGAGABAKIgMABQAAgGgEgEQgDgEgGAAQgGAAgFAFQgFAEgDAJQgDAIAAAIQAAAJAEAEQADAEAGAAQAEAAAGgEQAFgEADgJIALABQgEANgIAGQgIAGgJAAQgLAAgHgHg");
	this.shape_38.setTransform(99.9,56.375);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#D9D9D9").s().p("AgPAvIAPhDIAKAAIgNBDgAABghIADgMIAMAAIgEAMg");
	this.shape_39.setTransform(95.25,55.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#D9D9D9").s().p("AAKAvIAJgqIACgKQAAgDgDgCQgCgCgEAAQgGAAgGAEQgFACgDAGQgDAFgCANIgGAdIgMAAIAThcIALAAIgHAjQAHgGAEgCQAGgEAGAAQAIABAEAEQAFAFAAAHIgCALIgIApg");
	this.shape_40.setTransform(89.7,55.1);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_41.setTransform(82.575,56.375);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#D9D9D9").s().p("AgTAiIgLhDIALAAIAFAkIADAUIAJgQIAVgoIAMAAIgmBDg");
	this.shape_42.setTransform(76.45,56.375);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#D9D9D9").s().p("AgYAjIAOhDIAKAAIgDAOQAFgIAEgDQAFgFAFAAQAEABAFACIgEALQgDgCgEgBQgGABgHAGQgFAHgEARIgFAbg");
	this.shape_43.setTransform(67.3,56.3);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_44.setTransform(60.875,56.375);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#D9D9D9").s().p("AAKAvIAJgqIACgKQAAgDgDgCQgCgCgEAAQgHAAgFAEQgEACgEAGQgDAFgDANIgFAdIgMAAIAThcIAMAAIgIAjQAGgGAFgCQAGgEAGAAQAIABAFAEQAEAFAAAHIgCALIgIApg");
	this.shape_45.setTransform(53.5,55.1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#D9D9D9").s().p("AgNAsQgDgEAAgDIABgLIAIgmIgJAAIACgJIAJAAIAEgQIAMgIIgFAYIALAAIgCAJIgLAAIgHAkIgBAIIABAEIADABIAGgBIgBAKIgHAAQgHAAgEgCg");
	this.shape_46.setTransform(48.725,55.2);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#D9D9D9").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_47.setTransform(42.825,56.375);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#D9D9D9").s().p("AgNAsQgDgEAAgDIABgLIAIgmIgJAAIACgJIAJAAIAEgQIAMgIIgFAYIALAAIgCAJIgLAAIgHAkIgBAIIABAEIADABIAGgBIgBAKIgHAAQgHAAgEgCg");
	this.shape_48.setTransform(34.275,55.2);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#D9D9D9").s().p("AgOAvIANhDIALAAIgNBDgAABghIADgMIALAAIgCAMg");
	this.shape_49.setTransform(30.85,55.1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#D9D9D9").s().p("AALAvIAIgqIACgKQAAgDgCgCQgDgCgEAAQgGAAgGAEQgFACgDAGQgDAFgCANIgHAdIgLAAIAThcIALAAIgGAjQAFgGAFgCQAGgEAFAAQAJABAFAEQAEAFAAAHIgCALIgIApg");
	this.shape_50.setTransform(25.3,55.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#D9D9D9").s().p("AgNAsQgDgEAAgDIABgLIAIgmIgJAAIACgJIAJAAIAEgQIAMgIIgFAYIALAAIgCAJIgLAAIgHAkIgBAIIABAEIADABIAGgBIgBAKIgHAAQgHAAgEgCg");
	this.shape_51.setTransform(16.925,55.2);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#D9D9D9").s().p("AgIAQIABgQIAEgPIAMAAIgDAPIgGAQg");
	this.shape_52.setTransform(14.45,52.1);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#D9D9D9").s().p("AAKAjIAJgqIACgKQgBgDgCgCQgCgCgEAAQgJAAgGAHQgHAFgDAPIgHAgIgLAAIAOhDIAKAAIgCAMQAGgHAGgDQAFgEAHAAQAIABAEAEQAFAFAAAHIgBALIgJApg");
	this.shape_53.setTransform(8.35,56.3);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#D9D9D9").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_54.setTransform(1.275,56.375);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#D9D9D9").s().p("AgqAvIAThcIAbAAQAKAAAFABQAIACAFAFQAGAFADAIQACAHAAAKQAAAKgDAJQgDAJgGAHQgFAHgGAEQgGAEgJACQgFABgJABgAgcAkIAPAAQAKAAAHgCIAIgDQAEgDAEgFQAFgGADgIQADgIAAgJQAAgMgEgFQgEgHgGgBQgFgCgJAAIgQAAg");
	this.shape_55.setTransform(-7.025,55.1);

	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(276.85,65.1,1.1429,1.1429,0,0,0,35.1,17.6);

	this.moreButton = new lib.morefinishbutton();
	this.moreButton.name = "moreButton";
	this.moreButton.parent = this;
	this.moreButton.setTransform(168.45,159.5,1,1,0,0,0,97.5,16);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFCC66").s().p("AgIAvIAAgSIARAAIAAASgAgEAXIgFguIAAgXIATAAIAAAXIgFAug");
	this.shape_56.setTransform(82.675,16.55);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFCC66").s().p("AgmAvIAAhdIAiAAQALABAGABQAIACAGAHQAGAGADAJQADAJAAAMQAAALgDAJQgDAKgHAGQgFAFgIACQgHACgIABgAgTAfIANAAIALgBQAEgBADgDQAEgDACgGQABgGAAgLQAAgKgBgFQgCgHgEgCQgDgEgGgBQgDgBgLAAIgIAAg");
	this.shape_57.setTransform(72.4,16.55);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFCC66").s().p("AgiAvIAAhdIBEAAIAAAQIgyAAIAAAVIAuAAIAAAPIguAAIAAAZIAzAAIAAAQg");
	this.shape_58.setTransform(63.375,16.55);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFCC66").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape_59.setTransform(55.225,16.575);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFCC66").s().p("AgIAvIAAhdIARAAIAABdg");
	this.shape_60.setTransform(49.175,16.55);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFCC66").s().p("AAaAvIgIgWIgkAAIgIAWIgUAAIAkhdIATAAIAmBdgAgMAJIAYAAIgMghg");
	this.shape_61.setTransform(42.625,16.55);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFCC66").s().p("AgfAvIAAhdIA/AAIAAAQIgsAAIAAAWIAmAAIAAAPIgmAAIAAAog");
	this.shape_62.setTransform(34.15,16.55);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFCC66").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape_63.setTransform(22.725,16.575);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFCC66").s().p("AgiAvIAAhdIBEAAIAAAQIgyAAIAAAVIAuAAIAAAPIguAAIAAAZIAzAAIAAAQg");
	this.shape_64.setTransform(14.275,16.55);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFCC66").s().p("AgJAvIghhdIAUAAIAXBFIAWhFIAUAAIghBdg");
	this.shape_65.setTransform(5.475,16.55);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFCC66").s().p("AgiAvIAAhdIBEAAIAAAQIgyAAIAAAVIAuAAIAAAPIguAAIAAAZIAzAAIAAAQg");
	this.shape_66.setTransform(-3.025,16.55);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFCC66").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape_67.setTransform(-11.175,16.575);

	this.again = new lib.tryagainbutton();
	this.again.name = "again";
	this.again.parent = this;
	this.again.setTransform(295.95,159.5,1,1,0,0,0,97.5,16);

	this.closeButton = new lib.closeoptions();
	this.closeButton.name = "closeButton";
	this.closeButton.parent = this;
	this.closeButton.setTransform(307.95,13.25,0.6667,0.6664,0,0,0,10.1,9.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.closeButton},{t:this.again},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.moreButton},{t:this.stars},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#CCCCCC").ss(0.2,1,1).p("A72AAMA3tAAA");
	this.shape_68.setTransform(151.75,35.5);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#CCCCCC").ss(1,1,1,3,true).p("A72umMA3tAAAIAAFjIAAXqMg3tAAAIAA3qg");
	this.shape_69.setTransform(151.75,93.475);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#3B3B3B").s().p("A71L1IAA3pMA3sAAAIAAXpg");
	this.shape_70.setTransform(151.75,111.225);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#333333").s().p("A71CxIAAliMA3sAAAIAAFig");
	this.shape_71.setTransform(151.75,17.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68}]}).wait(1));

	// Layer 3
	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#262626").s().p("A77OaIAA8zMA33AAAIAAczg");
	this.shape_72.setTransform(155.3,98.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_72).wait(1));

}).prototype = getMCSymbolPrototype(lib.tryagain2, new cjs.Rectangle(-27.5,-1,361.6,191.5), null);


(lib.tryagain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_48 = function() {
		if (backgroundSound) backgroundSound.stop();
	}
	this.frame_69 = function() {
		backgroundSound = createjs.Sound.play("sakumamuzons",{interrupt: createjs.Sound.INTERRUPT_EARLY, loop:-1});
	}
	this.frame_76 = function() {
		var tryscreen = this;
		tryscreen.stop();
		
		tryscreen.screen.closeButton.addEventListener("click", closeScreen);
		tryscreen.screen.again.addEventListener("click", closeScreen);
		tryscreen.screen.moreButton.addEventListener("click", moregbutton);
		
		function closeScreen(event) {
			
			removeListeners();
			tryscreen.gotoAndPlay(77);
			canvas.style.pointerEvents = "none";
		}
		
		function moregbutton()
		{
		var gotourl;
			if(mobile) {
			gotourl = "https://m.1000webgames.com/?utm_campaign=truck_space_2&utm_medium=moregames_starplevel&utm_source=" + ref;	
			} else {
			gotourl = "https://1000webgames.com/?utm_campaign=truck_space_2&utm_medium=moregames_starplevel&utm_source=" + ref;
			}
			window.open(gotourl, "_blank");	
		}
		
		function removeListeners() {
			tryscreen.screen.closeButton.removeEventListener("click", closeScreen);
			tryscreen.screen.again.removeEventListener("click", closeScreen);
			tryscreen.screen.moreButton.removeEventListener("click", moregbutton);
		}
	}
	this.frame_167 = function() {
		this.stop();
		resetgame();
		this.parent.removeChild(this);
		startGame();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(48).call(this.frame_48).wait(21).call(this.frame_69).wait(7).call(this.frame_76).wait(91).call(this.frame_167).wait(1));

	// Layer 1
	this.screen = new lib.tryagain2();
	this.screen.name = "screen";
	this.screen.parent = this;
	this.screen.setTransform(321,278.4,1,1,0,0,0,152,128.4);
	this.screen.alpha = 0;
	this.screen._off = true;

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(48).to({_off:false},0).wait(1).to({regX:153.5,regY:95,x:322.5,y:237.15,alpha:0.065},0).wait(1).to({y:229.4,alpha:0.1297},0).wait(1).to({y:221.75,alpha:0.1937},0).wait(1).to({y:214.15,alpha:0.2568},0).wait(1).to({y:206.75,alpha:0.3187},0).wait(1).to({y:199.45,alpha:0.3792},0).wait(1).to({y:192.4,alpha:0.4379},0).wait(1).to({y:185.6,alpha:0.4948},0).wait(1).to({y:179,alpha:0.5497},0).wait(1).to({y:172.7,alpha:0.6023},0).wait(1).to({y:166.65,alpha:0.6525},0).wait(1).to({y:160.95,alpha:0.7003},0).wait(1).to({y:155.55,alpha:0.7453},0).wait(1).to({y:150.45,alpha:0.7877},0).wait(1).to({y:145.7,alpha:0.8272},0).wait(1).to({y:141.35,alpha:0.8637},0).wait(1).to({y:137.3,alpha:0.8972},0).wait(1).to({y:133.65,alpha:0.9277},0).wait(1).to({y:130.4,alpha:0.955},0).wait(1).to({y:127.5,alpha:0.9791},0).wait(1).to({regX:152,regY:128.4,x:321,y:158.4,alpha:1},0).to({y:172.4},7).wait(1).to({regX:153.5,regY:95,x:322.5,y:136.25},0).wait(1).to({y:133.1},0).wait(1).to({y:130},0).wait(1).to({y:127.4},0).wait(1).to({y:125.65},0).wait(1).to({regX:152,regY:128.4,x:321,y:158.4},0).wait(1).to({regX:153.5,regY:95,x:322.5,y:125.15,alpha:0.9985},0).wait(1).to({y:125.7,alpha:0.994},0).wait(1).to({y:126.6,alpha:0.9865},0).wait(1).to({y:127.85,alpha:0.976},0).wait(1).to({y:129.45,alpha:0.9626},0).wait(1).to({y:131.4,alpha:0.9463},0).wait(1).to({y:133.75,alpha:0.9271},0).wait(1).to({y:136.4,alpha:0.9049},0).wait(1).to({y:139.4,alpha:0.8799},0).wait(1).to({y:142.7,alpha:0.8521},0).wait(1).to({y:146.4,alpha:0.8215},0).wait(1).to({y:150.4,alpha:0.7881},0).wait(1).to({y:154.75,alpha:0.752},0).wait(1).to({y:159.4,alpha:0.7132},0).wait(1).to({y:164.35,alpha:0.6718},0).wait(1).to({y:169.65,alpha:0.6278},0).wait(1).to({y:175.2,alpha:0.5813},0).wait(1).to({y:181.1,alpha:0.5323},0).wait(1).to({y:187.25,alpha:0.481},0).wait(1).to({y:193.7,alpha:0.4275},0).wait(1).to({y:200.35,alpha:0.3717},0).wait(1).to({y:207.3,alpha:0.3139},0).wait(1).to({y:214.45,alpha:0.2542},0).wait(1).to({y:221.85,alpha:0.1928},0).wait(1).to({y:229.4,alpha:0.1298},0).wait(1).to({y:237.1,alpha:0.0654},0).wait(1).to({regX:152,regY:128.4,x:321,y:278.4,alpha:0},0).to({_off:true},20).wait(39));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,503.1,340.5);


(lib.timeover2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.stars = new lib.stars();
	this.stars.name = "stars";
	this.stars.parent = this;
	this.stars.setTransform(276.85,65.1,1.1429,1.1429,0,0,0,35.1,17.6);

	this.moreButton = new lib.morefinishbutton();
	this.moreButton.name = "moreButton";
	this.moreButton.parent = this;
	this.moreButton.setTransform(168.45,159.5,1,1,0,0,0,97.5,16);

	this.again = new lib.tryagainbutton();
	this.again.name = "again";
	this.again.parent = this;
	this.again.setTransform(295.95,159.5,1,1,0,0,0,97.5,16);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFCC66").s().p("AgIAvIAAgSIARAAIAAASgAgEAXIgFguIAAgXIATAAIAAAXIgFAug");
	this.shape.setTransform(55.725,16.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFCC66").s().p("AATAvIgNgVIgJgNQgDgDgDgCIgJgBIgEAAIAAAoIgTAAIAAhdIAoAAQAOABAHACQAGADAEAGQAEAHAAAHQAAALgGAHQgGAFgMADQAGADAEAEIALAQIALASgAgWgGIAOAAQAMAAAEgCQADgBACgCQACgDAAgFQAAgEgCgDQgDgCgFgCIgMAAIgPAAg");
	this.shape_1.setTransform(45.725,16.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFCC66").s().p("AgiAvIAAhdIBEAAIAAAQIgyAAIAAAVIAuAAIAAAPIguAAIAAAZIAzAAIAAAQg");
	this.shape_2.setTransform(36.425,16.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFCC66").s().p("AgJAvIghhdIAUAAIAXBFIAWhFIAUAAIghBdg");
	this.shape_3.setTransform(27.625,16.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFCC66").s().p("AggAjQgMgMAAgXQAAgMAEgKQADgIAGgFQAFgGAHgDQAJgDAKAAQAUAAANAMQAMANAAAWQAAAXgMAMQgMANgVAAQgUAAgMgNgAgSgXQgHAIAAAPQAAAPAIAJQAHAIAKAAQALAAAIgIQAHgIAAgQQAAgPgHgIQgHgIgMAAQgLAAgHAIg");
	this.shape_4.setTransform(18.275,16.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFCC66").s().p("AgiAvIAAhdIBEAAIAAAQIgyAAIAAAVIAuAAIAAAPIguAAIAAAZIAzAAIAAAQg");
	this.shape_5.setTransform(5.425,16.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFCC66").s().p("AAcAvIAAhJIgTBJIgRAAIgThJIAABJIgRAAIAAhdIAdAAIAPA/IARg/IAcAAIAABdg");
	this.shape_6.setTransform(-4.5,16.55);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFCC66").s().p("AgIAvIAAhdIARAAIAABdg");
	this.shape_7.setTransform(-11.675,16.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFCC66").s().p("AgIAvIAAhNIgcAAIAAgQIBJAAIAAAQIgcAAIAABNg");
	this.shape_8.setTransform(-17.475,16.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D9D9D9").s().p("AgHAGIADgLIAMAAIgDALg");
	this.shape_9.setTransform(120.075,75.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D9D9D9").s().p("AgNArQgDgCAAgFIABgKIAIgmIgJAAIACgJIAJAAIAEgQIAMgJIgFAZIALAAIgCAJIgLAAIgHAkIgBAJIABADIADABIAGgBIgBAJIgHABQgHAAgEgDg");
	this.shape_10.setTransform(117.425,71.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D9D9D9").s().p("AgaAeQgFgEAAgHIACgOIAIgnIAMAAIgJAqIgCAJQAAAEADACQACACAFAAQAEAAAFgCQAEgDADgDQADgEACgGIAEgMIAGgdIALAAIgOBDIgKAAIACgMQgLAOgNAAQgIgBgEgEg");
	this.shape_11.setTransform(111.725,72.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#D9D9D9").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_12.setTransform(104.275,72.875);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#D9D9D9").s().p("AgVAdQgIgFAAgNIAMgBQAAAFABADQACAEAEACQAEACAFAAQAHAAAEgDQAEgDAAgEQAAgDgDgCQgCgDgJgEIgLgFQgEgCgCgEQgCgDAAgFQAAgIAGgFQAGgGALAAQAMAAAHAGQAHAGAAAJIgLABQgBgGgEgEQgEgDgHAAQgFAAgDACQgEADAAADQAAAEADACQACACAHADQANAGAEACQAFAFAAAIQAAAFgDAFQgDAEgGADQgHADgHAAQgMAAgIgGg");
	this.shape_13.setTransform(93.8735,72.875);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#D9D9D9").s().p("AALAiIAJgpIABgKQAAgDgDgCQgCgCgEAAQgJAAgGAGQgHAHgDAOIgHAfIgLAAIAOhCIALAAIgDAMQAGgHAGgDQAGgDAFAAQAJgBAEAFQAFAEAAAIIgBAMIgJAng");
	this.shape_14.setTransform(86.75,72.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#D9D9D9").s().p("AgaAeQgFgEAAgHIACgOIAIgnIAMAAIgJAqIgCAJQAAAEADACQACACAFAAQAEAAAFgCQAEgDADgDQADgEACgGIAEgMIAGgdIALAAIgOBDIgKAAIACgMQgLAOgNAAQgIgBgEgEg");
	this.shape_15.setTransform(79.875,72.95);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#D9D9D9").s().p("AgYAiIAOhCIAKAAIgDAOQAEgIAFgDQAFgEAGAAQADAAAFACIgFALQgCgCgEAAQgGgBgGAIQgGAGgDAQIgHAbg");
	this.shape_16.setTransform(74.45,72.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_17.setTransform(64.425,72.875);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#D9D9D9").s().p("AAcAiIAKgrIABgIQAAgDgCgCQgCgCgEAAQgFAAgGADQgEADgEAGQgDAEgCAKIgHAgIgKAAIAKgsIAAgHQAAgDgBgCQgDgCgDAAQgFAAgFADQgFADgEAGQgEAGgCAJIgGAfIgMAAIAPhCIALAAIgCALQAGgHAFgCQAFgDAGAAQAFAAAFADQAEADABAGQAFgGAGgDQAFgDAHAAQAIAAAEAEQAEADABAIIgCAKIgJAqg");
	this.shape_18.setTransform(55.3,72.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#D9D9D9").s().p("AgOAuIANhCIALAAIgNBCgAABghIADgMIALAAIgCAMg");
	this.shape_19.setTransform(48.85,71.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#D9D9D9").s().p("AgNArQgDgCAAgFIABgKIAIgmIgJAAIACgJIAJAAIAEgQIAMgJIgFAZIALAAIgCAJIgLAAIgHAkIgBAJIABADIADABIAGgBIgBAJIgHABQgHAAgEgDg");
	this.shape_20.setTransform(45.775,71.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_21.setTransform(36.225,72.875);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#D9D9D9").s().p("AAKAuIAJgoIACgLQAAgDgDgCQgCgCgEAAQgHAAgFAEQgFADgDAFQgDAFgDAMIgFAdIgMAAIAThbIAMAAIgIAjQAGgGAFgCQAGgDAGAAQAIgBAEAFQAFAFAAAGIgCANIgIAng");
	this.shape_22.setTransform(28.85,71.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#D9D9D9").s().p("AgNArQgDgCAAgFIABgKIAIgmIgJAAIACgJIAJAAIAEgQIAMgJIgFAZIALAAIgCAJIgLAAIgHAkIgBAJIABADIADABIAGgBIgBAJIgHABQgHAAgEgDg");
	this.shape_23.setTransform(24.075,71.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_24.setTransform(14.525,72.875);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#D9D9D9").s().p("AgYAiIAOhCIAKAAIgDAOQAFgIAEgDQAFgEAFAAQAEAAAFACIgEALQgEgCgDAAQgGgBgGAIQgGAGgEAQIgFAbg");
	this.shape_25.setTransform(9.35,72.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#D9D9D9").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_26.setTransform(2.975,72.875);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#D9D9D9").s().p("AgXAvIANg5IgLAAIACgJIALAAIABgKIADgKQACgDADgCQAEgCAGAAIAMABIgCAKIgKgBQgCAAgCACQgCABgCAHIgBAHIANAAIgCAJIgNAAIgLA5g");
	this.shape_27.setTransform(-1.5,71.525);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_28.setTransform(-7.925,72.875);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#D9D9D9").s().p("AgLAsQgFgEgDgHIgCANIgLAAIAUhcIALAAIgHAhQAGgFADgCQAFgCAEAAQAKAAAGAHQAGAHABAMQAAAJgDAIQgCAHgEAFQgEAFgEADIgIAFIgIABQgGAAgFgDgAgDgIQgGAFgDAJQgDAHAAAFIAAACQAAAJAFAEQADAFAHAAQAEAAAGgEQAFgFADgJQADgIAAgIQABgIgFgEQgEgFgGAAQgGAAgEAFg");
	this.shape_29.setTransform(-15.25,71.675);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_30.setTransform(218.575,56.375);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#D9D9D9").s().p("AgWAcQgGgHAAgNQAAgKADgKQAFgLAIgGQAIgFAKAAQALAAAGAGQAHAGgBAKIgLABQAAgGgDgEQgEgEgGAAQgGAAgFAFQgGAEgCAJQgDAIAAAIQAAAJADAEQAFAEAFAAQAEAAAGgEQAFgEADgJIAMABQgFANgIAGQgIAGgJAAQgLAAgHgHg");
	this.shape_31.setTransform(212,56.375);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#D9D9D9").s().p("AgYAeQgHgGAAgIQAAgGADgEQADgFAEgBIAKgEIAOgBQALgBAFgCIABgHQAAgEgDgDQgEgDgIAAQgGAAgEADQgFAEgCAGIgLgBQADgLAHgFQAJgFAKAAQAMAAAIAGQAFAEAAAHIgBANIgEAQIgCANIABAJIgLAAIgBgJQgGAGgFACQgFACgHAAQgJAAgFgFgAAMABIgJABIgOACQgEACgCADQgCADAAADQAAAFAEADQADADAGAAQAGAAAEgDQAFgDAEgFQADgFABgKIgFABg");
	this.shape_32.setTransform(204.75,56.375);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#D9D9D9").s().p("AgiAwIAThdIALAAIgCAJQAGgGAEgCQAEgCAFgBQAKAAAGAHQAHAIAAAMQAAALgEAJQgEAIgFAFQgEAFgGADQgFACgFAAQgLAAgHgMIgIAlgAACgjQgDACgDAFQgDAEgDAIQgCAGAAAFIABAJQACAEAEADQADACAEABQAKAAAGgLQAGgLAAgMQAAgIgEgEQgEgFgGAAQgEAAgEACg");
	this.shape_33.setTransform(197.2,57.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#D9D9D9").s().p("AgVAdQgIgFAAgNIAMgBQAAAFABADQACAEAEACQAEACAFAAQAHAAAEgDQAEgDAAgEQAAgDgDgCQgCgDgJgEIgLgFQgEgCgCgEQgCgDAAgFQAAgIAGgFQAGgGALAAQAMAAAHAGQAHAGAAAJIgLABQgBgGgEgEQgEgDgHAAQgFAAgDACQgEADAAADQAAAEADACQACACAHADQANAGAEACQAFAFAAAIQAAAFgDAFQgDAEgGADQgHADgHAAQgMAAgIgGg");
	this.shape_34.setTransform(190.8235,56.375);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#D9D9D9").s().p("AgXAuQgFgCgDgEQgDgEAAgGIAAgDIAMABQAAAEABACIADADQADABAFAAQAKABAEgGQADgDADgNIABgFQgJAJgJAAQgKAAgHgHQgHgIAAgNQAAgLAGgJQAEgKAIgFQAHgFAHAAQAOAAAHAMIADgKIAKAAIgOA/QgCAMgDAGQgEAFgHADQgFAEgIAAQgIAAgHgCgAgGgkIgHAIQgDAEgBAGIgCAKQAAAHABACQACAFADADQAEACAEAAQAFAAAFgDQAGgEADgHQAEgJAAgHQAAgJgFgFQgFgEgGAAQgEAAgEABg");
	this.shape_35.setTransform(180.3,57.65);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#D9D9D9").s().p("AAKAjIAJgqIABgKQAAgDgCgCQgCgCgFAAQgIAAgGAHQgHAFgDAPIgGAgIgMAAIAOhDIAKAAIgCAMQAHgHAEgDQAGgEAHAAQAIABAEAEQAFAFAAAHIgCALIgIApg");
	this.shape_36.setTransform(172.85,56.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#D9D9D9").s().p("AgPAvIAPhDIAKAAIgNBDgAABghIADgMIAMAAIgEAMg");
	this.shape_37.setTransform(168.25,55.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#D9D9D9").s().p("AAKAvIgNgjIgOAMIgEAXIgMAAIAUhcIALAAIgMA4IAhgfIAPAAIgdAYIARArg");
	this.shape_38.setTransform(163.625,55.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#D9D9D9").s().p("AgYAjIAOhDIAKAAIgDAOQAFgIAEgDQAGgFAEAAQAEABAFACIgEALQgDgCgEgBQgGABgGAGQgGAHgDARIgGAbg");
	this.shape_39.setTransform(158.4,56.3);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#D9D9D9").s().p("AgZAeQgFgGAAgIQAAgGACgEQADgFAEgBIAKgEIAOgBQALgBAEgCIACgHQAAgEgDgDQgEgDgHAAQgHAAgEADQgFAEgCAGIgLgBQADgLAIgFQAIgFAKAAQAMAAAIAGQAFAEABAHIgCANIgEAQIgCANIABAJIgLAAIgBgJQgGAGgGACQgEACgHAAQgJAAgGgFgAAMABIgJABIgOACQgDACgDADQgCADAAADQAAAFADADQAEADAGAAQAFAAAFgDQAFgDAEgFQADgFABgKIgFABg");
	this.shape_40.setTransform(151.9,56.375);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#D9D9D9").s().p("AgjAwIAUhdIALAAIgCAJQAGgGAEgCQAEgCAFgBQAKAAAGAHQAHAIgBAMQABALgEAJQgEAIgFAFQgEAFgGADQgFACgFAAQgLAAgHgMIgIAlgAACgjQgDACgDAFQgEAEgCAIQgCAGAAAFIABAJQACAEAEADQAEACADABQAKAAAGgLQAGgLAAgMQAAgIgEgEQgEgFgGAAQgEAAgEACg");
	this.shape_41.setTransform(144.35,57.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#D9D9D9").s().p("AgcAoQgHgHAAgNQABgNAFgJQAEgKAIgFQAHgFAIAAQAMAAAGAMIAIgkIALAAIgTBcIgLAAIACgKQgJALgKAAQgKAAgGgHgAgJgLQgDACgEAEQgCAFgDAGQgCAGAAAGIABALQACAEADACQADADAFAAQAIAAAFgIQAJgLAAgQQAAgHgFgEQgEgFgFAAQgEAAgEACg");
	this.shape_42.setTransform(134.35,55.175);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_43.setTransform(126.625,56.375);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#D9D9D9").s().p("AAKAvIgNgjIgOAMIgEAXIgMAAIAUhcIALAAIgMA4IAhgfIAPAAIgdAYIARArg");
	this.shape_44.setTransform(120.175,55.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#D9D9D9").s().p("AgYAjIAOhDIAKAAIgDAOQAEgIAFgDQAGgFAFAAQADABAFACIgFALQgCgCgEgBQgGABgGAGQgGAHgDARIgHAbg");
	this.shape_45.setTransform(114.95,56.3);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#D9D9D9").s().p("AgYAeQgHgGAAgIQAAgGADgEQADgFAEgBIAKgEIAOgBQALgBAFgCIABgHQAAgEgDgDQgEgDgIAAQgGAAgEADQgFAEgCAGIgLgBQADgLAHgFQAJgFAKAAQAMAAAIAGQAFAEAAAHIgBANIgEAQIgCANIABAJIgLAAIgBgJQgGAGgFACQgFACgHAAQgJAAgFgFgAAMABIgJABIgOACQgEACgCADQgCADAAADQAAAFAEADQADADAGAAQAGAAAEgDQAFgDAEgFQADgFABgKIgFABg");
	this.shape_46.setTransform(108.45,56.375);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#D9D9D9").s().p("AAcAjIAKgsIABgIQAAgDgCgCQgCgCgEAAQgFAAgGADQgEADgEAGQgDAEgCAKIgHAhIgKAAIAKgtIAAgHQAAgDgBgCQgDgCgDAAQgFAAgFADQgFADgEAGQgEAGgCAIIgGAhIgMAAIAPhDIALAAIgCALQAGgHAFgCQAFgEAGAAQAFABAFADQAEADABAGQAFgGAGgDQAFgEAHAAQAIAAAEAFQAEAEABAHIgCAKIgJArg");
	this.shape_47.setTransform(99.4,56.3);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#D9D9D9").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_48.setTransform(86.875,56.375);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#D9D9D9").s().p("AgNAsQgDgEAAgDIABgLIAIgmIgJAAIACgJIAJAAIAEgQIAMgIIgFAYIALAAIgCAJIgLAAIgHAkIgBAIIABAEIADABIAGgBIgBAKIgHAAQgHAAgEgCg");
	this.shape_49.setTransform(81.925,55.2);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#D9D9D9").s().p("AAKAjIAJgqIACgKQgBgDgCgCQgCgCgEAAQgJAAgGAHQgHAFgDAPIgHAgIgLAAIAOhDIAKAAIgCAMQAGgHAGgDQAFgEAHAAQAIABAEAEQAFAFAAAHIgBALIgJApg");
	this.shape_50.setTransform(75.85,56.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#D9D9D9").s().p("AgPAvIAOhDIALAAIgNBDgAABghIADgMIAMAAIgDAMg");
	this.shape_51.setTransform(71.25,55.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#D9D9D9").s().p("AgYAjIAOhDIAKAAIgDAOQAEgIAGgDQAEgFAGAAQADABAFACIgFALQgDgCgDgBQgGABgHAGQgFAHgDARIgHAbg");
	this.shape_52.setTransform(64.3,56.3);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_53.setTransform(57.875,56.375);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#D9D9D9").s().p("AgOAvIAShcIALAAIgSBcg");
	this.shape_54.setTransform(53.1,55.1);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#D9D9D9").s().p("AgPAvIAPhDIAKAAIgNBDgAABghIADgMIAMAAIgEAMg");
	this.shape_55.setTransform(50.25,55.1);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#D9D9D9").s().p("AgYAeQgHgGAAgIQAAgGAEgEQACgFAEgBIAKgEIAOgBQALgBAFgCIABgHQAAgEgDgDQgEgDgIAAQgGAAgFADQgEAEgCAGIgMgBQAEgLAHgFQAJgFAKAAQANAAAHAGQAGAEgBAHIgBANIgEAQIgCANIACAJIgMAAIgBgJQgGAGgFACQgFACgGAAQgKAAgFgFgAAMABIgJABIgOACQgEACgCADQgCADAAADQAAAFAEADQADADAGAAQAFAAAFgDQAFgDADgFQADgFACgKIgFABg");
	this.shape_56.setTransform(44.75,56.375);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#D9D9D9").s().p("AgYAjIAOhDIAKAAIgDAOQAFgIAFgDQAFgFAFAAQADABAFACIgFALQgDgCgDgBQgGABgHAGQgFAHgEARIgGAbg");
	this.shape_57.setTransform(39.65,56.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#D9D9D9").s().p("AgNAsQgDgEAAgDIABgLIAIgmIgJAAIACgJIAJAAIAEgQIAMgIIgFAYIALAAIgCAJIgLAAIgHAkIgBAIIABAEIADABIAGgBIgBAKIgHAAQgHAAgEgCg");
	this.shape_58.setTransform(35.575,55.2);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#D9D9D9").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_59.setTransform(26.025,56.375);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#D9D9D9").s().p("AALAvIAIgqIACgKQAAgDgCgCQgDgCgEAAQgGAAgGAEQgFACgDAGQgDAFgDANIgGAdIgLAAIAThcIAMAAIgHAjQAFgGAFgCQAGgEAFAAQAJABAFAEQAEAFAAAHIgCALIgIApg");
	this.shape_60.setTransform(18.65,55.1);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#D9D9D9").s().p("AgNAsQgDgEAAgDIABgLIAIgmIgJAAIACgJIAJAAIAEgQIAMgIIgFAYIALAAIgCAJIgLAAIgHAkIgBAIIABAEIADABIAGgBIgBAKIgHAAQgHAAgEgCg");
	this.shape_61.setTransform(13.875,55.2);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#D9D9D9").s().p("AAKAvIgNgjIgOAMIgEAXIgMAAIAUhcIALAAIgMA4IAhgfIAPAAIgdAYIARArg");
	this.shape_62.setTransform(5.125,55.1);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#D9D9D9").s().p("AgYAjIAOhDIAKAAIgDAOQAFgIAEgDQAFgFAFAAQAEABAFACIgEALQgEgCgDgBQgGABgGAGQgGAHgEARIgFAbg");
	this.shape_63.setTransform(-0.1,56.3);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#D9D9D9").s().p("AgZAeQgFgGAAgIQAAgGACgEQADgFAEgBIALgEIANgBQALgBAEgCIACgHQAAgEgDgDQgEgDgHAAQgHAAgFADQgEAEgCAGIgMgBQAEgLAIgFQAHgFALAAQAMAAAIAGQAGAEAAAHIgCANIgEAQIgBANIAAAJIgLAAIgBgJQgGAGgGACQgEACgHAAQgJAAgGgFgAAMABIgKABIgMACQgEACgDADQgCADAAADQAAAFADADQAEADAGAAQAFAAAFgDQAFgDAEgFQACgFACgKIgFABg");
	this.shape_64.setTransform(-6.6,56.375);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#D9D9D9").s().p("AgpAvIAThcIAmAAQAKAAAFACQAFACAEAGQACAGAAAGQAAAGgBAGQgDAGgEAEQgDACgEACIgIADQgIADgKAAIgWAAIgIAmgAgTgBIATAAQAMAAAGgDQAGgCADgFQAEgGAAgGQAAgEgDgDQgBgDgDgBQgDgBgKAAIgWAAg");
	this.shape_65.setTransform(-14.15,55.1);

	this.closeButton = new lib.closeoptions();
	this.closeButton.name = "closeButton";
	this.closeButton.parent = this;
	this.closeButton.setTransform(306.45,13.25,0.6667,0.6664,0,0,0,10.1,9.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.closeButton},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.again},{t:this.moreButton},{t:this.stars}]}).wait(1));

	// Layer 1
	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#CCCCCC").ss(0.2,1,1).p("A72AAMA3tAAA");
	this.shape_66.setTransform(151.75,35.5);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#CCCCCC").ss(1,1,1,3,true).p("A72umMA3tAAAIAAFjIAAXqMg3tAAAIAA3qg");
	this.shape_67.setTransform(151.75,93.475);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#3B3B3B").s().p("A71L1IAA3pMA3sAAAIAAXpg");
	this.shape_68.setTransform(151.75,111.225);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#333333").s().p("A71CxIAAliMA3sAAAIAAFig");
	this.shape_69.setTransform(151.75,17.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66}]}).wait(1));

	// Layer 3
	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#262626").s().p("A77OaIAA8zMA33AAAIAAczg");
	this.shape_70.setTransform(155.3,98.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_70).wait(1));

}).prototype = getMCSymbolPrototype(lib.timeover2, new cjs.Rectangle(-27.5,-1,361.6,191.5), null);


(lib.timeover = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_48 = function() {
		if (backgroundSound) backgroundSound.stop();
	}
	this.frame_69 = function() {
		backgroundSound = createjs.Sound.play("sakumamuzons",{interrupt: createjs.Sound.INTERRUPT_EARLY, loop:-1});
	}
	this.frame_76 = function() {
		var tryscreen = this;
		tryscreen.stop();
		
		tryscreen.screen.closeButton.addEventListener("click", closeScreen);
		tryscreen.screen.again.addEventListener("click", closeScreen);
		tryscreen.screen.moreButton.addEventListener("click", moregbutton);
		
		function closeScreen(event) {
			
			removeListeners();
			tryscreen.gotoAndPlay(77);
			canvas.style.pointerEvents = "none";
		}
		
		function removeListeners() {
			tryscreen.screen.closeButton.removeEventListener("click", closeScreen);
			tryscreen.screen.again.removeEventListener("click", closeScreen);
			tryscreen.screen.moreButton.removeEventListener("click", moregbutton);
		}
		function moregbutton()
		{
		var gotourl;
			if(mobile) {
			gotourl = "https://m.1000webgames.com/?utm_campaign=truck_space_2&utm_medium=moregames_starplevel&utm_source=" + ref;	
			} else {
			gotourl = "https://1000webgames.com/?utm_campaign=truck_space_2&utm_medium=moregames_starplevel&utm_source=" + ref;
			}
			window.open(gotourl, "_blank");	
		}
	}
	this.frame_167 = function() {
		this.stop();
		resetgame();
		
		this.parent.removeChild(this);
		startGame();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(48).call(this.frame_48).wait(21).call(this.frame_69).wait(7).call(this.frame_76).wait(91).call(this.frame_167).wait(1));

	// Layer 1
	this.screen = new lib.timeover2();
	this.screen.name = "screen";
	this.screen.parent = this;
	this.screen.setTransform(321,278.4,1,1,0,0,0,152,128.4);
	this.screen.alpha = 0;
	this.screen._off = true;

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(48).to({_off:false},0).wait(1).to({regX:153.5,regY:95,x:322.5,y:237.15,alpha:0.065},0).wait(1).to({y:229.4,alpha:0.1297},0).wait(1).to({y:221.75,alpha:0.1937},0).wait(1).to({y:214.15,alpha:0.2568},0).wait(1).to({y:206.75,alpha:0.3187},0).wait(1).to({y:199.45,alpha:0.3792},0).wait(1).to({y:192.4,alpha:0.4379},0).wait(1).to({y:185.6,alpha:0.4948},0).wait(1).to({y:179,alpha:0.5497},0).wait(1).to({y:172.7,alpha:0.6023},0).wait(1).to({y:166.65,alpha:0.6525},0).wait(1).to({y:160.95,alpha:0.7003},0).wait(1).to({y:155.55,alpha:0.7453},0).wait(1).to({y:150.45,alpha:0.7877},0).wait(1).to({y:145.7,alpha:0.8272},0).wait(1).to({y:141.35,alpha:0.8637},0).wait(1).to({y:137.3,alpha:0.8972},0).wait(1).to({y:133.65,alpha:0.9277},0).wait(1).to({y:130.4,alpha:0.955},0).wait(1).to({y:127.5,alpha:0.9791},0).wait(1).to({regX:152,regY:128.4,x:321,y:158.4,alpha:1},0).to({y:172.4},7).wait(1).to({regX:153.5,regY:95,x:322.5,y:136.25},0).wait(1).to({y:133.1},0).wait(1).to({y:130},0).wait(1).to({y:127.4},0).wait(1).to({y:125.65},0).wait(1).to({regX:152,regY:128.4,x:321,y:158.4},0).wait(1).to({regX:153.5,regY:95,x:322.5,y:125.15,alpha:0.9985},0).wait(1).to({y:125.7,alpha:0.994},0).wait(1).to({y:126.6,alpha:0.9865},0).wait(1).to({y:127.85,alpha:0.976},0).wait(1).to({y:129.45,alpha:0.9626},0).wait(1).to({y:131.4,alpha:0.9463},0).wait(1).to({y:133.75,alpha:0.9271},0).wait(1).to({y:136.4,alpha:0.9049},0).wait(1).to({y:139.4,alpha:0.8799},0).wait(1).to({y:142.7,alpha:0.8521},0).wait(1).to({y:146.4,alpha:0.8215},0).wait(1).to({y:150.4,alpha:0.7881},0).wait(1).to({y:154.75,alpha:0.752},0).wait(1).to({y:159.4,alpha:0.7132},0).wait(1).to({y:164.35,alpha:0.6718},0).wait(1).to({y:169.65,alpha:0.6278},0).wait(1).to({y:175.2,alpha:0.5813},0).wait(1).to({y:181.1,alpha:0.5323},0).wait(1).to({y:187.25,alpha:0.481},0).wait(1).to({y:193.7,alpha:0.4275},0).wait(1).to({y:200.35,alpha:0.3717},0).wait(1).to({y:207.3,alpha:0.3139},0).wait(1).to({y:214.45,alpha:0.2542},0).wait(1).to({y:221.85,alpha:0.1928},0).wait(1).to({y:229.4,alpha:0.1298},0).wait(1).to({y:237.1,alpha:0.0654},0).wait(1).to({regX:152,regY:128.4,x:321,y:278.4,alpha:0},0).to({_off:true},20).wait(39));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,503.1,340.5);


(lib.settings1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var po = this;
		po.stop();
		po.poga.addEventListener("click", settingsPoga);
		
		function settingsPoga(event) {
			pause = true;
			po.poga.removeEventListener("click", settingsPoga);
			po.gotoAndStop(1);
			if(tryAgainScreen) tryAgainScreen.visible = false;
		}
	}
	this.frame_1 = function() {
		var set = this;
		set.stop();
		doc = window.document;
		
		setTimeout(stopit,0); // savadak muviklipi spele atrak neka lasa javascript
		
		function stopit(){
		if(doc.fullscreenElement || doc.mozFullScreenElement || doc.webkitFullscreenElement || doc.msFullscreenElement) {
		set.fulls.gotoAndStop(1);
		} else {
			set.fulls.gotoAndStop(0);
			}
				if (skana) {
				set.audio.gotoAndStop(0);
			} else {
				set.audio.gotoAndStop(1);
			}
		}
		
		set.closeButton.addEventListener("click", closeSettings);
		set.fulls.addEventListener("click", fullScreen);
		set.mainm.addEventListener("click", mainMenu);
		set.audio.addEventListener("click", setAudio);
		set.instruct.addEventListener("click", instructions);
		set.credits.addEventListener("click", creditScreen);
		set.achB.addEventListener("click", achScreen);
		
		function closeSettings(event) {
			pause = false;
			removeListeners();
			set.gotoAndStop(0);
			if(tryAgainScreen) tryAgainScreen.visible = true;
			if(isDriving) canvas.style.pointerEvents = "none";
		}
		
		function mainMenu(event) {
			removeListeners();
			set.gotoAndStop(0);
			if(isDriving) {
				isDriving = false;
				resetgame();
			}
			if(tryAgainScreen) exportRoot.removeChild(tryAgainScreen);
			exportRoot.gotoAndStop("first");
			exportRoot.pButton.poga.visible = true;
		}
		
		function achScreen(event) {
			removeListeners();
			set.gotoAndStop(0);
			if(isDriving) {
				isDriving = false;
				resetgame();
			}	
			if(tryAgainScreen) exportRoot.removeChild(tryAgainScreen);
			exportRoot.gotoAndStop(4);
			exportRoot.pButton.poga.visible = true;
		}
		
		function setAudio(event) {
		
			if (skana) {
				skana = false;
				set.audio.gotoAndStop(1);
				createjs.Sound.muted = true;
			} else {
				skana = true;
				set.audio.gotoAndStop(0);
				createjs.Sound.muted = false;
			}
			
		}
		
		function instructions(event) {
		
			removeListeners();
			set.gotoAndStop(2);
		}
		
		function creditScreen(event) {
		
			removeListeners();
			set.gotoAndStop(3);
		}
		
		function fullScreen(event) {
		var docEl = doc.documentElement;
		
		var requestFullScreen = docEl.requestFullscreen || docEl.mozRequestFullScreen || docEl.webkitRequestFullScreen || docEl.msRequestFullscreen;
		var cancelFullScreen = doc.exitFullscreen || doc.mozCancelFullScreen || doc.webkitExitFullscreen || doc.msExitFullscreen;
		
		  if(!doc.fullscreenElement && !doc.mozFullScreenElement && !doc.webkitFullscreenElement && !doc.msFullscreenElement) {
		    requestFullScreen.call(docEl);
			  set.fulls.gotoAndStop(1);
		  }
		  else {
		    cancelFullScreen.call(doc);
			  set.fulls.gotoAndStop(0);
		  }
		
		}
		
		
		
		function removeListeners() {
			set.closeButton.removeEventListener("click", closeSettings);
			set.fulls.removeEventListener("click", fullScreen);
			set.mainm.removeEventListener("click", mainMenu);
			set.audio.removeEventListener("click", setAudio);
			set.instruct.removeEventListener("click", instructions);
			set.credits.removeEventListener("click", creditScreen);
			set.achB.removeEventListener("click", achScreen);
		}
	}
	this.frame_2 = function() {
		var inf = this;
		inf.stop();
		
		inf.closeButton.addEventListener("click", closeInfo);
		
		function closeInfo(event) {
			inf.closeButton.removeEventListener("click", closeInfo);
			inf.gotoAndStop(1);
		}
	}
	this.frame_3 = function() {
		var cr = this;
		cr.stop();
		
		cr.closeButton.addEventListener("click", closeInfo);
		cr.incom.addEventListener("click", creditOut);
		cr.incom2.addEventListener("click", creditOut2);
		
		function closeInfo(event) {
			cr.closeButton.removeEventListener("click", closeInfo);
			cr.incom.removeEventListener("click", creditOut);
			cr.incom2.removeEventListener("click", creditOut2);
			cr.gotoAndStop(1);
		}
		
		function creditOut(event) {
			
			window.open("https://filmmusic.io/song/5181-street-trap", "_blank");
		}
		function creditOut2(event) {
			
			window.open("https://filmmusic.io/song/366-melo-rock-8", "_blank");
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1));

	// Layer 2
	this.poga = new lib.openoptions();
	this.poga.name = "poga";
	this.poga.parent = this;
	this.poga.setTransform(590.9,25.95,1,1,0,0,0,1.3,290.2);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgXAdIAAg5IAVAAQAGAAAEACQAFABADAEQAEAEACAFQACAGAAAHQAAAHgCAFQgCAGgEAEQgDADgFACIgKABgAgLATIAIAAIAGAAIAEgDQACgCABgDQACgEAAgHQAAgFgCgEQgBgEgCgCQgCgCgDAAIgJgBIgEAAg");
	this.shape.setTransform(147.85,260.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgPAZQgGgGgBgJIALgBQABAGADACQADADAEAAQAGAAADgCQADgDAAgDQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAgBAAIgEgDIgIgDQgJgCgEgCQgFgFAAgHQAAgEACgEQADgEAEgBQAFgCAGAAQAKgBAGAFQAFAEABAJIgMAAQgBgEgCgCQgDgCgEAAQgFAAgCACQgBAAAAABQAAAAgBAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQADACAHACIANAEQAEACACACQACAFAAAFQAAAEgDAFQgCAEgFACQgFACgIAAQgKAAgFgEg");
	this.shape_1.setTransform(131.425,260.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#333333").s().p("AAQAdIgFgNIgWAAIgEANIgNAAIAXg5IALAAIAXA5gAgHAGIAOAAIgHgUg");
	this.shape_2.setTransform(115.325,260.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AALAdIgLgqIgKAqIgNAAIgNg5IALAAIAIAnIALgnIANAAIAKAnIAJgnIALAAIgNA5g");
	this.shape_3.setTransform(131,244.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AgWBXIATAAIAAgrIAIAAIAAArIATAAIgYAhgAClBXIgrAAIAAgKIArAAIAAgSIAhAWIghAZgAjFBRIAhgWIAAASIAsAAIAAAKIgsAAIAAATgAgDgrIAAgrIgTAAIAWghIAYAhIgTAAIAAArg");
	this.shape_4.setTransform(202.2,252.375);

	this.incom2 = new lib.black();
	this.incom2.name = "incom2";
	this.incom2.parent = this;
	this.incom2.setTransform(234.8,92.65,0.2386,0.0389,0,0,0,12.2,20.6);
	this.incom2.alpha = 0.0195;
	this.incom2.visible = false;

	this.incom = new lib.black();
	this.incom.name = "incom";
	this.incom.parent = this;
	this.incom.setTransform(263.1,84.05,0.2362,0.0276,0,0,0,15.7,47);
	this.incom.alpha = 0.0195;
	this.incom.visible = false;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.poga}]}).to({state:[]},1).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.incom},{t:this.incom2}]},1).wait(1));

	// pogas
	this.achB = new lib.achbutton();
	this.achB.name = "achB";
	this.achB.parent = this;
	this.achB.setTransform(321.5,302,1,1,0,0,0,97.5,16);

	this.credits = new lib.creditsbutton();
	this.credits.name = "credits";
	this.credits.parent = this;
	this.credits.setTransform(321.5,261,1,1,0,0,0,97.5,16);

	this.instruct = new lib.instructionsbutton();
	this.instruct.name = "instruct";
	this.instruct.parent = this;
	this.instruct.setTransform(321.5,220,1,1,0,0,0,97.5,16);

	this.audio = new lib.audiobutton();
	this.audio.name = "audio";
	this.audio.parent = this;
	this.audio.setTransform(321.5,179,1,1,0,0,0,97.5,16);

	this.mainm = new lib.mainmenubutton();
	this.mainm.name = "mainm";
	this.mainm.parent = this;
	this.mainm.setTransform(321.5,138,1,1,0,0,0,97.5,16);

	this.fulls = new lib.fullscreenButton();
	this.fulls.name = "fulls";
	this.fulls.parent = this;
	this.fulls.setTransform(321.5,97,1,1,0,0,0,97.5,16);

	this.closeButton = new lib.closeoptions();
	this.closeButton.name = "closeButton";
	this.closeButton.parent = this;
	this.closeButton.setTransform(415.35,47.3,0.6667,0.6664,0,0,0,10.1,9.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D9D9D9").s().p("AgaAoQgJgIgCgQIATgBQABAJAFAEQAFAEAIABQAJAAAFgFQAEgDAAgGQAAgDgCgCQgCgDgFgBIgNgEQgQgEgGgEQgJgIAAgLQAAgHAFgHQAEgFAHgEQAIgDAKAAQARAAAJAIQAJAHAAANIgSABQgCgIgEgDQgDgCgIAAQgIgBgEAEQgEACAAAEQAAADAEACQADADAMAEQAOACAHAEQAHADADAGQAEAGAAAIQAAAJgEAGQgFAIgIADQgJADgMAAQgQAAgKgIg");
	this.shape_5.setTransform(266.9,51.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D9D9D9").s().p("AASAuIgkg7IAAA7IgSAAIAAhcIASAAIAlA9IAAg9IASAAIAABcg");
	this.shape_6.setTransform(257.9,51.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D9D9D9").s().p("AggAjQgMgMAAgXQAAgNAEgJQADgIAGgFQAFgFAHgEQAJgDAKAAQAUAAANAMQAMANAAAWQAAAWgMANQgMANgVAAQgUAAgMgNgAgSgXQgHAIAAAPQAAAQAIAIQAHAIAKAAQALAAAIgIQAHgIAAgQQAAgPgHgIQgHgIgMAAQgLAAgHAIg");
	this.shape_7.setTransform(248.225,51.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D9D9D9").s().p("AgIAuIAAhcIARAAIAABcg");
	this.shape_8.setTransform(241.375,51.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D9D9D9").s().p("AgIAuIAAhMIgcAAIAAgQIBJAAIAAAQIgcAAIAABMg");
	this.shape_9.setTransform(235.575,51.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D9D9D9").s().p("AgiAuIAAhcIAdAAQARABAFABQAIACAFAHQAFAHABALQAAAIgEAHQgDAEgEAEQgFADgFABQgHACgMAAIgMAAIAAAigAgQgDIALAAQAJgBAFgBQADgCACgDQACgCABgFQgBgFgDgDQgDgEgEAAIgMgBIgKAAg");
	this.shape_10.setTransform(227.45,51.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D9D9D9").s().p("AggAjQgMgMAAgXQAAgNAEgJQADgIAGgFQAFgFAHgEQAJgDAKAAQAUAAANAMQAMANAAAWQAAAWgMANQgMANgVAAQgUAAgMgNgAgSgXQgHAIAAAPQAAAQAIAIQAHAIAKAAQALAAAIgIQAHgIAAgQQAAgPgHgIQgHgIgMAAQgLAAgHAIg");
	this.shape_11.setTransform(217.925,51.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F1E8DE").s().p("AgFAFIACgJIAJAAIgCAJg");
	this.shape_12.setTransform(497.15,261.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#F1E8DE").s().p("AgSAbIAKgzIAIAAIgCAKQADgGAEgDQAEgCAEAAIAGACIgDAIIgFgCQgFAAgFAFQgEAFgDAMIgEAWg");
	this.shape_13.setTransform(495.225,259.75);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#F1E8DE").s().p("AgSAXQgFgFAAgGQAAgEACgDQACgEADgBIAIgDIALgBQAIAAADgCIABgFQAAgDgCgDQgDgCgGAAQgFAAgDACQgEADgBAEIgJAAQACgIAHgEQAGgEAHAAQAKAAAGAFQAEADAAAGIgBAJIgDAMIgBAKIABAHIgJAAIgBgHIgJAHIgIABQgHAAgEgEgAAJABIgHAAIgKADQgDABgCACQgCACAAADQAAADADADQADACAEAAQAFAAADgCQAEgDADgEQACgDABgIIgEABg");
	this.shape_14.setTransform(490.25,259.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#F1E8DE").s().p("AgQAWQgGgGAAgJQAAgIAEgJQADgIAGgDQAHgFAHAAQAIAAAFAFQAFAEAAAIIgJAAQAAgEgDgDQgDgDgEAAQgEAAgEADQgEAEgCAHQgDAFAAAHQAAAGADAEQADADAEAAQAEAAAEgDQAEgDACgHIAJABQgEAJgGAGQgGAEgHAAQgIAAgFgFg");
	this.shape_15.setTransform(485.225,259.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#F1E8DE").s().p("AgNAZQgFgDgCgFQgDgFAAgHQAAgIAEgHQAEgJAHgDQAFgEAHAAQAJAAAFAGQAGAFAAALIAAAGIgmAAIAAADQAAAIAEADQADAEAFAAQADAAAFgDQAEgDACgGIAJABQgCAHgHAGQgGAFgIAAQgGAAgFgCgAgGgPQgEADgDAJIAdAAIAAgDQAAgGgEgEQgDgDgFAAQgFAAgFAEg");
	this.shape_16.setTransform(476.95,259.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#F1E8DE").s().p("AAIAkIAGggIACgHQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAgBgBAAQgCgCgDAAQgFAAgEADQgDACgDAEQgCAEgCAJIgFAXIgJAAIAPhHIAJAAIgGAcQAFgFADgCQAFgCAEAAQAHAAADADQAEAEAAAFIgCAJIgGAfg");
	this.shape_17.setTransform(471.325,258.825);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#F1E8DE").s().p("AgKAhQgCgCAAgDIABgIIAGgdIgHAAIACgHIAHAAIADgNIAJgGIgEATIAIAAIgBAHIgJAAIgFAbIgBAHIABACQAAAAABABQAAAAAAAAQABAAAAAAQAAAAAAAAIAFAAIgBAHIgFABQgGAAgDgDg");
	this.shape_18.setTransform(467.575,258.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#F1E8DE").s().p("AgNAZQgFgDgCgFQgDgFAAgHQAAgIAEgHQAEgJAGgDQAHgEAGAAQAJAAAFAGQAGAFAAALIAAAGIglAAIgBADQAAAIADADQAEAEAEAAQAEAAAEgDQAFgDADgGIAIABQgCAHgGAGQgHAFgJAAQgFAAgFgCgAgFgPQgFADgCAJIAcAAIAAgDQAAgGgDgEQgEgDgFAAQgEAAgFAEg");
	this.shape_19.setTransform(460.25,259.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#F1E8DE").s().p("AgPAaIgIgzIAIAAIAFAbIACAQIAGgMIARgfIAJAAIgdAzg");
	this.shape_20.setTransform(455.55,259.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#F1E8DE").s().p("AgLAkIALgzIAIAAIgKAzgAABgZIACgKIAJAAIgCAKg");
	this.shape_21.setTransform(451.65,258.825);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#F1E8DE").s().p("AgSAbIAKgzIAIAAIgCAKQADgGAEgDQAEgCAEAAIAGACIgDAIIgFgCQgFAAgFAFQgEAFgDAMIgEAWg");
	this.shape_22.setTransform(449.075,259.75);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#F1E8DE").s().p("AgWAfQgEgFAAgLQAAgJADgHQAEgIAGgEQAGgEAGAAQAIAAAFAKIAGgcIAJAAIgPBGIgIAAIACgHQgHAIgIAAQgIAAgFgFgAgGgIQgDABgDAEQgCADgCAEQgCAGAAAEIABAIQABADADACQADACADAAQAGAAAEgGQAHgIAAgMQAAgGgEgDQgDgEgEAAQgDAAgCACg");
	this.shape_23.setTransform(444.525,258.875);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#F1E8DE").s().p("AgNAZQgFgDgDgFQgCgFAAgFQAAgPAJgKQAGgIAMAAQAJAAAGAGQAFAGAAAKQAAAHgDAIQgDAIgIAEQgGAEgGAAQgHAAgEgCgAgDgRIgHAGIgDAJIgCAIQAAAHAEADQADAEAGAAIAFgBIAEgDIAFgGIADgGIABgIQAAgHgEgFQgDgDgFAAQgEAAgDACg");
	this.shape_24.setTransform(435.85,259.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#F1E8DE").s().p("AgKAhQgCgCAAgDIABgIIAGgdIgHAAIACgHIAHAAIADgNIAJgGIgEATIAIAAIgBAHIgJAAIgFAbIgBAHIABACQAAAAABABQAAAAAAAAQABAAAAAAQAAAAAAAAIAFAAIgBAHIgFABQgGAAgDgDg");
	this.shape_25.setTransform(431.975,258.925);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#F1E8DE").s().p("AgQAWQgGgDAAgKIAJgBIABAGQABADAEACQADABAEAAQAEABADgDQAEgDAAgDQAAAAgBgBQAAAAAAgBQAAAAAAgBQgBgBAAAAQgCgCgHgDIgIgDQgDgCgCgDQgCgDABgDQAAgGAEgFQAFgEAIAAQAKAAAFAEQAFAFAAAIIgJAAQABgEgEgDQgDgDgFAAQgEAAgDACQgDACABACQAAABAAABQAAAAAAABQAAAAABABQAAAAABABIAHADQAKAFACABQAEAFABAFQgBAEgCAEQgCAEgFACQgFACgGAAQgIAAgHgFg");
	this.shape_26.setTransform(528.4,248.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#F1E8DE").s().p("AAIAaIAHgfIABgHQAAgBAAgBQgBAAAAgBQAAAAAAgBQgBAAAAgBQgCgCgDAAQgHAAgEAGQgGAFgCALIgFAXIgJAAIALgzIAIAAIgCAJQAFgFAEgCQAEgDAFAAQAGAAAEAEQAEADAAAGIgCAJIgGAeg");
	this.shape_27.setTransform(522.975,248.65);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#F1E8DE").s().p("AgOAZQgFgDgCgEQgDgGAAgFQABgPAIgKQAIgIAKAAQAKAAAGAGQAFAFABAKQgBAJgDAHQgDAIgIAEQgGAEgGAAQgHAAgFgCgAgDgRIgGAFIgFAJIgBAIQAAAIAEAEQADADAGAAIAEgBIAGgDIADgFIAEgHIABgJQAAgGgEgEQgDgEgGAAQgDAAgDACg");
	this.shape_28.setTransform(517.55,248.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#F1E8DE").s().p("AgKAhQgCgCAAgDIABgIIAGgdIgHAAIACgHIAHAAIADgNIAJgGIgEATIAIAAIgBAHIgJAAIgFAbIgBAHIABACQAAABABAAQAAAAAAAAQABAAAAAAQAAAAAAAAIAFAAIgBAHIgFABQgGAAgDgDg");
	this.shape_29.setTransform(513.675,247.825);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#F1E8DE").s().p("AgKAhQgCgCAAgDIABgIIAGgdIgHAAIACgHIAHAAIADgNIAJgGIgEATIAIAAIgBAHIgJAAIgFAbIgBAHIABACQAAABABAAQAAAAAAAAQABAAAAAAQAAAAAAAAIAFAAIgBAHIgFABQgGAAgDgDg");
	this.shape_30.setTransform(510.875,247.825);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#F1E8DE").s().p("AgUAYQgEgEAAgFIACgLIAGgeIAJAAIgHAhIgBAGQAAADACACQACACADAAQAEgBADgCQADgBACgDIAEgHQACgDABgGIAFgXIAJAAIgLAzIgIAAIABgJQgIAKgKAAQgGAAgDgCg");
	this.shape_31.setTransform(506.575,248.75);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#F1E8DE").s().p("AgJAiQgDgDgCgGIgDAKIgHAAIAPhGIAIAAIgEAZQAEgEACgBIAHgCQAHAAAFAGQAFAFAAAJQAAAHgCAGQgCAGgDAEIgFAGIgHADIgGABQgFAAgEgCgAgDgGQgDAEgDAGIgCAKIAAACQAAAGADAEQADADAFAAQADAAAEgDQAFgDACgHQADgHgBgGQABgFgEgEQgDgEgFAAQgEAAgEAEg");
	this.shape_32.setTransform(500.75,247.775);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#F1E8DE").s().p("AAIAaIAHgfIABgHQAAgBAAgBQgBAAAAgBQAAAAAAgBQgBAAAAgBQgCgCgDAAQgHAAgEAGQgGAFgCALIgFAXIgJAAIALgzIAIAAIgCAJQAFgFAEgCQAEgDAFAAQAGAAAEAEQAEADAAAGIgCAJIgGAeg");
	this.shape_33.setTransform(492.375,248.65);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#F1E8DE").s().p("AgNAZQgFgDgDgFQgCgGAAgGQAAgIAEgHQAEgJAGgDQAHgEAGAAQAJAAAGAFQAFAGAAAKIgBAHIgkAAIgBADQAAAHADAEQAEAEAEAAQAEAAAEgDQAFgDADgFIAIABQgCAFgGAGQgHAGgJAAQgFAAgFgCgAgFgPQgFAEgDAHIAdAAIAAgCQAAgGgDgDQgEgEgFAAQgFAAgEAEg");
	this.shape_34.setTransform(486.9,248.7);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#F1E8DE").s().p("AgNAZQgFgDgDgFQgCgGAAgGQAAgIAEgHQAEgJAHgDQAFgEAHAAQAJAAAGAFQAFAGAAAKIgBAHIglAAIAAADQAAAHAEAEQADAEAEAAQAEAAAEgDQAFgDACgFIAJABQgCAFgHAGQgGAGgJAAQgFAAgFgCgAgGgPQgEAEgDAHIAdAAIAAgCQAAgGgEgDQgDgEgFAAQgFAAgFAEg");
	this.shape_35.setTransform(481.35,248.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#F1E8DE").s().p("AgSAaIAKgzIAIAAIgCALQADgGAEgCQAEgEAEAAIAGADIgDAHIgFgBQgFAAgFAFQgEAGgDAMIgEAUg");
	this.shape_36.setTransform(477.375,248.65);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#F1E8DE").s().p("AgQAVQgGgFAAgJQAAgIAEgIQADgIAGgFQAHgEAHAAQAIAAAFAEQAFAGAAAHIgJABQAAgFgDgDQgDgDgEAAQgEAAgEAEQgEADgCAHQgDAGAAAGQAAAHADADQADADAEAAQAEAAAEgDQAEgDACgHIAJABQgEAKgGAEQgGAFgHAAQgIAAgFgGg");
	this.shape_37.setTransform(472.925,248.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#F1E8DE").s().p("AgQAWQgGgDAAgKIAJgBIABAGQABADADACQAEABAEAAQAEABADgDQADgDAAgDQAAAAAAgBQAAAAAAgBQAAAAAAgBQgBgBAAAAQgCgCgHgDIgIgDQgEgCgBgDQgBgDAAgDQAAgGAEgFQAFgEAIAAQAJAAAGAEQAFAFAAAIIgIAAQgBgEgDgDQgDgDgFAAQgEAAgDACQgDACAAACQAAABABABQAAAAAAABQAAAAABABQAAAAABABIAHADQAJAFADABQAFAFgBAFQAAAEgCAEQgDAEgEACQgFACgGAAQgJAAgGgFg");
	this.shape_38.setTransform(467.8,248.7);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#F1E8DE").s().p("AgNAEIACgIIAaAAIgCAIg");
	this.shape_39.setTransform(463.65,248.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#F1E8DE").s().p("AAIAaIAHgfIABgHQAAgBAAgBQAAAAgBgBQAAAAAAgBQgBAAAAgBQgCgCgDAAQgHAAgEAGQgGAFgCALIgFAXIgJAAIALgzIAIAAIgCAJQAFgFAEgCQAEgDAFAAQAGAAAEAEQAEADAAAGIgCAJIgGAeg");
	this.shape_40.setTransform(459.025,248.65);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#F1E8DE").s().p("AgNAZQgGgDgCgEQgDgGABgFQgBgPAKgKQAGgIAMAAQAJAAAGAGQAGAFgBAKQABAJgEAHQgEAIgGAEQgHAEgHAAQgFAAgFgCgAgEgRIgGAFIgDAJIgCAIQAAAIADAEQAEADAFAAIAGgBIAEgDIAFgFIACgHIACgJQAAgGgEgEQgEgEgEAAQgEAAgEACg");
	this.shape_41.setTransform(453.6,248.7);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#F1E8DE").s().p("AgNAZQgFgDgCgFQgDgGAAgGQAAgIAEgHQAEgJAGgDQAHgEAGAAQAJAAAFAFQAGAGAAAKIAAAHIglAAIgBADQAAAHAEAEQADAEAFAAQADAAAFgDQAEgDADgFIAIABQgCAFgGAGQgHAGgIAAQgGAAgFgCgAgGgPQgEAEgCAHIAcAAIAAgCQAAgGgDgDQgEgEgFAAQgEAAgGAEg");
	this.shape_42.setTransform(445.2,248.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#F1E8DE").s().p("AgQAWQgGgDAAgKIAJgBIABAGQACADACACQADABAFAAQAEABADgDQADgDABgDQAAAAgBgBQAAAAAAgBQAAAAAAgBQgBgBAAAAQgCgCgHgDIgIgDQgEgCgBgDQgBgDAAgDQAAgGAEgFQAFgEAIAAQAJAAAGAEQAFAFAAAIIgJAAQAAgEgDgDQgDgDgFAAQgEAAgDACQgCACAAACQAAABAAABQAAAAAAABQAAAAABABQAAAAABABIAHADQAJAFADABQAFAFAAAFQAAAEgDAEQgDAEgEACQgFACgGAAQgIAAgHgFg");
	this.shape_43.setTransform(440,248.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#F1E8DE").s().p("AgUAiQgGgDgDgFQgDgEAAgGIACgOIAIglIAKAAIgKArIgBAIQABAGAEADQAEADAIAAQAFAAAEgCQAFgDACgEQADgGACgKIAIgmIAKAAIgJAoQgCALgDAGQgFAHgGADQgGAFgIAAQgIAAgGgDg");
	this.shape_44.setTransform(434.35,247.8);

	this.instance = new lib.acceleratePedal();
	this.instance.parent = this;
	this.instance.setTransform(387,236,0.1355,0.1355);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#F1E8DE").s().p("AgFAFIACgJIAJAAIgCAJg");
	this.shape_45.setTransform(464.55,223.65);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#F1E8DE").s().p("AgSAXQgFgFAAgGQAAgEACgDQACgEADgBIAIgDIAKgBQAJAAADgCIACgFQAAgDgDgDQgDgCgGAAQgFAAgDACQgEADgBAEIgJAAQACgIAHgEQAGgEAHAAQAKAAAGAFQAEADAAAGIgBAJIgDAMIgBAKIABAHIgJAAIgBgHIgJAGIgIACQgHAAgEgEgAAJABIgHAAIgKADQgDABgCACQgCACAAADQAAADADADQADACAEAAQAFAAADgCQAEgDADgEQACgDABgIIgEABg");
	this.shape_46.setTransform(460.65,221.55);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#F1E8DE").s().p("AgSAbIAKgzIAIAAIgCAKQADgGAEgDQAEgCAEAAIAGACIgDAIIgFgCQgFAAgFAFQgEAFgDAMIgEAWg");
	this.shape_47.setTransform(456.725,221.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#F1E8DE").s().p("AgNAZQgFgDgDgFQgCgFAAgHQAAgIAEgHQAEgJAGgDQAHgEAGAAQAJAAAGAGQAFAFAAALIgBAGIgkAAIgBADQAAAIADADQAEAEAEAAQAEAAAEgDQAFgDADgGIAIABQgCAHgGAGQgHAFgJAAQgFAAgFgCgAgFgPQgFADgDAJIAdAAIAAgDQAAgGgDgEQgEgDgFAAQgFAAgEAEg");
	this.shape_48.setTransform(451.8,221.55);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#F1E8DE").s().p("AAWAbIAHgiIABgGQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQgCgCgEAAQgDAAgEADQgFACgBAEQgDAFgCAHIgFAZIgIAAIAIgiIAAgGQAAAAAAgBQAAAAAAgBQAAAAgBgBQAAAAAAAAQgBgBAAAAQgBgBAAAAQgBAAAAAAQgBgBgBAAQgDAAgFADQgEACgCAFQgCAEgCAHIgGAZIgIAAIALgzIAJAAIgDAIQAGgFADgCQAFgCAEAAQAEAAADACQADADABAEQAEgEAFgDQAEgCAFAAQAHAAADACQADADAAAGIgCAIIgHAhg");
	this.shape_49.setTransform(444.9,221.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#F1E8DE").s().p("AgTAXQgEgFAAgGQAAgEACgDQACgEADgBIAIgDIALgBQAIAAADgCIABgFQAAgDgCgDQgDgCgGAAQgFAAgDACQgEADgBAEIgJAAQACgIAGgEQAGgEAIAAQAKAAAGAFQAEADAAAGIgBAJIgDAMIgBAKIABAHIgJAAIgBgHIgJAGIgIACQgHAAgFgEgAAJABIgHAAIgKADQgDABgCACQgBACAAADQAAADACADQADACAEAAQAFAAADgCQAEgDADgEQABgDACgIIgEABg");
	this.shape_50.setTransform(437.95,221.55);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#F1E8DE").s().p("AgQAWQgGgGAAgJQAAgIAEgJQADgIAGgDQAHgFAHAAQAIAAAFAFQAFAEAAAIIgJAAQAAgEgDgDQgDgDgEAAQgEAAgEADQgEAEgCAHQgDAFAAAHQAAAGADAEQADADAEAAQAEAAAEgDQAEgDACgHIAJABQgEAJgGAGQgGAEgHAAQgIAAgFgFg");
	this.shape_51.setTransform(432.925,221.55);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#F1E8DE").s().p("AgNAZQgFgDgCgFQgDgGAAgGQAAgIAEgHQAEgJAGgDQAHgEAGAAQAJAAAFAFQAGAGAAAKIAAAHIglAAIgBADQAAAHADAEQAEAEAFAAQADAAAFgDQAEgDADgFIAIABQgCAFgGAGQgHAGgIAAQgGAAgFgCgAgFgPQgFAEgCAHIAcAAIAAgCQAAgGgDgDQgEgEgFAAQgEAAgFAEg");
	this.shape_52.setTransform(513.7,210.45);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#F1E8DE").s().p("AAIAkIAGggIACgHQAAgBAAAAQAAgBgBgBQAAAAAAAAQAAgBgBAAQgCgCgDAAQgFAAgEADQgDACgDAEQgCAEgCAJIgFAXIgJAAIAPhHIAJAAIgGAcQAFgFADgCQAFgCAEAAQAHAAADADQAEAEAAAFIgCAJIgGAfg");
	this.shape_53.setTransform(508.075,209.475);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#F1E8DE").s().p("AgKAhQgCgCAAgDIABgIIAGgdIgHAAIACgHIAHAAIADgNIAJgGIgEATIAIAAIgBAHIgJAAIgFAbIgBAHIABACQAAABABAAQAAAAAAAAQABAAAAAAQAAAAAAAAIAFAAIgBAHIgFABQgGAAgDgDg");
	this.shape_54.setTransform(504.325,209.575);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#F1E8DE").s().p("AgNAZQgFgDgDgFQgCgGAAgGQAAgIAEgHQAEgJAHgDQAFgEAHAAQAJAAAGAFQAFAGAAAKIgBAHIglAAIAAADQAAAHADAEQAEAEAEAAQAEAAAEgDQAFgDACgFIAJABQgCAFgHAGQgGAGgJAAQgFAAgFgCgAgFgPQgFAEgDAHIAdAAIAAgCQAAgGgEgDQgDgEgFAAQgFAAgEAEg");
	this.shape_55.setTransform(497,210.45);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#F1E8DE").s().p("AgKAhQgCgCAAgDIABgIIAGgdIgHAAIACgHIAHAAIADgNIAJgGIgEATIAIAAIgBAHIgJAAIgFAbIgBAHIABACQAAABABAAQAAAAAAAAQABAAAAAAQAAAAAAAAIAFAAIgBAHIgFABQgGAAgDgDg");
	this.shape_56.setTransform(493.175,209.575);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#F1E8DE").s().p("AgTAXQgEgEAAgHQAAgEACgEQACgDADgBIAIgDIALgBQAIAAADgCIABgGQABgDgDgBQgDgDgGAAQgEAAgEADQgDACgCAFIgJgBQADgIAFgEQAHgEAIAAQAJAAAGAEQAEAEAAAFIgBAKIgDAMIgCAKIACAHIgJAAIgBgHIgJAHIgIABQgIAAgEgEgAAJABIgHAAIgKACQgDABgBADQgCACAAADQAAADADADQACADAFgBQAEABADgDQAEgDACgEQADgEABgHIgEABg");
	this.shape_57.setTransform(488.6,210.45);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#F1E8DE").s().p("AgKAhQgCgCAAgDIABgIIAGgdIgHAAIACgHIAHAAIADgNIAJgGIgEATIAIAAIgBAHIgJAAIgFAbIgBAHIABACQAAABABAAQAAAAAAAAQABAAAAAAQAAAAAAAAIAFAAIgBAHIgFABQgGAAgDgDg");
	this.shape_58.setTransform(484.825,209.575);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#F1E8DE").s().p("AgOAZQgEgDgDgEQgCgGgBgFQAAgPAJgKQAIgIAKAAQAKAAAGAGQAGAFgBAKQAAAJgDAHQgEAIgGAEQgHAEgHAAQgGAAgFgCgAgEgRIgFAFIgFAJIgBAIQAAAIADAEQAFADAEAAIAGgBIAFgDIADgFIADgHIACgJQAAgGgEgEQgEgEgFAAQgDAAgEACg");
	this.shape_59.setTransform(480.35,210.45);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#F1E8DE").s().p("AgSAaIAKgzIAIAAIgCALQADgGAEgCQAEgEAEAAIAGADIgDAHIgFgBQgFAAgFAFQgEAGgDAMIgEAUg");
	this.shape_60.setTransform(476.325,210.4);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#F1E8DE").s().p("AgOAZQgEgDgDgEQgCgGgBgFQAAgPAKgKQAHgIAKAAQAKAAAGAGQAGAFgBAKQAAAJgDAHQgEAIgGAEQgHAEgHAAQgGAAgFgCgAgEgRIgFAFIgFAJIgBAIQAAAIADAEQAFADAEAAIAFgBIAGgDIADgFIADgHIACgJQAAgGgEgEQgEgEgFAAQgDAAgEACg");
	this.shape_61.setTransform(468.65,210.45);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#F1E8DE").s().p("AgKAhQgCgCAAgDIABgIIAGgdIgHAAIACgHIAHAAIADgNIAJgGIgEATIAIAAIgBAHIgJAAIgFAbIgBAHIABACQAAABABAAQAAAAAAAAQABAAAAAAQAAAAAAAAIAFAAIgBAHIgFABQgGAAgDgDg");
	this.shape_62.setTransform(464.775,209.575);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#F1E8DE").s().p("AAIAaIAHgfIABgHQAAgBAAgBQgBAAAAgBQAAAAAAgBQgBAAAAgBQgCgCgDAAQgHAAgEAGQgGAFgCALIgFAXIgJAAIALgzIAIAAIgCAJQAFgFAEgCQAEgDAFAAQAGAAAEAEQAEADAAAGIgCAJIgGAeg");
	this.shape_63.setTransform(457.375,210.4);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#F1E8DE").s().p("AgNAZQgFgDgDgFQgCgGAAgGQAAgIAEgHQAEgJAHgDQAFgEAHAAQAJAAAGAFQAFAGAAAKIgBAHIglAAIAAADQAAAHADAEQAEAEAEAAQAEAAAEgDQAFgDACgFIAJABQgCAFgHAGQgGAGgJAAQgFAAgFgCgAgFgPQgFAEgDAHIAdAAIAAgCQAAgGgEgDQgDgEgFAAQgFAAgEAEg");
	this.shape_64.setTransform(451.9,210.45);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#F1E8DE").s().p("AgNAZQgFgDgCgFQgDgGAAgGQAAgIAEgHQAEgJAHgDQAFgEAHAAQAJAAAFAFQAGAGAAAKIAAAHIgmAAIAAADQAAAHAEAEQADAEAFAAQADAAAFgDQAEgDACgFIAJABQgCAFgHAGQgGAGgIAAQgGAAgFgCgAgGgPQgEAEgDAHIAdAAIAAgCQAAgGgEgDQgDgEgFAAQgFAAgFAEg");
	this.shape_65.setTransform(446.35,210.45);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#F1E8DE").s().p("AgSAaIAKgzIAIAAIgCALQADgGAEgCQAEgEAEAAIAGADIgDAHIgFgBQgFAAgFAFQgEAGgDAMIgEAUg");
	this.shape_66.setTransform(442.375,210.4);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#F1E8DE").s().p("AgQAVQgGgFAAgJQAAgIAEgIQADgIAGgFQAHgEAHAAQAIAAAFAEQAFAGAAAHIgJABQAAgFgDgDQgDgDgEAAQgEAAgEAEQgEADgCAHQgDAGAAAGQAAAHADADQADADAEAAQAEAAAEgDQAEgDACgHIAJABQgEAKgGAEQgGAFgHAAQgIAAgFgGg");
	this.shape_67.setTransform(437.925,210.45);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#F1E8DE").s().p("AgQAWQgGgDAAgKIAJgBIABAGQACADACACQADABAFAAQAEABADgDQADgDABgDQAAAAgBgBQAAAAAAgBQAAAAAAgBQgBgBAAAAQgCgCgHgDIgIgDQgDgCgCgDQgBgDAAgDQAAgGAEgFQAFgEAIAAQAJAAAGAEQAFAFAAAIIgJAAQAAgEgDgDQgDgDgFAAQgEAAgDACQgCACAAACQAAABAAABQAAAAAAABQAAAAABABQAAAAABABIAHADQAJAFADABQAFAFAAAFQAAAEgDAEQgCAEgFACQgFACgGAAQgIAAgHgFg");
	this.shape_68.setTransform(432.8,210.45);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#F1E8DE").s().p("AgNAYQgFgCgDgFQgCgGAAgGQAAgHAEgJQAEgHAGgEQAHgEAGAAQAJAAAGAFQAFAHAAAKIgBAHIgkAAIgBACQAAAIADADQAEAEAEAAQAEAAAEgDQAFgDADgGIAIACQgCAFgGAHQgHAFgJAAQgFAAgFgDgAgFgPQgFADgDAIIAdAAIAAgBQAAgHgDgDQgEgEgFAAQgFAAgEAEg");
	this.shape_69.setTransform(516.6,199.35);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#F1E8DE").s().p("AAIAkIAGggIACgHQAAgBAAAAQAAgBgBgBQAAAAAAAAQAAgBgBAAQgCgCgDAAQgFAAgEADQgDACgDAEQgCAEgCAJIgFAXIgJAAIAPhHIAJAAIgGAcQAFgFADgCQAFgCAEAAQAHAAADADQAEAEAAAFIgCAJIgGAfg");
	this.shape_70.setTransform(510.975,198.375);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#F1E8DE").s().p("AgKAhQgCgCAAgDIABgIIAGgdIgHAAIACgHIAHAAIADgNIAJgGIgEATIAIAAIgBAHIgJAAIgFAbIgBAHIABACQAAABABAAQAAAAAAAAQABAAAAAAQAAAAAAAAIAFAAIgBAHIgFABQgGAAgDgDg");
	this.shape_71.setTransform(507.225,198.475);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#F1E8DE").s().p("AAIAbIAHghIABgHQAAAAAAgBQgBAAAAgBQAAAAAAgBQgBAAAAAAQgCgCgDAAQgHAAgEAEQgGAGgCAKIgFAZIgJAAIALg0IAIAAIgCAJQAFgEAEgDQAEgCAFgBQAGABAEADQAEADAAAGIgCAJIgGAfg");
	this.shape_72.setTransform(499.825,199.3);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#F1E8DE").s().p("AgOAYQgEgCgDgFQgCgEgBgHQAAgOAJgKQAIgIAKAAQAKAAAGAGQAGAFAAALQAAAIgEAIQgEAHgHAEQgGAEgHAAQgFAAgGgDgAgEgRIgFAFIgFAJIgBAIQAAAIADADQAFAFAEAAIAFgCIAGgEIADgEIADgHIACgIQAAgIgEgDQgEgEgFAAQgDAAgEACg");
	this.shape_73.setTransform(494.4,199.35);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#F1E8DE").s().p("AgRAjQgFgCgCgDQgCgCAAgFIAAgCIAJAAQAAABAAABQAAABAAAAQAAABABAAQAAABAAAAIACADIAHABQAHAAADgFQADgDACgJIAAgEQgHAHgGAAQgIAAgFgGQgFgFgBgKQAAgJAFgHQADgIAHgDQAFgEAFAAQALAAAFAKIACgJIAIAAIgKAxQgCAIgDAFQgDAEgEADQgFADgGAAQgHAAgEgCgAgDgbQgEABgCAEQgDAEgCAEIgBAIIABAHQACAEADACQACACAEAAQADAAAEgEQAFgCACgGQADgGAAgGQAAgHgEgDQgDgEgGAAQgBAAgDACg");
	this.shape_74.setTransform(486.05,200.35);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#F1E8DE").s().p("AgTAXQgEgFAAgGQAAgEACgDQACgEADgBIAIgDIALgBQAIAAAEgBIAAgHQAAgCgCgCQgDgDgGAAQgFAAgDADQgDACgCAEIgJAAQADgIAFgEQAHgEAIAAQAJAAAGAEQAEAEAAAFIgBAKIgDAMIgCAKIABAHIgIAAIgBgGIgJAFIgIACQgIAAgEgEgAAJABIgHABIgKACQgDABgBACQgCACAAADQAAAEADACQACACAFABQAEgBADgCQAEgCACgEQACgFACgHIgEABg");
	this.shape_75.setTransform(480.4,199.35);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#F1E8DE").s().p("AgSAbIAKg0IAIAAIgCALQADgGAEgDQAEgDAEAAIAGACIgDAIIgFgBQgFAAgFAFQgEAFgDANIgEAVg");
	this.shape_76.setTransform(476.475,199.3);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#F1E8DE").s().p("AgWAfQgEgFAAgLQAAgJADgHQAEgIAGgEQAGgEAGAAQAIAAAFAKIAGgcIAJAAIgPBGIgIAAIACgHQgHAIgIAAQgIAAgFgFgAgGgIQgDABgDAEQgCADgCAEQgCAGAAAEIABAIQABADADACQADACADAAQAGAAAEgGQAHgIAAgMQAAgGgEgDQgDgEgEAAQgDAAgCACg");
	this.shape_77.setTransform(471.925,198.425);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#F1E8DE").s().p("AgWAfQgEgFAAgLQAAgJADgHQAEgIAGgEQAGgEAGAAQAIAAAFAKIAGgcIAJAAIgPBGIgIAAIACgHQgHAIgIAAQgIAAgFgFgAgGgIQgDABgDAEQgCADgCAEQgCAGAAAEIABAIQABADADACQADACADAAQAGAAAEgGQAHgIAAgMQAAgGgEgDQgDgEgEAAQgDAAgCACg");
	this.shape_78.setTransform(463.575,198.425);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#F1E8DE").s().p("AAIAbIAHghIABgHQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBAAAAAAQgCgCgDAAQgHAAgEAEQgGAGgCAKIgFAZIgJAAIALg0IAIAAIgCAJQAFgEAEgDQAEgCAFgBQAGABAEADQAEADAAAGIgCAJIgGAfg");
	this.shape_79.setTransform(457.575,199.3);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#F1E8DE").s().p("AgTAXQgEgFAAgGQAAgEACgDQACgEADgBIAIgDIALgBQAIAAAEgBIABgHQgBgCgCgCQgDgDgGAAQgFAAgDADQgDACgCAEIgJAAQADgIAFgEQAHgEAIAAQAJAAAGAEQAEAEAAAFIgBAKIgDAMIgCAKIABAHIgIAAIgBgGIgJAFIgIACQgIAAgEgEgAAJABIgHABIgKACQgDABgBACQgCACAAADQAAAEADACQACACAFABQAEgBADgCQAEgCACgEQACgFACgHIgEABg");
	this.shape_80.setTransform(452.05,199.35);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#F1E8DE").s().p("AgaAkIAPhHIAIAAIgCAIQAFgFADgCQADgCAEAAQAIABAEAFQAFAGAAAJQAAAJgCAGQgDAGgEAEQgEAEgEACQgEABgEABQgIAAgGgKIgFAcgAABgaQgCABgCAEQgDADgBAGIgCAJIABAGQABAEADABQADACACAAQAIAAAFgIQAEgIAAgJQAAgGgDgEQgDgEgFABQgDAAgDACg");
	this.shape_81.setTransform(443.475,200.3);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#F1E8DE").s().p("AgSAXQgFgFAAgGQAAgEACgDQACgEADgBIAIgDIAKgBQAJAAADgBIACgHQAAgCgDgCQgDgDgGAAQgFAAgDADQgEACgBAEIgJAAQACgIAHgEQAGgEAHAAQAKAAAGAEQAEAEAAAFIgBAKIgDAMIgBAKIABAHIgJAAIgBgGIgJAFIgIACQgHAAgEgEgAAJABIgHABIgKACQgDABgCACQgCACAAADQAAAEADACQADACAEABQAFgBADgCQAEgCADgEQACgFABgHIgEABg");
	this.shape_82.setTransform(438.15,199.35);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#F1E8DE").s().p("AgSAkIAOg/IgYAAIABgIIA4AAIgBAIIgYAAIgMA/g");
	this.shape_83.setTransform(434.25,198.375);

	this.instance_1 = new lib.drag();
	this.instance_1.parent = this;
	this.instance_1.setTransform(382,191,0.3046,0.3046);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#F1E8DE").s().p("AgFAFIACgJIAJAAIgCAJg");
	this.shape_84.setTransform(199.45,218.65);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#F1E8DE").s().p("AgTAXQgEgFAAgGQAAgEACgEQACgDADgBIAIgDIALgBQAIAAAEgBIAAgHQAAgCgCgCQgDgDgGAAQgFAAgDADQgDACgCAEIgJAAQADgIAFgEQAHgEAIAAQAJAAAGAEQAEAEAAAFIgBAKIgDAMIgCAKIABAHIgIAAIgBgGIgJAFQgDACgFAAQgIAAgEgEgAAJABIgHABIgKABQgDACgBACQgCACAAADQAAAEADACQACACAFABQAEgBADgCQAEgDACgDQACgEACgIIgEABg");
	this.shape_85.setTransform(195.55,216.55);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#F1E8DE").s().p("AgSAaIAKgzIAIAAIgCALQADgGAEgDQAEgDAEAAIAGACIgDAIIgFgBQgFAAgFAFQgEAGgDAMIgEAUg");
	this.shape_86.setTransform(191.625,216.5);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#F1E8DE").s().p("AgNAYQgFgCgCgFQgDgFAAgHQAAgHAEgJQAEgHAHgEQAFgEAHAAQAJAAAGAFQAFAHAAAJIAAAIIgmAAIAAACQAAAHAEAEQADAEAFAAQADAAAFgDQAEgDACgFIAJABQgCAGgHAFQgGAGgIAAQgGAAgFgDgAgGgPQgEAEgDAHIAdAAIAAgBQAAgHgEgDQgDgEgFAAQgFAAgFAEg");
	this.shape_87.setTransform(186.7,216.55);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#F1E8DE").s().p("AAWAaIAHghIABgGQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAQgCgCgCABQgEgBgFADQgEADgCAEQgCAEgBAGIgGAZIgIAAIAHgiIABgEQAAgBAAgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBAAAAAAQgBgBAAAAQgBAAAAAAQgBAAAAAAQgEgBgEADQgEADgDAEQgCAEgDAHIgEAYIgJAAIAKgzIAJAAIgBAJQAFgGAEgCQADgCAFAAQAEABADACQADACABAFQAEgFAEgCQAFgCAFgBQAGAAADADQAEADAAAGIgCAIIgGAgg");
	this.shape_88.setTransform(179.8,216.5);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#F1E8DE").s().p("AgSAXQgFgFAAgGQAAgEACgEQACgDADgBIAIgDIAKgBQAJAAAEgBIABgHQgBgCgCgCQgDgDgGAAQgEAAgEADQgDACgCAEIgJAAQADgIAGgEQAFgEAJAAQAJAAAGAEQAEAEAAAFIgBAKIgDAMIgCAKIABAHIgIAAIgBgGIgJAFIgIACQgIAAgDgEgAAJABIgHABIgKABQgDACgBACQgDACAAADQAAAEAEACQACACAEABQAFgBADgCQAEgDACgDQACgEACgIIgEABg");
	this.shape_89.setTransform(172.85,216.55);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#F1E8DE").s().p("AgQAVQgGgFAAgKQAAgHAEgJQADgIAGgEQAHgEAHAAQAIAAAFAEQAFAFAAAIIgJABQAAgFgDgDQgDgDgEAAQgEAAgEAEQgEADgCAHQgDAFAAAHQAAAGADAEQADADAEABQAEgBAEgDQAEgDACgHIAJABQgEAKgGAEQgGAFgHAAQgIAAgFgGg");
	this.shape_90.setTransform(167.825,216.55);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#F1E8DE").s().p("AgNAYQgFgCgCgFQgDgGAAgGQAAgHAEgIQAEgJAHgDQAFgEAHAAQAJAAAFAGQAGAFAAALIAAAHIgmAAIAAACQAAAHAEAEQADAEAFAAQADAAAFgDQAEgDACgGIAJABQgCAHgHAGQgGAFgIAAQgGAAgFgDgAgGgPQgEADgDAJIAdAAIAAgCQAAgHgEgEQgDgDgFAAQgFAAgFAEg");
	this.shape_91.setTransform(269.05,205.45);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#F1E8DE").s().p("AAIAkIAGggIACgHQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAgBgBAAQgCgCgDAAQgFAAgEADQgDACgDAEQgCAEgCAJIgFAXIgJAAIAPhHIAJAAIgGAcQAFgFADgCQAFgCAEAAQAHAAADADQAEAEAAAFIgCAJIgGAfg");
	this.shape_92.setTransform(263.425,204.475);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#F1E8DE").s().p("AgKAhQgCgCAAgDIABgIIAGgdIgHAAIACgHIAHAAIADgNIAJgGIgEATIAIAAIgBAHIgJAAIgFAbIgBAHIABACQAAAAABABQAAAAAAAAQABAAAAAAQAAAAAAAAIAFAAIgBAHIgFABQgGAAgDgDg");
	this.shape_93.setTransform(259.675,204.575);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#F1E8DE").s().p("AgNAYQgFgCgDgFQgCgGAAgGQAAgHAEgIQAEgJAGgDQAHgEAGAAQAJAAAFAGQAGAFAAALIgBAHIgkAAIgBACQAAAHADAEQAEAEAFAAQADAAAEgDQAFgDADgGIAIABQgCAHgGAGQgHAFgIAAQgGAAgFgDgAgFgPQgFADgCAJIAcAAIAAgCQAAgHgDgEQgEgDgFAAQgEAAgFAEg");
	this.shape_94.setTransform(252.35,205.45);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#F1E8DE").s().p("AgKAhQgCgCAAgDIABgIIAGgdIgHAAIACgHIAHAAIADgNIAJgGIgEATIAIAAIgBAHIgJAAIgFAbIgBAHIABACQAAAAABABQAAAAAAAAQABAAAAAAQAAAAAAAAIAFAAIgBAHIgFABQgGAAgDgDg");
	this.shape_95.setTransform(248.525,204.575);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#F1E8DE").s().p("AgSAXQgFgEAAgHQAAgEACgDQACgEADgBIAIgDIAKgBQAJAAAEgBIABgGQgBgEgCgCQgDgCgGAAQgEAAgEACQgDADgCAEIgJAAQADgIAGgEQAFgEAJAAQAJAAAGAFQAEADAAAGIgBAJIgDAMIgCAKIABAHIgIAAIgBgHIgJAGIgIACQgIAAgDgEgAAJABIgHAAIgKADQgDAAgBADQgDACAAADQAAADAEADQACADAEAAQAFAAADgDQAEgCACgEQACgFACgHIgEABg");
	this.shape_96.setTransform(243.95,205.45);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#F1E8DE").s().p("AgKAhQgCgCAAgDIABgIIAGgdIgHAAIACgHIAHAAIADgNIAJgGIgEATIAIAAIgBAHIgJAAIgFAbIgBAHIABACQAAAAABABQAAAAAAAAQABAAAAAAQAAAAAAAAIAFAAIgBAHIgFABQgGAAgDgDg");
	this.shape_97.setTransform(240.175,204.575);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#F1E8DE").s().p("AgNAYQgFgCgDgFQgCgFAAgGQAAgOAJgKQAGgIAMAAQAJAAAGAGQAFAGAAAKQAAAHgDAJQgEAHgGAEQgHAEgHAAQgFAAgFgDgAgDgRIgHAGIgDAJIgCAIQAAAHADADQAFAEAEABIAGgCIAEgDIAFgGIACgGIACgIQAAgHgEgFQgEgDgEAAQgEAAgDACg");
	this.shape_98.setTransform(235.7,205.45);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#F1E8DE").s().p("AgSAbIAKgzIAIAAIgCAKQADgGAEgDQAEgCAEAAIAGABIgDAJIgFgCQgFAAgFAFQgEAFgDAMIgEAWg");
	this.shape_99.setTransform(231.675,205.4);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#F1E8DE").s().p("AgNAYQgFgCgDgFQgCgFAAgGQAAgOAJgKQAGgIAMAAQAJAAAGAGQAFAGAAAKQAAAHgDAJQgEAHgGAEQgHAEgHAAQgFAAgFgDgAgDgRIgHAGIgDAJIgCAIQAAAHADADQAFAEAEABIAGgCIAEgDIAFgGIACgGIACgIQAAgHgEgFQgEgDgEAAQgEAAgDACg");
	this.shape_100.setTransform(224,205.45);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#F1E8DE").s().p("AgKAhQgCgCAAgDIABgIIAGgdIgHAAIACgHIAHAAIADgNIAJgGIgEATIAIAAIgBAHIgJAAIgFAbIgBAHIABACQAAAAABABQAAAAAAAAQABAAAAAAQAAAAAAAAIAFAAIgBAHIgFABQgGAAgDgDg");
	this.shape_101.setTransform(220.125,204.575);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#F1E8DE").s().p("AgNAYQgFgCgCgFQgDgGAAgGQAAgHAEgIQAEgJAHgDQAFgEAHAAQAJAAAFAGQAGAFAAALIAAAHIgmAAIAAACQAAAHAEAEQADAEAFAAQADAAAFgDQAEgDACgGIAJABQgCAHgHAGQgGAFgIAAQgGAAgFgDgAgGgPQgEADgDAJIAdAAIAAgCQAAgHgEgEQgDgDgFAAQgFAAgFAEg");
	this.shape_102.setTransform(212.8,205.45);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#F1E8DE").s().p("AgQAXQgGgFAAgKIAJgBIABAHQABADADABQADACAFABQAFAAACgDQADgCAAgDQAAgBAAgBQAAAAAAgBQAAAAAAgBQgBAAAAgBQgCgCgHgDIgIgDQgEgCgBgDQgCgCAAgEQABgGAFgEQAEgFAIAAQAJAAAGAFQAFAEAAAHIgIABQgBgEgDgEQgDgCgGAAQgDAAgDACQgDACAAADQAAAAABABQAAAAAAABQAAAAABABQAAAAABAAIAGAFQAKAEADABQAFAFgBAGQAAAEgCADQgDADgEADQgFACgGAAQgJAAgGgEg");
	this.shape_103.setTransform(207.6,205.45);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#F1E8DE").s().p("AgUAXQgEgDAAgFIACgMIAGgcIAJAAIgHAgIgBAGQAAADACACQACABADAAQAEAAADgBQADgCACgDIAEgIQACgCABgGIAFgWIAJAAIgLAzIgIAAIABgKQgIALgKAAQgGAAgDgEg");
	this.shape_104.setTransform(202.475,205.5);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#F1E8DE").s().p("AgNAYQgFgCgDgFQgDgFABgGQgBgOAKgKQAGgIALAAQAKAAAGAGQAGAGgBAKQABAHgEAJQgEAHgGAEQgHAEgHAAQgGAAgEgDgAgEgRIgGAGIgDAJIgCAIQAAAHADADQAFAEAEABIAGgCIAEgDIAFgGIACgGIACgIQAAgHgEgFQgEgDgFAAQgDAAgEACg");
	this.shape_105.setTransform(196.75,205.45);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#F1E8DE").s().p("AAWAbIAHgiIABgGQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQgDgBgDAAQgDAAgFACQgDADgDAEQgCADgCAIIgFAZIgIAAIAHgiIABgGQAAAAAAgBQAAAAAAgBQAAAAgBgBQAAAAgBAAQAAgBAAAAQgBgBAAAAQgBAAAAAAQgBAAAAAAQgEAAgEACQgFADgCAEQgDAEgBAHIgGAZIgIAAIAKgzIAJAAIgCAIQAFgFAFgDQADgBAFAAQAEgBADADQADADABAEQAEgEAEgDQAFgDAFABQAGAAADACQAEADAAAGIgBAIIgHAhg");
	this.shape_106.setTransform(189.8,205.4);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#F1E8DE").s().p("AgNAYQgFgCgDgFQgCgGAAgGQAAgHAEgIQAEgJAHgDQAFgEAHAAQAJAAAGAGQAFAFAAALIgBAHIglAAIAAACQAAAHADAEQAEAEAEAAQAEAAAEgDQAFgDACgGIAJABQgCAHgHAGQgGAFgJAAQgFAAgFgDgAgFgPQgFADgDAJIAdAAIAAgCQAAgHgEgEQgDgDgFAAQgFAAgEAEg");
	this.shape_107.setTransform(180.1,205.45);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#F1E8DE").s().p("AgQAXQgGgFAAgKIAJgBIABAHQACADADABQADACAEABQAEAAAEgDQACgCAAgDQAAgBAAgBQAAAAAAgBQAAAAAAgBQgBAAAAgBQgCgCgHgDIgIgDQgDgCgCgDQgBgCgBgEQAAgGAGgEQAEgFAIAAQAJAAAGAFQAFAEAAAHIgJABQAAgEgDgEQgDgCgGAAQgDAAgDACQgCACgBADQAAAAABABQAAAAAAABQAAAAABABQAAAAABAAIAGAFQALAEACABQAEAFAAAGQAAAEgCADQgCADgFADQgFACgFAAQgJAAgHgEg");
	this.shape_108.setTransform(174.9,205.45);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#F1E8DE").s().p("AgUAhQgGgCgDgFQgDgFAAgGIACgMIAJgnIAJAAIgJArIgCAIQAAAGAFAEQAFADAGAAQAGAAAEgCQAEgDADgFQADgEACgLIAJgnIAJAAIgJAqQgCAKgEAHQgDAGgHAEQgHADgHAAQgIAAgGgDg");
	this.shape_109.setTransform(169.25,204.55);

	this.instance_2 = new lib.mouse();
	this.instance_2.parent = this;
	this.instance_2.setTransform(107,200,0.5749,0.5744);

	this.instance_3 = new lib.button();
	this.instance_3.parent = this;
	this.instance_3.setTransform(211,254,0.2154,0.2153);

	this.instance_4 = new lib.button();
	this.instance_4.parent = this;
	this.instance_4.setTransform(179,254,0.2154,0.2153);

	this.instance_5 = new lib.button();
	this.instance_5.parent = this;
	this.instance_5.setTransform(195,254,0.2154,0.2153);

	this.instance_6 = new lib.button();
	this.instance_6.parent = this;
	this.instance_6.setTransform(195,238,0.2154,0.2153);

	this.instance_7 = new lib.button();
	this.instance_7.parent = this;
	this.instance_7.setTransform(140,254,0.2154,0.2153);

	this.instance_8 = new lib.button();
	this.instance_8.parent = this;
	this.instance_8.setTransform(108,254,0.2154,0.2153);

	this.instance_9 = new lib.button();
	this.instance_9.parent = this;
	this.instance_9.setTransform(124,254,0.2154,0.2153);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#F1E8DE").s().p("AgFAFIACgJIAJAAIgCAJg");
	this.shape_110.setTransform(268.35,261.9);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#F1E8DE").s().p("AgNAZQgFgDgCgFQgDgFAAgHQAAgIAEgHQAEgJAGgDQAHgEAGAAQAJAAAFAGQAGAFAAALIAAAGIglAAIgBADQAAAIADADQAEAEAEAAQAEAAAEgDQAFgDADgGIAIABQgCAHgGAGQgHAFgJAAQgFAAgFgCgAgFgPQgFADgCAJIAcAAIAAgDQAAgGgDgEQgEgDgFAAQgEAAgFAEg");
	this.shape_111.setTransform(264.5,259.8);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#F1E8DE").s().p("AgPAaIgIgzIAIAAIAFAbIACAQIAGgMIARgfIAJAAIgdAzg");
	this.shape_112.setTransform(259.8,259.8);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#F1E8DE").s().p("AgLAkIALgzIAIAAIgKAzgAABgZIACgKIAJAAIgCAKg");
	this.shape_113.setTransform(255.9,258.825);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#F1E8DE").s().p("AgSAbIAKgzIAIAAIgCAKQADgGAEgDQAEgCAEAAIAGACIgDAIIgFgCQgFAAgFAFQgEAFgDAMIgEAWg");
	this.shape_114.setTransform(253.325,259.75);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#F1E8DE").s().p("AgWAfQgEgFAAgLQAAgJADgHQAEgIAGgEQAGgEAGAAQAIAAAFAKIAGgcIAJAAIgPBGIgIAAIACgHQgHAIgIAAQgIAAgFgFgAgGgIQgDABgDAEQgCADgCAEQgCAGAAAEIABAIQABADADACQADACADAAQAGAAAEgGQAHgIAAgMQAAgGgEgDQgDgEgEAAQgDAAgCACg");
	this.shape_115.setTransform(248.775,258.875);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#F1E8DE").s().p("AgNAZQgFgDgDgFQgCgFAAgFQAAgPAJgKQAGgIAMAAQAJAAAGAGQAFAGABAKQgBAHgDAIQgDAIgIAEQgGAEgGAAQgHAAgEgCgAgDgRIgHAGIgDAJIgCAIQAAAHAEADQAEAEAFAAIAFgBIAEgDIAFgGIADgGIABgIQAAgHgEgFQgDgDgFAAQgEAAgDACg");
	this.shape_116.setTransform(240.1,259.8);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#F1E8DE").s().p("AgKAhQgCgCAAgDIABgIIAGgdIgHAAIACgHIAHAAIADgNIAJgGIgEATIAIAAIgBAHIgJAAIgFAbIgBAHIABACQAAAAABABQAAAAAAAAQABAAAAAAQAAAAAAAAIAFAAIgBAHIgFABQgGAAgDgDg");
	this.shape_117.setTransform(236.225,258.925);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#F1E8DE").s().p("AgQAWQgGgDAAgKIAJgBIABAGQACADADACQADABAEAAQAFABADgDQADgDAAgDQAAAAgBgBQAAAAAAgBQAAAAAAgBQgBgBAAAAQgCgCgHgDIgIgDQgDgCgCgDQgBgDgBgDQAAgGAGgFQAEgEAIAAQAJAAAGAEQAFAFAAAIIgJAAQABgEgEgDQgDgDgGAAQgDAAgDACQgDACABACQAAABAAABQAAAAAAABQAAAAABABQAAAAABABIAGADQALAFACABQAEAFABAFQgBAEgCAEQgCAEgFACQgFACgFAAQgJAAgHgFg");
	this.shape_118.setTransform(353.45,248.7);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#F1E8DE").s().p("AgbAjIAAgIIAGABIAEgBQACgCADgEIACgGIgIgzIAJAAIAEAbIACAOIAWgpIAJAAIggA7QgEAIgEADQgEADgFAAIgGgCg");
	this.shape_119.setTransform(348.55,249.75);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#F1E8DE").s().p("AgNAZQgFgDgDgFQgCgGAAgGQAAgIAEgHQAEgJAHgDQAFgEAHAAQAJAAAGAFQAFAGAAAKIgBAHIglAAIAAADQAAAHADAEQAEAEAEAAQAEAAAEgDQAFgDACgFIAJABQgCAFgHAGQgGAGgJAAQgFAAgFgCgAgGgPQgEAEgDAHIAdAAIAAgCQAAgGgEgDQgDgEgFAAQgFAAgFAEg");
	this.shape_120.setTransform(343.1,248.7);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#F1E8DE").s().p("AAIAkIgKgbIgLAJIgDASIgJAAIAPhHIAIAAIgJAsIAZgYIAMAAIgWASIANAhg");
	this.shape_121.setTransform(338.15,247.725);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#F1E8DE").s().p("AAAAaIgBgeIAAgLIgFAMIgNAdIgKAAIgFgzIAJAAIACAYIABAMIAAAGIADgIIADgIIAMgaIAJAAIACAZIAAAQIAIgRIALgYIAJAAIgZAzg");
	this.shape_122.setTransform(329.475,248.7);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#F1E8DE").s().p("AgOAZQgFgDgCgEQgCgGgBgFQABgPAIgKQAHgIALAAQAKAAAGAGQAGAFAAAKQAAAJgEAHQgDAIgIAEQgGAEgGAAQgGAAgGgCgAgEgRIgFAFIgFAJIgBAIQAAAIAEAEQADADAGAAIAEgBIAGgDIADgFIAEgHIABgJQAAgGgEgEQgEgEgFAAQgDAAgEACg");
	this.shape_123.setTransform(322.6,248.7);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#F1E8DE").s().p("AgSAaIAKgzIAIAAIgCALQADgGAEgCQAEgEAEAAIAGADIgDAHIgFgBQgFAAgFAFQgEAGgDAMIgEAUg");
	this.shape_124.setTransform(318.575,248.65);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#F1E8DE").s().p("AgSAaIAKgzIAIAAIgCALQADgGAEgCQAEgEAEAAIAGADIgDAHIgFgBQgFAAgFAFQgEAGgDAMIgEAUg");
	this.shape_125.setTransform(315.225,248.65);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#F1E8DE").s().p("AgSAXQgFgEAAgHQAAgEACgEQACgDADgBIAIgDIALgBQAIAAADgCIABgGQAAgDgCgBQgDgDgGAAQgFAAgDADQgEACgBAFIgJgBQACgIAHgEQAGgEAHAAQAKAAAGAEQAEAEAAAFIgBAKIgDAMIgBAKIABAHIgJAAIgBgHIgJAHIgIABQgHAAgEgEgAAJABIgHAAIgKACQgDABgCADQgCACAAADQAAADADADQADADAEgBQAFABADgDQAEgDADgEQACgEABgHIgEABg");
	this.shape_126.setTransform(310.25,248.7);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#F1E8DE").s().p("AgSAaIAKgzIAIAAIgCALQADgGAEgCQAEgEAEAAIAGADIgDAHIgFgBQgFAAgFAFQgEAGgDAMIgEAUg");
	this.shape_127.setTransform(303.525,248.65);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#F1E8DE").s().p("AgOAZQgEgDgDgEQgCgGgBgFQAAgPAJgKQAIgIAKAAQAKAAAGAGQAGAFAAAKQAAAJgEAHQgEAIgHAEQgGAEgHAAQgFAAgGgCgAgEgRIgFAFIgFAJIgBAIQAAAIADAEQAFADAEAAIAFgBIAGgDIADgFIADgHIACgJQAAgGgEgEQgEgEgFAAQgDAAgEACg");
	this.shape_128.setTransform(298.65,248.7);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#F1E8DE").s().p("AggAkIAPhHIAUAAIAMABQAGACAEAEQAEAEACAFQACAGAAAHQAAAIgCAHQgDAHgEAGQgEAFgFADQgEADgHACIgLABgAgVAcIALAAQAIAAAFgCIAGgCIAHgGQADgFADgGQACgGAAgHQAAgJgDgEQgDgFgFgCIgLgBIgLAAg");
	this.shape_129.setTransform(289.475,247.725);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#F1E8DE").s().p("AgGAIQAGgBABgIIgFAAIADgKIAJAAIgCAIQgCAHgEAEQgCAEgFAAg");
	this.shape_130.setTransform(283.9,251.525);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#F1E8DE").s().p("AgVAgQgIgGAAgNIAKgBIAAACQgBAEACAEQACAEAFACQAEACAGgBQAHAAAFgDQAEgFABgEQgBgDgCgDQgCgDgLgFIgKgFQgGgDgCgDQgCgEAAgEQAAgGADgEQADgFAGgCQAFgDAHAAQAJAAAFADQAHADACAFQADAFAAAFIAAAAIgJABIgBgEIgDgFIgGgDQgDgCgFAAQgGAAgFAEQgDADAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAIAEAFIAMAFIAKAFQAEACACAEQACAEABAEQAAAGgFAFQgDAFgGADQgHACgGAAQgMAAgIgFg");
	this.shape_131.setTransform(279.95,247.7);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#F1E8DE").s().p("AgGAIQAGgBABgIIgFAAIADgKIAJAAIgCAIQgCAHgDAEQgDAEgFAAg");
	this.shape_132.setTransform(274.45,251.525);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#F1E8DE").s().p("AAXAkIgEgVIgcAAIgLAVIgLAAIAohHIALAAIAMBHgAAGgMIgLAUIAXAAIgDgRIgCgSIgHAPg");
	this.shape_133.setTransform(269.775,247.725);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#F1E8DE").s().p("AgGAIQAGgBABgIIgFAAIADgKIAJAAIgCAIQgCAHgEAEQgCAEgFAAg");
	this.shape_134.setTransform(265,251.525);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#F1E8DE").s().p("AAAAkIgBgrIgBgNIgFAKIgYAuIgKAAIgFhHIAKAAIACAjIAAANIAAAFIAAAFIAJgSIAWgoIAIAAIADApIAAARIADgHIAGgLIAUgoIAKAAIglBHg");
	this.shape_135.setTransform(260.825,247.725);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#F1E8DE").s().p("AgNAZQgFgDgCgFQgDgGAAgGQAAgIAEgHQAEgJAGgDQAHgEAGAAQAJAAAFAFQAGAGAAAKIAAAHIglAAIgBADQAAAHAEAEQADAEAFAAQADAAAFgDQAEgDADgFIAIABQgCAFgGAGQgHAGgIAAQgGAAgFgCgAgGgPQgEAEgCAHIAcAAIAAgCQAAgGgDgDQgEgEgFAAQgEAAgGAEg");
	this.shape_136.setTransform(249.45,248.7);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#F1E8DE").s().p("AgQAWQgGgDAAgKIAJgBIABAGQACADACACQADABAFAAQAEABADgDQADgDABgDQAAAAgBgBQAAAAAAgBQAAAAAAgBQgBgBAAAAQgCgCgHgDIgIgDQgDgCgCgDQgBgDAAgDQAAgGAEgFQAFgEAIAAQAJAAAGAEQAFAFAAAIIgJAAQAAgEgDgDQgDgDgFAAQgEAAgDACQgCACAAACQAAABAAABQAAAAAAABQAAAAABABQAAAAABABIAHADQAJAFADABQAFAFAAAFQAAAEgDAEQgDAEgEACQgFACgGAAQgIAAgHgFg");
	this.shape_137.setTransform(244.25,248.7);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#F1E8DE").s().p("AgUAiQgGgDgDgFQgDgEAAgGIACgOIAIglIAKAAIgKArIgBAIQABAGAEADQAEADAIAAQAFAAAEgCQAFgDACgEQADgGACgKIAIgmIAKAAIgJAoQgCALgDAGQgFAHgGADQgGAFgIAAQgIAAgGgDg");
	this.shape_138.setTransform(238.6,247.8);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#CCCCCC").s().p("AgSAaIAKgzIAIAAIgCALQADgGAEgCQAEgEAEAAIAGACIgDAIIgFgBQgFAAgFAFQgEAGgDAMIgEAUg");
	this.shape_139.setTransform(170.175,254.85);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#CCCCCC").s().p("AgTAhQgGgEgEgIQgEgHAAgIQAAgSALgMQAMgMAOAAQANAAAJAJQAIAJAAAOQAAAKgEAIQgDAIgFAEQgFAFgGACQgGAEgIAAQgIAAgIgEgAgPgSQgJAKAAAOQAAAHADAFQADAFAFAEQAFADAGAAQAFAAAEgDQAFgDAFgEQADgFADgHQACgHAAgFQgBgLgFgHQgGgGgJAAQgKAAgJAKg");
	this.shape_140.setTransform(164.4,253.9);

	this.instance_10 = new lib.button();
	this.instance_10.parent = this;
	this.instance_10.setTransform(124,238,0.2154,0.2153);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFFFFF").s().p("AgMAiIACgNIAMAAIgCANgAgBgUIABgNIAOAAIgDANg");
	this.shape_141.setTransform(433.15,173.375);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_142.setTransform(427.575,173.375);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FFFFFF").s().p("AgOAvIAShcIAMAAIgTBcg");
	this.shape_143.setTransform(422.8,172.1);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#FFFFFF").s().p("AgOAvIANhDIALAAIgNBDgAABggIADgNIALAAIgDANg");
	this.shape_144.setTransform(419.95,172.1);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FFFFFF").s().p("AgLAsQgFgEgDgHIgDANIgJAAIAThcIALAAIgGAhQAFgFADgCQAEgCAGAAQAJAAAGAHQAHAHgBAMQABAJgDAIQgDAHgEAFQgDAFgEADIgIAFIgIABQgGAAgFgDgAgDgIQgFAFgEAJQgDAHABAFIAAACQAAAJADAEQAEAFAGAAQAGAAAFgEQAFgFADgJQADgIABgIQgBgIgEgEQgEgFgGAAQgGAAgEAFg");
	this.shape_145.setTransform(414.45,172.175);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FFFFFF").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_146.setTransform(407.325,173.375);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#FFFFFF").s().p("AAWAvIAKguIAJgiIgJATIgiA9IgMAAIgJg7IgCgUIgEAUIgLA7IgNAAIAUhcIAPAAIAJA6IADAYQADgKAIgQIAig4IAPAAIgUBcg");
	this.shape_147.setTransform(398.6,172.1);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#FFFFFF").s().p("AgMAiIACgNIAMAAIgCANgAgBgUIABgNIAOAAIgDANg");
	this.shape_148.setTransform(178.7,169.875);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#FFFFFF").s().p("AgcAoQgHgHAAgNQABgNAFgJQAEgKAIgFQAHgFAIAAQAMAAAGAMIAIgkIALAAIgTBcIgLAAIACgKQgJALgKAAQgKAAgGgHgAgJgLQgDACgDAEQgDAFgDAGQgCAGAAAGIABALQACAEADACQADADAFAAQAIAAAFgIQAJgLAAgQQAAgHgFgEQgEgFgFAAQgEAAgEACg");
	this.shape_149.setTransform(173.6,168.675);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#FFFFFF").s().p("AgYAiIAOhCIAKAAIgDAOQAEgIAFgDQAGgFAEAAQAEAAAFADIgEALQgDgCgEAAQgGAAgGAGQgGAHgDARIgGAag");
	this.shape_150.setTransform(167.95,169.8);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FFFFFF").s().p("AgYAeQgHgGABgIQAAgGACgEQADgFAEgBIAKgEIAOgBQALgBAEgCIACgHQAAgEgDgDQgEgDgHAAQgHAAgEADQgFAEgCAGIgLgBQADgLAIgFQAHgFALAAQAMAAAIAGQAFAEABAHIgCANIgEAQIgCANIABAJIgLAAIgBgJQgGAGgFACQgFACgHAAQgJAAgFgFgAAMABIgJABIgOACQgDACgDADQgCADAAADQAAAFAEADQADADAGAAQAGAAAEgDQAFgDAEgFQADgFABgKIgFABg");
	this.shape_151.setTransform(161.45,169.875);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#FFFFFF").s().p("AgSAgQgGgDgDgHQgEgGAAgIQAAgTAMgNQAJgKAPAAQAMAAAIAHQAHAIAAANQAAALgFAKQgEAKgJAFQgJAFgIAAQgIAAgHgDgAgEgXQgFADgDAFQgEAFgCAGIgBALQAAAKAEAEQAFAFAHAAIAGgBQAEgCADgDIAFgHIAEgIQACgFAAgGQAAgJgFgFQgFgFgHAAQgEAAgEACg");
	this.shape_152.setTransform(154.325,169.875);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#FFFFFF").s().p("AgLAsQgFgEgDgHIgCANIgKAAIAThcIALAAIgHAhQAGgFADgCQAEgCAFAAQAKAAAGAHQAHAHAAAMQgBAJgCAIQgDAHgDAFQgEAFgEADIgIAFIgIABQgGAAgFgDgAgDgIQgFAFgEAJQgCAHAAAFIAAACQAAAJAEAEQAEAFAFAAQAFAAAGgEQAFgFADgJQAEgIAAgIQAAgIgFgEQgEgFgGAAQgGAAgEAFg");
	this.shape_153.setTransform(146.95,168.675);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FFFFFF").s().p("AgkAuIABgLIAHABQADAAADgCIAGgHIAEgHIgLhDIALAAIAFAjIADATIAcg2IANAAIgqBMQgHALgEADQgGAEgGABIgIgCg");
	this.shape_154.setTransform(140.4,171.25);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FFFFFF").s().p("AgRAgQgGgEgEgGQgDgHAAgIQAAgKAFgLQAFgKAIgFQAIgFAJAAQAMAAAHAHQAHAIAAANIgBAJIgwAAIAAADQAAAKAEAFQAEAFAHAAQAEAAAGgEQAGgEADgHIALABQgCAIgJAIQgIAHgLAAQgIAAgGgDgAgHgUQgGAFgDAKIAlAAIAAgCQAAgJgFgFQgEgEgHAAQgGAAgGAFg");
	this.shape_155.setTransform(133.275,169.875);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#FFFFFF").s().p("AAUAvIgagvIgUARIgGAeIgMAAIAThcIAMAAIgJAtIAygtIARAAIgrAmIAgA2g");
	this.shape_156.setTransform(125.975,168.6);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#FFCC99").s().p("AgPAnIADgPIAOAAIgCAPgAgCgXIADgPIAPAAIgEAPg");
	this.shape_157.setTransform(176.775,130.8);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#FFCC99").s().p("AgYAiQgKgHABgPIANgBQAAAGACAEQACAEAFADQAEACAGAAQAIAAAFgDQAEgEAAgFQAAgDgDgDQgCgDgLgFIgMgFQgFgDgDgEQgCgEAAgFQAAgKAHgGQAIgHAMAAQAOAAAIAHQAIAHAAALIgNABQAAgHgFgEQgFgFgIAAQgGAAgEAEQgEADAAADQAAAEAEADQACACAIAEQAPAGAEADQAGAGAAAJQAAAGgDAFQgEAGgHADQgHAEgJAAQgOAAgJgHg");
	this.shape_158.setTransform(170.8988,130.825);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#FFCC99").s().p("AgRA2IAWhrIANAAIgWBrg");
	this.shape_159.setTransform(165.675,129.325);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#FFCC99").s().p("AgVAlQgHgEgEgHQgEgHAAgKQAAgWANgOQAMgNAQAAQAPAAAIAJQAJAJAAAPQAAAMgGAMQgFALgKAGQgKAHgKAAQgJAAgIgEgAgFgbQgGADgEAGQgEAGgCAHQgCAHAAAGQAAALAGAGQAFAFAIAAIAHgBQAFgCADgEIAGgIIAEgJQADgHAAgGQAAgLgGgGQgFgGgIAAQgFAAgFADg");
	this.shape_160.setTransform(159.575,130.825);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#FFCC99").s().p("AgcAoIAQhNIAMAAIgEAQQAGgJAFgEQAGgFAGAAQAEAAAGADIgGAMQgDgCgEAAQgHAAgHAIQgHAHgEAUIgGAfg");
	this.shape_161.setTransform(153.55,130.725);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#FFCC99").s().p("AgPAyQgEgDAAgFIACgMIAKgsIgLAAIACgLIALAAIAEgTIAOgJIgGAcIANAAIgCALIgNAAIgIAqIgCAKIABADIAEABIAIgBIgCALIgJACQgIAAgEgEg");
	this.shape_162.setTransform(148.825,129.475);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#FFCC99").s().p("AAMAoIAKgxIACgKQAAgEgDgCQgDgDgFAAQgKAAgHAHQgHAIgEARIgIAkIgNAAIAQhNIANAAIgEAOQAIgIAGgEQAHgEAHAAQAJAAAGAFQAFAFAAAJIgBAOIgLAug");
	this.shape_163.setTransform(141.85,130.725);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#FFCC99").s().p("AgVAlQgHgEgEgHQgEgHAAgKQAAgWANgOQAMgNAQAAQAPAAAIAJQAJAJAAAPQAAAMgGAMQgFALgKAGQgKAHgKAAQgJAAgIgEgAgFgbQgGADgEAGQgEAGgCAHQgCAHAAAGQAAALAGAGQAFAFAIAAIAHgBQAFgCADgEIAGgIIAEgJQADgHAAgGQAAgLgGgGQgFgGgIAAQgFAAgFADg");
	this.shape_164.setTransform(133.725,130.825);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#FFCC99").s().p("AgjAsQgMgMAAgXQAAgcASgTQAPgQAWAAQARAAALAJQALAIABAQIgNABQgCgLgHgGQgGgGgLAAQgTAAgMASQgLAPAAAUQABAQAHAJQAJAJAMAAQALAAAJgIQAJgHAEgOIAOADQgGATgNAJQgNAKgQAAQgTgBgLgLg");
	this.shape_165.setTransform(124.6,129.35);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#FFFFFF").s().p("AgIAHIADgOIAOAAIgDAOg");
	this.shape_166.setTransform(470.425,109.15);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#FFFFFF").s().p("AgPAyQgEgDAAgFIACgMIAKgsIgLAAIACgLIALAAIAEgTIAOgJIgGAcIANAAIgCALIgNAAIgIAqIgCAKIABADIAEABIAIgBIgCALIgJACQgIAAgEgEg");
	this.shape_167.setTransform(467.325,104.675);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#FFFFFF").s().p("AgfAiQgFgEAAgIIADgRIAJgsIANAAIgLAxIAAAKQgBAEADACQACADAGAAQAGAAAEgDQAFgDAEgEQADgEADgHIAEgNIAHgiIANAAIgQBNIgNAAIAEgOQgNAQgPAAQgJAAgGgGg");
	this.shape_168.setTransform(460.8,106.1);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#FFFFFF").s().p("AgVAlQgHgEgEgHQgEgHAAgKQAAgWANgOQAMgNAQAAQAPAAAIAJQAJAJAAAPQAAAMgGAMQgFALgKAGQgKAHgKAAQgJAAgIgEgAgFgbQgGADgEAGQgEAGgCAHQgCAHAAAGQAAALAGAGQAFAFAIAAIAHgBQAFgCADgEIAGgIIAEgJQADgHAAgGQAAgLgGgGQgFgGgIAAQgFAAgFADg");
	this.shape_169.setTransform(452.225,106.025);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#FFFFFF").s().p("AgYAiQgKgHABgPIANgBQAAAGACAEQACAEAFADQAEACAGAAQAIAAAFgDQAEgEAAgFQAAgDgDgDQgCgDgLgFIgMgFQgFgDgDgEQgCgEAAgFQAAgKAHgGQAIgHAMAAQAOAAAIAHQAIAHAAALIgNABQAAgHgFgEQgFgFgIAAQgGAAgEAEQgEADAAADQAAAEAEADQACACAIAEQAPAGAEADQAGAGAAAJQAAAGgDAFQgEAGgHADQgHAEgJAAQgOAAgJgHg");
	this.shape_170.setTransform(440.1988,106.025);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#FFFFFF").s().p("AAMAoIALgxIABgKQAAgEgCgCQgEgDgEAAQgKAAgIAHQgIAIgDARIgIAkIgNAAIAQhNIANAAIgEAOQAIgIAGgEQAHgEAHAAQAKAAAFAFQAFAFAAAJIgCAOIgKAug");
	this.shape_171.setTransform(432,105.925);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#FFFFFF").s().p("AgfAiQgFgEAAgIIADgRIAJgsIANAAIgLAxIgBAKQABAEACACQACADAGAAQAFAAAFgDQAFgDAEgEQADgEADgHIAEgNIAHgiIANAAIgQBNIgMAAIACgOQgNAQgOAAQgJAAgGgGg");
	this.shape_172.setTransform(424.1,106.1);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#FFFFFF").s().p("AgcAoIAQhNIAMAAIgDAQQAFgJAFgEQAGgFAGAAQAEAAAGADIgFAMQgEgCgEAAQgHAAgIAIQgFAHgFAUIgHAfg");
	this.shape_173.setTransform(417.85,105.925);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#FFFFFF").s().p("AgVAlQgGgEgEgIQgEgIAAgJQAAgMAFgMQAHgMAJgGQAKgGAJAAQAOAAAJAJQAIAIAAAPIgCALIg3AAIgBAEQAAALAFAGQAFAGAIAAQAFAAAHgFQAGgEAEgJIANACQgDAJgJAJQgLAJgMAAQgJAAgIgEgAgJgYQgHAGgEAMIArAAIAAgDQAAgKgEgFQgGgFgIAAQgHAAgHAFg");
	this.shape_174.setTransform(406.35,106.025);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#FFFFFF").s().p("AAhAoIAKgzIACgJQAAgDgDgDQgCgCgEAAQgGAAgGAEQgGADgEAGQgDAGgDALIgIAmIgMAAIALg0IABgHQAAgEgCgDQgCgCgFAAQgFAAgGAEQgGADgEAHQgEAGgDALIgIAlIgMAAIAQhNIANAAIgDANQAIgIAFgEQAHgDAGAAQAHAAAEAEQAFAEACAHQAFgIAHgDQAHgEAHAAQAKAAAEAFQAGAEAAAJIgCAMIgLAxg");
	this.shape_175.setTransform(395.8,105.925);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#FFFFFF").s().p("AgRA2IAQhNIANAAIgQBNgAACgmIADgPIANAAIgDAPg");
	this.shape_176.setTransform(388.325,104.525);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#FFFFFF").s().p("AgPAyQgEgDAAgFIACgMIAKgsIgLAAIACgLIALAAIAEgTIAOgJIgGAcIANAAIgCALIgNAAIgIAqIgCAKIABADIAEABIAIgBIgCALIgJACQgIAAgEgEg");
	this.shape_177.setTransform(384.775,104.675);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#FFFFFF").s().p("AgVAlQgHgEgDgIQgEgIAAgJQAAgMAFgMQAHgMAJgGQAKgGAJAAQAOAAAIAJQAJAIAAAPIgCALIg3AAIgBAEQAAALAFAGQAFAGAIAAQAFAAAHgFQAGgEAEgJIANACQgDAJgKAJQgKAJgMAAQgKAAgHgEgAgJgYQgHAGgEAMIArAAIAAgDQABgKgGgFQgEgFgJAAQgHAAgHAFg");
	this.shape_178.setTransform(373.85,106.025);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#FFFFFF").s().p("AAMA2IAKgvIACgMQAAgEgDgCQgCgDgFAAQgIAAgGAEQgGAEgDAGQgEAGgDAOIgHAiIgNAAIAWhrIANAAIgIAqQAHgIAGgDQAGgDAHAAQAJAAAGAFQAFAFAAAJIgCAOIgKAug");
	this.shape_179.setTransform(365.325,104.525);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#FFFFFF").s().p("AgPAyQgEgDAAgFIACgMIAKgsIgLAAIACgLIALAAIAEgTIAOgJIgGAcIANAAIgCALIgNAAIgIAqIgCAKIABADIAEABIAIgBIgCALIgJACQgIAAgEgEg");
	this.shape_180.setTransform(359.775,104.675);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#FFFFFF").s().p("AgVAlQgGgEgEgIQgEgIAAgJQAAgMAFgMQAHgMAJgGQAJgGAKAAQAOAAAJAJQAIAIAAAPQAAAGgCAFIg4AAIAAAEQAAALAFAGQAFAGAHAAQAHAAAGgFQAGgEAEgJIANACQgDAJgJAJQgLAJgNAAQgIAAgIgEgAgJgYQgHAGgEAMIArAAIAAgDQAAgKgEgFQgGgFgIAAQgHAAgHAFg");
	this.shape_181.setTransform(348.85,106.025);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#FFFFFF").s().p("AgcAoIAQhNIAMAAIgEAQQAFgJAHgEQAFgFAGAAQAEAAAGADIgFAMQgEgCgEAAQgHAAgIAIQgFAHgFAUIgHAfg");
	this.shape_182.setTransform(342.85,105.925);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#FFFFFF").s().p("AgVAlQgHgEgEgHQgEgHAAgKQAAgWANgOQAMgNAQAAQAPAAAIAJQAJAJAAAPQAAAMgGAMQgFALgKAGQgKAHgKAAQgJAAgIgEgAgFgbQgGADgEAGQgEAGgCAHQgCAHAAAGQAAALAGAGQAFAFAIAAIAHgBQAFgCADgEIAGgIIAEgJQADgHAAgGQAAgLgGgGQgFgGgIAAQgFAAgFADg");
	this.shape_183.setTransform(335.525,106.025);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#FFFFFF").s().p("AgaA2IAOhCIgMAAIACgLIAMAAIACgLQACgHACgEQACgEADgDQAFgCAGAAIAPACIgCAMQgHgCgEAAQgFAAgBACQgCACgCAIIgCAHIAPAAIgCALIgPAAIgNBCg");
	this.shape_184.setTransform(330.35,104.45);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#FFFFFF").s().p("AgUAlQgIgEgDgIQgEgIAAgJQAAgMAFgMQAHgMAJgGQAKgGAJAAQAOAAAIAJQAJAIAAAPIgCALIg3AAIgBAEQAAALAFAGQAFAGAIAAQAFAAAHgFQAGgEAEgJIANACQgDAJgKAJQgKAJgMAAQgJAAgHgEgAgJgYQgHAGgEAMIArAAIABgDQAAgKgGgFQgEgFgJAAQgHAAgHAFg");
	this.shape_185.setTransform(323,106.025);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#FFFFFF").s().p("AgNAyQgGgEgDgIIgDAPIgMAAIAXhrIANAAIgIAnQAGgGAEgCQAFgDAGAAQALAAAHAIQAIAIAAAPQAAAKgDAJQgDAIgFAGQgEAGgFAEQgEADgFACQgFACgEAAQgHAAgGgFgAgEgKQgGAGgEAKQgDAJAAAGIAAACQAAAKAFAFQAEAGAHAAQAGAAAGgFQAGgFAEgKQADgLAAgIQAAgJgEgGQgFgFgHAAQgHAAgFAFg");
	this.shape_186.setTransform(314.525,104.625);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#FFFFFF").s().p("AgYAiQgKgHABgPIANgBQAAAGACAEQACAEAFADQAEACAGAAQAIAAAFgDQAEgEAAgFQAAgDgDgDQgCgDgLgFIgMgFQgFgDgDgEQgCgEAAgFQAAgKAHgGQAIgHAMAAQAOAAAIAHQAIAHAAALIgNABQAAgHgFgEQgFgFgIAAQgGAAgEAEQgEADAAADQAAAEAEADQACACAIAEQAPAGAEADQAGAGAAAJQAAAGgDAFQgEAGgHADQgHAEgJAAQgOAAgJgHg");
	this.shape_187.setTransform(302.6488,106.025);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#FFFFFF").s().p("AgUAlQgIgEgDgIQgEgIAAgJQAAgMAGgMQAGgMAJgGQAKgGAJAAQAOAAAIAJQAJAIAAAPIgCALIg3AAIgBAEQAAALAFAGQAFAGAIAAQAFAAAHgFQAGgEAEgJIANACQgDAJgKAJQgKAJgMAAQgJAAgHgEgAgJgYQgHAGgEAMIArAAIABgDQAAgKgGgFQgEgFgJAAQgHAAgHAFg");
	this.shape_188.setTransform(294.65,106.025);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#FFFFFF").s().p("AgRA2IAWhrIANAAIgWBrg");
	this.shape_189.setTransform(289.075,104.525);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#FFFFFF").s().p("AgZAgQgIgIAAgPQAAgLAFgNQAFgMAKgGQAJgHALAAQAMAAAIAHQAHAHAAAMIgNABQAAgIgEgEQgFgEgGAAQgIAAgFAFQgGAFgEALQgCAJAAAJQAAAKADAFQAFAFAHAAQAFAAAGgFQAGgFADgKIANACQgEAOgJAHQgKAIgKAAQgOAAgHgJg");
	this.shape_190.setTransform(283.65,106.025);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#FFFFFF").s().p("AgdAiQgGgGAAgKQAAgHADgFQADgFAFgCQAFgDAHgBIAQgBQAMgBAGgCIABgJQAAgFgDgCQgFgEgJAAQgHAAgFAEQgGADgCAHIgOgBQAFgLAIgHQAJgGANAAQAOAAAJAHQAGAFAAAIQAAAHgCAIIgEASQgCAJAAAGIACALIgOAAIgBgKQgHAGgHADQgFADgHAAQgLAAgHgHgAAOABIgLABQgLABgEACQgFABgDAEQgCADAAAFQAAAFAEAEQAEADAHAAQAGAAAFgDQAHgEADgGQAEgGACgLIgGABg");
	this.shape_191.setTransform(275.325,106.025);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#FFFFFF").s().p("AgPAyQgEgDAAgFIACgMIAKgsIgLAAIACgLIALAAIAEgTIAOgJIgGAcIANAAIgCALIgNAAIgIAqIgCAKIABADIAEABIAIgBIgCALIgJACQgIAAgEgEg");
	this.shape_192.setTransform(269.725,104.675);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#FFFFFF").s().p("AgYAiQgKgHABgPIANgBQAAAGACAEQACAEAFADQAEACAGAAQAIAAAFgDQAEgEAAgFQAAgDgDgDQgCgDgLgFIgMgFQgFgDgDgEQgCgEAAgFQAAgKAHgGQAIgHAMAAQAOAAAIAHQAIAHAAALIgNABQAAgHgFgEQgFgFgIAAQgGAAgEAEQgEADAAADQAAAEAEADQACACAIAEQAPAGAEADQAGAGAAAJQAAAGgDAFQgEAGgHADQgHAEgJAAQgOAAgJgHg");
	this.shape_193.setTransform(263.4488,106.025);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#FFFFFF").s().p("AgNAyQgGgEgDgIIgDAPIgMAAIAXhrIANAAIgIAnQAGgGAEgCQAFgDAGAAQALAAAHAIQAIAIAAAPQAAAKgDAJQgDAIgFAGQgEAGgFAEQgEADgFACQgFACgEAAQgHAAgGgFgAgEgKQgGAGgEAKQgDAJAAAGIAAACQAAAKAFAFQAEAGAHAAQAGAAAGgFQAGgFAEgKQADgLAAgIQAAgJgEgGQgFgFgHAAQgHAAgFAFg");
	this.shape_194.setTransform(255.325,104.625);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#FFFFFF").s().p("AgVAlQgHgEgEgHQgEgHAAgKQAAgWANgOQAMgNAQAAQAPAAAIAJQAJAJAAAPQAAAMgGAMQgFALgKAGQgKAHgKAAQgJAAgIgEgAgFgbQgGADgEAGQgEAGgCAHQgCAHAAAGQAAALAGAGQAFAFAIAAIAHgBQAFgCADgEIAGgIIAEgJQADgHAAgGQAAgLgGgGQgFgGgIAAQgFAAgFADg");
	this.shape_195.setTransform(247.125,106.025);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#FFFFFF").s().p("AgpA1IABgMIAIABQAEAAACgCQAEgCADgHIAFgIIgOhNIAOAAIAFAoIAEAWIAig+IANAAIgwBYQgIAMgFAFQgGAEgHAAIgJgCg");
	this.shape_196.setTransform(235.25,107.575);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#FFFFFF").s().p("AAMAoIAKgxIACgKQAAgEgCgCQgEgDgFAAQgKAAgHAHQgHAIgEARIgIAkIgNAAIAQhNIANAAIgEAOQAIgIAGgEQAHgEAHAAQAJAAAGAFQAFAFAAAJIgBAOIgLAug");
	this.shape_197.setTransform(226.9,105.925);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#FFFFFF").s().p("AgdAiQgGgGAAgKQAAgHADgFQADgFAFgCQAFgDAHgBIAQgBQAMgBAGgCIABgJQAAgFgDgCQgFgEgJAAQgHAAgFAEQgGADgCAHIgOgBQAFgLAIgHQAJgGANAAQAOAAAJAHQAGAFAAAIQAAAHgCAIIgEASQgCAJAAAGIACALIgOAAIgBgKQgHAGgHADQgFADgHAAQgLAAgHgHgAAOABIgLABQgLABgEACQgFABgDAEQgCADAAAFQAAAFAEAEQAEADAHAAQAGAAAFgDQAHgEADgGQAEgGACgLIgGABg");
	this.shape_198.setTransform(218.625,106.025);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#FFFFFF").s().p("AgaA1QgHgCgDgFQgDgFAAgGIAAgEIANACQAAAEACACQAAABAAAAQABABAAAAQABABAAAAQABABAAAAQAEABAGAAQALAAAFgGQADgEADgOIACgGQgLAKgKAAQgMAAgIgIQgIgJAAgPQAAgNAGgLQAHgLAIgGQAJgFAIAAQAPAAAJAOIACgNIAMAAIgPBLQgDAMgEAHQgEAHgIAEQgGADgKAAQgJAAgHgCgAgGgpQgFADgDAFQgEAFgCAIIgCALQAAAIABADQACAFAEADQAEADAFAAQAGAAAGgEQAHgFAEgIQAEgKAAgJQAAgJgFgGQgGgGgIAAQgEAAgEADg");
	this.shape_199.setTransform(206.275,107.475);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#FFFFFF").s().p("AAMAoIALgxIABgKQAAgEgCgCQgEgDgEAAQgLAAgGAHQgJAIgDARIgIAkIgNAAIAQhNIAMAAIgCAOQAHgIAGgEQAHgEAHAAQAJAAAGAFQAFAFAAAJIgCAOIgJAug");
	this.shape_200.setTransform(197.7,105.925);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#FFFFFF").s().p("AgRA2IAQhNIANAAIgQBNgAACgmIADgPIANAAIgDAPg");
	this.shape_201.setTransform(192.375,104.525);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#FFFFFF").s().p("AgPAyQgEgDAAgFIACgMIAKgsIgLAAIACgLIALAAIAEgTIAOgJIgGAcIANAAIgCALIgNAAIgIAqIgCAKIABADIAEABIAIgBIgCALIgJACQgIAAgEgEg");
	this.shape_202.setTransform(188.825,104.675);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#FFFFFF").s().p("AgPAyQgEgDAAgFIACgMIAKgsIgLAAIACgLIALAAIAEgTIAOgJIgGAcIANAAIgCALIgNAAIgIAqIgCAKIABADIAEABIAIgBIgCALIgJACQgIAAgEgEg");
	this.shape_203.setTransform(184.675,104.675);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#FFFFFF").s().p("AgRA2IAQhNIANAAIgQBNgAACgmIADgPIANAAIgDAPg");
	this.shape_204.setTransform(180.725,104.525);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#FFFFFF").s().p("AAMA2IAKgvIACgMQAAgEgDgCQgCgDgFAAQgIAAgGAEQgGAEgDAGQgEAGgDAOIgHAiIgNAAIAWhrIANAAIgIAqQAHgIAGgDQAGgDAHAAQAJAAAGAFQAFAFAAAJIgCAOIgKAug");
	this.shape_205.setTransform(174.375,104.525);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#FFFFFF").s().p("AgPAyQgEgDAAgFIACgMIAKgsIgLAAIACgLIALAAIAEgTIAOgJIgGAcIANAAIgCALIgNAAIgIAqIgCAKIABADIAEABIAIgBIgCALIgJACQgIAAgEgEg");
	this.shape_206.setTransform(164.675,104.675);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#FFFFFF").s().p("AgfAiQgFgEAAgIIADgRIAJgsIANAAIgLAxIgBAKQABAEACACQACADAGAAQAFAAAFgDQAFgDAEgEQADgEADgHIAEgNIAHgiIANAAIgQBNIgMAAIADgOQgOAQgOAAQgJAAgGgGg");
	this.shape_207.setTransform(158.15,106.1);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#FFFFFF").s().p("AgVAlQgHgEgEgHQgEgHAAgKQAAgWANgOQAMgNAQAAQAPAAAIAJQAJAJAAAPQAAAMgGAMQgFALgKAGQgKAHgKAAQgJAAgIgEgAgFgbQgGADgEAGQgEAGgCAHQgCAHAAAGQAAALAGAGQAFAFAIAAIAHgBQAFgCADgEIAGgIIAEgJQADgHAAgGQAAgLgGgGQgFgGgIAAQgFAAgFADg");
	this.shape_208.setTransform(149.575,106.025);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#FFFFFF").s().p("AAMA2IAKgvIACgMQAAgEgDgCQgCgDgFAAQgIAAgGAEQgGAEgDAGQgEAGgDAOIgHAiIgNAAIAWhrIANAAIgIAqQAHgIAGgDQAGgDAHAAQAJAAAGAFQAFAFAAAJIgCAOIgKAug");
	this.shape_209.setTransform(141.025,104.525);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#FFFFFF").s().p("AgPAyQgEgDAAgFIACgMIAKgsIgLAAIACgLIALAAIAEgTIAOgJIgGAcIANAAIgCALIgNAAIgIAqIgCAKIABADIAEABIAIgBIgCALIgJACQgIAAgEgEg");
	this.shape_210.setTransform(135.475,104.675);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#FFFFFF").s().p("AgRA2IAQhNIANAAIgQBNgAACgmIADgPIANAAIgDAPg");
	this.shape_211.setTransform(131.525,104.525);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#FFFFFF").s().p("AABAnIgCgsIgBgRIgGARIgWAsIgNAAIgIhNIAMAAIAEAjIACATIAAAIIADgLIAGgLIASgoIAOAAIACAmIABAYIALgaIARgkIAOAAIgnBNg");
	this.shape_212.setTransform(124.85,106);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#FFFFFF").s().p("AgUAlQgIgEgDgIQgEgIAAgJQAAgMAGgMQAFgMAKgGQAJgGAKAAQAOAAAIAJQAJAIAAAPIgCALIg3AAIgBAEQAAALAFAGQAFAGAIAAQAFAAAHgFQAGgEAEgJIANACQgDAJgKAJQgKAJgMAAQgKAAgGgEgAgJgYQgHAGgDAMIAqAAIABgDQAAgKgGgFQgFgFgHAAQgIAAgHAFg");
	this.shape_213.setTransform(489.75,87.225);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#FFFFFF").s().p("AgZAgQgIgIAAgPQAAgLAFgNQAFgMAKgGQAJgHALAAQAMAAAIAHQAHAHAAAMIgNABQAAgIgEgEQgFgEgGAAQgIAAgFAFQgGAFgEALQgCAJAAAJQAAAKADAFQAFAFAHAAQAFAAAGgFQAGgFADgKIANACQgEAOgJAHQgKAIgKAAQgOAAgHgJg");
	this.shape_214.setTransform(482.1,87.225);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#FFFFFF").s().p("AgdAiQgGgGAAgKQAAgHADgFQADgFAFgCQAFgDAHgBIAQgBQAMgBAGgCIABgJQAAgFgDgCQgFgEgJAAQgHAAgFAEQgGADgCAHIgOgBQAFgLAIgHQAJgGANAAQAOAAAJAHQAGAFAAAIQAAAHgCAIIgEASQgCAJAAAGIACALIgOAAIgBgKQgHAGgHADQgFADgHAAQgLAAgHgHgAAOABIgLABQgLABgEACQgFABgDAEQgCADAAAFQAAAFAEAEQAEADAHAAQAGAAAFgDQAHgEADgGQAEgGACgLIgGABg");
	this.shape_215.setTransform(473.775,87.225);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#FFFFFF").s().p("AgoA3IAWhrIANAAIgDALQAHgHAFgDQAFgDAGAAQALAAAHAIQAIAIAAAPQAAANgFAKQgEAJgFAGQgGAGgGADQgGADgGAAQgOAAgHgPIgJArgAABgoQgDACgDAGQgEAFgCAIQgDAHAAAGQAAAIACADQABAFAEADQAFADAEAAQALAAAIgNQAGgMAAgNQABgKgFgGQgFgFgHAAQgFAAgFADg");
	this.shape_216.setTransform(465.1,88.625);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#FFFFFF").s().p("AgYAiQgKgHABgPIANgBQAAAGACAEQACAEAFADQAEACAGAAQAIAAAFgDQAEgEAAgFQAAgDgDgDQgCgDgLgFIgMgFQgFgDgDgEQgCgEAAgFQAAgKAHgGQAIgHAMAAQAOAAAIAHQAIAHAAALIgNABQAAgHgFgEQgFgFgIAAQgGAAgEAEQgEADAAADQAAAEAEADQACACAIAEQAPAGAEADQAGAGAAAJQAAAGgDAFQgEAGgHADQgHAEgJAAQgOAAgJgHg");
	this.shape_217.setTransform(457.6988,87.225);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#FFFFFF").s().p("AgaA1QgHgCgDgFQgDgFAAgGIAAgEIANACQAAAEACACQAAABAAAAQABABAAAAQABABAAAAQABABAAAAQAEABAGAAQALAAAFgGQADgEADgOIACgGQgLAKgKAAQgMAAgIgIQgIgJAAgPQAAgNAGgLQAHgLAIgGQAJgFAIAAQAPAAAJAOIACgNIAMAAIgPBLQgDAMgEAHQgEAHgIAEQgGADgKAAQgJAAgHgCgAgGgpQgFADgDAFQgEAFgCAIIgCALQAAAIABADQACAFAEADQAEADAFAAQAGAAAGgEQAHgFAEgIQAEgKAAgJQAAgJgFgGQgGgGgIAAQgEAAgEADg");
	this.shape_218.setTransform(445.575,88.675);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#FFFFFF").s().p("AAMAoIALgxIABgKQAAgEgDgCQgDgDgEAAQgLAAgGAHQgJAIgDARIgIAkIgNAAIAQhNIAMAAIgCAOQAHgIAGgEQAHgEAHAAQAKAAAFAFQAFAFAAAJIgCAOIgJAug");
	this.shape_219.setTransform(437,87.125);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#FFFFFF").s().p("AgRA2IAQhNIANAAIgQBNgAACgmIADgPIANAAIgDAPg");
	this.shape_220.setTransform(431.675,85.725);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#FFFFFF").s().p("AALA2IgOgoIgQAOIgFAaIgOAAIAXhrIANAAIgOBCIAlgkIASAAIghAcIAUAxg");
	this.shape_221.setTransform(426.35,85.725);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#FFFFFF").s().p("AgcAoIAQhNIAMAAIgDAQQAEgJAHgEQAFgFAGAAQAEAAAGADIgFAMQgEgCgEAAQgHAAgIAIQgFAHgFAUIgHAfg");
	this.shape_222.setTransform(420.35,87.125);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#FFFFFF").s().p("AgdAiQgGgGAAgKQAAgHADgFQADgFAFgCQAFgDAHgBIAQgBQAMgBAGgCIABgJQAAgFgDgCQgFgEgJAAQgHAAgFAEQgGADgCAHIgOgBQAFgLAIgHQAJgGANAAQAOAAAJAHQAGAFAAAIQAAAHgCAIIgEASQgCAJAAAGIACALIgOAAIgBgKQgHAGgHADQgFADgHAAQgLAAgHgHgAAOABIgLABQgLABgEACQgFABgDAEQgCADAAAFQAAAFAEAEQAEADAHAAQAGAAAFgDQAHgEADgGQAEgGACgLIgGABg");
	this.shape_223.setTransform(412.875,87.225);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#FFFFFF").s().p("AgoA3IAXhrIAMAAIgCALQAGgHAEgDQAGgDAGAAQALAAAHAIQAIAIAAAPQAAANgEAKQgEAJgGAGQgGAGgGADQgGADgGAAQgNAAgIgPIgJArgAACgoQgEACgDAGQgEAFgDAIQgCAHAAAGQAAAIABADQACAFAFADQAEADAEAAQALAAAIgNQAGgMABgNQAAgKgFgGQgFgFgHAAQgFAAgEADg");
	this.shape_224.setTransform(404.2,88.625);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#FFFFFF").s().p("AggAuQgIgIAAgPQAAgPAGgKQAGgMAJgGQAIgGAJAAQAOAAAHAOIAJgqIANAAIgWBrIgNAAIADgMQgLAOgMAAQgLAAgHgJgAgKgNQgEACgEAFIgGAMQgDAIAAAGQAAAIACAFQACAFADADQAEADAGAAQAJAAAGgJQAKgNAAgSQAAgIgFgGQgFgFgGAAQgFAAgEACg");
	this.shape_225.setTransform(392.625,85.825);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#FFFFFF").s().p("AgUAlQgHgEgFgIQgDgIAAgJQAAgMAGgMQAFgMAKgGQAJgGAKAAQAOAAAIAJQAJAIAAAPIgBALIg5AAIAAAEQAAALAFAGQAFAGAHAAQAHAAAGgFQAHgEADgJIANACQgDAJgKAJQgKAJgNAAQgIAAgHgEgAgJgYQgHAGgDAMIAqAAIABgDQgBgKgFgFQgEgFgIAAQgIAAgHAFg");
	this.shape_226.setTransform(383.8,87.225);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#FFFFFF").s().p("AAMA2IgPgoIgQAOIgFAaIgOAAIAXhrIANAAIgOBCIAlgkIASAAIghAcIAUAxg");
	this.shape_227.setTransform(376.3,85.725);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#FFFFFF").s().p("AgcAoIAQhNIAMAAIgEAQQAFgJAHgEQAFgFAGAAQAEAAAGADIgFAMQgEgCgEAAQgHAAgIAIQgFAHgFAUIgHAfg");
	this.shape_228.setTransform(370.3,87.125);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#FFFFFF").s().p("AgdAiQgGgGAAgKQAAgHADgFQADgFAFgCQAFgDAHgBIAQgBQAMgBAGgCIABgJQAAgFgDgCQgFgEgJAAQgHAAgFAEQgGADgCAHIgOgBQAFgLAIgHQAJgGANAAQAOAAAJAHQAGAFAAAIQAAAHgCAIIgEASQgCAJAAAGIACALIgOAAIgBgKQgHAGgHADQgFADgHAAQgLAAgHgHgAAOABIgLABQgLABgEACQgFABgDAEQgCADAAAFQAAAFAEAEQAEADAHAAQAGAAAFgDQAHgEADgGQAEgGACgLIgGABg");
	this.shape_229.setTransform(362.825,87.225);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#FFFFFF").s().p("AAhAoIALgzIABgJQAAgDgCgDQgDgCgEAAQgGAAgGAEQgHADgDAGQgDAGgDALIgIAmIgMAAIALg0IABgHQAAgEgCgDQgDgCgEAAQgFAAgGAEQgGADgEAHQgEAGgCALIgIAlIgNAAIAPhNIAOAAIgDANQAIgIAFgEQAGgDAHAAQAGAAAFAEQAFAEABAHQAHgIAGgDQAGgEAIAAQAKAAAFAFQAEAEABAJIgDAMIgKAxg");
	this.shape_230.setTransform(352.4,87.125);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#FFFFFF").s().p("AgVAlQgGgEgEgIQgEgIAAgJQAAgMAFgMQAHgMAJgGQAKgGAJAAQAOAAAJAJQAIAIAAAPIgCALIg4AAIAAAEQAAALAFAGQAFAGAIAAQAFAAAHgFQAGgEAEgJIANACQgDAJgJAJQgLAJgMAAQgJAAgIgEgAgJgYQgHAGgEAMIArAAIAAgDQAAgKgEgFQgFgFgJAAQgHAAgHAFg");
	this.shape_231.setTransform(337.95,87.225);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#FFFFFF").s().p("AAMA2IAKgvIACgMQAAgEgDgCQgCgDgFAAQgIAAgGAEQgGAEgDAGQgEAGgDAOIgHAiIgNAAIAWhrIANAAIgIAqQAHgIAGgDQAGgDAHAAQAJAAAGAFQAFAFAAAJIgCAOIgKAug");
	this.shape_232.setTransform(329.425,85.725);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#FFFFFF").s().p("AgPAyQgEgDAAgFIACgMIAKgsIgLAAIACgLIALAAIAEgTIAOgJIgGAcIANAAIgCALIgNAAIgIAqIgCAKIABADIAEABIAIgBIgCALIgJACQgIAAgEgEg");
	this.shape_233.setTransform(323.875,85.875);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#FFFFFF").s().p("AgVAlQgHgEgEgHQgEgHAAgKQAAgWANgOQAMgNAQAAQAPAAAIAJQAJAJAAAPQAAAMgGAMQgFALgKAGQgKAHgKAAQgJAAgIgEgAgFgbQgGADgEAGQgEAGgCAHQgCAHAAAGQAAALAGAGQAFAFAIAAIAHgBQAFgCADgEIAGgIIAEgJQADgHAAgGQAAgLgGgGQgFgGgIAAQgFAAgFADg");
	this.shape_234.setTransform(312.975,87.225);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#FFFFFF").s().p("AgPAyQgEgDAAgFIACgMIAKgsIgLAAIACgLIALAAIAEgTIAOgJIgGAcIANAAIgCALIgNAAIgIAqIgCAKIABADIAEABIAIgBIgCALIgJACQgIAAgEgEg");
	this.shape_235.setTransform(307.225,85.875);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#FFFFFF").s().p("AAMAoIAKgxIACgKQAAgEgDgCQgDgDgFAAQgKAAgHAHQgHAIgEARIgIAkIgNAAIAQhNIANAAIgEAOQAIgIAGgEQAHgEAHAAQAJAAAGAFQAFAFAAAJIgBAOIgLAug");
	this.shape_236.setTransform(300.25,87.125);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#FFFFFF").s().p("AgRA2IAQhNIANAAIgQBNgAACgmIADgPIANAAIgDAPg");
	this.shape_237.setTransform(294.925,85.725);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#FFFFFF").s().p("AgpA1IABgMIAIABQAEAAADgCQACgCAFgHIADgIIgMhNIAMAAIAHAoIACAWIAig+IAOAAIgxBYQgGAMgGAFQgGAEgHAAIgJgCg");
	this.shape_238.setTransform(285.25,88.775);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#FFFFFF").s().p("AgRA2IAWhrIANAAIgWBrg");
	this.shape_239.setTransform(279.875,85.725);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#FFFFFF").s().p("AgUAlQgIgEgDgIQgEgIAAgJQAAgMAGgMQAFgMAKgGQAJgGAKAAQAOAAAIAJQAJAIAAAPIgCALIg3AAIgBAEQAAALAFAGQAFAGAIAAQAFAAAHgFQAGgEAEgJIANACQgDAJgKAJQgKAJgMAAQgKAAgGgEgAgJgYQgHAGgDAMIAqAAIABgDQAAgKgGgFQgFgFgHAAQgIAAgHAFg");
	this.shape_240.setTransform(273.75,87.225);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#FFFFFF").s().p("AgPAyQgEgDAAgFIACgMIAKgsIgLAAIACgLIALAAIAEgTIAOgJIgGAcIANAAIgCALIgNAAIgIAqIgCAKIABADIAEABIAIgBIgCALIgJACQgIAAgEgEg");
	this.shape_241.setTransform(268.025,85.875);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#FFFFFF").s().p("AgdAiQgGgGAAgKQAAgHADgFQADgFAFgCQAFgDAHgBIAQgBQAMgBAGgCIABgJQAAgFgDgCQgFgEgJAAQgHAAgFAEQgGADgCAHIgOgBQAFgLAIgHQAJgGANAAQAOAAAJAHQAGAFAAAIQAAAHgCAIIgEASQgCAJAAAGIACALIgOAAIgBgKQgHAGgHADQgFADgHAAQgLAAgHgHgAAOABIgLABQgLABgEACQgFABgDAEQgCADAAAFQAAAFAEAEQAEADAHAAQAGAAAFgDQAHgEADgGQAEgGACgLIgGABg");
	this.shape_242.setTransform(261.125,87.225);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#FFFFFF").s().p("AgcAoIAQhNIAMAAIgEAQQAGgJAFgEQAGgFAGAAQAEAAAGADIgGAMQgDgCgEAAQgHAAgHAIQgHAHgEAUIgGAfg");
	this.shape_243.setTransform(255.25,87.125);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#FFFFFF").s().p("AgfAiQgFgEAAgIIADgRIAJgsIANAAIgLAxIgBAKQABAEACACQACADAGAAQAFAAAFgDQAFgDAEgEQADgFADgGIAEgNIAHgiIANAAIgQBNIgMAAIADgOQgOAQgOAAQgJAAgGgGg");
	this.shape_244.setTransform(248.15,87.3);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#FFFFFF").s().p("AgZAgQgIgIAAgPQAAgLAFgNQAFgMAJgGQAKgHALAAQANAAAHAHQAHAHAAAMIgNABQAAgIgEgEQgFgEgGAAQgIAAgFAFQgGAFgEALQgCAJAAAJQAAAKADAFQAFAFAGAAQAGAAAGgFQAGgFADgKIANACQgFAOgIAHQgKAIgLAAQgNAAgHgJg");
	this.shape_245.setTransform(240.25,87.225);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#FFFFFF").s().p("AgZAgQgIgIAAgPQAAgLAFgNQAFgMAKgGQAJgHALAAQANAAAHAHQAHAHAAAMIgNABQAAgIgEgEQgEgEgIAAQgGAAgGAFQgGAFgDALQgEAJAAAJQAAAKAFAFQAEAFAGAAQAGAAAGgFQAGgFADgKIAOACQgFAOgKAHQgJAIgLAAQgMAAgIgJg");
	this.shape_246.setTransform(232.75,87.225);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#FFFFFF").s().p("AgdAiQgGgGAAgKQAAgHADgFQADgFAFgCQAFgDAHgBIAQgBQAMgBAGgCIABgJQAAgFgDgCQgFgEgJAAQgHAAgFAEQgGADgCAHIgOgBQAFgLAIgHQAJgGANAAQAOAAAJAHQAGAFAAAIQAAAHgCAIIgEASQgCAJAAAGIACALIgOAAIgBgKQgHAGgHADQgFADgHAAQgLAAgHgHgAAOABIgLABQgLABgEACQgFABgDAEQgCADAAAFQAAAFAEAEQAEADAHAAQAGAAAFgDQAHgEADgGQAEgGACgLIgGABg");
	this.shape_247.setTransform(224.425,87.225);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#FFFFFF").s().p("AgcAoIAQhNIAMAAIgEAQQAGgJAGgEQAFgFAGAAQAEAAAGADIgGAMQgDgCgEAAQgHAAgHAIQgHAHgEAUIgGAfg");
	this.shape_248.setTransform(214.4,87.125);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#FFFFFF").s().p("AgUAlQgHgEgFgIQgDgIAAgJQAAgMAGgMQAFgMAKgGQAKgGAJAAQAOAAAIAJQAJAIAAAPIgBALIg4AAIgBAEQAAALAFAGQAFAGAHAAQAHAAAGgFQAGgEAEgJIANACQgDAJgKAJQgKAJgNAAQgIAAgHgEgAgJgYQgHAGgDAMIAqAAIABgDQgBgKgFgFQgFgFgHAAQgIAAgHAFg");
	this.shape_249.setTransform(207.05,87.225);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#FFFFFF").s().p("AgRA2IAWhrIANAAIgWBrg");
	this.shape_250.setTransform(201.475,85.725);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#FFFFFF").s().p("AgRA2IAQhNIANAAIgQBNgAACgmIADgPIANAAIgDAPg");
	this.shape_251.setTransform(198.175,85.725);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#FFFFFF").s().p("AgdAiQgGgGAAgKQAAgHADgFQADgFAFgCQAFgDAHgBIAQgBQAMgBAGgCIABgJQAAgFgDgCQgFgEgJAAQgHAAgFAEQgGADgCAHIgOgBQAFgLAIgHQAJgGANAAQAOAAAJAHQAGAFAAAIQAAAHgCAIIgEASQgCAJAAAGIACALIgOAAIgBgKQgHAGgHADQgFADgHAAQgLAAgHgHgAAOABIgLABQgLABgEACQgFABgDAEQgCADAAAFQAAAFAEAEQAEADAHAAQAGAAAFgDQAHgEADgGQAEgGACgLIgGABg");
	this.shape_252.setTransform(191.875,87.225);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#FFFFFF").s().p("AgcAoIAQhNIAMAAIgDAQQAFgJAGgEQAFgFAGAAQAEAAAGADIgFAMQgEgCgEAAQgHAAgIAIQgFAHgFAUIgHAfg");
	this.shape_253.setTransform(186,87.125);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#FFFFFF").s().p("AgPAyQgEgDAAgFIACgMIAKgsIgLAAIACgLIALAAIAEgTIAOgJIgGAcIANAAIgCALIgNAAIgIAqIgCAKIABADIAEABIAIgBIgCALIgJACQgIAAgEgEg");
	this.shape_254.setTransform(181.275,85.875);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#FFFFFF").s().p("AgUAlQgIgEgDgIQgEgIAAgJQAAgMAGgMQAFgMAKgGQAKgGAJAAQAOAAAIAJQAJAIAAAPIgCALIg3AAIgBAEQAAALAFAGQAFAGAIAAQAFAAAHgFQAHgEADgJIANACQgDAJgKAJQgKAJgMAAQgKAAgGgEgAgJgYQgHAGgDAMIAqAAIABgDQAAgKgGgFQgFgFgHAAQgIAAgHAFg");
	this.shape_255.setTransform(170.35,87.225);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#FFFFFF").s().p("AAMA2IAKgvIACgMQAAgEgDgCQgCgDgFAAQgIAAgGAEQgGAEgDAGQgEAGgDAOIgHAiIgNAAIAWhrIANAAIgIAqQAHgIAGgDQAGgDAHAAQAJAAAGAFQAFAFAAAJIgCAOIgKAug");
	this.shape_256.setTransform(161.825,85.725);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#FFFFFF").s().p("AgPAyQgEgDAAgFIACgMIAKgsIgLAAIACgLIALAAIAEgTIAOgJIgGAcIANAAIgCALIgNAAIgIAqIgCAKIABADIAEABIAIgBIgCALIgJACQgIAAgEgEg");
	this.shape_257.setTransform(156.275,85.875);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#FFFFFF").s().p("AALA2IgOgoIgQAOIgGAaIgNAAIAWhrIAOAAIgOBCIAlgkIASAAIghAcIAUAxg");
	this.shape_258.setTransform(146.2,85.725);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#FFFFFF").s().p("AgcAoIAQhNIAMAAIgDAQQAFgJAFgEQAGgFAGAAQAEAAAGADIgFAMQgEgCgEAAQgHAAgIAIQgFAHgFAUIgHAfg");
	this.shape_259.setTransform(140.2,87.125);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#FFFFFF").s().p("AgdAiQgGgGAAgKQAAgHADgFQADgFAFgCQAFgDAHgBIAQgBQAMgBAGgCIABgJQAAgFgDgCQgFgEgJAAQgHAAgFAEQgGADgCAHIgOgBQAFgLAIgHQAJgGANAAQAOAAAJAHQAGAFAAAIQAAAHgCAIIgEASQgCAJAAAGIACALIgOAAIgBgKQgHAGgHADQgFADgHAAQgLAAgHgHgAAOABIgLABQgLABgEACQgFABgDAEQgCADAAAFQAAAFAEAEQAEADAHAAQAGAAAFgDQAHgEADgGQAEgGACgLIgGABg");
	this.shape_260.setTransform(132.725,87.225);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#FFFFFF").s().p("AgwA2IAWhrIAsAAQAMAAAGADQAFADAEAGQAEAHAAAIQAAAGgDAHQgDAHgDAFQgEADgFACQgEADgFABQgKACgLAAIgaAAIgJAsgAgWgBIAWAAQAPAAAGgDQAHgDADgGQAEgGAAgHQAAgFgCgDQgCgEgEgBQgDgCgLAAIgaAAg");
	this.shape_261.setTransform(124,85.725);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#D9D9D9").s().p("AgaAoQgJgIgCgQIATgCQABAKAFAEQAFAFAIgBQAJAAAFgDQAEgEAAgFQAAgEgCgCQgCgCgFgCIgNgFQgQgDgGgFQgJgHAAgLQAAgIAFgFQADgHAIgDQAIgDAKAAQARAAAJAHQAJAIAAANIgTABQgBgHgEgEQgDgDgIAAQgIABgEADQgEACAAADQAAAEAEACQADADANADQAOADAGAEQAHAEADAEQAEAHAAAJQAAAHgEAIQgFAGgIAEQgJADgMAAQgQAAgKgIg");
	this.shape_262.setTransform(201.75,54.65);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#D9D9D9").s().p("AASAvIgkg8IAAA8IgSAAIAAhcIASAAIAlA8IAAg8IASAAIAABcg");
	this.shape_263.setTransform(192.75,54.65);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#D9D9D9").s().p("AggAkQgMgNAAgWQAAgNAEgLQADgGAGgGQAFgFAHgDQAJgEAKAAQAUAAANANQAMANAAAVQAAAXgMANQgMAMgVAAQgUAAgMgMgAgSgXQgHAIAAAPQAAAPAIAJQAHAIAKAAQALAAAIgIQAHgIAAgQQAAgQgHgHQgHgIgMAAQgLAAgHAIg");
	this.shape_264.setTransform(183.075,54.65);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#D9D9D9").s().p("AgIAvIAAhcIARAAIAABcg");
	this.shape_265.setTransform(176.225,54.65);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#D9D9D9").s().p("AgIAvIAAhNIgcAAIAAgPIBJAAIAAAPIgcAAIAABNg");
	this.shape_266.setTransform(170.425,54.65);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#D9D9D9").s().p("AgcAkQgLgNAAgWQAAgWALgNQANgNASAAQARAAALAKQAGAGAEALIgTAFQgCgIgFgEQgFgEgIAAQgJAAgGAIQgHAHAAAQQAAARAHAHQAFAIAKAAQAHAAAGgEQAFgGADgKIASAGQgFAQgJAGQgKAIgPAAQgRAAgNgMg");
	this.shape_267.setTransform(161.7,54.65);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#D9D9D9").s().p("AgSAsQgHgDgEgFQgEgFgBgFQgCgIAAgQIAAgwIATAAIAAAxQAAAMABAEQABAFAEAEQAEADAIAAQAHAAAEgDQAEgDACgFIAAgQIAAgyIATAAIAAAwQAAAQgBAHQgCAHgEAFQgEAFgHADQgHACgLAAQgMAAgHgDg");
	this.shape_268.setTransform(152.3,54.725);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#D9D9D9").s().p("AATAvIgNgUIgJgPQgDgCgDgBIgJgBIgEAAIAAAnIgTAAIAAhcIAoAAQAOAAAHACQAGADAEAGQAEAHAAAHQAAALgGAHQgGAFgMACQAGAEAEAEIALAQIALASgAgWgGIAOAAQAMAAAEgBQADgBACgEQACgCAAgEQAAgFgCgDQgDgDgFgBIgMAAIgPAAg");
	this.shape_269.setTransform(143.375,54.65);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#D9D9D9").s().p("AgIAvIAAhNIgcAAIAAgPIBJAAIAAAPIgcAAIAABNg");
	this.shape_270.setTransform(134.275,54.65);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#D9D9D9").s().p("AgaAoQgJgIgCgQIASgCQACAKAFAEQAFAFAIgBQAJAAAEgDQAFgEAAgFQAAgEgCgCQgCgCgEgCIgOgFQgQgDgGgFQgJgHABgLQAAgIADgFQAEgHAIgDQAIgDAKAAQARAAAJAHQAJAIAAANIgTABQgBgHgDgEQgFgDgHAAQgIABgEADQgDACAAADQAAAEADACQADADANADQANADAHAEQAGAEAEAEQAEAHAAAJQAAAHgFAIQgEAGgIAEQgIADgNAAQgQAAgKgIg");
	this.shape_271.setTransform(125.9,54.65);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#D9D9D9").s().p("AASAvIglg8IAAA8IgRAAIAAhcIASAAIAmA8IAAg8IARAAIAABcg");
	this.shape_272.setTransform(116.9,54.65);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#D9D9D9").s().p("AgIAvIAAhcIARAAIAABcg");
	this.shape_273.setTransform(110.475,54.65);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_274.setTransform(394.575,264.975);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#D9D9D9").s().p("AgUAhQgGgHAAgNQAAgKADgJQADgLAEgGQADgGAEgEIAIgFQADgBAEAAQAJAAAGAGQAGAHAAANQAAANgEAMQgFAPgIAHQgIAGgHAAQgJAAgGgHgAAAgeQgEACgDAFQgEAHgDAOQgDAKAAAHQAAAIACAEQAEAFAGAAQAFAAAEgFQAHgHADgOQAEgNAAgJQAAgIgEgEQgDgEgFAAQgEAAgCACg");
	this.shape_275.setTransform(390,265.025);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#D9D9D9").s().p("AgFAGIABgKIAKAAIgCAKg");
	this.shape_276.setTransform(384.75,268.35);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#D9D9D9").s().p("AABAnIAEgUIgfAAIACgJIArgwIAIAAIgLAxIALAAIgBAIIgLAAIgFAUgAgPALIAWAAIAHggg");
	this.shape_277.setTransform(380.575,264.975);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_278.setTransform(376.275,264.975);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#D9D9D9").s().p("AgeAnIABgJIAGABQAAAAABAAQABAAAAAAQABgBAAAAQABAAAAAAIAGgHIADgGIgKg4IAKAAIAEAdIACAQIAZgtIAKAAIgjA/QgGAKgEADQgEADgFAAIgHgBg");
	this.shape_279.setTransform(371.875,267.2);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#D9D9D9").s().p("AgJAlQgEgDgDgGIgCALIgJAAIARhOIAKAAIgGAcQAEgFADgBQAEgCAEAAQAIAAAFAGQAGAGAAALQAAAHgDAGQgCAHgDAEIgGAGQgEAEgDABIgHABQgFAAgEgDgAgDgHQgEAEgDAHIgCALIAAACQAAAHADAEQAEAEAFAAQAEAAAEgDQAFgFACgHQADgIAAgGQAAgGgDgEQgEgEgFAAQgFAAgEAEg");
	this.shape_280.setTransform(365.825,265.05);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_281.setTransform(361.625,264.975);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKAAIABAGQABAEAEACQADABAFAAQAFAAADgCQAEgDAAgEQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBgBAAAAQgCgDgIgDIgJgEQgEgCgBgCQgCgEAAgEQAAgGAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgGgEgDQgDgDgGAAQgFABgCACQgDACAAADQAAADACABIAIAFQALAFADACQAEAEAAAGQAAAEgCAFQgDAEgFADQgGACgGAAQgKAAgHgFg");
	this.shape_282.setTransform(357.1233,266.05);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#D9D9D9").s().p("AgOAbQgGgDgCgFQgEgGAAgIQAAgHAFgKQAFgIAGgEQAHgFAHAAQAKAAAHAGQAFAHAAALIgBAIIgpAAIAAACQAAAIAEAFQAEAEAFAAQAEAAAFgDQAFgEADgGIAJABQgCAHgHAGQgIAHgJAAQgGAAgFgDgAgGgRQgFAEgCAJIAeAAIAAgCQAAgHgDgEQgEgFgFAAQgGABgFAEg");
	this.shape_283.setTransform(351.25,266.05);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKAAIABAGQABAEAEACQADABAFAAQAFAAADgCQAEgDAAgEQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBgBAAAAQgCgDgIgDIgJgEQgEgCgBgCQgCgEAAgEQAAgGAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgGgEgDQgDgDgGAAQgFABgCACQgDACAAADQAAADACABIAIAFQALAFADACQAEAEAAAGQAAAEgCAFQgDAEgFADQgGACgGAAQgKAAgHgFg");
	this.shape_284.setTransform(345.5233,266.05);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_285.setTransform(339.525,265.975);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#D9D9D9").s().p("AgOAbQgGgDgDgFQgCgGAAgIQgBgHAFgKQAEgIAHgEQAHgFAHAAQAKAAAHAGQAFAHABALIgCAIIgoAAIAAACQgBAIAEAFQAEAEAFAAQAEAAAFgDQAFgEACgGIAKABQgCAHgIAGQgHAHgJAAQgGAAgFgDgAgGgRQgFAEgCAJIAfAAIAAgCQgBgHgEgEQgDgFgGAAQgFABgFAEg");
	this.shape_286.setTransform(333.55,266.05);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgJAEgJQAEgIAGgFQAHgFAJAAQAJAAAFAGQAFAEAAAJIgKAAQAAgFgCgDQgDgDgFAAQgFAAgFAEQgEADgDAIQgCAHAAAGQAAAIADAEQAEADAEAAQAEAAAFgDQADgEADgIIAKACQgEAKgGAFQgIAGgHAAQgJAAgGgGg");
	this.shape_287.setTransform(327.95,266.05);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#D9D9D9").s().p("AgMAnIAMg4IAIAAIgKA4gAABgbIACgLIAKAAIgDALg");
	this.shape_288.setTransform(324.05,264.975);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#D9D9D9").s().p("AgMAnIAQhNIAJAAIgPBNg");
	this.shape_289.setTransform(321.55,264.975);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_290.setTransform(318.875,264.975);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#D9D9D9").s().p("AgTAnQgFgCgCgDQgCgEAAgEIAAgDIAKABIABAFIACACQADACAEAAQAIAAADgFQADgDADgKIAAgFQgIAIgHAAQgJAAgFgHQgGgGAAgLQAAgJAEgIQAFgIAHgEQAGgFAFAAQAMAAAFALIACgJIAJAAIgLA2QgCAJgDAFQgDAFgGADQgEADgHAAQgHAAgFgCgAgEgeIgGAGQgEAEgBAFIgBAJIABAHQABAEAEADQADACADAAQAEAAAEgEQAGgDACgGQADgHAAgGQAAgHgEgFQgDgEgHAAQgCAAgDACg");
	this.shape_291.setTransform(314.05,267.125);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#D9D9D9").s().p("AgUAdIAMg4IAIAAIgCAMQADgHAFgDQAEgDAEAAQADAAAEACIgEAJQgCgCgDAAQgFAAgGAGQgEAGgDANIgFAXg");
	this.shape_292.setTransform(309.625,265.975);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgDgGAAgGQAAgQAKgLQAIgJAMAAQAKAAAHAGQAGAHAAALQAAAJgEAIQgEAJgHAEQgIAFgHAAQgGAAgGgDgAgEgTQgDACgEAEQgDAEgBAGIgBAJQAAAIADAEQAEAEAGAAIAGgBIAFgEIAEgFIADgIQACgEABgFQgBgIgEgEQgEgEgGgBQgDABgEACg");
	this.shape_293.setTransform(304.3,266.05);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#D9D9D9").s().p("AgGAGIADgKIAKAAIgCAKg");
	this.shape_294.setTransform(299.3,268.35);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKAAIABAGQABAEAEACQADABAFAAQAFAAADgCQAEgDAAgEQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBgBAAAAQgCgDgIgDIgJgEQgEgCgBgCQgCgEAAgEQAAgGAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgGgEgDQgDgDgGAAQgFABgCACQgDACAAADQAAADACABIAIAFQALAFADACQAEAEAAAGQAAAEgCAFQgDAEgFADQgGACgGAAQgKAAgHgFg");
	this.shape_295.setTransform(295.4733,266.05);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_296.setTransform(289.475,265.975);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#D9D9D9").s().p("AgPAbQgGgDgCgFQgDgGAAgGQAAgQAJgLQAJgJAMAAQALAAAFAGQAHAHAAALQAAAJgEAIQgEAJgIAEQgGAFgIAAQgGAAgGgDgAgDgTQgFACgCAEQgDAEgCAGIgCAJQAAAIAFAEQADAEAHAAIAEgBIAGgEIAEgFIAEgIQABgEAAgFQAAgIgDgEQgFgEgGgBQgDABgDACg");
	this.shape_297.setTransform(283.55,266.05);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#D9D9D9").s().p("AAYAdIAIgkIABgHQAAgBAAAAQAAgBAAgBQgBAAAAAAQAAgBAAAAQgDgCgDAAQgEAAgFADQgEACgDAEQgCAFgCAIIgGAbIgJAAIAJglIAAgGQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgDAAQgEAAgFADQgEACgDAFQgCAFgDAHIgFAbIgKAAIAMg4IAKAAIgCAKQAFgGAFgDQADgCAGAAQAEAAAEADQADADABAFQAEgGAFgCQAFgDAFAAQAIAAADADQAEAEAAAGIgBAJIgIAjg");
	this.shape_298.setTransform(275.9,265.975);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#D9D9D9").s().p("AAYAdIAIgkIABgHQAAgBAAAAQAAgBAAgBQgBAAAAAAQAAgBgBAAQgBgCgEAAQgEAAgFADQgEACgCAEQgDAFgCAIIgFAbIgKAAIAIglIABgGQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgDAAQgEAAgEADQgFACgDAFQgCAFgDAHIgFAbIgKAAIAMg4IAJAAIgBAKQAFgGAEgDQAFgCAEAAQAFAAADADQAEADACAFQADgGAGgCQAEgDAGAAQAHAAAEADQADAEAAAGIgCAJIgHAjg");
	this.shape_299.setTransform(266.85,265.975);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#D9D9D9").s().p("AgPAbQgGgDgCgFQgDgGAAgGQAAgQAJgLQAJgJAMAAQALAAAFAGQAHAHAAALQAAAJgEAIQgEAJgIAEQgGAFgIAAQgHAAgFgDgAgDgTQgFACgCAEQgDAEgCAGIgCAJQAAAIAFAEQADAEAHAAIAEgBIAGgEIAFgFIADgIQABgEAAgFQAAgIgDgEQgFgEgFgBQgEABgDACg");
	this.shape_300.setTransform(259.35,266.05);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgJAEgJQAEgIAGgFQAIgFAIAAQAJAAAFAGQAFAEAAAJIgKAAQAAgFgCgDQgDgDgFAAQgFAAgFAEQgEADgDAIQgCAHAAAGQAAAIADAEQAEADAEAAQAEAAAFgDQADgEADgIIAKACQgEAKgGAFQgIAGgHAAQgJAAgGgGg");
	this.shape_301.setTransform(253.7,266.05);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgCgGAAgIQgBgHAFgKQAFgIAGgEQAHgFAHAAQAKAAAHAGQAFAHABALIgBAIIgpAAIAAACQAAAIADAFQAEAEAFAAQAEAAAFgDQAFgEACgGIAKABQgCAHgIAGQgGAHgKAAQgGAAgGgDgAgGgRQgFAEgDAJIAgAAIAAgCQAAgHgFgEQgDgFgGAAQgFABgFAEg");
	this.shape_302.setTransform(247.7,266.05);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#D9D9D9").s().p("AgQAdIgKg5IAKAAIAFAfIACARIAHgOIASgiIALAAIggA5g");
	this.shape_303.setTransform(242.5,266.05);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#D9D9D9").s().p("AgMAnIAMg4IAIAAIgKA4gAABgbIADgLIAJAAIgDALg");
	this.shape_304.setTransform(238.2,264.975);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#D9D9D9").s().p("AgLAlQgDgDAAgDIACgJIAHggIgIAAIACgIIAHAAIADgNIAKgIIgEAVIAKAAIgCAIIgKAAIgFAfIgBAHIABADIACAAIAGAAIgCAIIgGABQgGAAgDgDg");
	this.shape_305.setTransform(235.575,265.05);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#D9D9D9").s().p("AgVAZQgEgEgBgIQAAgFACgDQADgEADgBQAEgCAFgCIALgBQAKAAAEgBIABgHQAAgEgCgBQgEgDgGAAQgGAAgDADQgFACgBAFIgKgBQADgIAHgEQAGgFAJAAQAKAAAHAFQAEAEAAAGIgBAKIgDAOIgCALIACAIIgLAAIgBgIQgFAFgEACQgEACgFAAQgIAAgFgFgAAKABIgIABIgLABQgEACgBACQgCADAAADQAAAEADADQADACAFAAQAEAAAEgCQAFgDACgFQADgEABgIIgEABg");
	this.shape_306.setTransform(230.55,266.05);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgDgGAAgIQABgHAEgKQAFgIAGgEQAHgFAHAAQALAAAFAGQAHAHAAALIgBAIIgqAAIAAACQABAIADAFQAEAEAFAAQAEAAAFgDQAFgEACgGIAKABQgCAHgIAGQgGAHgKAAQgGAAgGgDgAgGgRQgFAEgDAJIAgAAIAAgCQAAgHgFgEQgDgFgGAAQgFABgFAEg");
	this.shape_307.setTransform(224.5,266.05);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#D9D9D9").s().p("AgUAdIAMg4IAIAAIgCAMQADgHAFgDQAEgDAEAAQADAAAEACIgEAJQgCgCgDAAQgFAAgGAGQgEAGgDANIgFAXg");
	this.shape_308.setTransform(220.125,265.975);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgJAEgJQAEgIAGgFQAIgFAIAAQAIAAAGAGQAFAEAAAJIgJAAQAAgFgDgDQgEgDgEAAQgGAAgEAEQgEADgCAIQgDAHAAAGQAAAIADAEQAEADAEAAQAEAAAFgDQAEgEACgIIAKACQgEAKgHAFQgGAGgIAAQgJAAgGgGg");
	this.shape_309.setTransform(215.25,266.05);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_310.setTransform(211.075,264.975);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_311.setTransform(208.025,264.975);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#D9D9D9").s().p("AgKAdIACgLIAKAAIgCALgAgBgQIABgMIALAAIgCAMg");
	this.shape_312.setTransform(204.775,266.05);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKAAIABAGQABAEAEACQADABAFAAQAFAAADgCQAEgDAAgEQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBgBAAAAQgCgDgIgDIgJgEQgEgCgBgCQgCgEAAgEQAAgGAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgGgEgDQgDgDgGAAQgFABgCACQgDACAAADQAAADACABIAIAFQALAFADACQAEAEAAAGQAAAEgCAFQgDAEgFADQgGACgGAAQgKAAgHgFg");
	this.shape_313.setTransform(200.4733,266.05);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#D9D9D9").s().p("AgdAoIARhOIAJAAIgCAIQAEgFAEgCQAEgCAEAAQAIAAAFAGQAGAGAAALQAAAJgDAHQgDAGgEAFQgFAEgEACQgFADgEAAQgJAAgGgLIgHAfgAABgdQgCACgCAEQgDADgCAGQgCAGAAAEIABAIQACADADACQACADAEAAQAIAAAFgKQAFgIAAgKQAAgHgDgEQgDgEgGAAQgDAAgEACg");
	this.shape_314.setTransform(194.3,267.075);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#D9D9D9").s().p("AgLAlQgDgDAAgDIACgJIAHggIgIAAIACgIIAHAAIADgNIAKgIIgEAVIAKAAIgCAIIgKAAIgFAfIgBAHIABADIACAAIAGAAIgCAIIgGABQgGAAgDgDg");
	this.shape_315.setTransform(190.425,265.05);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#D9D9D9").s().p("AgLAlQgDgDAAgDIACgJIAHggIgIAAIACgIIAHAAIADgNIAKgIIgEAVIAKAAIgCAIIgKAAIgFAfIgBAHIABADIACAAIAGAAIgCAIIgGABQgGAAgDgDg");
	this.shape_316.setTransform(187.375,265.05);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#D9D9D9").s().p("AAJAnIAHgiIACgJQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgFAAgFADQgEACgCAFQgDAEgCALIgFAYIgKAAIAQhNIAKAAIgGAeQAFgGAEgCQAFgCAEAAQAIAAADAEQAEADAAAHIgBAKIgHAhg");
	this.shape_317.setTransform(182.275,264.975);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#D9D9D9").s().p("AgRA0QAGgHAHgNQAGgLADgMQADgLAAgMQAAgRgGgUIAIAAQAIATAAATQAAANgDAKQgEAMgHAKQgEAIgKAMg");
	this.shape_318.setTransform(370.275,251.85);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#D9D9D9").s().p("AgUAhQgGgHAAgNQAAgKADgJQADgLADgGQAEgGAEgEIAIgFQACgBAFAAQAJAAAGAGQAGAHAAANQAAANgEAMQgFAPgJAHQgGAGgIAAQgJAAgGgHgAAAgeQgDACgEAFQgEAHgDAOQgDAKAAAHQAAAIACAEQAEAFAHAAQAEAAAFgFQAGgHAEgOQADgNAAgJQAAgIgDgEQgDgEgGAAQgDAAgDACg");
	this.shape_319.setTransform(366.45,250.825);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#D9D9D9").s().p("AgGAFIACgJIALAAIgDAJg");
	this.shape_320.setTransform(361.2,254.15);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#D9D9D9").s().p("AABAnIAEgUIgfAAIACgJIArgwIAIAAIgLAxIALAAIgBAIIgLAAIgFAUgAgPALIAWAAIAHggg");
	this.shape_321.setTransform(357.025,250.775);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#D9D9D9").s().p("AgSAnIAHgeIgYgvIALAAIALAWIAIAQQAEgHAGgIIASgXIANAAIglAwIgFAdg");
	this.shape_322.setTransform(348.3,250.775);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#D9D9D9").s().p("AghAnIARhNIAXAAIAKAAQAFABAEACQADADADAEQACADAAAFQgBAHgDAFQgEAFgHACQAGABADAEQAEAFAAAFQAAAHgEAGQgDAGgHADQgGADgHAAgAgUAeIASAAIAIAAIAJgDQADgCABgEQACgDAAgEQAAgFgEgDQgDgDgJAAIgUAAgAgMgFIAOAAQAMAAAEgEQAGgDAAgHQgBgDgBgDQgBgCgDgBQgDgCgHAAIgQAAg");
	this.shape_323.setTransform(339.9,250.775);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#D9D9D9").s().p("AgaAgQgIgJAAgQQAAgVANgNQALgNAQAAQAMAAAIAHQAIAHABALIgKABQgBgJgFgEQgFgEgIAAQgNAAgJANQgIALAAAOQAAAMAGAHQAGAGAKAAQAHAAAGgFQAHgGADgJIALABQgFAOgKAHQgJAHgLAAQgOAAgJgJg");
	this.shape_324.setTransform(329.575,250.775);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#D9D9D9").s().p("AgaAgQgIgJAAgQQAAgVANgNQALgNAQAAQAMAAAIAHQAIAHABALIgKABQgBgJgFgEQgFgEgIAAQgNAAgJANQgIALAAAOQAAAMAGAHQAGAGAKAAQAHAAAGgFQAHgGADgJIALABQgFAOgKAHQgJAHgLAAQgOAAgJgJg");
	this.shape_325.setTransform(321.625,250.775);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#D9D9D9").s().p("AgJA0QgIgTAAgUQAAgNADgJQAEgLAGgMQAEgHALgMIAHAAQgGAHgIAMQgGAMgDANQgCAKAAAMQgBARAHAUg");
	this.shape_326.setTransform(316.2,251.85);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#D9D9D9").s().p("AgMAnIAPhNIAKAAIgPBNg");
	this.shape_327.setTransform(309.55,250.775);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#D9D9D9").s().p("AgVAZQgFgFAAgHQAAgFADgDQACgEADgBQAEgDAFgBIAMgBQAIAAAEgBIACgHQAAgDgDgCQgDgDgGAAQgGAAgDADQgFACgCAGIgJgCQADgIAGgEQAHgFAJAAQAKAAAHAFQAEAEAAAGIgBAKIgDAOIgBALIABAHIgKAAIgBgHQgGAFgEACQgEACgFAAQgIAAgFgFgAAKABIgIABIgLABQgDACgCADQgCACAAADQAAAEADADQADACAFAAQAFAAADgCQAFgDACgFQADgEABgIIgEABg");
	this.shape_328.setTransform(305,251.85);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_329.setTransform(298.825,251.775);

	this.shape_330 = new cjs.Shape();
	this.shape_330.graphics.f("#D9D9D9").s().p("AgPAbQgGgDgCgFQgDgFAAgHQAAgQAJgLQAJgJAMAAQALAAAFAGQAHAHAAALQAAAJgEAIQgEAJgIAFQgGAEgIAAQgGAAgGgDgAgEgTQgDACgDAEQgEAEgBAGIgCAJQABAIADAEQAFAFAGgBIAEgBIAGgEIAEgGIAEgHQACgEAAgFQAAgIgFgEQgDgFgHAAQgDAAgEADg");
	this.shape_330.setTransform(292.9,251.85);

	this.shape_331 = new cjs.Shape();
	this.shape_331.graphics.f("#D9D9D9").s().p("AgMAnIAMg4IAJAAIgLA4gAABgbIACgLIAKAAIgDALg");
	this.shape_331.setTransform(288.85,250.775);

	this.shape_332 = new cjs.Shape();
	this.shape_332.graphics.f("#D9D9D9").s().p("AgLAlQgDgCAAgEIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgHIgEAWIAKAAIgCAHIgKAAIgFAeIgBAIIABACIACABIAGgBIgCAIIgGABQgGAAgDgCg");
	this.shape_332.setTransform(286.225,250.85);

	this.shape_333 = new cjs.Shape();
	this.shape_333.graphics.f("#D9D9D9").s().p("AgVAZQgEgFgBgHQAAgFACgDQADgEAEgBQADgDAFgBIALgBQAJAAAFgBIABgHQAAgDgCgCQgEgDgHAAQgEAAgFADQgDACgCAGIgKgCQADgIAHgEQAGgFAJAAQALAAAFAFQAGAEAAAGIgCAKIgDAOIgCALIABAHIgKAAIgBgHQgEAFgFACQgEACgFAAQgIAAgFgFgAAKABIgIABIgLABQgDACgCADQgCACAAADQAAAEADADQACACAGAAQAEAAAEgCQAEgDADgFQADgEABgIIgEABg");
	this.shape_333.setTransform(281.2,251.85);

	this.shape_334 = new cjs.Shape();
	this.shape_334.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_334.setTransform(275.025,251.775);

	this.shape_335 = new cjs.Shape();
	this.shape_335.graphics.f("#D9D9D9").s().p("AgUAdIAMg4IAIAAIgCAMQADgHAFgDQAEgDAEAAQADAAAEACIgEAJQgCgCgDAAQgFAAgGAGQgEAGgDANIgFAXg");
	this.shape_335.setTransform(270.775,251.775);

	this.shape_336 = new cjs.Shape();
	this.shape_336.graphics.f("#D9D9D9").s().p("AgOAbQgGgDgCgFQgDgGgBgIQAAgHAFgKQAFgIAGgEQAHgFAHAAQAKAAAHAGQAFAHAAALIgBAHIgoAAIAAADQAAAIADAFQAEAEAFAAQAEAAAFgDQAFgDADgHIAJABQgCAHgHAGQgIAHgJAAQgGAAgFgDgAgGgRQgFAFgCAIIAeAAIAAgCQAAgIgDgDQgEgFgFAAQgGAAgFAFg");
	this.shape_336.setTransform(265.4,251.85);

	this.shape_337 = new cjs.Shape();
	this.shape_337.graphics.f("#D9D9D9").s().p("AgLAlQgDgCAAgEIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgHIgEAWIAKAAIgCAHIgKAAIgFAeIgBAIIABACIACABIAGgBIgCAIIgGABQgGAAgDgCg");
	this.shape_337.setTransform(261.225,250.85);

	this.shape_338 = new cjs.Shape();
	this.shape_338.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_338.setTransform(256.125,251.775);

	this.shape_339 = new cjs.Shape();
	this.shape_339.graphics.f("#D9D9D9").s().p("AgMAnIAPhNIAKAAIgPBNg");
	this.shape_339.setTransform(251.975,250.775);

	this.shape_340 = new cjs.Shape();
	this.shape_340.graphics.f("#D9D9D9").s().p("AgUAhQgGgHAAgNQAAgKADgJQADgLAEgGQADgGAEgEIAHgFQAEgBAEAAQAJAAAGAGQAGAHAAANQAAANgEAMQgFAPgIAHQgIAGgHAAQgJAAgGgHgAAAgeQgDACgDAFQgFAHgDAOQgDAKAAAHQAAAIADAEQADAFAHAAQAEAAAFgFQAGgHADgOQAEgNAAgJQAAgIgEgEQgDgEgFAAQgEAAgCACg");
	this.shape_340.setTransform(244.35,250.825);

	this.shape_341 = new cjs.Shape();
	this.shape_341.graphics.f("#D9D9D9").s().p("AgGAFIADgJIAKAAIgCAJg");
	this.shape_341.setTransform(239.1,254.15);

	this.shape_342 = new cjs.Shape();
	this.shape_342.graphics.f("#D9D9D9").s().p("AABAnIAEgUIgfAAIACgJIArgwIAIAAIgLAxIALAAIgBAIIgLAAIgFAUgAgPALIAWAAIAHggg");
	this.shape_342.setTransform(234.925,250.775);

	this.shape_343 = new cjs.Shape();
	this.shape_343.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_343.setTransform(225.625,251.775);

	this.shape_344 = new cjs.Shape();
	this.shape_344.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgDgFAAgHQAAgQAKgLQAIgJAMAAQAKAAAHAGQAGAHAAALQAAAJgEAIQgEAJgHAFQgIAEgHAAQgGAAgGgDgAgEgTQgDACgEAEQgDAEgBAGIgBAJQAAAIADAEQAEAFAGgBIAGgBIAFgEIAEgGIADgHQACgEABgFQgBgIgEgEQgEgFgFAAQgEAAgEADg");
	this.shape_344.setTransform(219.7,251.85);

	this.shape_345 = new cjs.Shape();
	this.shape_345.graphics.f("#D9D9D9").s().p("AgMAnIALg4IAKAAIgMA4gAABgbIADgLIAJAAIgCALg");
	this.shape_345.setTransform(215.65,250.775);

	this.shape_346 = new cjs.Shape();
	this.shape_346.graphics.f("#D9D9D9").s().p("AgLAlQgDgCAAgEIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgHIgEAWIAKAAIgCAHIgKAAIgFAeIgBAIIABACIACABIAGgBIgCAIIgGABQgGAAgDgCg");
	this.shape_346.setTransform(213.025,250.85);

	this.shape_347 = new cjs.Shape();
	this.shape_347.graphics.f("#D9D9D9").s().p("AgWAZQgEgEAAgFIABgMIAHggIAKAAIgIAjIgBAHQAAADACACQACACAEAAQAEAAAEgCQADgCADgDQADgEABgEIADgKIAFgYIAKAAIgMA4IgJAAIACgLQgJAMgLAAQgGAAgEgEg");
	this.shape_347.setTransform(208.275,251.925);

	this.shape_348 = new cjs.Shape();
	this.shape_348.graphics.f("#D9D9D9").s().p("AgJAlQgEgDgDgGIgCAKIgJAAIARhNIAKAAIgGAcQAEgEADgCQAEgCAEAAQAIAAAFAGQAGAGAAAKQAAAIgDAHQgCAFgDAFIgGAHQgEADgDAAIgHACQgFAAgEgDgAgDgHQgEAEgDAHQgCAHAAAEIAAACQAAAHADAEQAEAEAFAAQAEAAAEgDQAFgEACgIQADgHAAgHQAAgGgDgEQgEgEgFAAQgFAAgEAEg");
	this.shape_348.setTransform(201.875,250.85);

	this.shape_349 = new cjs.Shape();
	this.shape_349.graphics.f("#D9D9D9").s().p("AgMAnIAMg4IAJAAIgLA4gAABgbIACgLIAKAAIgDALg");
	this.shape_349.setTransform(197.95,250.775);

	this.shape_350 = new cjs.Shape();
	this.shape_350.graphics.f("#D9D9D9").s().p("AgUAdIAMg4IAIAAIgCAMQADgHAFgDQAEgDAEAAQADAAAEACIgEAJQgCgCgDAAQgFAAgGAGQgEAGgDANIgFAXg");
	this.shape_350.setTransform(195.125,251.775);

	this.shape_351 = new cjs.Shape();
	this.shape_351.graphics.f("#D9D9D9").s().p("AgLAlQgDgCAAgEIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgHIgEAWIAKAAIgCAHIgKAAIgFAeIgBAIIABACIACABIAGgBIgCAIIgGABQgGAAgDgCg");
	this.shape_351.setTransform(191.675,250.85);

	this.shape_352 = new cjs.Shape();
	this.shape_352.graphics.f("#D9D9D9").s().p("AgLAlQgDgCAAgEIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgHIgEAWIAKAAIgCAHIgKAAIgFAeIgBAIIABACIACABIAGgBIgCAIIgGABQgGAAgDgCg");
	this.shape_352.setTransform(188.625,250.85);

	this.shape_353 = new cjs.Shape();
	this.shape_353.graphics.f("#D9D9D9").s().p("AAYAnIgDgWIgfAAIgMAWIgMAAIArhNIANAAIANBNgAAGgOIgLAWIAYAAIgDgSQgBgMAAgIIgJAQg");
	this.shape_353.setTransform(182.5,250.775);

	this.shape_354 = new cjs.Shape();
	this.shape_354.graphics.f("#D9D9D9").s().p("AAYAdIAIgkIABgHQAAgBAAAAQAAgBAAgBQgBAAAAAAQAAgBAAAAQgDgCgDAAQgEAAgFADQgEACgDAEQgCAFgCAIIgGAbIgJAAIAIglIABgGQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgDAAQgEAAgEADQgFACgDAFQgDAFgCAHIgFAbIgKAAIAMg4IAKAAIgCAKQAFgGAFgDQADgCAGAAQAEAAAEADQADADABAFQAFgGAEgCQAGgDAEAAQAHAAAFADQADAEAAAGIgBAJIgIAjg");
	this.shape_354.setTransform(434.5,237.575);

	this.shape_355 = new cjs.Shape();
	this.shape_355.graphics.f("#D9D9D9").s().p("AgPAbQgGgDgCgFQgDgGAAgGQAAgQAJgLQAJgJAMAAQALAAAFAGQAHAHAAALQAAAJgEAIQgEAJgIAFQgGAEgIAAQgHAAgFgDgAgEgTQgDACgDAEQgEAEgBAGIgCAJQABAIADAEQAFAFAGAAIAEgCIAGgEIAEgGIAEgHQACgEAAgFQAAgIgFgEQgDgFgHABQgDAAgEACg");
	this.shape_355.setTransform(427,237.65);

	this.shape_356 = new cjs.Shape();
	this.shape_356.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgJAEgIQAEgKAGgEQAIgFAIAAQAIAAAGAFQAFAGAAAIIgJABQAAgFgDgEQgEgDgEAAQgGAAgEAEQgEADgCAIQgDAGAAAIQAAAHADADQAEAEAEABQAEgBAFgEQAEgDACgHIAKAAQgEALgHAGQgGAFgIAAQgJAAgGgGg");
	this.shape_356.setTransform(421.35,237.65);

	this.shape_357 = new cjs.Shape();
	this.shape_357.graphics.f("#D9D9D9").s().p("AgFAFIACgKIAJAAIgBAKg");
	this.shape_357.setTransform(416.5,239.95);

	this.shape_358 = new cjs.Shape();
	this.shape_358.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgJAEgIQAEgKAGgEQAIgFAIAAQAIAAAGAFQAFAGAAAIIgJABQAAgFgDgEQgEgDgEAAQgGAAgEAEQgEADgCAIQgDAGAAAIQAAAHADADQAEAEAEABQAEgBAFgEQAEgDACgHIAKAAQgEALgHAGQgGAFgIAAQgJAAgGgGg");
	this.shape_358.setTransform(412.8,237.65);

	this.shape_359 = new cjs.Shape();
	this.shape_359.graphics.f("#D9D9D9").s().p("AgMAnIAMg4IAJAAIgMA4gAABgbIACgLIAKAAIgDALg");
	this.shape_359.setTransform(408.9,236.575);

	this.shape_360 = new cjs.Shape();
	this.shape_360.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKgBIABAIQABACAEACQADACAFABQAFgBADgDQAEgCAAgDQAAgBAAgBQAAAAgBgBQAAAAAAgBQgBAAAAgBQgCgDgIgDIgJgDQgEgCgBgEQgCgCAAgEQAAgHAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgFgEgDQgDgDgGAAQgFAAgCACQgDADAAACQAAADACACIAIAEQALAFADABQAEAFAAAGQAAAFgCAEQgDAEgFACQgGADgGAAQgKAAgHgFg");
	this.shape_360.setTransform(404.7233,237.65);

	this.shape_361 = new cjs.Shape();
	this.shape_361.graphics.f("#D9D9D9").s().p("AgWAZQgEgEAAgFIABgMIAHggIAKAAIgIAjIgBAHQAAADACACQACACAEAAQAEAAAEgCQADgCADgDQADgEABgEIADgKIAFgYIAKAAIgMA4IgJAAIACgLQgJAMgLAAQgGAAgEgEg");
	this.shape_361.setTransform(399.075,237.725);

	this.shape_362 = new cjs.Shape();
	this.shape_362.graphics.f("#D9D9D9").s().p("AAYAdIAIgkIABgHQAAgBAAAAQAAgBAAgBQgBAAAAAAQAAgBgBAAQgBgCgDAAQgFAAgEADQgFACgCAEQgDAFgCAIIgFAbIgJAAIAIglIAAgGQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgDAAQgEAAgFADQgEACgDAFQgDAFgBAHIgGAbIgKAAIAMg4IAJAAIgBAKQAFgGAEgDQAEgCAFAAQAFAAADADQAEADACAFQADgGAGgCQAFgDAFAAQAGAAAEADQAEAEAAAGIgCAJIgHAjg");
	this.shape_362.setTransform(391.25,237.575);

	this.shape_363 = new cjs.Shape();
	this.shape_363.graphics.f("#D9D9D9").s().p("AgPAFIACgJIAdAAIgCAJg");
	this.shape_363.setTransform(385.05,237.65);

	this.shape_364 = new cjs.Shape();
	this.shape_364.graphics.f("#D9D9D9").s().p("AAIAnIgKgdIgMAKIgEATIgKAAIAQhNIAKAAIgKAvIAbgaIAOAAIgZAUIAPAkg");
	this.shape_364.setTransform(380.7,236.575);

	this.shape_365 = new cjs.Shape();
	this.shape_365.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgJAEgIQADgKAIgEQAHgFAHAAQAKAAAFAFQAFAGAAAIIgKABQAAgFgDgEQgCgDgGAAQgEAAgFAEQgEADgDAIQgCAGAAAIQAAAHADADQADAEAFABQAEgBAEgEQAEgDADgHIAJAAQgDALgHAGQgHAFgHAAQgJAAgGgGg");
	this.shape_365.setTransform(375.05,237.65);

	this.shape_366 = new cjs.Shape();
	this.shape_366.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgDgGAAgGQAAgQAKgLQAIgJAMAAQAKAAAHAGQAGAHAAALQAAAJgEAIQgEAJgHAFQgIAEgHAAQgGAAgGgDgAgEgTQgDACgEAEQgDAEgBAGIgBAJQAAAIADAEQAEAFAGAAIAGgCIAFgEIAFgGIACgHQACgEABgFQgBgIgEgEQgEgFgGABQgDAAgEACg");
	this.shape_366.setTransform(369.1,237.65);

	this.shape_367 = new cjs.Shape();
	this.shape_367.graphics.f("#D9D9D9").s().p("AgLAlQgDgDAAgDIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgGIgEAVIAKAAIgCAHIgKAAIgFAeIgBAHIABADIACABIAGgBIgCAIIgGABQgGAAgDgCg");
	this.shape_367.setTransform(364.875,236.65);

	this.shape_368 = new cjs.Shape();
	this.shape_368.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKgBIABAIQABACAEACQADACAFABQAFgBADgDQAEgCAAgDQAAgBAAgBQAAAAgBgBQAAAAAAgBQgBAAAAgBQgCgDgIgDIgJgDQgEgCgBgEQgCgCAAgEQAAgHAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgFgEgDQgDgDgGAAQgFAAgCACQgDADAAACQAAADACACIAIAEQALAFADABQAEAFAAAGQAAAFgCAEQgDAEgFACQgGADgGAAQgKAAgHgFg");
	this.shape_368.setTransform(360.2733,237.65);

	this.shape_369 = new cjs.Shape();
	this.shape_369.graphics.f("#D9D9D9").s().p("AgPAFIACgJIAdAAIgCAJg");
	this.shape_369.setTransform(355.75,237.65);

	this.shape_370 = new cjs.Shape();
	this.shape_370.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgGQgCgFAAgHQgBgJAFgIQAFgJAGgFQAHgEAHAAQAKAAAGAGQAGAHABALIgBAHIgpAAIAAAEQAAAHADAEQAEAFAFAAQAEAAAFgEQAFgDACgGIAKABQgCAHgIAHQgGAGgKAAQgGAAgGgDgAgGgRQgFAEgDAJIAgAAIAAgCQAAgIgFgDQgDgEgGAAQgFgBgFAFg");
	this.shape_370.setTransform(350.75,237.65);

	this.shape_371 = new cjs.Shape();
	this.shape_371.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgGQgDgFABgHQAAgJAEgIQAEgJAHgFQAHgEAHAAQALAAAFAGQAHAHAAALIgBAHIgqAAIAAAEQABAHADAEQAEAFAFAAQAEAAAFgEQAFgDACgGIAKABQgCAHgIAHQgGAGgKAAQgGAAgGgDgAgGgRQgFAEgDAJIAgAAIAAgCQAAgIgFgDQgDgEgGAAQgFgBgFAFg");
	this.shape_371.setTransform(344.65,237.65);

	this.shape_372 = new cjs.Shape();
	this.shape_372.graphics.f("#D9D9D9").s().p("AgUAdIAMg4IAIAAIgCAMQADgHAFgDQAEgDAEAAQADAAAEACIgEAJQgCgCgDAAQgFAAgGAGQgEAGgDANIgFAXg");
	this.shape_372.setTransform(340.275,237.575);

	this.shape_373 = new cjs.Shape();
	this.shape_373.graphics.f("#D9D9D9").s().p("AgTAoIALgxIgJAAIABgHIAJAAIACgIIACgJQACgCACgDQADgBAFAAIALABIgCAJIgIgBQgBAAAAAAQgBAAgBAAQAAAAgBAAQAAABgBAAQgBACgBAFIgBAGIAKAAIgBAHIgLAAIgJAxg");
	this.shape_373.setTransform(337.25,236.5);

	this.shape_374 = new cjs.Shape();
	this.shape_374.graphics.f("#D9D9D9").s().p("AgFAFIABgKIAKAAIgCAKg");
	this.shape_374.setTransform(333,239.95);

	this.shape_375 = new cjs.Shape();
	this.shape_375.graphics.f("#D9D9D9").s().p("AAAAcIAAggIgBgMIgFANIgQAfIgKAAIgFg3IAJAAIACAZIABANIABAHIACgJIAEgIIANgcIALAAIABAbIABARIAJgSIALgaIAKAAIgcA3g");
	this.shape_375.setTransform(328.45,237.65);

	this.shape_376 = new cjs.Shape();
	this.shape_376.graphics.f("#D9D9D9").s().p("AABAcIgCggIAAgMIgFANIgQAfIgKAAIgGg3IAKAAIADAZIABANIAAAHIACgJIAEgIIANgcIAKAAIACAbIAAARIAJgSIANgaIAKAAIgcA3g");
	this.shape_376.setTransform(320.5,237.65);

	this.shape_377 = new cjs.Shape();
	this.shape_377.graphics.f("#D9D9D9").s().p("AAAAcIgBggIAAgMIgFANIgPAfIgKAAIgHg3IAKAAIACAZIABANIABAHIADgJIADgIIAOgcIAKAAIABAbIAAARIAJgSIAMgaIALAAIgdA3g");
	this.shape_377.setTransform(312.55,237.65);

	this.shape_378 = new cjs.Shape();
	this.shape_378.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_378.setTransform(306.775,236.575);

	this.shape_379 = new cjs.Shape();
	this.shape_379.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_379.setTransform(303.725,236.575);

	this.shape_380 = new cjs.Shape();
	this.shape_380.graphics.f("#D9D9D9").s().p("AgKAcIACgLIAKAAIgCALgAgBgRIABgKIALAAIgCAKg");
	this.shape_380.setTransform(300.475,237.65);

	this.shape_381 = new cjs.Shape();
	this.shape_381.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKgBIABAIQABACAEACQADACAFABQAFgBADgDQAEgCAAgDQAAgBAAgBQAAAAgBgBQAAAAAAgBQgBAAAAgBQgCgDgIgDIgJgDQgEgCgBgEQgCgCAAgEQAAgHAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgFgEgDQgDgDgGAAQgFAAgCACQgDADAAACQAAADACACIAIAEQALAFADABQAEAFAAAGQAAAFgCAEQgDAEgFACQgGADgGAAQgKAAgHgFg");
	this.shape_381.setTransform(296.1733,237.65);

	this.shape_382 = new cjs.Shape();
	this.shape_382.graphics.f("#D9D9D9").s().p("AgdAoIAQhOIAJAAIgBAIQAEgFAEgCQADgCAFAAQAIAAAFAGQAGAGAAALQAAAJgDAHQgDAGgEAFQgEAEgFACQgEADgFAAQgJAAgGgLIgHAfgAABgdQgCACgDAEQgDADgBAGQgCAGAAAEIABAIQABADADACQAEADADAAQAIAAAFgKQAFgIAAgKQAAgHgDgEQgEgEgFAAQgDAAgEACg");
	this.shape_382.setTransform(290,238.675);

	this.shape_383 = new cjs.Shape();
	this.shape_383.graphics.f("#D9D9D9").s().p("AgLAlQgDgDAAgDIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgGIgEAVIAKAAIgCAHIgKAAIgFAeIgBAHIABADIACABIAGgBIgCAIIgGABQgGAAgDgCg");
	this.shape_383.setTransform(286.125,236.65);

	this.shape_384 = new cjs.Shape();
	this.shape_384.graphics.f("#D9D9D9").s().p("AgLAlQgDgDAAgDIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgGIgEAVIAKAAIgCAHIgKAAIgFAeIgBAHIABADIACABIAGgBIgCAIIgGABQgGAAgDgCg");
	this.shape_384.setTransform(283.075,236.65);

	this.shape_385 = new cjs.Shape();
	this.shape_385.graphics.f("#D9D9D9").s().p("AAJAnIAHgiIACgJQAAgBAAAAQgBgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgFAAgFADQgEACgCAFQgDAEgCALIgFAYIgKAAIAQhNIAKAAIgGAeQAFgGAEgCQAFgCAEAAQAIAAADAEQAEADAAAHIgBAKIgHAhg");
	this.shape_385.setTransform(277.975,236.575);

	this.shape_386 = new cjs.Shape();
	this.shape_386.graphics.f("#D9D9D9").s().p("AgeAnIABgJIAGABQABAAAAAAQABAAAAAAQABgBAAAAQABAAAAgBIAGgHIADgFIgKg4IAKAAIAEAdIACAQIAZgtIAKAAIgjBAQgGAJgEADQgEADgFAAIgHgBg");
	this.shape_386.setTransform(269.425,238.8);

	this.shape_387 = new cjs.Shape();
	this.shape_387.graphics.f("#D9D9D9").s().p("AgJAlQgEgDgDgHIgCALIgJAAIARhNIAKAAIgGAcQAEgEADgCQAEgCAEAAQAIAAAFAGQAGAGAAAKQAAAIgDAHQgCAFgDAFIgGAHQgEACgDABIgHACQgFAAgEgDgAgDgHQgEAEgDAHIgCALIAAACQAAAHADAEQAEAEAFAAQAEAAAEgEQAFgDACgIQADgHAAgHQAAgGgDgEQgEgEgFAAQgFAAgEAEg");
	this.shape_387.setTransform(263.375,236.65);

	this.shape_388 = new cjs.Shape();
	this.shape_388.graphics.f("#D9D9D9").s().p("AgYAiQgFgGAAgLQAAgLAEgHQAEgJAHgFQAGgEAGAAQALAAAEALIAHgfIAKAAIgRBNIgJAAIACgIQgHAKgKAAQgHAAgGgGgAgHgJIgGAFIgFAIQgCAGAAAFIABAJQACADADACQACADAFAAQAGAAAFgHQAGgJABgOQAAgFgEgEQgDgEgFAAQgDAAgDACg");
	this.shape_388.setTransform(254.7,236.65);

	this.shape_389 = new cjs.Shape();
	this.shape_389.graphics.f("#D9D9D9").s().p("AgOAbQgGgDgCgGQgEgFAAgHQAAgJAFgIQAFgJAGgFQAHgEAHAAQAKAAAHAGQAFAHAAALIgBAHIgpAAIAAAEQAAAHAEAEQAEAFAFAAQAEAAAFgEQAFgDADgGIAJABQgCAHgHAHQgIAGgJAAQgGAAgFgDgAgGgRQgFAEgCAJIAeAAIAAgCQAAgIgDgDQgEgEgFAAQgGgBgFAFg");
	this.shape_389.setTransform(248.2,237.65);

	this.shape_390 = new cjs.Shape();
	this.shape_390.graphics.f("#D9D9D9").s().p("AgLAlQgDgDAAgDIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgGIgEAVIAKAAIgCAHIgKAAIgFAeIgBAHIABADIACABIAGgBIgCAIIgGABQgGAAgDgCg");
	this.shape_390.setTransform(244.025,236.65);

	this.shape_391 = new cjs.Shape();
	this.shape_391.graphics.f("#D9D9D9").s().p("AgPAbQgGgDgCgFQgDgGAAgGQAAgQAJgLQAJgJAMAAQALAAAFAGQAHAHAAALQAAAJgEAIQgEAJgIAFQgGAEgIAAQgHAAgFgDgAgDgTQgFACgCAEQgDAEgCAGIgCAJQAAAIAFAEQADAFAHAAIAEgCIAGgEIAFgGIADgHQABgEAAgFQAAgIgDgEQgFgFgFABQgEAAgDACg");
	this.shape_391.setTransform(239.1,237.65);

	this.shape_392 = new cjs.Shape();
	this.shape_392.graphics.f("#D9D9D9").s().p("AAYAdIAIgkIABgHQAAgBAAAAQAAgBAAgBQgBAAAAAAQAAgBAAAAQgCgCgEAAQgEAAgFADQgEACgDAEQgCAFgCAIIgGAbIgJAAIAJglIAAgGQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgDAAQgEAAgFADQgEACgDAFQgDAFgCAHIgFAbIgKAAIAMg4IAKAAIgCAKQAFgGAFgDQADgCAGAAQAEAAAEADQADADABAFQAFgGAEgCQAGgDAEAAQAHAAAFADQADAEAAAGIgBAJIgIAjg");
	this.shape_392.setTransform(231.45,237.575);

	this.shape_393 = new cjs.Shape();
	this.shape_393.graphics.f("#D9D9D9").s().p("AgPAbQgGgDgCgFQgDgGAAgGQAAgQAKgLQAIgJAMAAQALAAAFAGQAHAHAAALQAAAJgEAIQgEAJgIAFQgGAEgIAAQgHAAgFgDgAgEgTQgDACgDAEQgEAEgBAGIgBAJQAAAIADAEQAFAFAFAAIAFgCIAGgEIAEgGIAEgHQACgEAAgFQAAgIgFgEQgDgFgHABQgDAAgEACg");
	this.shape_393.setTransform(223.95,237.65);

	this.shape_394 = new cjs.Shape();
	this.shape_394.graphics.f("#D9D9D9").s().p("AgUAdIAMg4IAIAAIgCAMQADgHAFgDQAEgDAEAAQADAAAEACIgEAJQgCgCgDAAQgFAAgGAGQgEAGgDANIgFAXg");
	this.shape_394.setTransform(219.525,237.575);

	this.shape_395 = new cjs.Shape();
	this.shape_395.graphics.f("#D9D9D9").s().p("AgdAoIAQhOIAJAAIgBAIQAFgFADgCQADgCAFAAQAIAAAFAGQAGAGAAALQAAAJgDAHQgDAGgEAFQgFAEgEACQgEADgFAAQgJAAgGgLIgHAfgAABgdQgCACgDAEQgDADgBAGQgCAGAAAEIABAIQACADADACQACADAEAAQAIAAAFgKQAFgIAAgKQAAgHgDgEQgEgEgFAAQgEAAgDACg");
	this.shape_395.setTransform(213.85,238.675);

	this.shape_396 = new cjs.Shape();
	this.shape_396.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgJAEgIQADgKAIgEQAHgFAHAAQAJAAAGAFQAFAGAAAIIgJABQgBgFgDgEQgCgDgGAAQgEAAgFAEQgEADgDAIQgCAGAAAIQAAAHADADQAEAEAEABQAEgBAEgEQAEgDADgHIAJAAQgDALgHAGQgGAFgIAAQgJAAgGgGg");
	this.shape_396.setTransform(205.5,237.65);

	this.shape_397 = new cjs.Shape();
	this.shape_397.graphics.f("#D9D9D9").s().p("AgMAnIALg4IAJAAIgLA4gAABgbIADgLIAJAAIgCALg");
	this.shape_397.setTransform(201.6,236.575);

	this.shape_398 = new cjs.Shape();
	this.shape_398.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKgBIABAIQABACAEACQADACAFABQAFgBADgDQAEgCAAgDQAAgBAAgBQAAAAgBgBQAAAAAAgBQgBAAAAgBQgCgDgIgDIgJgDQgEgCgBgEQgCgCAAgEQAAgHAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgFgEgDQgDgDgGAAQgFAAgCACQgDADAAACQAAADACACIAIAEQALAFADABQAEAFAAAGQAAAFgCAEQgDAEgFACQgGADgGAAQgKAAgHgFg");
	this.shape_398.setTransform(197.4233,237.65);

	this.shape_399 = new cjs.Shape();
	this.shape_399.graphics.f("#D9D9D9").s().p("AgWAZQgEgEAAgFIABgMIAHggIAKAAIgIAjIgBAHQAAADACACQACACAEAAQAEAAAEgCQADgCADgDQADgEABgEIADgKIAFgYIAKAAIgMA4IgJAAIACgLQgJAMgLAAQgGAAgEgEg");
	this.shape_399.setTransform(191.775,237.725);

	this.shape_400 = new cjs.Shape();
	this.shape_400.graphics.f("#D9D9D9").s().p("AATAnIAIgmQACgMAGgRIgIARIgdAyIgKAAIgIgxIgCgQIgCAQIgKAxIgKAAIAQhNIANAAIAIAyIABATIAKgWIAcgvIAOAAIgRBNg");
	this.shape_400.setTransform(184.25,236.575);

	this.shape_401 = new cjs.Shape();
	this.shape_401.graphics.f("#D9D9D9").s().p("AAYAdIAIgkIABgHQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQgDgCgDAAQgEAAgFADQgEACgDAEQgCAFgCAIIgGAbIgJAAIAJglIAAgGQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgDAAQgEAAgFADQgEACgDAFQgCAFgDAHIgFAbIgKAAIAMg4IAKAAIgCAKQAFgGAFgDQADgCAGAAQAEAAAEADQADADABAFQAEgGAFgCQAFgDAFAAQAIAAADADQAEAEAAAGIgBAJIgIAjg");
	this.shape_401.setTransform(446.9,223.375);

	this.shape_402 = new cjs.Shape();
	this.shape_402.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgDgGAAgGQAAgQAKgLQAIgJAMAAQAKAAAGAHQAHAGAAALQAAAJgEAJQgEAIgIAEQgHAFgHAAQgHAAgFgDgAgEgTQgDACgEAEQgCAFgCAFIgBAJQAAAIADAEQAEAEAGABIAFgCIAGgEIAEgFIADgIQADgEAAgFQAAgIgFgEQgDgFgHABQgDgBgEADg");
	this.shape_402.setTransform(439.4,223.45);

	this.shape_403 = new cjs.Shape();
	this.shape_403.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgIAEgJQADgKAIgEQAGgFAJAAQAIAAAGAGQAFAEAAAJIgJAAQAAgEgEgEQgCgDgGAAQgFAAgEAEQgEADgCAIQgDAHAAAGQAAAIADADQADAFAFAAQAEAAAFgFQAEgDACgIIAJABQgDAMgHAEQgGAGgIAAQgJAAgGgGg");
	this.shape_403.setTransform(433.75,223.45);

	this.shape_404 = new cjs.Shape();
	this.shape_404.graphics.f("#D9D9D9").s().p("AgGAFIADgKIAKAAIgCAKg");
	this.shape_404.setTransform(428.9,225.75);

	this.shape_405 = new cjs.Shape();
	this.shape_405.graphics.f("#D9D9D9").s().p("AgdAoIARhOIAJAAIgDAIQAGgFACgCQAEgCAFAAQAIAAAGAGQAFAGAAALQAAAJgDAHQgDAGgFAFQgEAEgEACQgFADgEAAQgKAAgFgLIgGAfgAABgdQgCACgCAEQgEADgBAGQgCAGAAAEIABAIQACADACACQAEADACAAQAJAAAFgKQAFgIAAgKQAAgHgDgEQgDgEgGAAQgEAAgDACg");
	this.shape_405.setTransform(424.4,224.475);

	this.shape_406 = new cjs.Shape();
	this.shape_406.graphics.f("#D9D9D9").s().p("AAYAdIAIgkIABgHQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAQgCgCgCAAQgFAAgEADQgFACgDAEQgCAFgCAIIgGAbIgIAAIAIglIAAgGQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgDAAQgEAAgFADQgEACgDAFQgCAFgCAHIgGAbIgKAAIAMg4IAKAAIgCAKQAFgGAEgDQAFgCAEAAQAFAAADADQAEADABAFQAFgGAEgCQAFgDAFAAQAIAAADADQAEAEAAAGIgBAJIgIAjg");
	this.shape_406.setTransform(417.1,223.375);

	this.shape_407 = new cjs.Shape();
	this.shape_407.graphics.f("#D9D9D9").s().p("AgVAZQgFgFABgHQAAgEACgEQABgEAEgBQAEgDAFAAIAMgBQAIAAAEgDIACgGQAAgDgDgCQgDgDgHAAQgEAAgEADQgEADgDAFIgJgBQADgJAGgFQAHgEAJAAQAKAAAHAFQAEAEAAAGIgBALIgDANIgBALIABAHIgKAAIgBgGQgGAEgEACQgEACgFAAQgIAAgFgFgAAKABIgIABIgLACQgDABgCACQgCADAAADQAAAEADACQADAEAFAAQAFAAADgEQAFgCACgEQADgFABgIIgEABg");
	this.shape_407.setTransform(409.5,223.45);

	this.shape_408 = new cjs.Shape();
	this.shape_408.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgIAEgJQADgKAIgEQAHgFAHAAQAJAAAGAGQAFAEAAAJIgJAAQgBgEgDgEQgCgDgGAAQgEAAgFAEQgEADgDAIQgCAHAAAGQAAAIADADQAEAFAEAAQAEAAAEgFQAEgDADgIIAJABQgDAMgHAEQgGAGgIAAQgJAAgGgGg");
	this.shape_408.setTransform(403.95,223.45);

	this.shape_409 = new cjs.Shape();
	this.shape_409.graphics.f("#D9D9D9").s().p("AgYAiQgFgGAAgMQAAgKAEgHQAFgJAGgFQAGgEAGAAQALAAAEAKIAHgeIAKAAIgRBNIgJAAIACgIQgHAKgKAAQgHAAgGgGgAgHgKIgGAGIgEAJQgDAFAAAFIABAJQACAEADABQACADAFAAQAGAAAEgHQAHgJABgOQgBgFgDgEQgEgEgEAAQgDAAgDABg");
	this.shape_409.setTransform(398.35,222.45);

	this.shape_410 = new cjs.Shape();
	this.shape_410.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_410.setTransform(391.725,223.375);

	this.shape_411 = new cjs.Shape();
	this.shape_411.graphics.f("#D9D9D9").s().p("AgVAZQgEgFgBgHQAAgEACgEQACgEAFgBQADgDAFAAIALgBQAJAAAFgDIABgGQAAgDgCgCQgEgDgGAAQgFAAgFADQgEADgBAFIgKgBQADgJAHgFQAGgEAJAAQALAAAFAFQAGAEAAAGIgCALIgDANIgCALIABAHIgKAAIgBgGQgEAEgFACQgEACgFAAQgIAAgFgFgAAKABIgIABIgLACQgEABgBACQgCADAAADQAAAEADACQACAEAGAAQAFAAADgEQAEgCADgEQADgFABgIIgEABg");
	this.shape_411.setTransform(385.7,223.45);

	this.shape_412 = new cjs.Shape();
	this.shape_412.graphics.f("#D9D9D9").s().p("AgJAlQgEgDgDgHIgCALIgJAAIARhNIAKAAIgGAcQAEgEADgCQAEgCAEAAQAIAAAFAGQAGAGAAALQAAAHgDAGQgCAGgDAFIgGAGQgEADgDABIgHACQgFAAgEgDgAgDgHQgEAEgDAIIgCAKIAAACQAAAHADAEQAEAEAFAAQAEAAAEgEQAFgEACgHQADgIAAgGQAAgGgDgEQgEgEgFAAQgFAAgEAEg");
	this.shape_412.setTransform(379.575,222.45);

	this.shape_413 = new cjs.Shape();
	this.shape_413.graphics.f("#D9D9D9").s().p("AgGAFIACgKIALAAIgDAKg");
	this.shape_413.setTransform(374.7,225.75);

	this.shape_414 = new cjs.Shape();
	this.shape_414.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgIAEgJQADgKAIgEQAHgFAHAAQAKAAAFAGQAFAEAAAJIgKAAQAAgEgDgEQgCgDgGAAQgEAAgFAEQgEADgDAIQgCAHAAAGQAAAIADADQADAFAFAAQAEAAAEgFQAEgDADgIIAJABQgDAMgHAEQgHAGgHAAQgJAAgGgGg");
	this.shape_414.setTransform(371,223.45);

	this.shape_415 = new cjs.Shape();
	this.shape_415.graphics.f("#D9D9D9").s().p("AgMAnIALg4IAJAAIgLA4gAABgbIADgLIAJAAIgCALg");
	this.shape_415.setTransform(367.1,222.375);

	this.shape_416 = new cjs.Shape();
	this.shape_416.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKgBIABAIQABACAEADQADACAFAAQAFAAADgEQAEgCAAgDQAAgBAAgBQAAAAgBgBQAAAAAAgBQgBAAAAgBQgCgCgIgDIgJgFQgEgBgBgDQgCgEAAgDQAAgHAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgGgEgDQgDgCgGAAQgFgBgCADQgDADAAACQAAACACACIAIAFQALAFADABQAEAFAAAHQAAAEgCAEQgDAEgFACQgGADgGAAQgKAAgHgFg");
	this.shape_416.setTransform(362.9233,223.45);

	this.shape_417 = new cjs.Shape();
	this.shape_417.graphics.f("#D9D9D9").s().p("AgWAZQgEgEAAgFIABgMIAHggIAKAAIgIAjIgBAHQAAADACACQACACAEAAQAEAAAEgCQADgCADgDQADgEABgEIADgKIAFgYIAKAAIgMA4IgJAAIACgLQgJAMgLAAQgGAAgEgEg");
	this.shape_417.setTransform(357.275,223.525);

	this.shape_418 = new cjs.Shape();
	this.shape_418.graphics.f("#D9D9D9").s().p("AAYAdIAIgkIABgHQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQgDgCgDAAQgEAAgFADQgEACgDAEQgCAFgCAIIgGAbIgJAAIAIglIABgGQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgDAAQgEAAgEADQgFACgDAFQgDAFgCAHIgFAbIgKAAIAMg4IAKAAIgCAKQAFgGAFgDQADgCAGAAQAEAAAEADQADADABAFQAFgGAEgCQAGgDAEAAQAHAAAFADQADAEAAAGIgBAJIgIAjg");
	this.shape_418.setTransform(349.45,223.375);

	this.shape_419 = new cjs.Shape();
	this.shape_419.graphics.f("#D9D9D9").s().p("AgPAFIACgJIAdAAIgCAJg");
	this.shape_419.setTransform(343.25,223.45);

	this.shape_420 = new cjs.Shape();
	this.shape_420.graphics.f("#D9D9D9").s().p("AgdAoIARhOIAJAAIgCAIQAEgFAEgCQAEgCAEAAQAIAAAFAGQAGAGAAALQAAAJgDAHQgDAGgEAFQgEAEgFACQgEADgFAAQgKAAgFgLIgHAfgAABgdQgCACgCAEQgDADgCAGQgCAGAAAEIABAIQACADADACQACADAEAAQAIAAAFgKQAFgIAAgKQAAgHgDgEQgEgEgFAAQgEAAgDACg");
	this.shape_420.setTransform(337.95,224.475);

	this.shape_421 = new cjs.Shape();
	this.shape_421.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgIAEgJQAEgKAGgEQAIgFAHAAQAKAAAFAGQAFAEAAAJIgKAAQAAgEgDgEQgDgDgFAAQgEAAgFAEQgEADgDAIQgCAHAAAGQAAAIADADQADAFAFAAQAEAAAEgFQAFgDACgIIAJABQgDAMgGAEQgIAGgHAAQgKAAgFgGg");
	this.shape_421.setTransform(332.65,223.45);

	this.shape_422 = new cjs.Shape();
	this.shape_422.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKgBIABAIQABACAEADQADACAFAAQAFAAADgEQAEgCAAgDQAAgBAAgBQAAAAgBgBQAAAAAAgBQgBAAAAgBQgCgCgIgDIgJgFQgEgBgBgDQgCgEAAgDQAAgHAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgGgEgDQgDgCgGAAQgFgBgCADQgDADAAACQAAACACACIAIAFQALAFADABQAEAFAAAHQAAAEgCAEQgDAEgFACQgGADgGAAQgKAAgHgFg");
	this.shape_422.setTransform(327.0233,223.45);

	this.shape_423 = new cjs.Shape();
	this.shape_423.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgGQgCgFAAgHQAAgIAEgJQAFgJAGgFQAHgEAHAAQALAAAFAHQAHAGAAALIgBAIIgpAAIAAADQAAAHADAEQAEAFAFAAQAEAAAFgEQAFgDACgGIAKABQgCAHgIAHQgGAGgKAAQgGAAgGgDgAgGgRQgFAFgDAIIAgAAIAAgCQAAgHgFgFQgDgDgGAAQgFgBgFAFg");
	this.shape_423.setTransform(321.15,223.45);

	this.shape_424 = new cjs.Shape();
	this.shape_424.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_424.setTransform(316.875,222.375);

	this.shape_425 = new cjs.Shape();
	this.shape_425.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_425.setTransform(313.825,222.375);

	this.shape_426 = new cjs.Shape();
	this.shape_426.graphics.f("#D9D9D9").s().p("AgKAcIACgLIAKAAIgCALgAgBgRIABgLIALAAIgCALg");
	this.shape_426.setTransform(310.575,223.45);

	this.shape_427 = new cjs.Shape();
	this.shape_427.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKgBIABAIQABACAEADQADACAFAAQAFAAADgEQAEgCAAgDQAAgBAAgBQAAAAgBgBQAAAAAAgBQgBAAAAgBQgCgCgIgDIgJgFQgEgBgBgDQgCgEAAgDQAAgHAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgGgEgDQgDgCgGAAQgFgBgCADQgDADAAACQAAACACACIAIAFQALAFADABQAEAFAAAHQAAAEgCAEQgDAEgFACQgGADgGAAQgKAAgHgFg");
	this.shape_427.setTransform(306.2733,223.45);

	this.shape_428 = new cjs.Shape();
	this.shape_428.graphics.f("#D9D9D9").s().p("AgdAoIAQhOIAJAAIgCAIQAGgFACgCQAFgCAEAAQAIAAAGAGQAFAGAAALQAAAJgDAHQgDAGgFAFQgDAEgFACQgFADgEAAQgKAAgFgLIgGAfgAABgdQgCACgDAEQgCADgCAGQgCAGAAAEIABAIQABADADACQAEADACAAQAJAAAFgKQAFgIAAgKQAAgHgDgEQgDgEgGAAQgDAAgEACg");
	this.shape_428.setTransform(300.1,224.475);

	this.shape_429 = new cjs.Shape();
	this.shape_429.graphics.f("#D9D9D9").s().p("AgLAkQgDgCAAgDIACgJIAHggIgIAAIACgIIAHAAIADgNIAKgHIgEAUIAKAAIgCAIIgKAAIgFAeIgBAHIABAEIACAAIAGAAIgCAHIgGACQgGgBgDgDg");
	this.shape_429.setTransform(296.225,222.45);

	this.shape_430 = new cjs.Shape();
	this.shape_430.graphics.f("#D9D9D9").s().p("AgLAkQgDgCAAgDIACgJIAHggIgIAAIACgIIAHAAIADgNIAKgHIgEAUIAKAAIgCAIIgKAAIgFAeIgBAHIABAEIACAAIAGAAIgCAHIgGACQgGgBgDgDg");
	this.shape_430.setTransform(293.175,222.45);

	this.shape_431 = new cjs.Shape();
	this.shape_431.graphics.f("#D9D9D9").s().p("AAJAnIAHgiIACgJQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgFAAgFADQgEACgCAFQgDAEgCALIgFAYIgKAAIAQhNIAKAAIgGAeQAFgGAEgCQAFgCAEAAQAIAAADAEQAEADAAAHIgBAKIgHAhg");
	this.shape_431.setTransform(288.075,222.375);

	this.shape_432 = new cjs.Shape();
	this.shape_432.graphics.f("#D9D9D9").s().p("AgDAzIAAhlIAHAAIAABlg");
	this.shape_432.setTransform(280.525,223.45);

	this.shape_433 = new cjs.Shape();
	this.shape_433.graphics.f("#D9D9D9").s().p("AgdAoIARhOIAJAAIgDAIQAGgFACgCQAFgCAEAAQAIAAAGAGQAFAGAAALQAAAJgDAHQgDAGgFAFQgEAEgEACQgEADgFAAQgJAAgGgLIgGAfgAABgdQgCACgCAEQgEADgBAGQgCAGAAAEIABAIQABADAEACQADADACAAQAJAAAFgKQAFgIAAgKQAAgHgDgEQgEgEgFAAQgEAAgDACg");
	this.shape_433.setTransform(272.85,224.475);

	this.shape_434 = new cjs.Shape();
	this.shape_434.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgIAEgJQAEgKAGgEQAHgFAIAAQAKAAAFAGQAFAEAAAJIgKAAQAAgEgCgEQgDgDgFAAQgFAAgFAEQgEADgDAIQgCAHAAAGQAAAIADADQAEAFAEAAQAEAAAEgFQAEgDADgIIAKABQgEAMgGAEQgIAGgHAAQgJAAgGgGg");
	this.shape_434.setTransform(264.5,223.45);

	this.shape_435 = new cjs.Shape();
	this.shape_435.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKgBIABAIQABACAEADQADACAFAAQAFAAADgEQAEgCAAgDQAAgBAAgBQAAAAgBgBQAAAAAAgBQgBAAAAgBQgCgCgIgDIgJgFQgEgBgBgDQgCgEAAgDQAAgHAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgGgEgDQgDgCgGAAQgFgBgCADQgDADAAACQAAACACACIAIAFQALAFADABQAEAFAAAHQAAAEgCAEQgDAEgFACQgGADgGAAQgKAAgHgFg");
	this.shape_435.setTransform(255.8233,223.45);

	this.shape_436 = new cjs.Shape();
	this.shape_436.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgGQgCgFAAgHQAAgIAEgJQAFgJAGgFQAHgEAHAAQALAAAFAHQAHAGAAALIgBAIIgqAAIAAADQABAHADAEQAEAFAFAAQAEAAAFgEQAFgDACgGIAKABQgCAHgIAHQgGAGgKAAQgGAAgGgDgAgGgRQgFAFgDAIIAgAAIAAgCQAAgHgFgFQgDgDgGAAQgFgBgFAFg");
	this.shape_436.setTransform(246.9,223.45);

	this.shape_437 = new cjs.Shape();
	this.shape_437.graphics.f("#D9D9D9").s().p("AgDAzIAAhlIAHAAIAABlg");
	this.shape_437.setTransform(239.225,223.45);

	this.shape_438 = new cjs.Shape();
	this.shape_438.graphics.f("#D9D9D9").s().p("AgeAnIABgJIAGABQAAAAABAAQABAAAAAAQABgBAAAAQABAAAAgBIAGgGIADgGIgKg4IAKAAIAEAdIACAQIAZgtIAKAAIgjBAQgGAJgEADQgEADgFAAIgHgBg");
	this.shape_438.setTransform(232.325,224.6);

	this.shape_439 = new cjs.Shape();
	this.shape_439.graphics.f("#D9D9D9").s().p("AgJAlQgEgDgDgHIgCALIgJAAIARhNIAKAAIgGAcQAEgEADgCQAEgCAEAAQAIAAAFAGQAGAGAAALQAAAHgDAGQgCAGgDAFIgGAGQgEADgDABIgHACQgFAAgEgDgAgDgHQgEAEgDAIQgCAGAAAEIAAACQAAAHADAEQAEAEAFAAQAEAAAEgEQAFgEACgHQADgIAAgGQAAgGgDgEQgEgEgFAAQgFAAgEAEg");
	this.shape_439.setTransform(226.275,222.45);

	this.shape_440 = new cjs.Shape();
	this.shape_440.graphics.f("#D9D9D9").s().p("AAKAcIgHgLIgDgKIgQAVIgNAAIAZgcIgOgcIALAAIAEAKIAFALIAQgVIALAAIgYAcIAPAcg");
	this.shape_440.setTransform(217.55,223.45);

	this.shape_441 = new cjs.Shape();
	this.shape_441.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgDgGAAgGQAAgQAJgLQAJgJAMAAQAKAAAHAHQAGAGAAALQAAAJgEAJQgEAIgHAEQgIAFgHAAQgHAAgFgDgAgDgTQgFACgDAEQgCAFgCAFIgCAJQAAAIAFAEQADAEAHABIAFgCIAFgEIAFgFIADgIQABgEAAgFQAAgIgDgEQgFgFgFABQgEgBgDADg");
	this.shape_441.setTransform(211.75,223.45);

	this.shape_442 = new cjs.Shape();
	this.shape_442.graphics.f("#D9D9D9").s().p("AgYAiQgFgGAAgMQAAgKAEgHQAEgJAHgFQAGgEAGAAQALAAAFAKIAGgeIAKAAIgQBNIgJAAIABgIQgHAKgKAAQgHAAgGgGgAgHgKIgGAGIgFAJQgCAFAAAFIABAJQACAEADABQACADAEAAQAHAAAFgHQAGgJABgOQAAgFgEgEQgEgEgEAAQgEAAgCABg");
	this.shape_442.setTransform(206,222.45);

	this.shape_443 = new cjs.Shape();
	this.shape_443.graphics.f("#D9D9D9").s().p("AgVAZQgFgFABgHQAAgEACgEQABgEAFgBQADgDAFAAIAMgBQAJAAADgDIACgGQAAgDgDgCQgDgDgHAAQgEAAgFADQgEADgCAFIgJgBQADgJAGgFQAHgEAJAAQAKAAAGAFQAFAEABAGIgCALIgDANIgBALIAAAHIgJAAIgBgGQgFAEgFACQgEACgFAAQgIAAgFgFgAAKABIgIABIgLACQgDABgCACQgCADAAADQAAAEADACQADAEAFAAQAFAAADgEQAFgCACgEQADgFABgIIgEABg");
	this.shape_443.setTransform(199.45,223.45);

	this.shape_444 = new cjs.Shape();
	this.shape_444.graphics.f("#D9D9D9").s().p("AgUAdIAMg4IAIAAIgCAMQADgHAFgDQAEgDAEAAQADAAAEACIgEAJQgCgCgDAAQgFAAgGAGQgEAGgDANIgFAXg");
	this.shape_444.setTransform(195.125,223.375);

	this.shape_445 = new cjs.Shape();
	this.shape_445.graphics.f("#D9D9D9").s().p("AgVAZQgFgFAAgHQAAgEADgEQACgEADgBQAEgDAFAAIAMgBQAIAAAFgDIABgGQAAgDgCgCQgEgDgGAAQgGAAgDADQgFADgBAFIgKgBQADgJAHgFQAGgEAJAAQAKAAAHAFQAEAEAAAGIgBALIgDANIgBALIABAHIgKAAIgCgGQgFAEgEACQgEACgFAAQgIAAgFgFgAAKABIgIABIgLACQgEABgBACQgCADAAADQAAAEADACQACAEAGAAQAEAAAEgEQAEgCADgEQADgFABgIIgEABg");
	this.shape_445.setTransform(189.7,223.45);

	this.shape_446 = new cjs.Shape();
	this.shape_446.graphics.f("#D9D9D9").s().p("AgjAnIAQhNIAgAAQAJAAAEABQAEACADAFQADAFAAAGQAAAFgCAFQgCAFgDADIgGAEIgHADQgHABgIAAIgTAAIgGAggAgQgBIAQAAQAKAAAFgCQAFgCADgEQADgFAAgFQAAgEgCgCQgBgDgDgBQgDgBgIAAIgTAAg");
	this.shape_446.setTransform(183.275,222.375);

	this.shape_447 = new cjs.Shape();
	this.shape_447.graphics.f("#D9D9D9").s().p("AgXAjQgJgGAAgPIAKgBIAAADQAAAEACAEQACAEAFACQAFACAHAAQAIAAAFgEQAFgEAAgGQAAgDgDgEQgCgDgMgFIgMgFQgFgDgDgEQgCgFAAgFQAAgGADgFQADgFAHgCQAGgDAHAAQAKAAAHADQAGAEADAFQADAFAAAFIAAACIgKABIgBgGQgBgDgCgCIgGgEQgEgBgFAAQgIAAgEAEQgEADAAAFQAAADABACQACACAEACIAMAGIAMAFQAEADACAEQADAEAAAFQAAAHgEAFQgEAGgHADQgHADgIAAQgNAAgIgGg");
	this.shape_447.setTransform(453.175,193.775);

	this.shape_448 = new cjs.Shape();
	this.shape_448.graphics.f("#D9D9D9").s().p("AgWAlQgHgDgDgFQgDgGAAgGIACgOIAJgqIALAAIgLAvIgBAJQAAAGAFAEQAFAEAIAAQAGAAAEgCQAFgDADgGQADgFADgMIAJgqIAKAAIgJAtQgDAMgEAGQgEAIgHAEQgHAEgJAAQgJAAgGgDg");
	this.shape_448.setTransform(445.825,193.85);

	this.shape_449 = new cjs.Shape();
	this.shape_449.graphics.f("#D9D9D9").s().p("AgfADIAAgGIA/AAIAAAGg");
	this.shape_449.setTransform(437.55,199.55);

	this.shape_450 = new cjs.Shape();
	this.shape_450.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_450.setTransform(432.025,194.775);

	this.shape_451 = new cjs.Shape();
	this.shape_451.graphics.f("#D9D9D9").s().p("AgOAbQgGgDgCgFQgDgGgBgIQAAgIAFgJQAFgJAGgDQAHgFAHAAQAKAAAHAHQAFAGAAALIgBAIIgoAAIAAACQAAAJADADQAEAFAFAAQAEAAAFgDQAFgEADgGIAJABQgCAHgHAGQgIAHgJAAQgGAAgFgDgAgGgRQgFAEgCAJIAeAAIAAgCQAAgHgDgFQgEgEgFAAQgGABgFAEg");
	this.shape_451.setTransform(426.05,194.85);

	this.shape_452 = new cjs.Shape();
	this.shape_452.graphics.f("#D9D9D9").s().p("AgFAGIACgLIAJAAIgBALg");
	this.shape_452.setTransform(421.1,197.15);

	this.shape_453 = new cjs.Shape();
	this.shape_453.graphics.f("#D9D9D9").s().p("AgYAiQgFgGAAgMQAAgKAEgIQAFgIAGgEQAGgFAHAAQAJAAAGAKIAGgeIAKAAIgQBOIgJAAIABgJQgHAKgJAAQgJAAgFgGgAgHgKIgGAGIgFAJQgBAFAAAFIABAJQABAEACACQAEACADAAQAHAAAFgHQAGgJAAgNQABgGgEgEQgDgEgFAAQgEAAgCABg");
	this.shape_453.setTransform(417.3,193.85);

	this.shape_454 = new cjs.Shape();
	this.shape_454.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgCgGgBgIQABgIAEgJQAEgJAHgDQAHgFAHAAQALAAAFAHQAHAGAAALIgBAIIgqAAIAAACQABAJADADQAEAFAFAAQAEAAAFgDQAFgEACgGIAKABQgCAHgIAGQgGAHgKAAQgGAAgGgDgAgGgRQgFAEgDAJIAgAAIAAgCQAAgHgFgFQgDgEgGAAQgFABgFAEg");
	this.shape_454.setTransform(410.8,194.85);

	this.shape_455 = new cjs.Shape();
	this.shape_455.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgCgFQgEgGAAgIQABgIAEgJQAFgJAGgDQAHgFAHAAQALAAAFAHQAHAGgBALIgBAIIgpAAIAAACQAAAJAEADQAEAFAFAAQAEAAAFgDQAFgEADgGIAJABQgCAHgHAGQgIAHgJAAQgGAAgGgDgAgGgRQgFAEgCAJIAeAAIAAgCQAAgHgDgFQgEgEgFAAQgGABgFAEg");
	this.shape_455.setTransform(404.7,194.85);

	this.shape_456 = new cjs.Shape();
	this.shape_456.graphics.f("#D9D9D9").s().p("AgYAiQgFgGAAgMQAAgKAEgIQAFgIAGgEQAGgFAHAAQAJAAAFAKIAHgeIAKAAIgRBOIgJAAIACgJQgHAKgJAAQgJAAgFgGgAgHgKIgGAGIgEAJQgCAFAAAFIABAJQABAEACACQAEACAEAAQAGAAAEgHQAIgJgBgNQAAgGgDgEQgEgEgEAAQgDAAgDABg");
	this.shape_456.setTransform(399,193.85);

	this.shape_457 = new cjs.Shape();
	this.shape_457.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_457.setTransform(394.325,193.775);

	this.shape_458 = new cjs.Shape();
	this.shape_458.graphics.f("#D9D9D9").s().p("AgUAhQgGgHAAgNQAAgKADgJQADgLADgGQAEgGAEgEIAIgFQADgBAEAAQAJAAAGAGQAGAHAAANQAAANgEAMQgFAPgJAHQgGAGgIAAQgJAAgGgHgAAAgeQgEACgDAFQgEAHgDAOQgDAKAAAHQAAAIACAEQAEAFAGAAQAFAAAFgFQAGgHAEgOQADgNAAgJQAAgIgDgEQgEgEgFAAQgDAAgDACg");
	this.shape_458.setTransform(389.75,193.825);

	this.shape_459 = new cjs.Shape();
	this.shape_459.graphics.f("#D9D9D9").s().p("AgFAGIABgLIAKAAIgCALg");
	this.shape_459.setTransform(384.5,197.15);

	this.shape_460 = new cjs.Shape();
	this.shape_460.graphics.f("#D9D9D9").s().p("AgTAiQgHgGgBgKIAKgBQABAIADAEQAEADAGAAQAGAAAGgFQAFgFAAgHQAAgFgEgEQgEgEgGAAIgDAAIACgHIACAAQAIAAAEgEQAFgEAAgGQAAgFgEgEQgDgEgGAAQgFAAgDAEQgEAEgCAHIgJgCQACgKAHgFQAHgFAIAAQAKAAAGAGQAGAFAAAJQAAAGgEAFQgDAEgGAEQAEABACAEQADAEAAAFQAAALgIAHQgIAIgKAAQgLAAgGgGg");
	this.shape_460.setTransform(380.475,193.825);

	this.shape_461 = new cjs.Shape();
	this.shape_461.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_461.setTransform(376.025,193.775);

	this.shape_462 = new cjs.Shape();
	this.shape_462.graphics.f("#D9D9D9").s().p("AgeAnIABgJIAGABQAAAAABAAQABAAAAAAQABgBAAAAQABAAAAAAIAGgHIADgGIgKg4IAKAAIAEAdIACAQIAZgtIAKAAIgjA/QgGAKgEADQgEADgFAAIgHgBg");
	this.shape_462.setTransform(371.625,196);

	this.shape_463 = new cjs.Shape();
	this.shape_463.graphics.f("#D9D9D9").s().p("AgJAlQgEgDgDgHIgCAMIgJAAIARhOIAKAAIgGAcQAEgFADgBQAEgCAEAAQAIAAAFAGQAGAGAAALQAAAHgDAGQgCAHgDAEIgGAGQgEADgDACIgHABQgFAAgEgDgAgDgHQgEAEgDAIIgCAKIAAACQAAAHADAEQAEAEAFAAQAEAAAEgDQAFgFACgHQADgHAAgHQAAgGgDgEQgEgEgFAAQgFAAgEAEg");
	this.shape_463.setTransform(365.575,193.85);

	this.shape_464 = new cjs.Shape();
	this.shape_464.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_464.setTransform(361.375,193.775);

	this.shape_465 = new cjs.Shape();
	this.shape_465.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKgBIABAHQABADAEADQADABAFAAQAFAAADgCQAEgDAAgEQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBgBAAAAQgCgCgIgDIgJgFQgEgCgBgCQgCgDAAgEQAAgHAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgFgEgEQgDgDgGAAQgFABgCACQgDACAAADQAAADACABIAIAFQALAFADACQAEAEAAAHQAAADgCAFQgDAEgFADQgGACgGAAQgKAAgHgFg");
	this.shape_465.setTransform(356.8733,194.85);

	this.shape_466 = new cjs.Shape();
	this.shape_466.graphics.f("#D9D9D9").s().p("AgOAbQgGgDgCgFQgDgGAAgIQgBgIAFgJQAEgJAHgDQAHgFAHAAQAKAAAHAHQAFAGAAALIgBAIIgoAAIAAACQgBAJAEADQAEAFAFAAQAEAAAFgDQAFgEADgGIAJABQgCAHgHAGQgIAHgJAAQgGAAgFgDgAgGgRQgFAEgCAJIAeAAIAAgCQAAgHgDgFQgEgEgGAAQgFABgFAEg");
	this.shape_466.setTransform(351,194.85);

	this.shape_467 = new cjs.Shape();
	this.shape_467.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKgBIABAHQABADAEADQADABAFAAQAFAAADgCQAEgDAAgEQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBgBAAAAQgCgCgIgDIgJgFQgEgCgBgCQgCgDAAgEQAAgHAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgFgEgEQgDgDgGAAQgFABgCACQgDACAAADQAAADACABIAIAFQALAFADACQAEAEAAAHQAAADgCAFQgDAEgFADQgGACgGAAQgKAAgHgFg");
	this.shape_467.setTransform(345.2733,194.85);

	this.shape_468 = new cjs.Shape();
	this.shape_468.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_468.setTransform(339.275,194.775);

	this.shape_469 = new cjs.Shape();
	this.shape_469.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgCgGAAgIQAAgIAEgJQAFgJAGgDQAHgFAHAAQALAAAFAHQAHAGAAALIgBAIIgqAAIAAACQABAJADADQAEAFAFAAQAEAAAFgDQAFgEACgGIAKABQgCAHgIAGQgGAHgKAAQgGAAgGgDgAgGgRQgFAEgDAJIAgAAIAAgCQAAgHgFgFQgDgEgGAAQgFABgFAEg");
	this.shape_469.setTransform(333.3,194.85);

	this.shape_470 = new cjs.Shape();
	this.shape_470.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgIAEgKQAEgIAGgFQAIgFAHAAQAKAAAFAGQAFAEAAAJIgKAAQAAgFgDgDQgDgDgFAAQgEAAgFAEQgEAEgDAHQgCAHAAAGQAAAIADAEQADADAFAAQAEAAAEgDQAFgEACgIIAKABQgEAMgGAEQgIAGgHAAQgKAAgFgGg");
	this.shape_470.setTransform(327.7,194.85);

	this.shape_471 = new cjs.Shape();
	this.shape_471.graphics.f("#D9D9D9").s().p("AgMAnIALg4IAJAAIgKA4gAABgbIADgLIAJAAIgDALg");
	this.shape_471.setTransform(323.8,193.775);

	this.shape_472 = new cjs.Shape();
	this.shape_472.graphics.f("#D9D9D9").s().p("AgMAnIAQhNIAJAAIgQBNg");
	this.shape_472.setTransform(321.3,193.775);

	this.shape_473 = new cjs.Shape();
	this.shape_473.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_473.setTransform(318.625,193.775);

	this.shape_474 = new cjs.Shape();
	this.shape_474.graphics.f("#D9D9D9").s().p("AgTAnQgFgCgCgDQgDgEABgEIAAgDIAKABIAAAFIADACQADACAEAAQAIAAAEgFQACgDACgKIABgFQgIAIgHAAQgJAAgFgHQgGgGAAgLQAAgJAFgIQAEgIAHgEQAFgFAGAAQAMAAAFALIACgJIAJAAIgLA2QgCAJgDAFQgDAFgFADQgFADgHAAQgHAAgFgCgAgEgeIgGAGQgDAEgCAFIgBAJIABAHQACAEADADQADACADAAQAEAAAFgEQAEgDAEgGQACgHAAgGQAAgHgEgFQgDgEgHAAQgCAAgDACg");
	this.shape_474.setTransform(313.8,195.925);

	this.shape_475 = new cjs.Shape();
	this.shape_475.graphics.f("#D9D9D9").s().p("AgUAdIAMg4IAIAAIgCAMQADgHAFgDQAEgDAEAAQADAAAEACIgEAJQgCgCgDAAQgFAAgGAGQgEAGgDANIgFAXg");
	this.shape_475.setTransform(309.375,194.775);

	this.shape_476 = new cjs.Shape();
	this.shape_476.graphics.f("#D9D9D9").s().p("AgPAbQgGgDgCgFQgDgGAAgGQAAgQAKgLQAIgJAMAAQALAAAFAHQAHAGAAALQAAAJgEAJQgEAIgIAEQgGAFgIAAQgHAAgFgDgAgEgTQgDACgDAEQgEAFgBAFIgBAJQAAAIADAEQAFAEAFAAIAFgBIAGgEIAEgFIAEgIQACgEAAgFQAAgIgFgEQgDgEgHgBQgDABgEACg");
	this.shape_476.setTransform(304.05,194.85);

	this.shape_477 = new cjs.Shape();
	this.shape_477.graphics.f("#D9D9D9").s().p("AgFAGIACgLIAJAAIgBALg");
	this.shape_477.setTransform(299.05,197.15);

	this.shape_478 = new cjs.Shape();
	this.shape_478.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKgBIABAHQABADAEADQADABAFAAQAFAAADgCQAEgDAAgEQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBgBAAAAQgCgCgIgDIgJgFQgEgCgBgCQgCgDAAgEQAAgHAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgFgEgEQgDgDgGAAQgFABgCACQgDACAAADQAAADACABIAIAFQALAFADACQAEAEAAAHQAAADgCAFQgDAEgFADQgGACgGAAQgKAAgHgFg");
	this.shape_478.setTransform(295.2233,194.85);

	this.shape_479 = new cjs.Shape();
	this.shape_479.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_479.setTransform(289.225,194.775);

	this.shape_480 = new cjs.Shape();
	this.shape_480.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgDgGAAgGQAAgQAJgLQAJgJAMAAQAKAAAHAHQAGAGAAALQAAAJgEAJQgEAIgHAEQgIAFgHAAQgHAAgFgDgAgDgTQgFACgDAEQgCAFgCAFIgCAJQAAAIAFAEQADAEAHAAIAFgBIAFgEIAFgFIADgIQABgEAAgFQAAgIgDgEQgFgEgFgBQgEABgDACg");
	this.shape_480.setTransform(283.3,194.85);

	this.shape_481 = new cjs.Shape();
	this.shape_481.graphics.f("#D9D9D9").s().p("AAYAdIAIgkIABgHQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQgDgCgDAAQgEAAgFADQgEACgDAEQgCAFgCAIIgGAbIgJAAIAIglIABgGQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgDAAQgEAAgEADQgFACgDAFQgDAFgCAHIgFAbIgKAAIAMg4IAKAAIgCAKQAFgGAFgDQADgCAGAAQAEAAAEADQADADABAFQAFgGAEgCQAGgDAEAAQAHAAAFADQADAEAAAGIgBAJIgIAjg");
	this.shape_481.setTransform(275.65,194.775);

	this.shape_482 = new cjs.Shape();
	this.shape_482.graphics.f("#D9D9D9").s().p("AAYAdIAIgkIABgHQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAQgCgCgCAAQgFAAgEADQgFACgCAEQgDAFgCAIIgFAbIgJAAIAIglIAAgGQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgDAAQgEAAgFADQgEACgDAFQgDAFgBAHIgGAbIgKAAIAMg4IAJAAIgBAKQAFgGAEgDQAFgCAEAAQAFAAADADQAEADACAFQADgGAGgCQAFgDAFAAQAGAAAEADQAEAEAAAGIgCAJIgHAjg");
	this.shape_482.setTransform(266.6,194.775);

	this.shape_483 = new cjs.Shape();
	this.shape_483.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgDgGAAgGQAAgQAJgLQAJgJAMAAQAKAAAHAHQAGAGAAALQAAAJgEAJQgEAIgHAEQgIAFgHAAQgGAAgGgDgAgDgTQgEACgEAEQgDAFgBAFIgCAJQABAIAEAEQAEAEAFAAIAGgBIAFgEIAFgFIACgIQACgEAAgFQAAgIgDgEQgEgEgGgBQgEABgDACg");
	this.shape_483.setTransform(259.1,194.85);

	this.shape_484 = new cjs.Shape();
	this.shape_484.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgIAEgKQAEgIAGgFQAIgFAHAAQAKAAAFAGQAFAEAAAJIgKAAQAAgFgDgDQgDgDgFAAQgEAAgFAEQgEAEgDAHQgCAHAAAGQAAAIADAEQADADAFAAQAEAAAEgDQAFgEACgIIAKABQgEAMgGAEQgIAGgHAAQgKAAgFgGg");
	this.shape_484.setTransform(253.45,194.85);

	this.shape_485 = new cjs.Shape();
	this.shape_485.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgCgGAAgIQAAgIAEgJQAFgJAGgDQAHgFAHAAQALAAAFAHQAHAGAAALIgBAIIgqAAIAAACQABAJADADQAEAFAFAAQAEAAAFgDQAFgEACgGIAKABQgCAHgIAGQgGAHgKAAQgGAAgGgDgAgGgRQgFAEgDAJIAgAAIAAgCQAAgHgFgFQgDgEgGAAQgFABgFAEg");
	this.shape_485.setTransform(247.45,194.85);

	this.shape_486 = new cjs.Shape();
	this.shape_486.graphics.f("#D9D9D9").s().p("AgQAdIgKg5IAKAAIAFAfIACARIAHgOIASgiIAKAAIgfA5g");
	this.shape_486.setTransform(242.25,194.85);

	this.shape_487 = new cjs.Shape();
	this.shape_487.graphics.f("#D9D9D9").s().p("AgMAnIALg4IAJAAIgLA4gAABgbIADgLIAJAAIgCALg");
	this.shape_487.setTransform(237.95,193.775);

	this.shape_488 = new cjs.Shape();
	this.shape_488.graphics.f("#D9D9D9").s().p("AgLAkQgDgBAAgEIACgJIAHggIgIAAIACgIIAHAAIADgNIAKgIIgEAVIAKAAIgCAIIgKAAIgFAfIgBAGIABAEIACAAIAGAAIgCAIIgGABQgGAAgDgEg");
	this.shape_488.setTransform(235.325,193.85);

	this.shape_489 = new cjs.Shape();
	this.shape_489.graphics.f("#D9D9D9").s().p("AgVAZQgFgFAAgHQABgEACgEQACgEADgBQAEgCAFgCIAMAAQAIAAAEgCIACgHQAAgEgDgBQgDgDgGAAQgGAAgDADQgFADgCAEIgJgBQADgIAGgEQAHgFAJAAQAKAAAHAFQAEAEAAAGIgBAKIgDAOIgBALIABAIIgKAAIgBgHQgGAEgEACQgEACgFAAQgIAAgFgFgAAKABIgIABIgLACQgDABgCACQgCADAAADQAAAEADADQADACAFAAQAFAAADgCQAFgDACgEQADgFABgIIgEABg");
	this.shape_489.setTransform(230.3,194.85);

	this.shape_490 = new cjs.Shape();
	this.shape_490.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgCgFQgEgGAAgIQABgIAEgJQAFgJAGgDQAHgFAHAAQALAAAFAHQAHAGgBALIAAAIIgqAAIAAACQAAAJAEADQAEAFAFAAQAEAAAFgDQAFgEADgGIAJABQgCAHgHAGQgIAHgJAAQgGAAgGgDgAgGgRQgFAEgCAJIAeAAIAAgCQAAgHgDgFQgEgEgFAAQgGABgFAEg");
	this.shape_490.setTransform(224.25,194.85);

	this.shape_491 = new cjs.Shape();
	this.shape_491.graphics.f("#D9D9D9").s().p("AgUAdIAMg4IAIAAIgCAMQADgHAFgDQAEgDAEAAQADAAAEACIgEAJQgCgCgDAAQgFAAgGAGQgEAGgDANIgFAXg");
	this.shape_491.setTransform(219.875,194.775);

	this.shape_492 = new cjs.Shape();
	this.shape_492.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgIAEgKQAEgIAGgFQAHgFAJAAQAJAAAFAGQAFAEAAAJIgKAAQAAgFgCgDQgDgDgFAAQgFAAgFAEQgEAEgDAHQgCAHAAAGQAAAIADAEQAEADAEAAQAEAAAFgDQADgEADgIIAKABQgEAMgGAEQgIAGgHAAQgJAAgGgGg");
	this.shape_492.setTransform(215,194.85);

	this.shape_493 = new cjs.Shape();
	this.shape_493.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_493.setTransform(210.825,193.775);

	this.shape_494 = new cjs.Shape();
	this.shape_494.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_494.setTransform(207.775,193.775);

	this.shape_495 = new cjs.Shape();
	this.shape_495.graphics.f("#D9D9D9").s().p("AgKAdIACgMIAKAAIgCAMgAgBgQIABgMIALAAIgCAMg");
	this.shape_495.setTransform(204.525,194.85);

	this.shape_496 = new cjs.Shape();
	this.shape_496.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKgBIABAHQABADAEADQADABAFAAQAFAAADgCQAEgDAAgEQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBgBAAAAQgCgCgIgDIgJgFQgEgCgBgCQgCgDAAgEQAAgHAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgFgEgEQgDgDgGAAQgFABgCACQgDACAAADQAAADACABIAIAFQALAFADACQAEAEAAAHQAAADgCAFQgDAEgFADQgGACgGAAQgKAAgHgFg");
	this.shape_496.setTransform(200.2233,194.85);

	this.shape_497 = new cjs.Shape();
	this.shape_497.graphics.f("#D9D9D9").s().p("AgdAoIAQhOIAJAAIgBAIQAFgFADgCQADgCAFAAQAIAAAFAGQAGAGAAALQAAAJgDAHQgDAGgEAFQgFAEgEACQgEADgFAAQgJAAgGgLIgHAfgAABgdQgCACgDAEQgDADgBAGQgCAGAAAEIABAIQACADACACQADADAEAAQAIAAAFgKQAFgIAAgKQAAgHgDgEQgEgEgFAAQgEAAgDACg");
	this.shape_497.setTransform(194.05,195.875);

	this.shape_498 = new cjs.Shape();
	this.shape_498.graphics.f("#D9D9D9").s().p("AgLAkQgDgBAAgEIACgJIAHggIgIAAIACgIIAHAAIADgNIAKgIIgEAVIAKAAIgCAIIgKAAIgFAfIgBAGIABAEIACAAIAGAAIgCAIIgGABQgGAAgDgEg");
	this.shape_498.setTransform(190.175,193.85);

	this.shape_499 = new cjs.Shape();
	this.shape_499.graphics.f("#D9D9D9").s().p("AgLAkQgDgBAAgEIACgJIAHggIgIAAIACgIIAHAAIADgNIAKgIIgEAVIAKAAIgCAIIgKAAIgFAfIgBAGIABAEIACAAIAGAAIgCAIIgGABQgGAAgDgEg");
	this.shape_499.setTransform(187.125,193.85);

	this.shape_500 = new cjs.Shape();
	this.shape_500.graphics.f("#D9D9D9").s().p("AAJAnIAHgiIACgJQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgFAAgFADQgEACgCAFQgDAEgCALIgFAYIgKAAIAQhNIAKAAIgGAeQAFgGAEgCQAFgCAEAAQAIAAADAEQAEADAAAHIgBAKIgHAhg");
	this.shape_500.setTransform(182.025,193.775);

	this.shape_501 = new cjs.Shape();
	this.shape_501.graphics.f("#D9D9D9").s().p("AgOAbQgGgDgCgFQgDgGAAgIQgBgHAFgKQAEgIAHgEQAHgFAHAAQAKAAAHAGQAFAHAAALIgBAHIgoAAIAAADQgBAIAEAFQAEAEAFAAQAEAAAFgDQAFgDADgHIAJABQgCAHgHAGQgIAHgJAAQgGAAgFgDgAgGgRQgFAFgCAIIAeAAIAAgCQAAgHgDgEQgEgFgGAAQgFABgFAEg");
	this.shape_501.setTransform(429.75,180.65);

	this.shape_502 = new cjs.Shape();
	this.shape_502.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKAAIABAGQABAEAEABQADACAFAAQAFAAADgCQAEgDAAgEQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBgBAAAAQgCgDgIgDIgJgDQgEgDgBgDQgCgCAAgFQAAgGAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgFgEgDQgDgEgGAAQgFABgCACQgDACAAADQAAACACADIAIAEQALAFADACQAEAEAAAGQAAAEgCAFQgDAEgFADQgGACgGAAQgKAAgHgFg");
	this.shape_502.setTransform(424.0233,180.65);

	this.shape_503 = new cjs.Shape();
	this.shape_503.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_503.setTransform(418.025,180.575);

	this.shape_504 = new cjs.Shape();
	this.shape_504.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgCgGAAgIQAAgHAEgKQAFgIAGgEQAHgFAHAAQALAAAFAGQAHAHAAALIgBAHIgqAAIAAADQABAIADAFQAEAEAFAAQAEAAAFgDQAFgDACgHIAKABQgCAHgIAGQgGAHgKAAQgGAAgGgDgAgGgRQgFAFgDAIIAgAAIAAgCQAAgHgFgEQgDgFgGAAQgFABgFAEg");
	this.shape_504.setTransform(412.05,180.65);

	this.shape_505 = new cjs.Shape();
	this.shape_505.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgJAEgJQAEgIAGgFQAIgFAHAAQAKAAAFAFQAFAFAAAJIgKABQAAgGgDgDQgDgDgFAAQgEAAgFAEQgEADgDAIQgCAGAAAIQAAAHADAEQADADAFAAQAEAAAEgDQAFgEACgHIAKABQgEAKgGAFQgIAGgHAAQgKAAgFgGg");
	this.shape_505.setTransform(406.45,180.65);

	this.shape_506 = new cjs.Shape();
	this.shape_506.graphics.f("#D9D9D9").s().p("AgMAnIALg4IAJAAIgKA4gAABgbIADgLIAJAAIgDALg");
	this.shape_506.setTransform(402.55,179.575);

	this.shape_507 = new cjs.Shape();
	this.shape_507.graphics.f("#D9D9D9").s().p("AgZAnIAQhNIAKAAIgOBEIAoAAIgCAJg");
	this.shape_507.setTransform(397.9,179.575);

	this.shape_508 = new cjs.Shape();
	this.shape_508.graphics.f("#D9D9D9").s().p("AgYAiQgFgGAAgMQAAgKAEgIQAEgIAHgEQAGgFAGAAQALAAAFALIAGgfIAKAAIgQBOIgKAAIACgJQgHAKgKAAQgHAAgGgGgAgHgKIgGAGIgFAIQgCAGAAAEIABAKQACAEADACQACACAFAAQAGAAAFgHQAGgJABgNQAAgGgEgEQgDgEgFAAQgEAAgCABg");
	this.shape_508.setTransform(389.25,179.65);

	this.shape_509 = new cjs.Shape();
	this.shape_509.graphics.f("#D9D9D9").s().p("AgOAbQgGgDgCgFQgEgGAAgIQAAgHAFgKQAFgIAGgEQAHgFAHAAQAKAAAHAGQAFAHAAALIgBAHIgpAAIAAADQAAAIAEAFQAEAEAFAAQAEAAAFgDQAFgDADgHIAJABQgCAHgHAGQgIAHgJAAQgGAAgFgDgAgGgRQgFAFgCAIIAeAAIAAgCQAAgHgDgEQgEgFgFAAQgGABgFAEg");
	this.shape_509.setTransform(382.75,180.65);

	this.shape_510 = new cjs.Shape();
	this.shape_510.graphics.f("#D9D9D9").s().p("AgLAlQgDgCAAgEIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgHIgEAWIAKAAIgCAHIgKAAIgFAfIgBAHIABACIACABIAGgBIgCAJIgGAAQgGAAgDgCg");
	this.shape_510.setTransform(378.575,179.65);

	this.shape_511 = new cjs.Shape();
	this.shape_511.graphics.f("#D9D9D9").s().p("AgUAdIAMg4IAIAAIgCAMQADgHAFgDQAEgDAEAAQADAAAEACIgEAJQgCgCgDAAQgFAAgGAGQgEAGgDANIgFAXg");
	this.shape_511.setTransform(375.325,180.575);

	this.shape_512 = new cjs.Shape();
	this.shape_512.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgDgGAAgGQAAgQAKgLQAIgJAMAAQAKAAAHAGQAGAHAAALQAAAJgEAIQgEAJgHAFQgIAEgHAAQgGAAgGgDgAgEgTQgDACgEAEQgDAEgBAGIgBAJQAAAIADAEQAEAFAGgBIAGgBIAFgEIAFgFIACgIQACgEABgFQgBgIgEgEQgEgEgFgBQgEABgEACg");
	this.shape_512.setTransform(370,180.65);

	this.shape_513 = new cjs.Shape();
	this.shape_513.graphics.f("#D9D9D9").s().p("AgdAoIAQhOIAJAAIgCAIQAGgFACgCQAEgCAFAAQAIAAAGAGQAFAGAAALQAAAJgDAHQgDAGgFAFQgDAEgFACQgFADgEAAQgKAAgFgLIgGAfgAABgdQgCACgDAEQgCADgCAGQgCAGAAAEIABAIQABADADACQAEADACAAQAJAAAFgKQAFgIAAgKQAAgHgDgEQgDgEgGAAQgDAAgEACg");
	this.shape_513.setTransform(363.55,181.675);

	this.shape_514 = new cjs.Shape();
	this.shape_514.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_514.setTransform(357.625,180.575);

	this.shape_515 = new cjs.Shape();
	this.shape_515.graphics.f("#D9D9D9").s().p("AgWAlQgHgDgDgFQgDgGAAgGIACgOIAJgqIALAAIgLAvIgBAJQAAAGAFAFQAFADAIAAQAGAAAEgCQAFgDADgGQADgFADgMIAJgqIAKAAIgJAtQgDAMgEAGQgEAIgHAEQgHAEgJAAQgJAAgGgDg");
	this.shape_515.setTransform(351.275,179.65);

	this.shape_516 = new cjs.Shape();
	this.shape_516.graphics.f("#D9D9D9").s().p("AgUAhQgGgHAAgNQAAgKADgJQADgLAEgGQADgGAEgEIAIgFQADgBAEAAQAJAAAGAGQAGAHAAANQAAANgEAMQgFAPgIAHQgIAGgHAAQgJAAgGgHgAAAgeQgEACgDAFQgEAHgDAOQgDAKAAAHQAAAIACAEQAEAFAGAAQAFAAAEgFQAHgHADgOQAEgNAAgJQAAgIgEgEQgDgEgFAAQgEAAgCACg");
	this.shape_516.setTransform(340.95,179.625);

	this.shape_517 = new cjs.Shape();
	this.shape_517.graphics.f("#D9D9D9").s().p("AgFAGIABgKIAKAAIgCAKg");
	this.shape_517.setTransform(335.7,182.95);

	this.shape_518 = new cjs.Shape();
	this.shape_518.graphics.f("#D9D9D9").s().p("AgTAiQgHgGgBgKIAKgBQABAIADAEQAEADAGAAQAGAAAGgFQAFgFAAgHQAAgFgEgEQgEgEgGAAIgDAAIACgHIACAAQAIAAAEgEQAFgEAAgGQAAgFgEgEQgDgEgGAAQgFAAgDAEQgEAEgCAHIgJgCQACgKAHgFQAHgFAIAAQAKAAAGAGQAGAFAAAJQAAAGgEAFQgDAEgGAEQAEABACAEQADAEAAAFQAAALgIAHQgIAIgKAAQgLAAgGgGg");
	this.shape_518.setTransform(331.675,179.625);

	this.shape_519 = new cjs.Shape();
	this.shape_519.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_519.setTransform(322.225,180.575);

	this.shape_520 = new cjs.Shape();
	this.shape_520.graphics.f("#D9D9D9").s().p("AgPAbQgGgDgCgFQgDgGAAgGQAAgQAJgLQAJgJAMAAQALAAAFAGQAHAHAAALQAAAJgEAIQgEAJgIAFQgGAEgIAAQgGAAgGgDgAgEgTQgEACgCAEQgEAEgBAGIgCAJQAAAIAEAEQAFAFAGgBIAEgBIAGgEIAEgFIAEgIQACgEAAgFQAAgIgFgEQgDgEgHgBQgDABgEACg");
	this.shape_520.setTransform(316.3,180.65);

	this.shape_521 = new cjs.Shape();
	this.shape_521.graphics.f("#D9D9D9").s().p("AgMAnIAMg4IAJAAIgLA4gAABgbIACgLIAKAAIgDALg");
	this.shape_521.setTransform(312.25,179.575);

	this.shape_522 = new cjs.Shape();
	this.shape_522.graphics.f("#D9D9D9").s().p("AgLAlQgDgCAAgEIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgHIgEAWIAKAAIgCAHIgKAAIgFAfIgBAHIABACIACABIAGgBIgCAJIgGAAQgGAAgDgCg");
	this.shape_522.setTransform(309.625,179.65);

	this.shape_523 = new cjs.Shape();
	this.shape_523.graphics.f("#D9D9D9").s().p("AgWAZQgEgEAAgFIABgMIAHggIAKAAIgIAjIgBAHQAAADACACQACACAEAAQAEAAAEgCQADgCADgDQADgEABgEIADgKIAFgYIAKAAIgMA4IgJAAIACgLQgJAMgLAAQgGAAgEgEg");
	this.shape_523.setTransform(304.875,180.725);

	this.shape_524 = new cjs.Shape();
	this.shape_524.graphics.f("#D9D9D9").s().p("AgJAlQgEgDgDgGIgCALIgJAAIARhOIAKAAIgGAcQAEgFADgBQAEgCAEAAQAIAAAFAGQAGAGAAAKQAAAIgDAHQgCAGgDAEIgGAGQgEAEgDABIgHABQgFAAgEgDgAgDgHQgEAEgDAHIgCALIAAACQAAAHADAEQAEAEAFAAQAEAAAEgDQAFgFACgHQADgIAAgGQAAgGgDgEQgEgEgFAAQgFAAgEAEg");
	this.shape_524.setTransform(298.475,179.65);

	this.shape_525 = new cjs.Shape();
	this.shape_525.graphics.f("#D9D9D9").s().p("AgMAnIALg4IAJAAIgKA4gAABgbIADgLIAJAAIgDALg");
	this.shape_525.setTransform(294.55,179.575);

	this.shape_526 = new cjs.Shape();
	this.shape_526.graphics.f("#D9D9D9").s().p("AgUAdIAMg4IAIAAIgCAMQADgHAFgDQAEgDAEAAQADAAAEACIgEAJQgCgCgDAAQgFAAgGAGQgEAGgDANIgFAXg");
	this.shape_526.setTransform(291.725,180.575);

	this.shape_527 = new cjs.Shape();
	this.shape_527.graphics.f("#D9D9D9").s().p("AgLAlQgDgCAAgEIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgHIgEAWIAKAAIgCAHIgKAAIgFAfIgBAHIABACIACABIAGgBIgCAJIgGAAQgGAAgDgCg");
	this.shape_527.setTransform(288.275,179.65);

	this.shape_528 = new cjs.Shape();
	this.shape_528.graphics.f("#D9D9D9").s().p("AgLAlQgDgCAAgEIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgHIgEAWIAKAAIgCAHIgKAAIgFAfIgBAHIABACIACABIAGgBIgCAJIgGAAQgGAAgDgCg");
	this.shape_528.setTransform(285.225,179.65);

	this.shape_529 = new cjs.Shape();
	this.shape_529.graphics.f("#D9D9D9").s().p("AAYAnIgDgWIgfAAIgNAWIgLAAIAshNIAMAAIANBNgAAGgOIgLAWIAZAAIgEgSQgCgMAAgIIgIAQg");
	this.shape_529.setTransform(279.1,179.575);

	this.shape_530 = new cjs.Shape();
	this.shape_530.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKAAIABAGQABAEAEABQADACAFAAQAFAAADgCQAEgDAAgEQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBgBAAAAQgCgDgIgDIgJgDQgEgDgBgDQgCgCAAgFQAAgGAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgFgEgDQgDgEgGAAQgFABgCACQgDACAAADQAAACACADIAIAEQALAFADACQAEAEAAAGQAAAEgCAFQgDAEgFADQgGACgGAAQgKAAgHgFg");
	this.shape_530.setTransform(270.2233,180.65);

	this.shape_531 = new cjs.Shape();
	this.shape_531.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_531.setTransform(264.225,180.575);

	this.shape_532 = new cjs.Shape();
	this.shape_532.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgDgGAAgGQAAgQAKgLQAIgJAMAAQAKAAAHAGQAGAHAAALQAAAJgEAIQgEAJgHAFQgIAEgHAAQgGAAgGgDgAgDgTQgFACgDAEQgDAEgBAGIgBAJQAAAIADAEQAFAFAFgBIAGgBIAFgEIAFgFIACgIQACgEAAgFQAAgIgEgEQgEgEgFgBQgEABgDACg");
	this.shape_532.setTransform(258.3,180.65);

	this.shape_533 = new cjs.Shape();
	this.shape_533.graphics.f("#D9D9D9").s().p("AAYAdIAIgkIABgHQAAgBAAAAQAAgBAAgBQgBAAAAAAQAAgBAAAAQgCgCgEAAQgEAAgFADQgEACgCAEQgDAFgCAIIgFAbIgKAAIAIglIABgGQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgDAAQgEAAgEADQgFACgDAFQgCAFgDAHIgFAbIgKAAIAMg4IAJAAIgBAKQAFgGAFgDQAEgCAEAAQAFAAAEADQADADACAFQADgGAGgCQAEgDAGAAQAHAAAEADQADAEAAAGIgCAJIgHAjg");
	this.shape_533.setTransform(250.65,180.575);

	this.shape_534 = new cjs.Shape();
	this.shape_534.graphics.f("#D9D9D9").s().p("AAYAdIAIgkIABgHQAAgBAAAAQAAgBAAgBQgBAAAAAAQAAgBgBAAQgCgCgCAAQgFAAgEADQgFACgDAEQgCAFgCAIIgGAbIgIAAIAIglIAAgGQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgDAAQgEAAgFADQgEACgDAFQgCAFgCAHIgGAbIgKAAIAMg4IAKAAIgCAKQAFgGAEgDQAFgCAEAAQAFAAADADQAEADACAFQAEgGAEgCQAFgDAFAAQAIAAADADQAEAEAAAGIgBAJIgIAjg");
	this.shape_534.setTransform(241.6,180.575);

	this.shape_535 = new cjs.Shape();
	this.shape_535.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgDgGAAgGQAAgQAKgLQAIgJAMAAQAKAAAHAGQAGAHAAALQAAAJgEAIQgEAJgHAFQgIAEgHAAQgGAAgGgDgAgEgTQgDACgEAEQgDAEgBAGIgBAJQAAAIADAEQAEAFAGgBIAGgBIAFgEIAEgFIADgIQACgEABgFQgBgIgEgEQgEgEgGgBQgDABgEACg");
	this.shape_535.setTransform(234.1,180.65);

	this.shape_536 = new cjs.Shape();
	this.shape_536.graphics.f("#D9D9D9").s().p("AgaAgQgIgJAAgQQAAgVANgNQALgNAQAAQAMAAAIAHQAIAHABALIgKABQgBgJgFgEQgFgEgIAAQgNAAgJANQgIALAAAOQAAAMAGAHQAGAGAKAAQAHAAAGgFQAHgGADgJIALABQgFAOgKAHQgJAHgLAAQgOAAgJgJg");
	this.shape_536.setTransform(227.425,179.575);

	this.shape_537 = new cjs.Shape();
	this.shape_537.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgDgGAAgIQABgHAEgKQAEgIAHgEQAHgFAHAAQALAAAFAGQAHAHgBALIAAAHIgqAAIAAADQABAIADAFQAEAEAFAAQAEAAAFgDQAFgDADgHIAJABQgCAHgHAGQgIAHgJAAQgGAAgGgDgAgGgRQgFAFgDAIIAfAAIAAgCQABgHgEgEQgEgFgFAAQgGABgFAEg");
	this.shape_537.setTransform(216.95,180.65);

	this.shape_538 = new cjs.Shape();
	this.shape_538.graphics.f("#D9D9D9").s().p("AgQAdIgKg4IAKAAIAFAeIACARIAHgOIASghIAKAAIgfA4g");
	this.shape_538.setTransform(211.75,180.65);

	this.shape_539 = new cjs.Shape();
	this.shape_539.graphics.f("#D9D9D9").s().p("AgMAnIALg4IAJAAIgLA4gAABgbIADgLIAJAAIgCALg");
	this.shape_539.setTransform(207.45,179.575);

	this.shape_540 = new cjs.Shape();
	this.shape_540.graphics.f("#D9D9D9").s().p("AgLAlQgDgCAAgEIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgHIgEAWIAKAAIgCAHIgKAAIgFAfIgBAHIABACIACABIAGgBIgCAJIgGAAQgGAAgDgCg");
	this.shape_540.setTransform(204.825,179.65);

	this.shape_541 = new cjs.Shape();
	this.shape_541.graphics.f("#D9D9D9").s().p("AgVAZQgFgFABgHQAAgFACgDQABgEAEgBQAEgDAFgBIAMgBQAIAAAEgBIACgHQAAgEgDgBQgDgDgHAAQgEAAgEADQgEACgDAFIgJgBQADgIAGgEQAHgFAJAAQAKAAAHAFQAEAEAAAGIgBAKIgDAOIgBALIABAIIgKAAIgBgIQgGAFgEACQgEACgFAAQgIAAgFgFgAAKABIgIABIgLABQgDACgCADQgCACAAADQAAAEADADQADACAFAAQAFAAADgCQAFgDACgFQADgEABgIIgEABg");
	this.shape_541.setTransform(199.8,180.65);

	this.shape_542 = new cjs.Shape();
	this.shape_542.graphics.f("#D9D9D9").s().p("AgOAbQgGgDgCgFQgEgGAAgIQAAgHAFgKQAFgIAGgEQAHgFAHAAQAKAAAHAGQAFAHAAALIgBAHIgpAAIAAADQAAAIAEAFQAEAEAFAAQAEAAAFgDQAFgDADgHIAJABQgCAHgHAGQgIAHgJAAQgGAAgFgDgAgGgRQgFAFgCAIIAeAAIAAgCQAAgHgDgEQgEgFgFAAQgGABgFAEg");
	this.shape_542.setTransform(193.75,180.65);

	this.shape_543 = new cjs.Shape();
	this.shape_543.graphics.f("#D9D9D9").s().p("AgUAdIAMg4IAIAAIgCAMQADgHAFgDQAEgDAEAAQADAAAEACIgEAJQgCgCgDAAQgFAAgGAGQgEAGgDANIgFAXg");
	this.shape_543.setTransform(189.375,180.575);

	this.shape_544 = new cjs.Shape();
	this.shape_544.graphics.f("#D9D9D9").s().p("AgaAgQgIgJAAgQQAAgVANgNQALgNAQAAQAMAAAIAHQAIAHABALIgKABQgBgJgFgEQgFgEgIAAQgNAAgJANQgIALAAAOQAAAMAGAHQAGAGAKAAQAHAAAGgFQAHgGADgJIALABQgFAOgKAHQgJAHgLAAQgOAAgJgJg");
	this.shape_544.setTransform(183.475,179.575);

	this.shape_545 = new cjs.Shape();
	this.shape_545.graphics.f("#D9D9D9").s().p("AAYAdIAIgkIABgHQAAgBAAAAQAAgBAAgBQgBAAAAAAQAAgBgBAAQgBgCgEAAQgEAAgFADQgEACgCAEQgDAFgCAIIgFAbIgKAAIAIglIABgGQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgDAAQgEAAgEADQgFACgDAFQgCAFgDAHIgFAbIgKAAIAMg4IAJAAIgBAKQAFgGAEgDQAFgCAEAAQAFAAADADQAEADACAFQADgGAGgCQAEgDAGAAQAHAAAEADQADAEAAAGIgCAJIgHAjg");
	this.shape_545.setTransform(434.25,166.375);

	this.shape_546 = new cjs.Shape();
	this.shape_546.graphics.f("#D9D9D9").s().p("AgPAbQgGgDgCgFQgDgFAAgHQAAgQAJgLQAJgJAMAAQALAAAFAGQAHAHAAALQAAAJgEAIQgEAJgIAFQgGAEgIAAQgHAAgFgDgAgDgTQgFACgCAEQgDAFgCAFIgCAJQAAAIAFAEQADAFAHgBIAEgBIAGgEIAFgGIADgHQABgEAAgFQAAgIgDgEQgFgFgFAAQgEAAgDADg");
	this.shape_546.setTransform(426.75,166.45);

	this.shape_547 = new cjs.Shape();
	this.shape_547.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgIAEgJQAEgKAGgEQAHgFAIAAQAKAAAFAFQAFAGAAAIIgKABQAAgFgCgEQgDgDgFAAQgFAAgFAEQgEAEgCAHQgDAGAAAIQAAAHADAEQAEADAEAAQAEAAAEgDQAEgEADgHIAKABQgEAKgGAGQgIAFgHAAQgJAAgGgGg");
	this.shape_547.setTransform(421.1,166.45);

	this.shape_548 = new cjs.Shape();
	this.shape_548.graphics.f("#D9D9D9").s().p("AgFAFIABgJIAKAAIgCAJg");
	this.shape_548.setTransform(416.25,168.75);

	this.shape_549 = new cjs.Shape();
	this.shape_549.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgIAEgJQAEgKAGgEQAHgFAJAAQAJAAAFAFQAFAGAAAIIgKABQAAgFgCgEQgDgDgFAAQgFAAgFAEQgEAEgDAHQgCAGAAAIQAAAHADAEQAEADAEAAQAEAAAFgDQADgEADgHIAKABQgEAKgGAGQgIAFgHAAQgJAAgGgGg");
	this.shape_549.setTransform(412.55,166.45);

	this.shape_550 = new cjs.Shape();
	this.shape_550.graphics.f("#D9D9D9").s().p("AgMAnIAMg4IAJAAIgLA4gAABgbIACgLIAKAAIgDALg");
	this.shape_550.setTransform(408.65,165.375);

	this.shape_551 = new cjs.Shape();
	this.shape_551.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKAAIABAHQABACAEACQADACAFAAQAFAAADgDQAEgCAAgEQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBgBAAAAQgCgCgIgEIgJgDQgEgDgBgDQgCgCAAgFQAAgGAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgFgEgDQgDgDgGgBQgFAAgCADQgDACAAADQAAADACACIAIAEQALAFADABQAEAFAAAGQAAAEgCAFQgDAEgFACQgGADgGAAQgKAAgHgFg");
	this.shape_551.setTransform(404.4733,166.45);

	this.shape_552 = new cjs.Shape();
	this.shape_552.graphics.f("#D9D9D9").s().p("AgWAZQgEgEAAgFIABgMIAHggIAKAAIgIAjIgBAHQAAADACACQACACAEAAQAEAAAEgCQADgCADgDQADgEABgEIADgKIAFgYIAKAAIgMA4IgJAAIACgLQgJAMgLAAQgGAAgEgEg");
	this.shape_552.setTransform(398.825,166.525);

	this.shape_553 = new cjs.Shape();
	this.shape_553.graphics.f("#D9D9D9").s().p("AAYAdIAIgkIABgHQAAgBAAAAQAAgBAAgBQgBAAAAAAQAAgBgBAAQgCgCgCAAQgFAAgEADQgFACgDAEQgCAFgCAIIgGAbIgIAAIAIglIAAgGQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgDAAQgEAAgFADQgEACgDAFQgCAFgCAHIgGAbIgKAAIAMg4IAKAAIgCAKQAFgGAEgDQAFgCAEAAQAFAAADADQAEADABAFQAFgGAFgCQAEgDAFAAQAIAAADADQAEAEAAAGIgBAJIgIAjg");
	this.shape_553.setTransform(391,166.375);

	this.shape_554 = new cjs.Shape();
	this.shape_554.graphics.f("#D9D9D9").s().p("AgPAFIACgJIAdAAIgCAJg");
	this.shape_554.setTransform(384.8,166.45);

	this.shape_555 = new cjs.Shape();
	this.shape_555.graphics.f("#D9D9D9").s().p("AAIAnIgKgdIgMAKIgEATIgJAAIAPhNIAKAAIgKAvIAbgaIAOAAIgZAUIAPAkg");
	this.shape_555.setTransform(380.45,165.375);

	this.shape_556 = new cjs.Shape();
	this.shape_556.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgIAEgJQADgKAIgEQAGgFAJAAQAIAAAGAFQAFAGAAAIIgJABQAAgFgEgEQgCgDgGAAQgFAAgEAEQgEAEgCAHQgDAGAAAIQAAAHADAEQADADAFAAQAEAAAFgDQAEgEACgHIAJABQgDAKgHAGQgGAFgIAAQgJAAgGgGg");
	this.shape_556.setTransform(374.8,166.45);

	this.shape_557 = new cjs.Shape();
	this.shape_557.graphics.f("#D9D9D9").s().p("AgPAbQgGgDgCgFQgDgFAAgHQAAgQAKgLQAIgJAMAAQALAAAFAGQAHAHAAALQAAAJgEAIQgEAJgIAFQgGAEgIAAQgHAAgFgDgAgEgTQgDACgDAEQgEAFgBAFIgBAJQAAAIADAEQAFAFAFgBIAFgBIAGgEIAEgGIAEgHQACgEAAgFQAAgIgFgEQgDgFgHAAQgDAAgEADg");
	this.shape_557.setTransform(368.85,166.45);

	this.shape_558 = new cjs.Shape();
	this.shape_558.graphics.f("#D9D9D9").s().p("AgLAlQgDgCAAgEIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgHIgEAWIAKAAIgCAHIgKAAIgFAeIgBAIIABACIACABIAGgBIgCAIIgGABQgGAAgDgCg");
	this.shape_558.setTransform(364.625,165.45);

	this.shape_559 = new cjs.Shape();
	this.shape_559.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKAAIABAHQABACAEACQADACAFAAQAFAAADgDQAEgCAAgEQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBgBAAAAQgCgCgIgEIgJgDQgEgDgBgDQgCgCAAgFQAAgGAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgFgEgDQgDgDgGgBQgFAAgCADQgDACAAADQAAADACACIAIAEQALAFADABQAEAFAAAGQAAAEgCAFQgDAEgFACQgGADgGAAQgKAAgHgFg");
	this.shape_559.setTransform(360.0233,166.45);

	this.shape_560 = new cjs.Shape();
	this.shape_560.graphics.f("#D9D9D9").s().p("AgPAFIACgJIAdAAIgCAJg");
	this.shape_560.setTransform(355.5,166.45);

	this.shape_561 = new cjs.Shape();
	this.shape_561.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgDgGABgHQAAgJAEgIQAEgKAHgEQAHgEAHAAQALAAAFAGQAHAHAAALIgBAHIgqAAIAAAEQABAIADAEQAEAEAFAAQAEAAAFgDQAFgDACgHIAKABQgCAHgIAHQgGAGgKAAQgGAAgGgDgAgGgRQgFAFgDAIIAgAAIAAgCQAAgIgFgDQgDgEgGgBQgFAAgFAFg");
	this.shape_561.setTransform(350.5,166.45);

	this.shape_562 = new cjs.Shape();
	this.shape_562.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgCgFQgEgGAAgHQABgJAEgIQAFgKAGgEQAHgEAHAAQALAAAFAGQAHAHgBALIgBAHIgpAAIAAAEQAAAIAEAEQAEAEAFAAQAEAAAFgDQAFgDADgHIAJABQgCAHgHAHQgIAGgJAAQgGAAgGgDgAgGgRQgFAFgCAIIAeAAIAAgCQAAgIgDgDQgEgEgFgBQgGAAgFAFg");
	this.shape_562.setTransform(344.4,166.45);

	this.shape_563 = new cjs.Shape();
	this.shape_563.graphics.f("#D9D9D9").s().p("AgUAdIAMg4IAIAAIgCAMQADgHAFgDQAEgDAEAAQADAAAEACIgEAJQgCgCgDAAQgFAAgGAGQgEAGgDANIgFAXg");
	this.shape_563.setTransform(340.025,166.375);

	this.shape_564 = new cjs.Shape();
	this.shape_564.graphics.f("#D9D9D9").s().p("AgTAoIALgxIgJAAIABgHIAJAAIABgIIAEgJQABgCABgCQAEgCAFAAIALACIgCAIIgIgBQgBAAAAAAQgBAAgBAAQAAAAgBAAQAAABAAAAQgCABgBAGIgCAGIALAAIgBAHIgLAAIgJAxg");
	this.shape_564.setTransform(337,165.3);

	this.shape_565 = new cjs.Shape();
	this.shape_565.graphics.f("#D9D9D9").s().p("AgFAFIABgJIAKAAIgCAJg");
	this.shape_565.setTransform(332.75,168.75);

	this.shape_566 = new cjs.Shape();
	this.shape_566.graphics.f("#D9D9D9").s().p("AAAAcIgBggIAAgMIgFAMIgPAgIgKAAIgGg3IAJAAIACAZIABANIABAHIADgJIADgIIAOgcIAKAAIABAbIAAASIAKgTIALgaIAKAAIgcA3g");
	this.shape_566.setTransform(328.2,166.45);

	this.shape_567 = new cjs.Shape();
	this.shape_567.graphics.f("#D9D9D9").s().p("AABAcIgBggIgBgMIgFAMIgQAgIgKAAIgFg3IAJAAIADAZIAAANIABAHIACgJIAEgIIANgcIAKAAIACAbIABASIAJgTIAMgaIAJAAIgcA3g");
	this.shape_567.setTransform(320.25,166.45);

	this.shape_568 = new cjs.Shape();
	this.shape_568.graphics.f("#D9D9D9").s().p("AABAcIgCggIAAgMIgFAMIgQAgIgJAAIgHg3IAKAAIADAZIABANIAAAHIACgJIAEgIIAOgcIAJAAIACAbIAAASIAJgTIANgaIAKAAIgcA3g");
	this.shape_568.setTransform(312.3,166.45);

	this.shape_569 = new cjs.Shape();
	this.shape_569.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_569.setTransform(306.525,165.375);

	this.shape_570 = new cjs.Shape();
	this.shape_570.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_570.setTransform(303.475,165.375);

	this.shape_571 = new cjs.Shape();
	this.shape_571.graphics.f("#D9D9D9").s().p("AgKAcIACgKIAKAAIgCAKgAgBgRIABgKIALAAIgCAKg");
	this.shape_571.setTransform(300.225,166.45);

	this.shape_572 = new cjs.Shape();
	this.shape_572.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKAAIABAHQABACAEACQADACAFAAQAFAAADgDQAEgCAAgEQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBgBAAAAQgCgCgIgEIgJgDQgEgDgBgDQgCgCAAgFQAAgGAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgFgEgDQgDgDgGgBQgFAAgCADQgDACAAADQAAADACACIAIAEQALAFADABQAEAFAAAGQAAAEgCAFQgDAEgFACQgGADgGAAQgKAAgHgFg");
	this.shape_572.setTransform(295.9233,166.45);

	this.shape_573 = new cjs.Shape();
	this.shape_573.graphics.f("#D9D9D9").s().p("AgdAoIAQhOIAJAAIgCAIQAGgFACgCQAFgCAEAAQAIAAAGAGQAFAGAAALQAAAJgDAHQgDAGgFAFQgDAEgFACQgFADgEAAQgKAAgFgLIgGAfgAABgdQgCACgDAEQgCADgCAGQgCAGAAAEIABAIQABADADACQAEADACAAQAJAAAFgKQAFgIAAgKQAAgHgDgEQgDgEgGAAQgDAAgEACg");
	this.shape_573.setTransform(289.75,167.475);

	this.shape_574 = new cjs.Shape();
	this.shape_574.graphics.f("#D9D9D9").s().p("AgLAlQgDgCAAgEIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgHIgEAWIAKAAIgCAHIgKAAIgFAeIgBAIIABACIACABIAGgBIgCAIIgGABQgGAAgDgCg");
	this.shape_574.setTransform(285.875,165.45);

	this.shape_575 = new cjs.Shape();
	this.shape_575.graphics.f("#D9D9D9").s().p("AgLAlQgDgCAAgEIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgHIgEAWIAKAAIgCAHIgKAAIgFAeIgBAIIABACIACABIAGgBIgCAIIgGABQgGAAgDgCg");
	this.shape_575.setTransform(282.825,165.45);

	this.shape_576 = new cjs.Shape();
	this.shape_576.graphics.f("#D9D9D9").s().p("AAJAnIAHgiIACgJQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgFAAgFADQgEACgCAFQgDAEgCALIgFAYIgKAAIAQhNIAKAAIgGAeQAFgGAEgCQAFgCAEAAQAIAAADAEQAEADAAAHIgBAKIgHAhg");
	this.shape_576.setTransform(277.725,165.375);

	this.shape_577 = new cjs.Shape();
	this.shape_577.graphics.f("#D9D9D9").s().p("AgeAnIABgJIAGABQABAAAAAAQABAAAAAAQABgBAAAAQABAAAAAAIAGgIIADgFIgKg4IAKAAIAEAdIACAQIAZgtIAKAAIgjA/QgGAKgEADQgEADgFAAIgHgBg");
	this.shape_577.setTransform(269.175,167.6);

	this.shape_578 = new cjs.Shape();
	this.shape_578.graphics.f("#D9D9D9").s().p("AgJAlQgEgDgDgGIgCAKIgJAAIARhNIAKAAIgGAcQAEgEADgCQAEgCAEAAQAIAAAFAGQAGAGAAAKQAAAIgDAHQgCAFgDAFIgGAHQgEACgDABIgHACQgFAAgEgDgAgDgHQgEAEgDAHIgCALIAAACQAAAHADAEQAEAEAFAAQAEAAAEgDQAFgEACgIQADgHAAgHQAAgGgDgEQgEgEgFAAQgFAAgEAEg");
	this.shape_578.setTransform(263.125,165.45);

	this.shape_579 = new cjs.Shape();
	this.shape_579.graphics.f("#D9D9D9").s().p("AgYAiQgFgGAAgLQAAgLAEgHQAFgJAGgFQAGgEAGAAQALAAAEALIAHgfIAKAAIgRBNIgJAAIACgIQgHAKgKAAQgHAAgGgGgAgHgJIgGAFIgEAIQgCAGgBAEIACAKQABADACACQADADAFAAQAGAAAEgHQAIgJAAgOQgBgFgDgEQgEgEgEAAQgDAAgDACg");
	this.shape_579.setTransform(254.45,165.45);

	this.shape_580 = new cjs.Shape();
	this.shape_580.graphics.f("#D9D9D9").s().p("AgOAbQgGgDgCgFQgDgGAAgHQgBgJAFgIQAEgKAHgEQAHgEAHAAQAKAAAHAGQAFAHAAALIgBAHIgoAAIAAAEQgBAIAEAEQAEAEAFAAQAEAAAFgDQAFgDADgHIAJABQgCAHgHAHQgIAGgJAAQgGAAgFgDgAgGgRQgFAFgCAIIAeAAIAAgCQAAgIgDgDQgEgEgGgBQgFAAgFAFg");
	this.shape_580.setTransform(247.95,166.45);

	this.shape_581 = new cjs.Shape();
	this.shape_581.graphics.f("#D9D9D9").s().p("AgLAlQgDgCAAgEIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgHIgEAWIAKAAIgCAHIgKAAIgFAeIgBAIIABACIACABIAGgBIgCAIIgGABQgGAAgDgCg");
	this.shape_581.setTransform(243.775,165.45);

	this.shape_582 = new cjs.Shape();
	this.shape_582.graphics.f("#D9D9D9").s().p("AgPAbQgGgDgCgFQgDgFAAgHQAAgQAJgLQAJgJAMAAQAKAAAHAGQAGAHAAALQAAAJgEAIQgEAJgHAFQgIAEgHAAQgGAAgGgDgAgDgTQgEACgEAEQgDAFgBAFIgCAJQABAIAEAEQAEAFAFgBIAGgBIAFgEIAFgGIACgHQACgEAAgFQAAgIgDgEQgEgFgGAAQgEAAgDADg");
	this.shape_582.setTransform(238.85,166.45);

	this.shape_583 = new cjs.Shape();
	this.shape_583.graphics.f("#D9D9D9").s().p("AAYAdIAIgkIABgHQAAgBAAAAQAAgBAAgBQgBAAAAAAQAAgBAAAAQgCgCgEAAQgEAAgFADQgEACgCAEQgDAFgCAIIgGAbIgJAAIAIglIABgGQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgDAAQgEAAgEADQgFACgDAFQgDAFgCAHIgFAbIgKAAIAMg4IAKAAIgCAKQAFgGAFgDQAEgCAFAAQAEAAAEADQADADABAFQAFgGAEgCQAFgDAGAAQAGAAAFADQADAEAAAGIgCAJIgHAjg");
	this.shape_583.setTransform(231.2,166.375);

	this.shape_584 = new cjs.Shape();
	this.shape_584.graphics.f("#D9D9D9").s().p("AgPAbQgGgDgCgFQgDgFAAgHQAAgQAJgLQAJgJAMAAQALAAAFAGQAHAHAAALQAAAJgEAIQgEAJgIAFQgGAEgIAAQgGAAgGgDgAgDgTQgFACgCAEQgDAFgCAFIgCAJQAAAIAFAEQADAFAHgBIAEgBIAGgEIAEgGIAEgHQABgEAAgFQABgIgEgEQgFgFgGAAQgDAAgDADg");
	this.shape_584.setTransform(223.7,166.45);

	this.shape_585 = new cjs.Shape();
	this.shape_585.graphics.f("#D9D9D9").s().p("AgUAdIAMg4IAIAAIgCAMQADgHAFgDQAEgDAEAAQADAAAEACIgEAJQgCgCgDAAQgFAAgGAGQgEAGgDANIgFAXg");
	this.shape_585.setTransform(219.275,166.375);

	this.shape_586 = new cjs.Shape();
	this.shape_586.graphics.f("#D9D9D9").s().p("AgdAoIAQhOIAJAAIgCAIQAFgFADgCQAEgCAFAAQAIAAAGAGQAFAGAAALQAAAJgDAHQgDAGgEAFQgEAEgFACQgFADgEAAQgKAAgFgLIgGAfgAABgdQgCACgDAEQgDADgBAGQgCAGAAAEIABAIQABADADACQADADAEAAQAIAAAFgKQAFgIAAgKQAAgHgDgEQgDgEgGAAQgDAAgEACg");
	this.shape_586.setTransform(213.6,167.475);

	this.shape_587 = new cjs.Shape();
	this.shape_587.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgIAEgJQADgKAIgEQAGgFAJAAQAIAAAGAFQAFAGAAAIIgJABQAAgFgEgEQgDgDgEAAQgGAAgEAEQgEAEgCAHQgDAGAAAIQAAAHADAEQADADAFAAQAEAAAFgDQAEgEACgHIAJABQgDAKgHAGQgGAFgIAAQgKAAgFgGg");
	this.shape_587.setTransform(205.25,166.45);

	this.shape_588 = new cjs.Shape();
	this.shape_588.graphics.f("#D9D9D9").s().p("AgMAnIAMg4IAJAAIgMA4gAABgbIACgLIAKAAIgCALg");
	this.shape_588.setTransform(201.35,165.375);

	this.shape_589 = new cjs.Shape();
	this.shape_589.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKAAIABAHQABACAEACQADACAFAAQAFAAADgDQAEgCAAgEQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBgBAAAAQgCgCgIgEIgJgDQgEgDgBgDQgCgCAAgFQAAgGAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgFgEgDQgDgDgGgBQgFAAgCADQgDACAAADQAAADACACIAIAEQALAFADABQAEAFAAAGQAAAEgCAFQgDAEgFACQgGADgGAAQgKAAgHgFg");
	this.shape_589.setTransform(197.1733,166.45);

	this.shape_590 = new cjs.Shape();
	this.shape_590.graphics.f("#D9D9D9").s().p("AgWAZQgEgEAAgFIABgMIAHggIAKAAIgIAjIgBAHQAAADACACQACACAEAAQAEAAAEgCQADgCADgDQADgEABgEIADgKIAFgYIAKAAIgMA4IgJAAIACgLQgJAMgLAAQgGAAgEgEg");
	this.shape_590.setTransform(191.525,166.525);

	this.shape_591 = new cjs.Shape();
	this.shape_591.graphics.f("#D9D9D9").s().p("AASAnIAJgmQADgMAFgRIgIARIgcAyIgLAAIgHgxIgDgQIgCAQIgLAxIgJAAIAQhNIAMAAIAIAyIACATIAKgWIAdgvIANAAIgRBNg");
	this.shape_591.setTransform(184,165.375);

	this.shape_592 = new cjs.Shape();
	this.shape_592.graphics.f("#D9D9D9").s().p("AAYAnIgDgWIgfAAIgMAWIgMAAIAshNIAMAAIANBNgAAGgOIgLAWIAZAAIgEgSQgCgMAAgIIgIAQg");
	this.shape_592.setTransform(236.7,151.175);

	this.shape_593 = new cjs.Shape();
	this.shape_593.graphics.f("#D9D9D9").s().p("AgSAnIgQhNIAKAAIAJAtIAEAVIAIgQIAbgyIALAAIgrBNg");
	this.shape_593.setTransform(230.9,151.175);

	this.shape_594 = new cjs.Shape();
	this.shape_594.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgGQgDgFAAgHQABgJAEgIQAEgJAHgFQAHgEAHAAQALAAAFAHQAHAGAAALIgBAHIgqAAIAAAEQABAHADAEQAEAFAFAAQAEAAAFgEQAFgDACgGIAKABQgCAHgIAHQgGAGgKAAQgGAAgGgDgAgGgRQgFAEgDAJIAgAAIAAgCQAAgIgFgEQgDgDgGAAQgFgBgFAFg");
	this.shape_594.setTransform(223.15,152.25);

	this.shape_595 = new cjs.Shape();
	this.shape_595.graphics.f("#D9D9D9").s().p("AgXAjQgJgGAAgPIAKgBIAAADQAAAEACAEQACAEAFACQAFACAHAAQAIAAAFgEQAFgEAAgGQAAgDgDgEQgCgDgMgFIgMgFQgFgDgDgEQgCgFAAgFQAAgGADgFQADgFAHgCQAGgDAHAAQAKAAAHADQAGAEADAFQADAFAAAFIAAACIgKABIgBgGQgBgDgCgCIgGgEQgEgBgFAAQgIAAgEAEQgEADAAAFQAAADABACQACACAEACIAMAGIAMAFQAEADACAEQADAEAAAFQAAAHgEAFQgEAGgHADQgHADgIAAQgNAAgIgGg");
	this.shape_595.setTransform(216.675,151.175);

	this.shape_596 = new cjs.Shape();
	this.shape_596.graphics.f("#D9D9D9").s().p("AgPAFIACgJIAdAAIgCAJg");
	this.shape_596.setTransform(211.05,152.25);

	this.shape_597 = new cjs.Shape();
	this.shape_597.graphics.f("#D9D9D9").s().p("AgkAnIARhNIA4AAIgCAIIguAAIgFAZIAsAAIgCAIIgsAAIgFAbIAwAAIgCAJg");
	this.shape_597.setTransform(205.775,151.175);

	this.shape_598 = new cjs.Shape();
	this.shape_598.graphics.f("#D9D9D9").s().p("AAQAnIgNgXIgDgIIgHAIIgWAXIgOAAIAlgnIgVgmIALAAIAKARIAFAJIACAGQAEgGAIgIIARgSIAOAAIgmAnIAWAmg");
	this.shape_598.setTransform(198.3,151.175);

	this.shape_599 = new cjs.Shape();
	this.shape_599.graphics.f("#D9D9D9").s().p("AAUAnIgGgOIgHgOQgDgEgCgBQgCgCgHAAIgMAAIgHAjIgLAAIARhNIAgAAQAKAAAFABQAFACADAEQADAFAAAHQAAAJgHAHQgGAFgOACIAGAGQAFAHADAHIAGAPgAgRgDIAPAAIAMgBQAGAAAEgCQADgCACgEQADgDAAgEQAAgEgCgCQgCgDgCgBIgJgBIgYAAg");
	this.shape_599.setTransform(190.575,151.175);

	this.shape_600 = new cjs.Shape();
	this.shape_600.graphics.f("#D9D9D9").s().p("AggAnIAQhNIAXAAIAKAAQAFABAEACQADADACAEQACADAAAFQABAHgEAFQgDAFgIACQAHABADAEQADAFAAAFQAAAHgEAGQgDAGgHADQgGADgIAAgAgVAeIASAAIAJAAIAIgDQADgCACgEQACgDAAgEQAAgFgDgDQgEgDgKAAIgSAAgAgNgFIAPAAQALAAAGgEQAEgDAAgHQABgDgCgDQgCgCgCgBQgCgCgIAAIgPAAg");
	this.shape_600.setTransform(182.8,151.175);

	this.shape_601 = new cjs.Shape();
	this.shape_601.graphics.f("#D9D9D9").s().p("AgPAFIACgJIAdAAIgCAJg");
	this.shape_601.setTransform(439.15,138.05);

	this.shape_602 = new cjs.Shape();
	this.shape_602.graphics.f("#D9D9D9").s().p("AgJAlQgEgDgDgHIgCAMIgJAAIARhOIAKAAIgGAcQAEgEADgCQAEgCAEAAQAIAAAFAGQAGAGAAALQAAAHgDAGQgCAHgDAEIgGAGQgEADgDACIgHABQgFAAgEgDgAgDgHQgEAEgDAIQgCAGAAAEIAAACQAAAHADAEQAEAEAFAAQAEAAAEgEQAFgEACgHQADgHAAgHQAAgGgDgEQgEgEgFAAQgFAAgEAEg");
	this.shape_602.setTransform(434.075,137.05);

	this.shape_603 = new cjs.Shape();
	this.shape_603.graphics.f("#D9D9D9").s().p("AgTAoIALgwIgJAAIABgIIAJAAIACgIIACgJQACgDACgCQADgBAFAAIALABIgCAJIgIgCQgBAAAAABQgBAAgBAAQAAAAgBAAQAAABgBAAQgBABgBAGIgBAGIAKAAIgBAIIgLAAIgJAwg");
	this.shape_603.setTransform(430.4,136.9);

	this.shape_604 = new cjs.Shape();
	this.shape_604.graphics.f("#D9D9D9").s().p("AAMAnIgTgsIgIgVIgDASIgKAvIgKAAIARhNIAKAAIAMAdIAJAWIAFAOIAEgUIAJgtIALAAIgQBNg");
	this.shape_604.setTransform(424.4,136.975);

	this.shape_605 = new cjs.Shape();
	this.shape_605.graphics.f("#D9D9D9").s().p("AgHAoIAMg7QgIAGgOAEIABgJQAIgDAHgEIAJgJIAFgEIAFAAIgQBOg");
	this.shape_605.setTransform(417.3,136.95);

	this.shape_606 = new cjs.Shape();
	this.shape_606.graphics.f("#D9D9D9").s().p("AgTAiQgHgGAAgJQAAgJAEgGQAFgFAIgDQgEgCgDgEQgCgEAAgEQAAgHAFgGQAHgIALAAQAKAAAGAFQAGAGAAAIQAAAGgDAEQgEAFgGADQAEACACADQADAEAAAGQAAALgHAIQgIAIgMAAQgJAAgGgGgAgLAFQgFAGAAAJIABAGQACADAEACQACABAFAAQAHAAAEgHQAEgGAAgHQAAgFgDgEQgEgDgGAAQgGAAgFAFgAgBgeQgEACgCAEQgBADAAAEQgBAFAEADQADADAFAAQAGAAAEgEQAFgEAAgGQAAgFgDgDQgEgEgFAAQgFAAgCACg");
	this.shape_606.setTransform(411.25,137.025);

	this.shape_607 = new cjs.Shape();
	this.shape_607.graphics.f("#D9D9D9").s().p("AghAnIARhNIAyAAIgCAIIgoAAIgFAaIApAAIgCAIIgpAAIgHAjg");
	this.shape_607.setTransform(404.925,136.975);

	this.shape_608 = new cjs.Shape();
	this.shape_608.graphics.f("#D9D9D9").s().p("AgHAoIAMg7QgIAGgOAEIABgJQAIgDAHgEIAJgJIAFgEIAFAAIgQBOg");
	this.shape_608.setTransform(398.4,136.95);

	this.shape_609 = new cjs.Shape();
	this.shape_609.graphics.f("#D9D9D9").s().p("AgTAhQgHgHAAgOQAAgLAFgMQADgKAFgGQAEgGAGgDQAEgDAHAAQAIAAAFAFQAFAFABAJIgJABQgBgGgDgDQgDgDgEAAQgEAAgEADQgEAEgDAGIgFAMQAEgDAFgCQAEgCADAAQAJAAAFAGQAGAHAAAJQAAANgIAKQgIAIgKAAQgKAAgGgHgAgKAAQgGAHAAAKQAAAGAEAFQAEAEAFAAQADAAAEgCQAEgDADgGQADgFAAgGQAAgHgEgEQgEgEgFAAQgGAAgFAFg");
	this.shape_609.setTransform(392.425,137.025);

	this.shape_610 = new cjs.Shape();
	this.shape_610.graphics.f("#D9D9D9").s().p("AATAnIAIgmQACgMAGgRIgJARIgcAyIgKAAIgIgxIgCgQIgCAQIgKAxIgLAAIARhNIANAAIAIAyIACATIAJgWIAcgvIAOAAIgRBNg");
	this.shape_610.setTransform(384.75,136.975);

	this.shape_611 = new cjs.Shape();
	this.shape_611.graphics.f("#D9D9D9").s().p("AgfADIAAgGIA/AAIAAAGg");
	this.shape_611.setTransform(376.1,142.75);

	this.shape_612 = new cjs.Shape();
	this.shape_612.graphics.f("#D9D9D9").s().p("AgUAhQgGgHAAgNQAAgKADgJQADgLAEgGQADgGAEgEIAHgFQAEgBAEAAQAJAAAGAGQAGAHAAANQAAANgEAMQgFAPgIAHQgIAGgHAAQgJAAgGgHgAAAgeQgDACgDAFQgFAHgDAOQgDAKAAAHQAAAIACAEQAEAFAGAAQAFAAAEgFQAHgHADgOQAEgNAAgJQAAgIgEgEQgDgEgFAAQgDAAgDACg");
	this.shape_612.setTransform(371,137.025);

	this.shape_613 = new cjs.Shape();
	this.shape_613.graphics.f("#D9D9D9").s().p("AAKAdIgGgMIgEgKIgQAWIgNAAIAZgdIgOgcIALAAIAEAKIAFAMIAQgWIAMAAIgZAcIAPAdg");
	this.shape_613.setTransform(364.95,138.05);

	this.shape_614 = new cjs.Shape();
	this.shape_614.graphics.f("#D9D9D9").s().p("AgaAgQgIgJAAgQQAAgVANgNQALgNAQAAQAMAAAIAHQAIAHABALIgKABQgBgJgFgEQgFgEgIAAQgNAAgJANQgIALAAAOQAAAMAGAHQAGAGAKAAQAHAAAGgFQAHgGADgJIALABQgFAOgKAHQgJAHgLAAQgOAAgJgJg");
	this.shape_614.setTransform(358.575,136.975);

	this.shape_615 = new cjs.Shape();
	this.shape_615.graphics.f("#D9D9D9").s().p("AgWAlQgHgDgDgFQgDgFAAgHIACgOIAJgqIALAAIgLAvIgBAJQAAAGAFAEQAFAEAIAAQAGAAAEgDQAFgDADgFQADgFADgMIAJgqIAKAAIgJAtQgDAMgEAGQgEAHgHAFQgHAEgJAAQgJAAgGgDg");
	this.shape_615.setTransform(350.775,137.05);

	this.shape_616 = new cjs.Shape();
	this.shape_616.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_616.setTransform(345.025,136.975);

	this.shape_617 = new cjs.Shape();
	this.shape_617.graphics.f("#D9D9D9").s().p("AgMAnIAPhNIAKAAIgQBNg");
	this.shape_617.setTransform(342.2,136.975);

	this.shape_618 = new cjs.Shape();
	this.shape_618.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgGQgCgFAAgIQgBgIAFgIQAEgKAHgDQAHgFAHAAQAKAAAGAHQAGAGABALIgBAIIgpAAIAAACQgBAJAEADQAEAFAFAAQAEAAAFgEQAFgDACgGIAKABQgCAHgIAGQgGAHgKAAQgGAAgGgDgAgGgRQgFAFgDAIIAgAAIAAgCQAAgHgFgFQgDgDgGAAQgFAAgFAEg");
	this.shape_618.setTransform(337.7,138.05);

	this.shape_619 = new cjs.Shape();
	this.shape_619.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_619.setTransform(331.475,137.975);

	this.shape_620 = new cjs.Shape();
	this.shape_620.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_620.setTransform(325.375,137.975);

	this.shape_621 = new cjs.Shape();
	this.shape_621.graphics.f("#D9D9D9").s().p("AgVAZQgEgFAAgHQAAgEABgEQACgEAFgBQADgCAFgBIALgBQAJAAAFgCIABgHQAAgDgDgCQgDgDgHAAQgEAAgFADQgDADgCAEIgKAAQADgJAHgEQAGgFAJAAQALAAAFAFQAGAEAAAGIgCALIgDANIgCALIABAIIgKAAIgBgHQgEAEgFACQgEACgFAAQgIAAgFgFgAAKABIgIABIgLACQgDABgCACQgCADAAADQAAAEADADQACADAGAAQAEAAAEgDQAEgDADgEQADgFABgIIgEABg");
	this.shape_621.setTransform(319.35,138.05);

	this.shape_622 = new cjs.Shape();
	this.shape_622.graphics.f("#D9D9D9").s().p("AAJAnIAHgiIACgJQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgFAAgFADQgEACgCAFQgDAEgCALIgFAYIgKAAIAQhNIAKAAIgGAeQAFgGAEgCQAFgCAEAAQAIAAADAEQAEADAAAHIgBAKIgHAhg");
	this.shape_622.setTransform(313.175,136.975);

	this.shape_623 = new cjs.Shape();
	this.shape_623.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgIAEgKQAEgJAGgEQAHgFAJAAQAJAAAFAGQAFAEAAAJIgKAAQAAgEgCgEQgDgDgFAAQgFAAgFAEQgEAEgDAHQgCAHAAAGQAAAIADADQAEAFAEAAQAEAAAFgFQADgDADgIIAKABQgEAMgGAEQgIAGgHAAQgJAAgGgGg");
	this.shape_623.setTransform(307.7,138.05);

	this.shape_624 = new cjs.Shape();
	this.shape_624.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_624.setTransform(303.525,136.975);

	this.shape_625 = new cjs.Shape();
	this.shape_625.graphics.f("#D9D9D9").s().p("AAYAdIAIgkIABgHQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQgDgCgDAAQgEAAgFADQgEACgDAEQgCAFgCAIIgGAbIgJAAIAJglIAAgGQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgDAAQgEAAgFADQgEACgDAFQgDAFgCAHIgFAbIgKAAIAMg4IAKAAIgCAKQAFgGAFgDQADgCAGAAQAEAAAEADQADADABAFQAFgGAEgCQAGgDAEAAQAHAAAFADQADAEAAAGIgBAJIgIAjg");
	this.shape_625.setTransform(297.15,137.975);

	this.shape_626 = new cjs.Shape();
	this.shape_626.graphics.f("#D9D9D9").s().p("AgPAbQgGgDgCgFQgDgFAAgHQAAgQAKgLQAIgJAMAAQALAAAFAHQAHAGAAALQAAAJgEAJQgEAIgIAEQgGAFgIAAQgHAAgFgDgAgEgTQgDACgDAEQgEAFgBAFIgBAJQAAAIADAEQAFAEAFABIAFgCIAGgEIAEgFIAEgIQACgEAAgFQAAgIgFgEQgDgEgHAAQgDgBgEADg");
	this.shape_626.setTransform(289.65,138.05);

	this.shape_627 = new cjs.Shape();
	this.shape_627.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgIAEgKQADgJAIgEQAGgFAJAAQAIAAAGAGQAFAEAAAJIgJAAQAAgEgEgEQgDgDgEAAQgGAAgEAEQgEAEgCAHQgDAHAAAGQAAAIADADQADAFAFAAQAEAAAFgFQAEgDACgIIAJABQgDAMgHAEQgGAGgIAAQgKAAgFgGg");
	this.shape_627.setTransform(284,138.05);

	this.shape_628 = new cjs.Shape();
	this.shape_628.graphics.f("#D9D9D9").s().p("AgGAGIADgLIAKAAIgCALg");
	this.shape_628.setTransform(279.15,140.35);

	this.shape_629 = new cjs.Shape();
	this.shape_629.graphics.f("#D9D9D9").s().p("AgOAbQgGgDgCgGQgDgFAAgIQgBgIAFgIQAEgKAHgDQAHgFAHAAQAKAAAHAHQAFAGAAALIgBAIIgoAAIAAACQgBAJAEADQAEAFAFAAQAEAAAFgEQAFgDACgGIAKABQgCAHgIAGQgHAHgJAAQgGAAgFgDgAgGgRQgFAFgCAIIAeAAIAAgCQAAgHgEgFQgDgDgGAAQgFAAgFAEg");
	this.shape_629.setTransform(274.95,138.05);

	this.shape_630 = new cjs.Shape();
	this.shape_630.graphics.f("#D9D9D9").s().p("AgJAlQgEgDgDgHIgCAMIgJAAIARhOIAKAAIgGAcQAEgEADgCQAEgCAEAAQAIAAAFAGQAGAGAAALQAAAHgDAGQgCAHgDAEIgGAGQgEADgDACIgHABQgFAAgEgDgAgDgHQgEAEgDAIIgCAKIAAACQAAAHADAEQAEAEAFAAQAEAAAEgEQAFgEACgHQADgHAAgHQAAgGgDgEQgEgEgFAAQgFAAgEAEg");
	this.shape_630.setTransform(268.775,137.05);

	this.shape_631 = new cjs.Shape();
	this.shape_631.graphics.f("#D9D9D9").s().p("AgWAZQgEgEAAgFIABgMIAHggIAKAAIgIAjIgBAHQAAADACACQACACAEAAQAEAAAEgCQADgCADgDQADgEABgEIADgKIAFgYIAKAAIgMA4IgJAAIACgLQgJAMgLAAQgGAAgEgEg");
	this.shape_631.setTransform(262.975,138.125);

	this.shape_632 = new cjs.Shape();
	this.shape_632.graphics.f("#D9D9D9").s().p("AgLAkQgDgCAAgDIACgJIAHggIgIAAIACgIIAHAAIADgNIAKgHIgEAUIAKAAIgCAIIgKAAIgFAfIgBAGIABAEIACAAIAGAAIgCAIIgGABQgGAAgDgEg");
	this.shape_632.setTransform(258.575,137.05);

	this.shape_633 = new cjs.Shape();
	this.shape_633.graphics.f("#D9D9D9").s().p("AgWAZQgEgEAAgFIABgMIAHggIAKAAIgIAjIgBAHQAAADACACQACACAEAAQAEAAAEgCQADgCADgDQADgEABgEIADgKIAFgYIAKAAIgMA4IgJAAIACgLQgJAMgLAAQgGAAgEgEg");
	this.shape_633.setTransform(253.825,138.125);

	this.shape_634 = new cjs.Shape();
	this.shape_634.graphics.f("#D9D9D9").s().p("AgPAbQgGgDgCgFQgDgFAAgHQAAgQAJgLQAJgJAMAAQALAAAFAHQAHAGAAALQAAAJgEAJQgEAIgIAEQgGAFgIAAQgGAAgGgDgAgDgTQgFACgCAEQgDAFgCAFIgCAJQAAAIAFAEQADAEAHABIAEgCIAGgEIAEgFIAEgIQABgEABgFQgBgIgDgEQgFgEgGAAQgDgBgDADg");
	this.shape_634.setTransform(247.55,138.05);

	this.shape_635 = new cjs.Shape();
	this.shape_635.graphics.f("#D9D9D9").s().p("AgeAnIABgJIAGABQABAAAAAAQABAAAAAAQABgBAAAAQABAAAAgBIAGgGIADgGIgKg4IAKAAIAEAdIACAQIAZgtIAKAAIgjBAQgGAJgEADQgEADgFAAIgHgBg");
	this.shape_635.setTransform(241.875,139.2);

	this.shape_636 = new cjs.Shape();
	this.shape_636.graphics.f("#D9D9D9").s().p("AgFAGIACgLIAJAAIgBALg");
	this.shape_636.setTransform(237.05,140.35);

	this.shape_637 = new cjs.Shape();
	this.shape_637.graphics.f("#D9D9D9").s().p("AABAdIgBghIgBgMIgFANIgQAgIgKAAIgFg5IAJAAIADAaIAAAOIABAGIACgJIAEgIIANgdIAKAAIACAcIABARIAJgTIALgaIAKAAIgbA5g");
	this.shape_637.setTransform(232.5,138.05);

	this.shape_638 = new cjs.Shape();
	this.shape_638.graphics.f("#D9D9D9").s().p("AABAdIgCghIAAgMIgFANIgPAgIgKAAIgHg5IAKAAIADAaIABAOIAAAGIADgJIADgIIAOgdIAJAAIACAcIAAARIAJgTIANgaIAKAAIgcA5g");
	this.shape_638.setTransform(224.55,138.05);

	this.shape_639 = new cjs.Shape();
	this.shape_639.graphics.f("#D9D9D9").s().p("AAAAdIgBghIAAgMIgFANIgPAgIgKAAIgGg5IAJAAIACAaIABAOIABAGIADgJIADgIIAOgdIAKAAIABAcIAAARIAKgTIALgaIAKAAIgcA5g");
	this.shape_639.setTransform(216.6,138.05);

	this.shape_640 = new cjs.Shape();
	this.shape_640.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_640.setTransform(210.825,136.975);

	this.shape_641 = new cjs.Shape();
	this.shape_641.graphics.f("#D9D9D9").s().p("AgYApIAphRIAIAAIgpBRg");
	this.shape_641.setTransform(207.775,136.975);

	this.shape_642 = new cjs.Shape();
	this.shape_642.graphics.f("#D9D9D9").s().p("AgKAdIACgMIAKAAIgCAMgAgBgRIABgLIALAAIgCALg");
	this.shape_642.setTransform(204.525,138.05);

	this.shape_643 = new cjs.Shape();
	this.shape_643.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKgBIABAHQABAEAEACQADACAFAAQAFAAADgDQAEgDAAgDQAAgBAAgBQAAAAgBgBQAAAAAAgBQgBAAAAgBQgCgCgIgDIgJgFQgEgBgBgDQgCgEAAgDQAAgHAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgGgEgDQgDgCgGAAQgFgBgCADQgDADAAACQAAACACACIAIAFQALAFADACQAEAEAAAHQAAAEgCAEQgDAEgFACQgGADgGAAQgKAAgHgFg");
	this.shape_643.setTransform(200.2233,138.05);

	this.shape_644 = new cjs.Shape();
	this.shape_644.graphics.f("#D9D9D9").s().p("AgdAoIAQhOIAJAAIgBAIQAFgFADgCQADgCAFAAQAIAAAFAGQAGAGAAALQAAAJgDAHQgDAGgEAFQgFAEgEACQgEADgFAAQgJAAgGgLIgHAfgAABgdQgCACgDAEQgDADgBAGQgCAGAAAEIABAIQACADACACQADADAEAAQAIAAAFgKQAFgIAAgKQAAgHgDgEQgEgEgFAAQgEAAgDACg");
	this.shape_644.setTransform(194.05,139.075);

	this.shape_645 = new cjs.Shape();
	this.shape_645.graphics.f("#D9D9D9").s().p("AgLAkQgDgCAAgDIACgJIAHggIgIAAIACgIIAHAAIADgNIAKgHIgEAUIAKAAIgCAIIgKAAIgFAfIgBAGIABAEIACAAIAGAAIgCAIIgGABQgGAAgDgEg");
	this.shape_645.setTransform(190.175,137.05);

	this.shape_646 = new cjs.Shape();
	this.shape_646.graphics.f("#D9D9D9").s().p("AgLAkQgDgCAAgDIACgJIAHggIgIAAIACgIIAHAAIADgNIAKgHIgEAUIAKAAIgCAIIgKAAIgFAfIgBAGIABAEIACAAIAGAAIgCAIIgGABQgGAAgDgEg");
	this.shape_646.setTransform(187.125,137.05);

	this.shape_647 = new cjs.Shape();
	this.shape_647.graphics.f("#D9D9D9").s().p("AAJAnIAHgiIACgJQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgFAAgFADQgEACgCAFQgDAEgCALIgFAYIgKAAIAQhNIAKAAIgGAeQAFgGAEgCQAFgCAEAAQAIAAADAEQAEADAAAHIgBAKIgHAhg");
	this.shape_647.setTransform(182.025,136.975);

	this.shape_648 = new cjs.Shape();
	this.shape_648.graphics.f("#D9D9D9").s().p("AgDAzIAAhlIAHAAIAABlg");
	this.shape_648.setTransform(266.475,123.85);

	this.shape_649 = new cjs.Shape();
	this.shape_649.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKAAIABAGQABAEAEACQADABAFAAQAFAAADgCQAEgDAAgEQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBgBAAAAQgCgDgIgDIgJgEQgEgCgBgCQgCgEAAgEQAAgGAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgGgEgDQgDgDgGAAQgFABgCACQgDACAAADQAAADACABIAIAFQALAFADACQAEAEAAAGQAAAEgCAFQgDAEgFADQgGACgGAAQgKAAgHgFg");
	this.shape_649.setTransform(259.4733,123.85);

	this.shape_650 = new cjs.Shape();
	this.shape_650.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_650.setTransform(253.475,123.775);

	this.shape_651 = new cjs.Shape();
	this.shape_651.graphics.f("#D9D9D9").s().p("AgPAbQgGgDgCgFQgDgGAAgGQAAgQAJgLQAJgJAMAAQALAAAFAHQAHAGAAALQAAAJgEAIQgEAJgIAEQgGAFgIAAQgGAAgGgDgAgDgTQgFACgCAEQgDAEgCAGIgCAJQAAAIAFAEQADAEAHAAIAEgBIAGgEIAEgFIAEgIQABgEABgFQgBgIgDgEQgFgEgGgBQgDABgDACg");
	this.shape_651.setTransform(247.55,123.85);

	this.shape_652 = new cjs.Shape();
	this.shape_652.graphics.f("#D9D9D9").s().p("AgMAnIAMg4IAIAAIgKA4gAABgbIACgLIAKAAIgDALg");
	this.shape_652.setTransform(243.5,122.775);

	this.shape_653 = new cjs.Shape();
	this.shape_653.graphics.f("#D9D9D9").s().p("AgLAlQgDgDAAgDIACgJIAHggIgIAAIACgIIAHAAIADgNIAKgIIgEAVIAKAAIgCAIIgKAAIgFAfIgBAHIABADIACAAIAGAAIgCAIIgGABQgGAAgDgDg");
	this.shape_653.setTransform(240.875,122.85);

	this.shape_654 = new cjs.Shape();
	this.shape_654.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgJAEgJQAEgIAGgFQAIgFAIAAQAIAAAGAGQAFAEAAAJIgJAAQAAgFgDgDQgEgDgEAAQgGAAgEAEQgEADgCAIQgDAHAAAGQAAAIADAEQAEADAEAAQAEAAAFgDQAEgEACgIIAKACQgEAKgHAFQgGAGgIAAQgJAAgGgGg");
	this.shape_654.setTransform(236.4,123.85);

	this.shape_655 = new cjs.Shape();
	this.shape_655.graphics.f("#D9D9D9").s().p("AgWAZQgEgEAAgFIABgMIAHggIAKAAIgIAjIgBAHQAAADACACQACACAEAAQAEAAAEgCQADgCADgDQADgEABgEIADgKIAFgYIAKAAIgMA4IgJAAIACgLQgJAMgLAAQgGAAgEgEg");
	this.shape_655.setTransform(230.625,123.925);

	this.shape_656 = new cjs.Shape();
	this.shape_656.graphics.f("#D9D9D9").s().p("AgYAiQgFgGAAgMQAAgKAEgIQAFgIAGgEQAGgFAHAAQAJAAAGAKIAGgeIAKAAIgQBOIgJAAIABgJQgHAKgJAAQgJAAgFgGgAgHgKIgGAGIgFAIQgBAGAAAEIABAKQABAEACACQAEACADAAQAHAAAFgHQAGgJAAgNQABgGgEgEQgDgEgFAAQgEAAgCABg");
	this.shape_656.setTransform(224.7,122.85);

	this.shape_657 = new cjs.Shape();
	this.shape_657.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgDgGAAgGQAAgQAKgLQAIgJAMAAQAKAAAHAHQAGAGAAALQAAAJgEAIQgEAJgHAEQgIAFgHAAQgGAAgGgDgAgDgTQgFACgDAEQgDAEgBAGIgBAJQAAAIADAEQAFAEAFAAIAGgBIAFgEIAFgFIACgIQACgEAAgFQAAgIgEgEQgEgEgFgBQgEABgDACg");
	this.shape_657.setTransform(218.25,123.85);

	this.shape_658 = new cjs.Shape();
	this.shape_658.graphics.f("#D9D9D9").s().p("AgUAdIAMg4IAIAAIgCAMQADgHAFgDQAEgDAEAAQADAAAEACIgEAJQgCgCgDAAQgFAAgGAGQgEAGgDANIgFAXg");
	this.shape_658.setTransform(213.825,123.775);

	this.shape_659 = new cjs.Shape();
	this.shape_659.graphics.f("#D9D9D9").s().p("AgjAnIAQhNIAgAAQAJAAAEABQAEACADAFQADAFAAAGQAAAFgCAFQgCAFgDADIgGAEIgHADQgHABgIAAIgTAAIgGAggAgQgBIAQAAQAKAAAFgCQAFgCADgEQADgFAAgFQAAgEgCgCQgBgDgDgBQgDgBgIAAIgTAAg");
	this.shape_659.setTransform(208.075,122.775);

	this.shape_660 = new cjs.Shape();
	this.shape_660.graphics.f("#D9D9D9").s().p("AgPAFIACgJIAdAAIgCAJg");
	this.shape_660.setTransform(202.45,123.85);

	this.shape_661 = new cjs.Shape();
	this.shape_661.graphics.f("#D9D9D9").s().p("AAJAdIgFgMIgEgKIgRAWIgMAAIAZgdIgOgcIAKAAIAGALIADALIARgWIAMAAIgYAdIAOAcg");
	this.shape_661.setTransform(197.8,123.85);

	this.shape_662 = new cjs.Shape();
	this.shape_662.graphics.f("#D9D9D9").s().p("AgOAbQgGgDgCgFQgEgGAAgIQAAgHAFgKQAFgIAGgEQAHgFAHAAQAKAAAHAHQAFAGAAALIgBAIIgpAAIAAACQAAAIAEAFQAEAEAFAAQAEAAAFgDQAFgEADgGIAJABQgCAHgHAGQgIAHgJAAQgGAAgFgDgAgGgRQgFAEgCAJIAeAAIAAgCQAAgHgDgEQgEgFgFAAQgGABgFAEg");
	this.shape_662.setTransform(191.95,123.85);

	this.shape_663 = new cjs.Shape();
	this.shape_663.graphics.f("#D9D9D9").s().p("AgMAnIAQhNIAJAAIgPBNg");
	this.shape_663.setTransform(187.9,122.775);

	this.shape_664 = new cjs.Shape();
	this.shape_664.graphics.f("#D9D9D9").s().p("AAYAnIgDgWIgfAAIgMAWIgMAAIAshNIAMAAIANBNgAAGgOIgLAWIAZAAIgEgSQgCgMAAgIIgIAQg");
	this.shape_664.setTransform(182.25,122.775);

	this.shape_665 = new cjs.Shape();
	this.shape_665.graphics.f("#D9D9D9").s().p("AgeAnIABgJIAGABQABAAAAAAQABAAAAAAQABgBAAAAQABAAAAAAIAGgIIADgFIgKg4IAKAAIAEAdIACAQIAZgtIAKAAIgjA/QgGAKgEADQgEADgFAAIgHgBg");
	this.shape_665.setTransform(446.475,110.8);

	this.shape_666 = new cjs.Shape();
	this.shape_666.graphics.f("#D9D9D9").s().p("AgJAlQgEgDgDgGIgCAKIgJAAIARhNIAKAAIgGAcQAEgEADgCQAEgCAEAAQAIAAAFAGQAGAGAAAKQAAAIgDAHQgCAFgDAFIgGAHQgEADgDAAIgHACQgFAAgEgDgAgDgHQgEAEgDAHIgCALIAAACQAAAHADAEQAEAEAFAAQAEAAAEgDQAFgEACgIQADgHAAgHQAAgGgDgEQgEgEgFAAQgFAAgEAEg");
	this.shape_666.setTransform(440.425,108.65);

	this.shape_667 = new cjs.Shape();
	this.shape_667.graphics.f("#D9D9D9").s().p("AgOAbQgGgDgCgFQgEgGAAgIQAAgHAFgKQAFgIAGgFQAHgEAHAAQAKAAAHAGQAFAHAAALIgBAHIgpAAIAAADQAAAIAEAFQAEAEAFAAQAEAAAFgDQAFgDADgHIAJABQgCAHgHAGQgIAHgJAAQgGAAgFgDgAgGgRQgFAFgCAIIAeAAIAAgCQAAgIgDgDQgEgFgFAAQgGAAgFAFg");
	this.shape_667.setTransform(431.35,109.65);

	this.shape_668 = new cjs.Shape();
	this.shape_668.graphics.f("#D9D9D9").s().p("AgUAdIAMg4IAIAAIgCAMQADgHAFgDQAEgDAEAAQADAAAEACIgEAJQgCgCgDAAQgFAAgGAGQgEAGgDANIgFAXg");
	this.shape_668.setTransform(426.975,109.575);

	this.shape_669 = new cjs.Shape();
	this.shape_669.graphics.f("#D9D9D9").s().p("AgWAZQgEgEAAgFIABgMIAHggIAKAAIgIAjIgBAHQAAADACACQACACAEAAQAEAAAEgCQADgCADgDQADgEABgEIADgKIAFgYIAKAAIgMA4IgJAAIACgLQgJAMgLAAQgGAAgEgEg");
	this.shape_669.setTransform(421.825,109.725);

	this.shape_670 = new cjs.Shape();
	this.shape_670.graphics.f("#D9D9D9").s().p("AgLAlQgDgCAAgEIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgHIgEAWIAKAAIgCAHIgKAAIgFAeIgBAIIABACIACABIAGgBIgCAIIgGABQgGAAgDgCg");
	this.shape_670.setTransform(417.425,108.65);

	this.shape_671 = new cjs.Shape();
	this.shape_671.graphics.f("#D9D9D9").s().p("AgWAZQgEgEAAgFIABgMIAHggIAKAAIgIAjIgBAHQAAADACACQACACAEAAQAEAAAEgCQADgCADgDQADgEABgEIADgKIAFgYIAKAAIgMA4IgJAAIACgLQgJAMgLAAQgGAAgEgEg");
	this.shape_671.setTransform(412.675,109.725);

	this.shape_672 = new cjs.Shape();
	this.shape_672.graphics.f("#D9D9D9").s().p("AghAnIARhNIAyAAIgCAIIgoAAIgFAaIApAAIgCAIIgpAAIgHAjg");
	this.shape_672.setTransform(406.425,108.575);

	this.shape_673 = new cjs.Shape();
	this.shape_673.graphics.f("#D9D9D9").s().p("AgDA0IAAhnIAHAAIAABng");
	this.shape_673.setTransform(398.075,109.65);

	this.shape_674 = new cjs.Shape();
	this.shape_674.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgJAEgIQAEgKAGgEQAIgFAIAAQAIAAAGAFQAFAFAAAJIgJABQAAgGgDgDQgEgDgEAAQgGAAgEAEQgEAEgCAHQgDAGAAAIQAAAHADAEQAEADAEAAQAEAAAFgDQAEgEACgHIAKABQgEALgHAFQgGAFgIAAQgKAAgFgGg");
	this.shape_674.setTransform(391.2,109.65);

	this.shape_675 = new cjs.Shape();
	this.shape_675.graphics.f("#D9D9D9").s().p("AgMAnIAMg4IAJAAIgMA4gAABgbIACgLIAKAAIgCALg");
	this.shape_675.setTransform(387.3,108.575);

	this.shape_676 = new cjs.Shape();
	this.shape_676.graphics.f("#D9D9D9").s().p("AgSAZQgHgFABgLIAKAAIABAHQABADAEABQADACAFAAQAFAAADgDQAEgCAAgEQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBgBAAAAQgCgDgIgDIgJgDQgEgCgBgEQgCgCAAgFQAAgGAFgFQAGgFAIAAQALAAAGAFQAFAFAAAIIgJABQAAgFgEgDQgDgEgGAAQgFAAgCADQgDACAAADQAAADACACIAIAEQALAFADABQAEAFAAAGQAAAFgCAEQgDAEgFADQgGACgGAAQgKAAgHgFg");
	this.shape_676.setTransform(383.1233,109.65);

	this.shape_677 = new cjs.Shape();
	this.shape_677.graphics.f("#D9D9D9").s().p("AgWAZQgEgEAAgFIABgMIAHggIAKAAIgIAjIgBAHQAAADACACQACACAEAAQAEAAAEgCQADgCADgDQADgEABgEIADgKIAFgYIAKAAIgMA4IgJAAIACgLQgJAMgLAAQgGAAgEgEg");
	this.shape_677.setTransform(377.475,109.725);

	this.shape_678 = new cjs.Shape();
	this.shape_678.graphics.f("#D9D9D9").s().p("AASAnIAJgmQADgMAFgRIgIARIgcAyIgLAAIgHgxIgCgQIgDAQIgLAxIgKAAIARhNIAMAAIAIAyIACATIALgWIAcgvIAMAAIgQBNg");
	this.shape_678.setTransform(369.95,108.575);

	this.shape_679 = new cjs.Shape();
	this.shape_679.graphics.f("#D9D9D9").s().p("AgTAnQgFgCgCgDQgCgEgBgEIAAgDIAKABIABAFIADACQADACAEAAQAIAAAEgFQACgDACgKIABgFQgHAIgIAAQgJAAgFgHQgGgGAAgLQAAgJAFgIQAEgIAGgEQAHgFAGAAQAKAAAGALIADgJIAJAAIgMA2QgCAJgDAFQgDAFgFADQgFADgHAAQgHAAgFgCgAgEgeIgHAGQgCAEgBAFIgCAJIABAHQABAEADADQADACAEAAQAEAAAFgEQAFgDADgGQACgHAAgGQAAgHgDgFQgFgEgFAAQgDAAgDACg");
	this.shape_679.setTransform(359,110.725);

	this.shape_680 = new cjs.Shape();
	this.shape_680.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_680.setTransform(352.725,109.575);

	this.shape_681 = new cjs.Shape();
	this.shape_681.graphics.f("#D9D9D9").s().p("AgMAnIALg4IAKAAIgMA4gAABgbIACgLIAKAAIgCALg");
	this.shape_681.setTransform(348.85,108.575);

	this.shape_682 = new cjs.Shape();
	this.shape_682.graphics.f("#D9D9D9").s().p("AAYAdIAIgkIABgHQAAgBAAAAQAAgBAAgBQgBAAAAAAQAAgBAAAAQgCgCgEAAQgEAAgFADQgEACgCAEQgDAFgCAIIgGAbIgJAAIAIglIABgGQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgDAAQgEAAgEADQgFACgDAFQgDAFgCAHIgFAbIgKAAIAMg4IAJAAIgBAKQAFgGAFgDQAEgCAFAAQAEAAAEADQADADABAFQAFgGAEgCQAFgDAGAAQAGAAAFADQADAEAAAGIgCAJIgHAjg");
	this.shape_682.setTransform(342.8,109.575);

	this.shape_683 = new cjs.Shape();
	this.shape_683.graphics.f("#D9D9D9").s().p("AgVAZQgEgFgBgHQABgFABgDQADgEAEgBQADgDAFgBIALgBQAJAAAFgBIABgHQAAgDgCgCQgEgDgHAAQgEAAgFADQgDACgCAGIgKgCQADgIAHgFQAGgEAJAAQALAAAFAFQAGAEAAAGIgCAKIgDAOIgCALIABAHIgKAAIgBgHQgEAFgFACQgEACgFAAQgIAAgFgFgAAKABIgIABIgLABQgDACgCADQgCACAAADQAAAEADACQACADAGAAQAEAAAEgDQAEgCADgFQADgEABgIIgEABg");
	this.shape_683.setTransform(335.2,109.65);

	this.shape_684 = new cjs.Shape();
	this.shape_684.graphics.f("#D9D9D9").s().p("AgdAeQgHgJAAgNQAAgNAGgMQAGgMAKgFQAKgGAKAAQAJAAAGADQAHADADAFQAEAFACAJIgKABQgCgIgFgFQgGgEgIAAQgHAAgIAFQgHAEgFAKQgEAJAAALQAAAMAFAGQAHAGAKAAQAJAAAMgHIADgRIgXAAIACgIIAiAAIgHAfQgGAEgJADQgIADgHAAQgRAAgJgLg");
	this.shape_684.setTransform(328.25,108.575);

	this.shape_685 = new cjs.Shape();
	this.shape_685.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgDgFAAgHQAAgQAJgLQAJgJAMAAQAKAAAHAGQAGAHAAALQAAAJgEAIQgEAJgHAFQgIAEgHAAQgGAAgGgDgAgDgTQgEACgEAEQgDAEgBAGIgCAJQABAIAEAEQAEAFAFgBIAGgBIAFgEIAFgGIACgHQACgEAAgFQAAgIgDgEQgEgFgGAAQgEAAgDADg");
	this.shape_685.setTransform(317.6,109.65);

	this.shape_686 = new cjs.Shape();
	this.shape_686.graphics.f("#D9D9D9").s().p("AgUAdIAMg4IAIAAIgCAMQADgHAFgDQAEgDAEAAQADAAAEACIgEAJQgCgCgDAAQgFAAgGAGQgEAGgDANIgFAXg");
	this.shape_686.setTransform(313.175,109.575);

	this.shape_687 = new cjs.Shape();
	this.shape_687.graphics.f("#D9D9D9").s().p("AgLAlQgDgCAAgEIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgHIgEAWIAKAAIgCAHIgKAAIgFAeIgBAIIABACIACABIAGgBIgCAIIgGABQgGAAgDgCg");
	this.shape_687.setTransform(309.725,108.65);

	this.shape_688 = new cjs.Shape();
	this.shape_688.graphics.f("#D9D9D9").s().p("AgSAYQgGgGAAgLQAAgJAEgIQAEgKAGgEQAHgFAJAAQAIAAAGAFQAFAFAAAJIgJABQAAgGgDgDQgEgDgEAAQgGAAgEAEQgEAEgCAHQgDAGAAAIQAAAHADAEQAEADAEAAQAEAAAFgDQAEgEACgHIAKABQgEALgHAFQgGAFgIAAQgJAAgGgGg");
	this.shape_688.setTransform(305.25,109.65);

	this.shape_689 = new cjs.Shape();
	this.shape_689.graphics.f("#D9D9D9").s().p("AgOAbQgGgDgCgFQgDgGAAgIQgBgHAFgKQAEgIAHgFQAHgEAHAAQAKAAAHAGQAFAHAAALIgBAHIgoAAIAAADQgBAIAEAFQAEAEAFAAQAEAAAFgDQAFgDADgHIAJABQgCAHgHAGQgIAHgJAAQgGAAgFgDgAgGgRQgFAFgCAIIAeAAIAAgCQAAgIgDgDQgEgFgGAAQgFAAgFAFg");
	this.shape_689.setTransform(299.25,109.65);

	this.shape_690 = new cjs.Shape();
	this.shape_690.graphics.f("#D9D9D9").s().p("AgMAnIAQhNIAJAAIgQBNg");
	this.shape_690.setTransform(295.2,108.575);

	this.shape_691 = new cjs.Shape();
	this.shape_691.graphics.f("#D9D9D9").s().p("AgkAnIARhNIA4AAIgCAIIguAAIgFAZIAsAAIgCAIIgsAAIgFAbIAwAAIgCAJg");
	this.shape_691.setTransform(290.425,108.575);

	this.shape_692 = new cjs.Shape();
	this.shape_692.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgDgFAAgHQAAgQAKgLQAIgJAMAAQAKAAAHAGQAGAHAAALQAAAJgEAIQgEAJgHAFQgIAEgHAAQgGAAgGgDgAgEgTQgEACgDAEQgDAEgBAGIgBAJQAAAIADAEQAFAFAFgBIAGgBIAFgEIAFgGIACgHQACgEAAgFQAAgIgEgEQgEgFgFAAQgEAAgEADg");
	this.shape_692.setTransform(280.35,109.65);

	this.shape_693 = new cjs.Shape();
	this.shape_693.graphics.f("#D9D9D9").s().p("AgdAoIAQhOIAJAAIgCAIQAFgFADgCQAEgCAFAAQAIAAAGAGQAFAGAAALQAAAJgDAHQgDAGgEAFQgEAEgFACQgFADgEAAQgKAAgFgLIgGAfgAABgdQgCACgDAEQgDADgBAGQgCAGAAAEIABAIQABADADACQADADADAAQAJAAAFgKQAFgIAAgKQAAgHgDgEQgDgEgGAAQgDAAgEACg");
	this.shape_693.setTransform(273.9,110.675);

	this.shape_694 = new cjs.Shape();
	this.shape_694.graphics.f("#D9D9D9").s().p("AAYAdIAIgkIABgHQAAgBAAAAQAAgBAAgBQgBAAAAAAQAAgBgBAAQgCgCgCAAQgFAAgEADQgFACgCAEQgDAFgCAIIgFAbIgJAAIAIglIAAgGQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgDAAQgEAAgFADQgEACgDAFQgDAFgBAHIgGAbIgKAAIAMg4IAJAAIgBAKQAFgGAEgDQAFgCAEAAQAFAAADADQAEADACAFQADgGAGgCQAFgDAFAAQAGAAAEADQAEAEAAAGIgCAJIgHAjg");
	this.shape_694.setTransform(266.6,109.575);

	this.shape_695 = new cjs.Shape();
	this.shape_695.graphics.f("#D9D9D9").s().p("AgPAbQgFgDgDgFQgCgGAAgIQAAgHAEgKQAFgIAGgFQAHgEAHAAQALAAAFAGQAHAHAAALIgBAHIgqAAIAAADQABAIADAFQAEAEAFAAQAEAAAFgDQAFgDACgHIAKABQgCAHgIAGQgGAHgKAAQgGAAgGgDgAgGgRQgFAFgDAIIAgAAIAAgCQAAgIgFgDQgDgFgGAAQgFAAgFAFg");
	this.shape_695.setTransform(259.05,109.65);

	this.shape_696 = new cjs.Shape();
	this.shape_696.graphics.f("#D9D9D9").s().p("AgLAlQgDgCAAgEIACgJIAHggIgIAAIACgHIAHAAIADgPIAKgHIgEAWIAKAAIgCAHIgKAAIgFAeIgBAIIABACIACABIAGgBIgCAIIgGABQgGAAgDgCg");
	this.shape_696.setTransform(254.875,108.65);

	this.shape_697 = new cjs.Shape();
	this.shape_697.graphics.f("#D9D9D9").s().p("AgYAiQgFgGAAgLQAAgLAEgIQAFgIAGgFQAGgEAGAAQALAAAEALIAHgfIAKAAIgRBNIgJAAIACgIQgHAKgKAAQgHAAgGgGgAgHgJIgGAFIgEAIQgDAGAAAEIABAKQACADADACQACADAFAAQAGAAAEgHQAIgJAAgNQgBgGgDgEQgDgEgFAAQgDAAgDACg");
	this.shape_697.setTransform(250.3,108.65);

	this.shape_698 = new cjs.Shape();
	this.shape_698.graphics.f("#D9D9D9").s().p("AgMAnIAMg4IAJAAIgMA4gAABgbIACgLIAKAAIgCALg");
	this.shape_698.setTransform(245.9,108.575);

	this.shape_699 = new cjs.Shape();
	this.shape_699.graphics.f("#D9D9D9").s().p("AATAnIAIgmQADgMAFgRIgIARIgcAyIgLAAIgHgxIgDgQIgCAQIgKAxIgKAAIAQhNIANAAIAIAyIABATIAKgWIAcgvIAOAAIgRBNg");
	this.shape_699.setTransform(240.15,108.575);

	this.shape_700 = new cjs.Shape();
	this.shape_700.graphics.f("#D9D9D9").s().p("AAIAnIgKgdIgMAKIgEATIgJAAIAPhNIALAAIgLAvIAcgaIAMAAIgYAUIAPAkg");
	this.shape_700.setTransform(229.8,108.575);

	this.shape_701 = new cjs.Shape();
	this.shape_701.graphics.f("#D9D9D9").s().p("AAJAdIAIgjIABgIQAAgBAAAAQgBgBAAAAQAAgBAAAAQgBgBAAAAQgCgCgEAAQgHAAgFAFQgGAGgDAMIgFAaIgKAAIAMg4IAJAAIgCAKQAFgGAEgCQAFgDAFAAQAHAAAEAEQAEADAAAHIgBAKIgHAhg");
	this.shape_701.setTransform(223.525,109.575);

	this.shape_702 = new cjs.Shape();
	this.shape_702.graphics.f("#D9D9D9").s().p("AgWAZQgEgEAAgFIABgMIAHggIAKAAIgIAjIgBAHQAAADACACQACACAEAAQAEAAAEgCQADgCADgDQADgEABgEIADgKIAFgYIAKAAIgMA4IgJAAIACgLQgJAMgLAAQgGAAgEgEg");
	this.shape_702.setTransform(217.775,109.725);

	this.shape_703 = new cjs.Shape();
	this.shape_703.graphics.f("#D9D9D9").s().p("AgdAoIAQhOIAJAAIgBAIQAFgFADgCQADgCAFAAQAIAAAFAGQAGAGAAALQAAAJgDAHQgDAGgEAFQgFAEgEACQgEADgFAAQgJAAgGgLIgHAfgAABgdQgCACgDAEQgDADgBAGQgCAGAAAEIABAIQACADACACQADADAEAAQAIAAAFgKQAFgIAAgKQAAgHgDgEQgEgEgFAAQgEAAgDACg");
	this.shape_703.setTransform(211.15,110.675);

	this.shape_704 = new cjs.Shape();
	this.shape_704.graphics.f("#D9D9D9").s().p("AgUAdIAMg4IAIAAIgCAMQADgHAFgDQAEgDAEAAQADAAAEACIgEAJQgCgCgDAAQgFAAgGAGQgEAGgDANIgFAXg");
	this.shape_704.setTransform(207.075,109.575);

	this.shape_705 = new cjs.Shape();
	this.shape_705.graphics.f("#D9D9D9").s().p("AgOAbQgGgDgDgFQgCgGAAgIQgBgHAFgKQAEgIAHgFQAHgEAHAAQAKAAAHAGQAFAHABALIgCAHIgoAAIAAADQgBAIAEAFQAEAEAFAAQAEAAAFgDQAFgDACgHIAKABQgCAHgIAGQgHAHgJAAQgGAAgFgDgAgGgRQgFAFgCAIIAfAAIAAgCQgBgIgEgDQgDgFgGAAQgFAAgFAFg");
	this.shape_705.setTransform(201.7,109.65);

	this.shape_706 = new cjs.Shape();
	this.shape_706.graphics.f("#D9D9D9").s().p("AgJAlQgEgDgDgGIgCAKIgJAAIARhNIAKAAIgGAcQAEgEADgCQAEgCAEAAQAIAAAFAGQAGAGAAAKQAAAIgDAHQgCAFgDAFIgGAHQgEADgDAAIgHACQgFAAgEgDgAgDgHQgEAEgDAHIgCALIAAACQAAAHADAEQAEAEAFAAQAEAAAEgDQAFgEACgIQADgHAAgHQAAgGgDgEQgEgEgFAAQgFAAgEAEg");
	this.shape_706.setTransform(195.525,108.65);

	this.shape_707 = new cjs.Shape();
	this.shape_707.graphics.f("#D9D9D9").s().p("AgeAnIABgJIAGABQABAAAAAAQABAAAAAAQABgBAAAAQABAAAAAAIAGgIIADgFIgKg4IAKAAIAEAdIACAQIAZgtIAKAAIgjA/QgGAKgEADQgEADgFAAIgHgBg");
	this.shape_707.setTransform(189.975,110.8);

	this.shape_708 = new cjs.Shape();
	this.shape_708.graphics.f("#D9D9D9").s().p("AgaAgQgIgJAAgQQAAgVANgNQALgNAQAAQAMAAAIAHQAIAHABALIgKABQgBgJgFgEQgFgEgIAAQgNAAgJANQgIALAAAOQAAAMAGAHQAGAGAKAAQAHAAAGgFQAHgGADgJIALABQgFAOgKAHQgJAHgLAAQgOAAgJgJg");
	this.shape_708.setTransform(183.475,108.575);

	this.shape_709 = new cjs.Shape();
	this.shape_709.graphics.f("#FFCC99").s().p("AgNAiIADgNIAMAAIgCANgAgBgUIABgNIANAAIgCANg");
	this.shape_709.setTransform(215.05,89.325);

	this.shape_710 = new cjs.Shape();
	this.shape_710.graphics.f("#FFCC99").s().p("AgWAcQgGgHgBgNQAAgKAFgKQAEgLAIgGQAIgFAKAAQAKAAAHAGQAGAGABAKIgMABQAAgGgEgEQgDgEgGAAQgGAAgFAFQgFAEgDAJQgDAIAAAIQAAAJAEAEQADAEAGAAQAEAAAGgEQAFgEADgJIALABQgEANgIAGQgIAGgJAAQgLAAgHgHg");
	this.shape_710.setTransform(210.15,89.325);

	this.shape_711 = new cjs.Shape();
	this.shape_711.graphics.f("#FFCC99").s().p("AgPAuIAPhCIAKAAIgNBCgAABghIADgMIAMAAIgEAMg");
	this.shape_711.setTransform(205.5,88.05);

	this.shape_712 = new cjs.Shape();
	this.shape_712.graphics.f("#FFCC99").s().p("AgVAdQgIgFAAgNIAMgBQAAAFABADQACAEAEACQAEACAFAAQAHAAAEgDQAEgDAAgEQAAgDgDgCQgCgDgJgEIgLgFQgEgCgCgEQgCgDAAgFQAAgIAGgFQAGgGALAAQAMAAAHAGQAHAGAAAJIgLABQgBgGgEgEQgEgDgHAAQgFAAgDACQgEADAAADQAAAEADACQACACAHADQANAGAEACQAFAFAAAIQAAAFgDAFQgDAEgGADQgHADgHAAQgMAAgIgGg");
	this.shape_712.setTransform(200.5735,89.325);

	this.shape_713 = new cjs.Shape();
	this.shape_713.graphics.f("#FFCC99").s().p("AgaAeQgFgFAAgGIACgPIAIgmIAMAAIgJArIgCAIQAAAEADACQACACAFAAQAEAAAFgCQAEgCADgEQADgEACgGIAEgMIAGgdIALAAIgOBDIgKAAIACgMQgLAOgNAAQgIAAgEgFg");
	this.shape_713.setTransform(193.825,89.4);

	this.shape_714 = new cjs.Shape();
	this.shape_714.graphics.f("#FFCC99").s().p("AAWAuIAKgtIAKgiIgLATIghA8IgMAAIgKg6IgBgUIgDAUIgNA6IgMAAIAThbIAQAAIAKA6IABAYQAEgKAJgQIAgg4IAQAAIgTBbg");
	this.shape_714.setTransform(184.9,88.05);

	this.shape_715 = new cjs.Shape();
	this.shape_715.graphics.f("#D9D9D9").s().p("AgaAoQgJgIgCgQIASgCQACAKAFAEQAFAEAIAAQAJAAAFgDQAEgFAAgEQAAgEgCgCQgCgDgFgBIgNgFQgQgDgGgFQgJgHAAgLQABgIAEgFQADgHAIgDQAIgDAKAAQARAAAJAHQAJAIAAANIgTABQgBgIgDgDQgFgCgHAAQgIAAgEADQgDACgBAEQABADADACQADADANADQAOADAGAEQAGAEAEAEQAEAGAAAKQAAAHgFAHQgEAIgIADQgJADgMAAQgQAAgKgIg");
	this.shape_715.setTransform(251.8,53.1);

	this.shape_716 = new cjs.Shape();
	this.shape_716.graphics.f("#D9D9D9").s().p("AgIAvIAAhNIgcAAIAAgQIBJAAIAAAQIgcAAIAABNg");
	this.shape_716.setTransform(243.575,53.1);

	this.shape_717 = new cjs.Shape();
	this.shape_717.graphics.f("#D9D9D9").s().p("AgIAvIAAhdIARAAIAABdg");
	this.shape_717.setTransform(237.825,53.1);

	this.shape_718 = new cjs.Shape();
	this.shape_718.graphics.f("#D9D9D9").s().p("AgmAvIAAhdIAiAAQALAAAGACQAIADAGAGQAGAGADAJQADAJAAAMQAAALgDAJQgEAKgGAGQgFAFgIACQgGADgJAAgAgTAfIANAAIALgBQAFgBADgDQADgDABgGQACgGAAgLQAAgKgCgFQgCgHgDgCQgDgEgFgBIgPgBIgIAAg");
	this.shape_718.setTransform(231.45,53.1);

	this.shape_719 = new cjs.Shape();
	this.shape_719.graphics.f("#D9D9D9").s().p("AgiAvIAAhdIBEAAIAAAQIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_719.setTransform(222.425,53.1);

	this.shape_720 = new cjs.Shape();
	this.shape_720.graphics.f("#D9D9D9").s().p("AATAvIgNgVIgJgNQgDgDgDgCIgJgBIgEAAIAAAoIgTAAIAAhdIAoAAQAOAAAHADQAGADAEAGQAEAHAAAHQAAALgGAHQgGAFgMACQAGAEAEAEIALAQIALASgAgWgGIAOAAQAMAAAEgBQADgCACgDQACgCAAgFQAAgEgCgDQgDgCgFgCIgMAAIgPAAg");
	this.shape_720.setTransform(213.675,53.1);

	this.shape_721 = new cjs.Shape();
	this.shape_721.graphics.f("#D9D9D9").s().p("AgbAjQgNgMAAgWQAAgXANgMQALgNATAAQARAAALAKQAGAGADALIgSAFQgCgIgFgEQgFgEgIAAQgJAAgHAIQgGAHAAAQQAAARAGAHQAHAIAJAAQAHAAAGgEQAFgGACgJIASAFQgEAPgJAHQgKAIgPAAQgSAAgLgNg");
	this.shape_721.setTransform(203.8,53.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.closeButton,p:{x:415.35,y:47.3}},{t:this.fulls},{t:this.mainm},{t:this.audio},{t:this.instruct},{t:this.credits},{t:this.achB}]},1).to({state:[{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.closeButton,p:{x:513.75,y:49.55}},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.instance_10},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.instance_1},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.instance},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12}]},1).to({state:[{t:this.shape_721},{t:this.shape_720},{t:this.shape_719},{t:this.shape_718},{t:this.shape_717},{t:this.shape_716},{t:this.shape_715},{t:this.closeButton,p:{x:451.45,y:49.55}},{t:this.shape_714},{t:this.shape_713},{t:this.shape_712},{t:this.shape_711},{t:this.shape_710},{t:this.shape_709},{t:this.shape_708},{t:this.shape_707},{t:this.shape_706},{t:this.shape_705},{t:this.shape_704},{t:this.shape_703},{t:this.shape_702},{t:this.shape_701},{t:this.shape_700},{t:this.shape_699},{t:this.shape_698},{t:this.shape_697},{t:this.shape_696},{t:this.shape_695},{t:this.shape_694},{t:this.shape_693},{t:this.shape_692},{t:this.shape_691},{t:this.shape_690},{t:this.shape_689},{t:this.shape_688},{t:this.shape_687},{t:this.shape_686},{t:this.shape_685},{t:this.shape_684},{t:this.shape_683},{t:this.shape_682},{t:this.shape_681},{t:this.shape_680},{t:this.shape_679},{t:this.shape_678},{t:this.shape_677},{t:this.shape_676},{t:this.shape_675},{t:this.shape_674},{t:this.shape_673},{t:this.shape_672},{t:this.shape_671},{t:this.shape_670},{t:this.shape_669},{t:this.shape_668},{t:this.shape_667},{t:this.shape_666},{t:this.shape_665},{t:this.shape_664},{t:this.shape_663},{t:this.shape_662},{t:this.shape_661},{t:this.shape_660},{t:this.shape_659},{t:this.shape_658},{t:this.shape_657},{t:this.shape_656},{t:this.shape_655},{t:this.shape_654},{t:this.shape_653},{t:this.shape_652},{t:this.shape_651},{t:this.shape_650},{t:this.shape_649},{t:this.shape_648},{t:this.shape_647},{t:this.shape_646},{t:this.shape_645},{t:this.shape_644},{t:this.shape_643},{t:this.shape_642},{t:this.shape_641},{t:this.shape_640},{t:this.shape_639},{t:this.shape_638},{t:this.shape_637},{t:this.shape_636},{t:this.shape_635},{t:this.shape_634},{t:this.shape_633},{t:this.shape_632},{t:this.shape_631},{t:this.shape_630},{t:this.shape_629},{t:this.shape_628},{t:this.shape_627},{t:this.shape_626},{t:this.shape_625},{t:this.shape_624},{t:this.shape_623},{t:this.shape_622},{t:this.shape_621},{t:this.shape_620},{t:this.shape_619},{t:this.shape_618},{t:this.shape_617},{t:this.shape_616},{t:this.shape_615},{t:this.shape_614},{t:this.shape_613},{t:this.shape_612},{t:this.shape_611},{t:this.shape_610},{t:this.shape_609},{t:this.shape_608},{t:this.shape_607},{t:this.shape_606},{t:this.shape_605},{t:this.shape_604},{t:this.shape_603},{t:this.shape_602},{t:this.shape_601},{t:this.shape_600},{t:this.shape_599},{t:this.shape_598},{t:this.shape_597},{t:this.shape_596},{t:this.shape_595},{t:this.shape_594},{t:this.shape_593},{t:this.shape_592},{t:this.shape_591},{t:this.shape_590},{t:this.shape_589},{t:this.shape_588},{t:this.shape_587},{t:this.shape_586},{t:this.shape_585},{t:this.shape_584},{t:this.shape_583},{t:this.shape_582},{t:this.shape_581},{t:this.shape_580},{t:this.shape_579},{t:this.shape_578},{t:this.shape_577},{t:this.shape_576},{t:this.shape_575},{t:this.shape_574},{t:this.shape_573},{t:this.shape_572},{t:this.shape_571},{t:this.shape_570},{t:this.shape_569},{t:this.shape_568},{t:this.shape_567},{t:this.shape_566},{t:this.shape_565},{t:this.shape_564},{t:this.shape_563},{t:this.shape_562},{t:this.shape_561},{t:this.shape_560},{t:this.shape_559},{t:this.shape_558},{t:this.shape_557},{t:this.shape_556},{t:this.shape_555},{t:this.shape_554},{t:this.shape_553},{t:this.shape_552},{t:this.shape_551},{t:this.shape_550},{t:this.shape_549},{t:this.shape_548},{t:this.shape_547},{t:this.shape_546},{t:this.shape_545},{t:this.shape_544},{t:this.shape_543},{t:this.shape_542},{t:this.shape_541},{t:this.shape_540},{t:this.shape_539},{t:this.shape_538},{t:this.shape_537},{t:this.shape_536},{t:this.shape_535},{t:this.shape_534},{t:this.shape_533},{t:this.shape_532},{t:this.shape_531},{t:this.shape_530},{t:this.shape_529},{t:this.shape_528},{t:this.shape_527},{t:this.shape_526},{t:this.shape_525},{t:this.shape_524},{t:this.shape_523},{t:this.shape_522},{t:this.shape_521},{t:this.shape_520},{t:this.shape_519},{t:this.shape_518},{t:this.shape_517},{t:this.shape_516},{t:this.shape_515},{t:this.shape_514},{t:this.shape_513},{t:this.shape_512},{t:this.shape_511},{t:this.shape_510},{t:this.shape_509},{t:this.shape_508},{t:this.shape_507},{t:this.shape_506},{t:this.shape_505},{t:this.shape_504},{t:this.shape_503},{t:this.shape_502},{t:this.shape_501},{t:this.shape_500},{t:this.shape_499},{t:this.shape_498},{t:this.shape_497},{t:this.shape_496},{t:this.shape_495},{t:this.shape_494},{t:this.shape_493},{t:this.shape_492},{t:this.shape_491},{t:this.shape_490},{t:this.shape_489},{t:this.shape_488},{t:this.shape_487},{t:this.shape_486},{t:this.shape_485},{t:this.shape_484},{t:this.shape_483},{t:this.shape_482},{t:this.shape_481},{t:this.shape_480},{t:this.shape_479},{t:this.shape_478},{t:this.shape_477},{t:this.shape_476},{t:this.shape_475},{t:this.shape_474},{t:this.shape_473},{t:this.shape_472},{t:this.shape_471},{t:this.shape_470},{t:this.shape_469},{t:this.shape_468},{t:this.shape_467},{t:this.shape_466},{t:this.shape_465},{t:this.shape_464},{t:this.shape_463},{t:this.shape_462},{t:this.shape_461},{t:this.shape_460},{t:this.shape_459},{t:this.shape_458},{t:this.shape_457},{t:this.shape_456},{t:this.shape_455},{t:this.shape_454},{t:this.shape_453},{t:this.shape_452},{t:this.shape_451},{t:this.shape_450},{t:this.shape_449},{t:this.shape_448},{t:this.shape_447},{t:this.shape_446},{t:this.shape_445},{t:this.shape_444},{t:this.shape_443},{t:this.shape_442},{t:this.shape_441},{t:this.shape_440},{t:this.shape_439},{t:this.shape_438},{t:this.shape_437},{t:this.shape_436},{t:this.shape_435},{t:this.shape_434},{t:this.shape_433},{t:this.shape_432},{t:this.shape_431},{t:this.shape_430},{t:this.shape_429},{t:this.shape_428},{t:this.shape_427},{t:this.shape_426},{t:this.shape_425},{t:this.shape_424},{t:this.shape_423},{t:this.shape_422},{t:this.shape_421},{t:this.shape_420},{t:this.shape_419},{t:this.shape_418},{t:this.shape_417},{t:this.shape_416},{t:this.shape_415},{t:this.shape_414},{t:this.shape_413},{t:this.shape_412},{t:this.shape_411},{t:this.shape_410},{t:this.shape_409},{t:this.shape_408},{t:this.shape_407},{t:this.shape_406},{t:this.shape_405},{t:this.shape_404},{t:this.shape_403},{t:this.shape_402},{t:this.shape_401},{t:this.shape_400},{t:this.shape_399},{t:this.shape_398},{t:this.shape_397},{t:this.shape_396},{t:this.shape_395},{t:this.shape_394},{t:this.shape_393},{t:this.shape_392},{t:this.shape_391},{t:this.shape_390},{t:this.shape_389},{t:this.shape_388},{t:this.shape_387},{t:this.shape_386},{t:this.shape_385},{t:this.shape_384},{t:this.shape_383},{t:this.shape_382},{t:this.shape_381},{t:this.shape_380},{t:this.shape_379},{t:this.shape_378},{t:this.shape_377},{t:this.shape_376},{t:this.shape_375},{t:this.shape_374},{t:this.shape_373},{t:this.shape_372},{t:this.shape_371},{t:this.shape_370},{t:this.shape_369},{t:this.shape_368},{t:this.shape_367},{t:this.shape_366},{t:this.shape_365},{t:this.shape_364},{t:this.shape_363},{t:this.shape_362},{t:this.shape_361},{t:this.shape_360},{t:this.shape_359},{t:this.shape_358},{t:this.shape_357},{t:this.shape_356},{t:this.shape_355},{t:this.shape_354},{t:this.shape_353},{t:this.shape_352},{t:this.shape_351},{t:this.shape_350},{t:this.shape_349},{t:this.shape_348},{t:this.shape_347},{t:this.shape_346},{t:this.shape_345},{t:this.shape_344},{t:this.shape_343},{t:this.shape_342},{t:this.shape_341},{t:this.shape_340},{t:this.shape_339},{t:this.shape_338},{t:this.shape_337},{t:this.shape_336},{t:this.shape_335},{t:this.shape_334},{t:this.shape_333},{t:this.shape_332},{t:this.shape_331},{t:this.shape_330},{t:this.shape_329},{t:this.shape_328},{t:this.shape_327},{t:this.shape_326},{t:this.shape_325},{t:this.shape_324},{t:this.shape_323},{t:this.shape_322},{t:this.shape_321},{t:this.shape_320},{t:this.shape_319},{t:this.shape_318},{t:this.shape_317},{t:this.shape_316},{t:this.shape_315},{t:this.shape_314},{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302},{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274}]},1).wait(1));

	// ramis
	this.shape_722 = new cjs.Shape();
	this.shape_722.graphics.f().s("#CCCCCC").ss(0.2,1,1).p("AyHAAMAkPAAA");
	this.shape_722.setTransform(321.45,69.5);

	this.shape_723 = new cjs.Shape();
	this.shape_723.graphics.f().s("#CCCCCC").ss(1,1,1,3,true).p("AyH27MAkPAAAIAAFjMAAAAoUMgkPAAAMAAAgoUg");
	this.shape_723.setTransform(321.45,180.825);

	this.shape_724 = new cjs.Shape();
	this.shape_724.graphics.f("#3B3B3B").s().p("AyHULMAAAgoVMAkPAAAMAAAAoVg");
	this.shape_724.setTransform(321.45,198.575);

	this.shape_725 = new cjs.Shape();
	this.shape_725.graphics.f("#333333").s().p("AyHCxIAAlhMAkPAAAIAAFhg");
	this.shape_725.setTransform(321.45,51.75);

	this.shape_726 = new cjs.Shape();
	this.shape_726.graphics.f().s("#CCCCCC").ss(0.2,1,1).p("Egh+AAAMBD9AAA");
	this.shape_726.setTransform(318.3,71.5);

	this.shape_727 = new cjs.Shape();
	this.shape_727.graphics.f().s("#CCCCCC").ss(1,1,1,3,true).p("Egh+gUEMBD9AAAIAAFjMAAAAimMhD9AAAMAAAgimg");
	this.shape_727.setTransform(318.3,164.475);

	this.shape_728 = new cjs.Shape();
	this.shape_728.graphics.f("#3B3B3B").s().p("Egh9ARTMAAAgilMBD8AAAMAAAAilg");
	this.shape_728.setTransform(318.3,182.225);

	this.shape_729 = new cjs.Shape();
	this.shape_729.graphics.f("#333333").s().p("Egh9ACxIAAliMBD8AAAIAAFig");
	this.shape_729.setTransform(318.3,53.75);

	this.shape_730 = new cjs.Shape();
	this.shape_730.graphics.f().s("#CCCCCC").ss(0.2,1,1).p("A3vAAMAvfAAA");
	this.shape_730.setTransform(321.45,71.5);

	this.shape_731 = new cjs.Shape();
	this.shape_731.graphics.f().s("#CCCCCC").ss(1,1,1,3,true).p("A3v0EMAvfAAAIAAFjMAAAAimMgvfAAAMAAAgimg");
	this.shape_731.setTransform(321.45,164.475);

	this.shape_732 = new cjs.Shape();
	this.shape_732.graphics.f("#3B3B3B").s().p("A3vRTMAAAgilMAvfAAAMAAAAilg");
	this.shape_732.setTransform(321.45,182.225);

	this.shape_733 = new cjs.Shape();
	this.shape_733.graphics.f("#333333").s().p("A3vCxIAAliMAvfAAAIAAFig");
	this.shape_733.setTransform(321.45,53.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_725},{t:this.shape_724},{t:this.shape_723},{t:this.shape_722}]},1).to({state:[{t:this.shape_729},{t:this.shape_728},{t:this.shape_727},{t:this.shape_726}]},1).to({state:[{t:this.shape_733},{t:this.shape_732},{t:this.shape_731},{t:this.shape_730}]},1).wait(1));

	// background
	this.shape_734 = new cjs.Shape();
	this.shape_734.graphics.f("rgba(95,95,95,0.02)").s().p("EgyAAcIMAAAg4PMBkAAAAMAAAA4Pg");
	this.shape_734.setTransform(320.05,180);

	this.shape_735 = new cjs.Shape();
	this.shape_735.graphics.f("rgba(83,83,83,0.02)").s().p("EgyAAcIMAAAg4PMBkAAAAMAAAA4Pg");
	this.shape_735.setTransform(320.05,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_734}]},1).to({state:[{t:this.shape_735}]},1).to({state:[{t:this.shape_734}]},1).wait(1));

	// Layer 3
	this.shape_736 = new cjs.Shape();
	this.shape_736.graphics.f("#262626").s().p("AyLW2MAAAgtrMAkXAAAMAAAAtrg");
	this.shape_736.setTransform(324.025,185.225);

	this.shape_737 = new cjs.Shape();
	this.shape_737.graphics.f("#262626").s().p("AYNUGIAAxlI4/AAIAARlIhWAAIAAzYI4OAAIAATYInsAAMAAAgoLMBEFAAAMAAAAoLg");
	this.shape_737.setTransform(320.925,167.6);

	this.shape_738 = new cjs.Shape();
	this.shape_738.graphics.f("#262626").s().p("A3wUGMAAAgoLMAviAAAMAAAAoLg");
	this.shape_738.setTransform(323.65,167.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_736}]},1).to({state:[{t:this.shape_737}]},1).to({state:[{t:this.shape_738}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,640.1,360);


(lib.selectlevel = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var selectScreen = this;
		var levelIcons;
		selectScreen.stop();
		
		setTimeout(stopit,0);
		function stopit() {
			levelIcons = [selectScreen.select1,selectScreen.select2,selectScreen.select3,selectScreen.select4,selectScreen.select5,selectScreen.select6,selectScreen.select7,selectScreen.select8,selectScreen.select9,selectScreen.select10
			,selectScreen.select11,selectScreen.select12,selectScreen.select13,selectScreen.select14,selectScreen.select15,selectScreen.select16,selectScreen.select17,selectScreen.select18,selectScreen.select19,selectScreen.select20];
			
			levelIcons[0].addEventListener("click", function() {playLevel(1);});
			showStars(levelScores[0],targetScores[0],levelIcons[0]);
		
		for (i = 0; i < levelIcons.length - 1; i++) {
			(function () {
		    if(levelScores[i] > 0) {
				showStars(levelScores[i+1],targetScores[i+1],levelIcons[i + 1]);
				levelIcons[i + 1].gotoAndStop(1);
				var levelLabel = i + 2;
				levelIcons[i + 1].addEventListener("click", function() {playLevel(levelLabel);});
				}
				}());
			}	
		
		selectScreen.closeButton.addEventListener("click", closeLevels);
		}
		
		function closeLevels(event) {
			removeListeners();
			exportRoot.gotoAndStop(1);
		}
		
		function playLevel(levelNr) {
			removeListeners();
			Level = levelNr;
			exportRoot.gotoAndStop(3);
		}
		
		function showStars(scoreLevel,targetScore,levelIcon) {
			
			if(scoreLevel > 100) levelIcon.stars.gotoAndStop(1);
		if(scoreLevel >= targetScore - (targetScore / 15)) levelIcon.stars.gotoAndStop(2);
		if(scoreLevel >= targetScore) levelIcon.stars.gotoAndStop(3);
			
		}
		
		function removeListeners() {
			selectScreen.closeButton.removeEventListener("click", closeLevels);
			//selectScreen.level1.removeAllEventListeners();
			
			for (i = 0; i < levelIcons.length; i++) {
				levelIcons[i].removeAllEventListeners();		
			}
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 2
	this.select20 = new lib.select20();
	this.select20.name = "select20";
	this.select20.parent = this;
	this.select20.setTransform(520.95,302.95,0.903,0.9056,0,0,0,59.8,33.2);

	this.select19 = new lib.select19();
	this.select19.name = "select19";
	this.select19.parent = this;
	this.select19.setTransform(412.2,302.95,0.903,0.9056,0,0,0,59.8,33.2);

	this.select18 = new lib.select18();
	this.select18.name = "select18";
	this.select18.parent = this;
	this.select18.setTransform(303.6,302.95,0.903,0.9056,0,0,0,59.8,33.2);

	this.select17 = new lib.select17();
	this.select17.name = "select17";
	this.select17.parent = this;
	this.select17.setTransform(194.95,302.95,0.903,0.9056,0,0,0,59.8,33.2);

	this.select16 = new lib.select16();
	this.select16.name = "select16";
	this.select16.parent = this;
	this.select16.setTransform(86.35,302.95,0.903,0.9056,0,0,0,59.8,33.2);

	this.select15 = new lib.select15();
	this.select15.name = "select15";
	this.select15.parent = this;
	this.select15.setTransform(520.95,232.95,0.903,0.9056,0,0,0,59.8,33.2);

	this.select14 = new lib.select14();
	this.select14.name = "select14";
	this.select14.parent = this;
	this.select14.setTransform(412.2,232.95,0.903,0.9056,0,0,0,59.8,33.2);

	this.select13 = new lib.select13();
	this.select13.name = "select13";
	this.select13.parent = this;
	this.select13.setTransform(303.6,232.95,0.903,0.9056,0,0,0,59.8,33.2);

	this.select12 = new lib.select12();
	this.select12.name = "select12";
	this.select12.parent = this;
	this.select12.setTransform(194.95,232.95,0.903,0.9056,0,0,0,59.8,33.2);

	this.select11 = new lib.select11();
	this.select11.name = "select11";
	this.select11.parent = this;
	this.select11.setTransform(86.35,232.95,0.903,0.9056,0,0,0,59.8,33.2);

	this.select10 = new lib.select10();
	this.select10.name = "select10";
	this.select10.parent = this;
	this.select10.setTransform(520.95,162.95,0.903,0.9056,0,0,0,59.8,33.2);

	this.select9 = new lib.select9();
	this.select9.name = "select9";
	this.select9.parent = this;
	this.select9.setTransform(412.3,162.95,0.903,0.9056,0,0,0,59.9,33.2);

	this.select8 = new lib.select8();
	this.select8.name = "select8";
	this.select8.parent = this;
	this.select8.setTransform(303.7,162.95,0.903,0.9056,0,0,0,59.9,33.2);

	this.select7 = new lib.select7();
	this.select7.name = "select7";
	this.select7.parent = this;
	this.select7.setTransform(195.95,162.95,0.903,0.9056,0,0,0,60.9,33.2);

	this.select6 = new lib.select6();
	this.select6.name = "select6";
	this.select6.parent = this;
	this.select6.setTransform(87.25,162.95,0.903,0.9056,0,0,0,60.8,33.2);

	this.select5 = new lib.select5();
	this.select5.name = "select5";
	this.select5.parent = this;
	this.select5.setTransform(520.95,92.95,0.903,0.9056,0,0,0,59.8,33.2);

	this.select4 = new lib.select4();
	this.select4.name = "select4";
	this.select4.parent = this;
	this.select4.setTransform(412.3,92.95,0.903,0.9056,0,0,0,59.9,33.2);

	this.select3 = new lib.select3();
	this.select3.name = "select3";
	this.select3.parent = this;
	this.select3.setTransform(303.7,92.95,0.903,0.9056,0,0,0,59.9,33.2);

	this.select2 = new lib.select2();
	this.select2.name = "select2";
	this.select2.parent = this;
	this.select2.setTransform(195.95,92.95,0.903,0.9056,0,0,0,60.9,33.2);

	this.closeButton = new lib.closeoptions2();
	this.closeButton.name = "closeButton";
	this.closeButton.parent = this;
	this.closeButton.setTransform(565.05,42.2,0.375,0.3739,0,0,0,10,9.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D9D9D9").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape.setTransform(124.825,45.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D9D9D9").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_1.setTransform(116.375,45.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D9D9D9").s().p("AgJAvIghhcIAUAAIAXBDIAWhDIAUAAIghBcg");
	this.shape_2.setTransform(107.575,45.65);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D9D9D9").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_3.setTransform(99.075,45.65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D9D9D9").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape_4.setTransform(90.925,45.675);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D9D9D9").s().p("AgIAvIAAhNIgcAAIAAgPIBJAAIAAAPIgcAAIAABNg");
	this.shape_5.setTransform(79.075,45.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D9D9D9").s().p("AgbAkQgMgNAAgWQAAgWAMgNQAMgNASAAQARAAALAKQAGAGAEALIgTAFQgCgIgFgEQgFgEgIAAQgJAAgGAIQgHAHAAAQQAAARAHAHQAFAIAKAAQAHAAAGgEQAFgGADgKIASAGQgFAQgJAGQgKAIgPAAQgRAAgMgMg");
	this.shape_6.setTransform(70.35,45.65);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D9D9D9").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_7.setTransform(61.525,45.65);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D9D9D9").s().p("AggAuIAAhbIATAAIAABMIAuAAIAAAPg");
	this.shape_8.setTransform(53.375,45.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D9D9D9").s().p("AgiAvIAAhcIBEAAIAAAPIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_9.setTransform(44.925,45.65);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D9D9D9").s().p("AgaAoQgJgIgCgQIATgCQABAKAFAEQAFAFAIgBQAJAAAFgDQAEgEAAgFQAAgEgCgCQgCgDgFgBIgNgFQgQgDgGgFQgJgHAAgLQAAgIAFgFQAEgHAHgDQAIgDAKAAQARAAAJAHQAJAIAAANIgSABQgCgHgEgEQgDgDgIAAQgIABgEADQgEACAAADQAAAEAEACQADADAMADQAOADAHAEQAHAEADAEQAEAHAAAJQAAAHgEAIQgFAGgIAEQgJADgMAAQgQAAgKgIg");
	this.shape_10.setTransform(36.05,45.65);

	this.select1 = new lib.select1();
	this.select1.name = "select1";
	this.select1.parent = this;
	this.select1.setTransform(87.25,92.95,0.903,0.9056,0,0,0,60.8,33.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.select1},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.closeButton},{t:this.select2},{t:this.select3},{t:this.select4},{t:this.select5},{t:this.select6},{t:this.select7},{t:this.select8},{t:this.select9},{t:this.select10},{t:this.select11},{t:this.select12},{t:this.select13},{t:this.select14},{t:this.select15},{t:this.select16},{t:this.select17},{t:this.select18},{t:this.select19},{t:this.select20}]}).wait(2));

	// ramis
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#CCCCCC").ss(0.2,1,1).p("EgrAAAAMBWBAAA");
	this.shape_11.setTransform(302,55.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#CCCCCC").ss(1,1,1,3,true).p("EgrAgYHMBWBAAAIAADUMAAAAs7MhWBAAAMAAAgs7g");
	this.shape_12.setTransform(302,189.075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#3B3B3B").s().p("EgrAAWeMAAAgs7MBWBAAAMAAAAs7g");
	this.shape_13.setTransform(302,199.65);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("EgrAABqIAAjTMBWBAAAIAADTg");
	this.shape_14.setTransform(302,45.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11}]}).wait(2));

	// ena
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#262626").s().p("Egq+AYAMAAAgv/MBV9AAAMAAAAv/g");
	this.shape_15.setTransform(305.375,192.975);

	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(25.8,31.1,558,315.5);


(lib.menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var men = this;
		men.stop();
		setTimeout(stopit,10);
		
		function stopit(){
		if (backgroundSound) backgroundSound.stop();
		if (idleSound) idleSound.stop();
		if (engineSound) engineSound.stop();	
		backgroundSound = createjs.Sound.play("sakumamuzons",{interrupt: createjs.Sound.INTERRUPT_ANY, loop:-1});	
		}
		
		men.playButton.addEventListener("click", playGame);
		men.achButton.addEventListener("click", playAch);
		men.selectButton.addEventListener("click", playSelect);
		
		function playGame()
		{
			
			removeListeners();	
			Level=1;
			var levelString = "level" + 1;
			exportRoot.gotoAndStop(levelString);
			
		}
		
		function playAch()
		{
		
			removeListeners();	
			exportRoot.gotoAndStop(4);
			
		}
		
		function playSelect()
		{
		
			removeListeners();	
			exportRoot.gotoAndStop(2);
		
		}
		
		function removeListeners() {
			men.playButton.removeEventListener("click", playGame);
			men.achButton.removeEventListener("click", playAch);
			men.selectButton.removeEventListener("click", playSelect);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.achButton = new lib.achievementsbutton();
	this.achButton.name = "achButton";
	this.achButton.parent = this;
	this.achButton.setTransform(116.5,96,1,1,0,0,0,97.5,16);

	this.selectButton = new lib.selectlevelbutton();
	this.selectButton.name = "selectButton";
	this.selectButton.parent = this;
	this.selectButton.setTransform(19,40);

	this.playButton = new lib.playButton();
	this.playButton.name = "playButton";
	this.playButton.parent = this;
	this.playButton.setTransform(128,24.5,1,1,0,0,0,109,24.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.playButton},{t:this.selectButton},{t:this.achButton}]}).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(11.5,0,131,112);


(lib.AchScreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var aScreen = this;
		aScreen.stop();
		
		var achIcons;
		
		
		setTimeout(stopi,0);
		function stopi() {
		achIcons =[aScreen.a1,aScreen.a2,aScreen.a3,aScreen.a4,aScreen.a5,aScreen.a6,aScreen.a7,aScreen.a8,aScreen.a9,aScreen.a10,aScreen.a11,aScreen.a12];
			
		for (i = 0; i < achIcons.length; i++) {	
			if(achievement[i] == 1) achIcons[i].gotoAndStop(1);
			
			}
		}
		aScreen.closeButton.addEventListener("click", closeScreen);
		
		
		function closeScreen(event) {
			removeListeners();
			exportRoot.gotoAndStop(1);
		}
		
		function removeListeners() {
			aScreen.closeButton.removeEventListener("click", closeScreen);
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_1
	this.a12 = new lib.achievement12();
	this.a12.name = "a12";
	this.a12.parent = this;
	this.a12.setTransform(380.3,300.1,1,1,0,0,0,58.3,17.1);

	this.a11 = new lib.achievement11();
	this.a11.name = "a11";
	this.a11.parent = this;
	this.a11.setTransform(182.3,300.1,1,1,0,0,0,58.3,17.1);

	this.a10 = new lib.achievement10();
	this.a10.name = "a10";
	this.a10.parent = this;
	this.a10.setTransform(380.3,255.1,1,1,0,0,0,58.3,17.1);

	this.a9 = new lib.achievement9();
	this.a9.name = "a9";
	this.a9.parent = this;
	this.a9.setTransform(182.3,255.1,1,1,0,0,0,58.3,17.1);

	this.a8 = new lib.achievement8();
	this.a8.name = "a8";
	this.a8.parent = this;
	this.a8.setTransform(380.3,210.1,1,1,0,0,0,58.3,17.1);

	this.a7 = new lib.achievement7();
	this.a7.name = "a7";
	this.a7.parent = this;
	this.a7.setTransform(182.3,210.1,1,1,0,0,0,58.3,17.1);

	this.a6 = new lib.achievement6();
	this.a6.name = "a6";
	this.a6.parent = this;
	this.a6.setTransform(380.3,165.1,1,1,0,0,0,58.3,17.1);

	this.a5 = new lib.achievement5();
	this.a5.name = "a5";
	this.a5.parent = this;
	this.a5.setTransform(182.3,165.1,1,1,0,0,0,58.3,17.1);

	this.a4 = new lib.achievement4();
	this.a4.name = "a4";
	this.a4.parent = this;
	this.a4.setTransform(380.3,120.1,1,1,0,0,0,58.3,17.1);

	this.a3 = new lib.achievement3();
	this.a3.name = "a3";
	this.a3.parent = this;
	this.a3.setTransform(182.3,120.1,1,1,0,0,0,58.3,17.1);

	this.a2 = new lib.achievement2();
	this.a2.name = "a2";
	this.a2.parent = this;
	this.a2.setTransform(380.3,75.1,1,1,0,0,0,58.3,17.1);

	this.a1 = new lib.achievement1();
	this.a1.name = "a1";
	this.a1.parent = this;
	this.a1.setTransform(182.3,75.1,1,1,0,0,0,58.3,17.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D9D9D9").s().p("AgaAoQgJgIgCgQIASgCQACAKAFAEQAFAFAIgBQAJAAAFgDQAEgFAAgEQAAgEgCgCQgCgDgFgBIgNgFQgQgDgGgFQgJgHAAgLQAAgIAFgFQADgHAIgDQAIgDAKAAQARAAAJAHQAJAIAAANIgTABQgBgHgEgEQgDgDgIAAQgIABgEADQgEACAAADQAAAEAEACQADADANADQAOAEAGADQAHAEADAEQAEAHAAAJQAAAHgEAHQgFAIgIADQgJADgMAAQgQAAgKgIg");
	this.shape.setTransform(194.55,35.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D9D9D9").s().p("AgIAvIAAhNIgcAAIAAgQIBJAAIAAAQIgcAAIAABNg");
	this.shape_1.setTransform(186.325,35.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D9D9D9").s().p("AASAvIgkg8IAAA8IgSAAIAAhdIATAAIAlA9IAAg9IARAAIAABdg");
	this.shape_2.setTransform(177.6,35.65);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D9D9D9").s().p("AgiAvIAAhdIBEAAIAAAQIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_3.setTransform(168.775,35.65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D9D9D9").s().p("AAcAvIAAhJIgTBJIgRAAIgThJIAABJIgRAAIAAhdIAdAAIAPA/IARg/IAcAAIAABdg");
	this.shape_4.setTransform(158.85,35.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D9D9D9").s().p("AgiAvIAAhdIBEAAIAAAQIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_5.setTransform(149.275,35.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D9D9D9").s().p("AgJAvIghhdIAUAAIAXBEIAWhEIAUAAIghBdg");
	this.shape_6.setTransform(140.475,35.65);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D9D9D9").s().p("AgiAvIAAhdIBEAAIAAAQIgyAAIAAAVIAuAAIAAAOIguAAIAAAaIAzAAIAAAQg");
	this.shape_7.setTransform(131.975,35.65);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D9D9D9").s().p("AgIAvIAAhdIARAAIAABdg");
	this.shape_8.setTransform(125.725,35.65);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D9D9D9").s().p("AASAvIAAgpIgjAAIAAApIgTAAIAAhdIATAAIAAAlIAjAAIAAglIATAAIAABdg");
	this.shape_9.setTransform(119.175,35.65);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D9D9D9").s().p("AgbAkQgNgNAAgWQAAgXANgMQALgNATAAQARAAALAKQAGAGADALIgSAFQgCgIgFgEQgFgEgIAAQgJAAgHAIQgGAHAAAQQAAARAGAHQAHAIAJAAQAHAAAGgEQAFgGACgKIASAGQgEAQgJAGQgKAIgPAAQgSAAgLgMg");
	this.shape_10.setTransform(109.75,35.65);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D9D9D9").s().p("AAaAvIgIgWIgkAAIgIAWIgUAAIAkhdIATAAIAmBdgAgMAKIAYAAIgMgig");
	this.shape_11.setTransform(100.375,35.65);

	this.closeButton = new lib.closeoptions2();
	this.closeButton.name = "closeButton";
	this.closeButton.parent = this;
	this.closeButton.setTransform(537.05,32.2,0.375,0.3739,0,0,0,10,9.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.closeButton},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.a1},{t:this.a2},{t:this.a3},{t:this.a4},{t:this.a5},{t:this.a6},{t:this.a7},{t:this.a8},{t:this.a9},{t:this.a10},{t:this.a11},{t:this.a12}]}).wait(2));

	// ramis
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#CCCCCC").ss(0.2,1,1).p("EgjyAAAMBHlAAA");
	this.shape_12.setTransform(320.9,45.85);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#CCCCCC").ss(1,1,1,3,true).p("EgjygYHMBHlAAAIAADUMAAAAs7MhHlAAAMAAAgs7g");
	this.shape_13.setTransform(320.9,179.075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#3B3B3B").s().p("EgjxAWeMAAAgs7MBHkAAAMAAAAs7g");
	this.shape_14.setTransform(320.9,189.65);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#333333").s().p("EgjxABqIAAjTMBHkAAAIAADTg");
	this.shape_15.setTransform(320.9,35.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12}]}).wait(2));

	// ena
	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#262626").s().p("EgjwAYAMAAAgv/MBHhAAAMAAAAv/g");
	this.shape_16.setTransform(324.275,182.975);

	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(90.9,21.1,464.9,315.5);


// stage content:
(lib.html5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{first:1,level1:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		readMemory();
		
		
		stage.addEventListener("click", setFocus.bind(this));
		
		function setFocus()
		{
			window.focus();
		}
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
		startGame();
	}
	this.frame_4 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1));

	// fullscreen
	this.pButton = new lib.settings1();
	this.pButton.name = "pButton";
	this.pButton.parent = this;
	this.pButton.setTransform(-265.9,12.7,1,1,0,0,0,-265.9,12.7);
	this.pButton._off = true;

	this.timeline.addTween(cjs.Tween.get(this.pButton).wait(1).to({_off:false},0).wait(4));

	// game menu
	this.tsc = new lib.ts();
	this.tsc.name = "tsc";
	this.tsc.parent = this;

	this.scoreT = new lib.menuscore();
	this.scoreT.name = "scoreT";
	this.scoreT.parent = this;
	this.scoreT.setTransform(565,0);

	this.menuB = new lib.menu();
	this.menuB.name = "menuB";
	this.menuB.parent = this;
	this.menuB.setTransform(0,236);

	this.instance = new lib.selectlevel();
	this.instance.parent = this;
	this.instance.setTransform(286.9,123.5,1,1,0,0,0,286.9,128.4);

	this.gmenu = new lib.gmenu();
	this.gmenu.name = "gmenu";
	this.gmenu.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.menuB},{t:this.scoreT},{t:this.tsc}]},1).to({state:[{t:this.instance},{t:this.scoreT}]},1).to({state:[{t:this.gmenu}]},1).to({state:[{t:this.scoreT}]},1).wait(1));

	// Actions
	this.movieClip_2 = new lib.webgamespreloader();
	this.movieClip_2.name = "movieClip_2";
	this.movieClip_2.parent = this;

	this.ievads = new lib.ievads();
	this.ievads.name = "ievads";
	this.ievads.parent = this;
	this.ievads.setTransform(596.2,360.35,0.9359,0.9358,0,0,0,776.4,0.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F3F3F3").s().p("EhqfCMoMAAAkZPMDU/AAAMAAAEZPg");
	this.shape.setTransform(320.6,180);

	this.instance_1 = new lib.AchScreen();
	this.instance_1.parent = this;
	this.instance_1.setTransform(303.6,190.6,1,1,0,0,0,303.6,190.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.movieClip_2}]}).to({state:[{t:this.ievads}]},1).to({state:[{t:this.shape}]},1).to({state:[]},1).to({state:[{t:this.shape},{t:this.instance_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41,-699.2,1043.2,1779.2);
// library properties:
lib.properties = {
	id: '064A5EF8A526134DBB45A732B5EC511C',
	width: 640,
	height: 360,
	fps: 60,
	color: "#2B2B2B",
	opacity: 1.00,
	manifest: [
		{src:"images/_1000WebGames.png", id:"_1000WebGames"},
		{src:"images/_1000Games.png", id:"_1000Games"},
		{src:"images/_1000bulta.png", id:"_1000bulta"},
		{src:"images/acceleratePedal.png", id:"acceleratePedal"},
		{src:"images/ach1.jpg", id:"ach1"},
		{src:"images/ach10.jpg", id:"ach10"},
		{src:"images/ach11.jpg", id:"ach11"},
		{src:"images/ach12.jpg", id:"ach12"},
		{src:"images/ach2.jpg", id:"ach2"},
		{src:"images/ach3.jpg", id:"ach3"},
		{src:"images/ach4.jpg", id:"ach4"},
		{src:"images/ach5.jpg", id:"ach5"},
		{src:"images/ach6.jpg", id:"ach6"},
		{src:"images/ach7.jpg", id:"ach7"},
		{src:"images/ach8.jpg", id:"ach8"},
		{src:"images/ach9.jpg", id:"ach9"},
		{src:"images/button.png", id:"button"},
		{src:"images/check.png", id:"check"},
		{src:"images/clock.png", id:"clock"},
		{src:"images/drag.png", id:"drag"},
		{src:"images/explosion.png", id:"explosion"},
		{src:"images/icon1.jpg", id:"icon1"},
		{src:"images/icon10.jpg", id:"icon10"},
		{src:"images/icon11.jpg", id:"icon11"},
		{src:"images/icon12.jpg", id:"icon12"},
		{src:"images/icon13.jpg", id:"icon13"},
		{src:"images/icon14.jpg", id:"icon14"},
		{src:"images/icon15.jpg", id:"icon15"},
		{src:"images/icon16.jpg", id:"icon16"},
		{src:"images/icon17.jpg", id:"icon17"},
		{src:"images/icon18.jpg", id:"icon18"},
		{src:"images/icon19.jpg", id:"icon19"},
		{src:"images/icon2.jpg", id:"icon2"},
		{src:"images/icon20.jpg", id:"icon20"},
		{src:"images/icon3.jpg", id:"icon3"},
		{src:"images/icon4.jpg", id:"icon4"},
		{src:"images/icon5.jpg", id:"icon5"},
		{src:"images/icon6.jpg", id:"icon6"},
		{src:"images/icon7.jpg", id:"icon7"},
		{src:"images/icon8.jpg", id:"icon8"},
		{src:"images/icon9.jpg", id:"icon9"},
		{src:"images/mouse.png", id:"mouse"},
		{src:"images/sakums.jpg", id:"sakums"},
		{src:"images/settings.png", id:"settings"},
		{src:"images/smoke.png", id:"smoke"},
		{src:"images/smoke2.png", id:"smoke2"},
		{src:"images/smoke3.png", id:"smoke3"},
		{src:"images/star0.png", id:"star0"},
		{src:"images/star1.png", id:"star1"},
		{src:"images/star2.png", id:"star2"},
		{src:"images/star3.png", id:"star3"},
		{src:"sounds/bi.mp3", id:"bi"},
		{src:"sounds/bum.mp3", id:"bum"},
		{src:"sounds/engine.mp3", id:"engine"},
		{src:"sounds/fonamuzons.mp3", id:"fonamuzons"},
		{src:"sounds/idle.mp3", id:"idle"},
		{src:"sounds/sakumamuzons.mp3", id:"sakumamuzons"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['064A5EF8A526134DBB45A732B5EC511C'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;